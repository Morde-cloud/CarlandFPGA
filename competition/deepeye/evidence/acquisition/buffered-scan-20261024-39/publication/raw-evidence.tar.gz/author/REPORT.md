Bounded author result: capture/queue wrapper, operation 39. Main retains evaluation and acceptance.

The new stateless wrapper wires the two pinned stages with independent capture stop/rearm and queue cancellation. Queued tags survive capture rearm; queue cancellation preserves capture work. No dependencies were edited.

Actual hidden ModelSim 10.7 attempt-03 passed 3,801 cycles, 7,602 pre/post public trace records and 182,448 port comparisons. All 64 reset/stop/rearm/cancel/strobe/ready combinations were exercised. A separate direct RTL chain checks wiring; a public transaction model checks records, order, disposition and counters. The 26 saved-log parser mutations and four output guard cases were rejected.

Preserved failed attempt-01: vlib -version unsupported, exit 1, no compilation. Preserved failed attempt-02: compilation clean, vsim absolute -lib load failed with exit 12. Two bounded fix cycles used; no further vendor execution was needed. Executable metadata version fields are null; actual vlog/vsim banners and all executable hashes are recorded.

Final source SHA256:

- fpga/acquisition/deepeye_buffered_scan_capture.sv: c8a540db8122b8f5520582a0f1fa9be0c43cb54a62f03c7c4edc893906f28411
- fpga/acquisition/buffered_scan_capture_candidate.md: c36d01bb248250ff83642dc44e6d236ebaf11e623bc0e2348f41fe8e3f0c8fdd
- tests/rtl/acquisition/tb_buffered_scan_capture.sv: 53f4949732af0b913d28b0118c91f285510d020e466cb4a2f63bbab4ba5cf057
- tools/acquisition/run_buffered_scan_capture.py: 014b9a4dacfa4234d8302d7e197d7d5c272da8ef0b8ddb83a0fe214989819436

Actual invocation:

`D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe -B -X utf8 tools/acquisition/run_buffered_scan_capture.py --out evidence/acquisition/buffered-scan-20261024-39/author/attempt-03`

See RESULT.json for actual argv/cwd/PID/exits and raw trace hashes, final_source_pins.json for protected pins, and each preserved attempt's commands/ for full raw stdout/stderr.

H01-H15 and requirements c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remain fixed. Fixed 32-bit exhaustion/saturation were not reached or forced. No synthesis, timing, board, sample authenticity or system acceptance claim. All 29 formal cards remain not_run. No desktop or human-only blocker remains in this bounded task.
