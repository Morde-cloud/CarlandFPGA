onerror {quit -code 2}
onbreak {quit -code 3}
run -all
quit -code 0
