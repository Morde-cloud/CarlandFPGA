"""Freeze actual operation-39 author evidence; does not rerun vendor tools."""
import hashlib
import json
from pathlib import Path
import platform
import subprocess
import sys
from datetime import datetime, timezone

AUTHOR = Path(__file__).resolve().parent
ROOT = AUTHOR.parents[3]
WORKTREE = ROOT.parents[1]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def create(path, data):
    with path.open("x", encoding="utf-8", newline="\n") as f:
        f.write(data)

def save(path, data):
    create(path, json.dumps(data, ensure_ascii=False, indent=2) + "\n")

attempts = []
for n in range(1, 4):
    directory = AUTHOR / f"attempt-{n:02d}"
    result = json.loads((directory / "RESULT.json").read_text(encoding="utf-8"))
    attempts.append(dict(attempt=f"attempt-{n:02d}", status=result["status"], error=result.get("error"),
                         result_sha256=sha(directory / "RESULT.json"),
                         command_exits=[dict(label=r["label"], pid=r["pid"], exit_code=r["exit_code"])
                                        for r in result["commands"]]))
assert [r["status"] for r in attempts] == ["failed", "failed", "bounded_author_checks_passed"]
passed = json.loads((AUTHOR / "attempt-03/RESULT.json").read_text(encoding="utf-8"))
identity = json.loads((AUTHOR / "bootstrap/actual-runtime-identity.json").read_text(encoding="utf-8"))
assert identity["request_meta_thread_id"] == passed["canonical_agent_id"]
assert identity["execution_allowed"] is True
pins = passed["source_pins_after"]
assert passed["source_pins_before"] == pins
source_pins = {}
for rel in [
    "fpga/acquisition/deepeye_buffered_scan_capture.sv",
    "fpga/acquisition/buffered_scan_capture_candidate.md",
    "tests/rtl/acquisition/tb_buffered_scan_capture.sv",
    "tools/acquisition/run_buffered_scan_capture.py",
]:
    path = ROOT / rel
    assert sha(path) == pins[rel]
    source_pins[rel] = dict(sha256=sha(path), bytes=path.stat().st_size,
                            lines=len(path.read_text(encoding="utf-8").splitlines()))
protected = {rel: digest for rel, digest in pins.items() if rel not in source_pins}
for rel, digest in protected.items():
    path = ROOT / rel if rel != "MAIN_SPEC.md" else Path(
        "D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/buffered-scan-20261024-39/MAIN_SPEC.md")
    assert sha(path) == digest
save(AUTHOR / "final_source_pins.json", dict(product=source_pins, protected_unchanged=protected))

# These are actual read-only finalization commands. Their saved outputs carry
# host identity, the concurrent parent's HEAD and the exact owned paths.
receipts = []
si = subprocess.STARTUPINFO()
si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
si.wShowWindow = subprocess.SW_HIDE
paths = list(source_pins) + ["evidence/acquisition/buffered-scan-20261024-39/author/"]
for label, argv in [
    ("whoami", ["whoami.exe"]),
    ("head", ["git", "rev-parse", "HEAD"]),
    ("owned-status", ["git", "status", "--short", "--", *paths]),
]:
    stdout = AUTHOR / ("final-" + label + ".stdout.bin")
    stderr = AUTHOR / ("final-" + label + ".stderr.bin")
    record = dict(label=label, argv=argv, cwd=str(ROOT), started_utc=datetime.now(timezone.utc).isoformat())
    with stdout.open("xb") as output, stderr.open("xb") as error:
        process = subprocess.Popen(argv, cwd=ROOT, stdout=output, stderr=error,
                                   stdin=subprocess.DEVNULL, startupinfo=si,
                                   creationflags=subprocess.CREATE_NO_WINDOW)
        record["pid"] = process.pid
        record["exit_code"] = process.wait(timeout=30)
    record.update(stdout_sha256=sha(stdout), stderr_sha256=sha(stderr),
                  finished_utc=datetime.now(timezone.utc).isoformat())
    receipts.append(record)
    assert record["exit_code"] == 0
save(AUTHOR / "final-command-receipts.json", receipts)

result = {
    "schema": "deepeye.buffered-scan.final-author-result.v1",
    "task_id": passed["task"], "work_id": passed["work_id"], "operation_id": passed["operation_id"],
    "job_id": passed["job_id"], "actual_identity": identity,
    "status": "bounded_author_checks_passed", "acceptance": "not_authorized_main_retains",
    "main_agent_id": "01a13b55-095b-7461-8dd5-5476a130bd82",
    "source_base_commit": passed["base_commit"],
    "concurrent_parent_head_at_finish": (AUTHOR / "final-head.stdout.bin").read_text().strip(),
    "human_contract": {"ids": passed["requirements_ids"], "read_all_15": True,
                       "commit": "f5989cd5defce561f9ba98e6b18fc2682945f0a2",
                       "requirements_sha256": passed["requirements_sha256"],
                       "frozen_design": passed["frozen_design"],
                       "actual_receipts": "bootstrap/early-tool-receipts.json; attempt-03/commands/04-contract-json.stdout.bin; attempt-03/commands/05-contract-md.stdout.bin"},
    "owned_paths": paths, "source_pins": source_pins,
    "protected_inputs": protected, "protected_inputs_unchanged": True,
    "attempts": attempts, "fix_cycles_used": 2, "max_fix_cycles": 2,
    "checks": passed["checks"], "parser_negative_controls": passed["parser_negative_controls"],
    "output_guard_checks": passed["output_guard_checks"],
    "actual_tool_versions": {"vlog": "ModelSim SE-64 10.7 Compiler 2017.12 Dec 7 2017",
                             "vsim": "ModelSim SE-64 10.7 Simulator 2017.12 Dec 7 2017",
                             "vlib": "version flag unsupported (attempt-01 exit 1); executable metadata has null versions; actual executable SHA recorded"},
    "tool_executable_sha256": passed["tool_executable_sha256"],
    "successful_vendor_commands": passed["commands"],
    "raw_trace": "attempt-03/commands/13-vsim.stdout.bin",
    "raw_trace_sha256": sha(AUTHOR / "attempt-03/commands/13-vsim.stdout.bin"),
    "reference_disclosure": {
        "rtl_chain": "Separate direct unchanged capture+queue chain checks wrapper wiring only; independently controlled queue_cancel",
        "original_tb": "Base 0885ed48b9edc48be7fd20135e8c141a485218d4 tests/rtl/acquisition/tb_raw_scan_queue.sv lines 727-795",
        "original_tb_sha256": protected["tests/rtl/acquisition/tb_raw_scan_queue.sv"],
        "transaction_model": "Separate public channel-tuple and FIFO-list model; original TB informed packing/pre-edge handshakes; old stop|rearm cancellation not reused",
        "main_oracle": "not_read_not_imported",
    },
    "limits": ["Fixed 32-bit sequence exhaustion and counter saturation not reached; no internal state forced",
               "Earlier narrow-parameter dependency tests are reused prior evidence only, not newly rerun or new 32-bit proof",
               "No sample/source authenticity, sample-rate, TRACE, DMA, AXI/HWH, CDC or system-control integration claim",
               "No synthesis, implementation, timing or board execution; A alone operates the board",
               "All 29 formal cards remain not_run; identity and coverage checks are not product acceptance"],
    "formal_cards": {"count": 29, "status": "not_run"},
    "desktop_dependency": None, "human_only_dependency": None,
    "finalized_utc": datetime.now(timezone.utc).isoformat(),
    "finalizer": {"argv": sys.argv, "python_executable": sys.executable,
                  "python_version": sys.version, "platform": platform.platform()},
}
save(AUTHOR / "RESULT.json", result)
report = [
    "Bounded author result: capture/queue wrapper, operation 39. Main retains evaluation and acceptance.",
    "",
    "The new stateless wrapper wires the two pinned stages with independent capture stop/rearm and queue cancellation. Queued tags survive capture rearm; queue cancellation preserves capture work. No dependencies were edited.",
    "",
    f"Actual hidden ModelSim 10.7 attempt-03 passed {passed['checks']['cycles']:,} cycles, {passed['checks']['trace_records']:,} pre/post public trace records and {passed['checks']['all_public_output_comparisons']:,} port comparisons. All 64 reset/stop/rearm/cancel/strobe/ready combinations were exercised. A separate direct RTL chain checks wiring; a public transaction model checks records, order, disposition and counters. The {passed['parser_negative_controls']['fixtures']} saved-log parser mutations and four output guard cases were rejected.",
    "",
    "Preserved failed attempt-01: vlib -version unsupported, exit 1, no compilation. Preserved failed attempt-02: compilation clean, vsim absolute -lib load failed with exit 12. Two bounded fix cycles used; no further vendor execution was needed. Executable metadata version fields are null; actual vlog/vsim banners and all executable hashes are recorded.",
    "",
    "Final source SHA256:",
    "",
]
for path, pin in source_pins.items():
    report.append(f"- {path}: {pin['sha256']}")
report += ["", "Actual invocation:", "",
           "`D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe -B -X utf8 tools/acquisition/run_buffered_scan_capture.py --out evidence/acquisition/buffered-scan-20261024-39/author/attempt-03`",
           "", "See RESULT.json for actual argv/cwd/PID/exits and raw trace hashes, final_source_pins.json for protected pins, and each preserved attempt's commands/ for full raw stdout/stderr.",
           "", "H01-H15 and requirements c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remain fixed. Fixed 32-bit exhaustion/saturation were not reached or forced. No synthesis, timing, board, sample authenticity or system acceptance claim. All 29 formal cards remain not_run. No desktop or human-only blocker remains in this bounded task."]
create(AUTHOR / "REPORT.md", "\n".join(report) + "\n")
manifest = {p.relative_to(AUTHOR).as_posix(): dict(sha256=sha(p), bytes=p.stat().st_size)
            for p in sorted(AUTHOR.rglob("*")) if p.is_file()}
save(AUTHOR / "artifact_sha256_before_native_complete.json", manifest)
print(json.dumps({"status": result["status"], "result_sha256": sha(AUTHOR / "RESULT.json"),
                  "source_pins": source_pins, "artifacts": len(manifest),
                  "artifact_bytes": sum(p["bytes"] for p in manifest.values()),
                  "parser_negative_controls": result["parser_negative_controls"]}, indent=2))
