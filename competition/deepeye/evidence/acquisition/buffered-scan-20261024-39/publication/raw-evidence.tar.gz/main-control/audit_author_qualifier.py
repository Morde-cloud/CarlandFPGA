from pathlib import Path
import hashlib,importlib.util,json,re,sys
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/acquisition/buffered-scan-20261024-39';A=E/'author';O=E/'main/qualifier-red-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
terminal=get(D/'native-terminal.json');assert terminal['terminal'] and terminal['status']=='completed' and not terminal['stale'];tr=json.loads(terminal['result']['text']);assert sha(Path(tr['evidence']))==tr['result_sha256']
verified={}
for n,v in get(A/'artifact_sha256_before_native_complete.json').items():assert sha(A/n)==v['sha256'];verified[n]=v
author=get(A/'RESULT.json')
for n,v in author['source_pins'].items():assert sha(P/n)==v['sha256']
runner=P/'tools/acquisition/run_buffered_scan_capture.py';spec=importlib.util.spec_from_file_location('author39_checked',runner);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
base=A/'attempt-03';plan=[m.Vector(x['label'],{k:v for k,v in x.items() if k!='label'}) for x in get(base/'stimulus.json')];raw=(base/'commands/13-vsim.stdout.bin').read_bytes();score=m.parse_trace(raw,plan);assert score==get(base/'trace_checks.json')
mutations={
 'nonzero_error_footer':raw.replace(b'# Errors: 0, Warnings: 0',b'# Errors: 1, Warnings: 0'),
 'conflicting_duplicate_footer':raw+b'# Errors: 9, Warnings: 0\n',
 'truncated_after_final':raw[:raw.index(b'# ** Note: $finish')],
 'wrong_finish_location':raw.replace(b'tb_buffered_scan_capture.sv(153)',b'tb_buffered_scan_capture.sv(154)'),
 'trailing_control_byte':raw+b'\x00\n',
};probes=[]
for name,b in mutations.items():
 assert b!=raw;p=O/(name+'.stdout.bin');p.write_bytes(b)
 try:m.parse_trace(b,plan);accepted=True;error=None
 except (ValueError,AssertionError) as ex:accepted=False;error=str(ex)
 probes.append({'name':name,'accepted':accepted,'sha256':sha(p),'error':error})
(O/'runner-original.py').write_bytes(runner.read_bytes())
result={'status':'REJECTED_QUALIFIER' if any(x['accepted'] for x in probes) else 'PASS','runner_sha256':sha(runner),'positive':score,'verified_author_files':verified,'probes':probes,'scope':'Independent saved-log qualifier probes. Positive RTL/main simulation remains separately valid; this is not an RTL functional failure.'}
with (O/'RESULT.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps({'status':result['status'],'verified':len(verified),'probes':probes}))
