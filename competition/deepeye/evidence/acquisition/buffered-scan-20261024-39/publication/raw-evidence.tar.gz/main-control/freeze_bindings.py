from pathlib import Path
import json,datetime
import main_reference as m
E=m.E;old=json.loads((E/'TB_FREEZE.json').read_bytes());old.pop('source38inspected')
old.update(supersedes='TB_FREEZE.json',correction='Removed irrelevant incorrect source38inspected field; author39 source remains uninspected. No TB bytes changed.',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),vectors_sha256=m.sha(E/'vectors.json'),stimulus_sha256=m.sha(E/'stimulus.txt'),model_sha256=m.sha(E/'main_reference.py'))
with (E/'TB_FREEZE2.json').open('x',encoding='utf-8') as f:json.dump(old,f,indent=2)
print(json.dumps({'vectors_sha256':old['vectors_sha256'],'tb_sha256':old['sha256']}))
