from pathlib import Path
import hashlib,json,subprocess,sys
D=Path(__file__).parent;R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/acquisition/buffered-scan-20261024-39/main';O=E/'compiled-mutants-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
rtl=P/'fpga/acquisition/deepeye_buffered_scan_capture.sv';h=sha(rtl);assert h=='c8a540db8122b8f5520582a0f1fa9be0c43cb54a62f03c7c4edc893906f28411';source=rtl.read_text();rows=[]
changes=[('stop-flushes-queue','.cancel(queue_cancel)','.cancel(queue_cancel | stop | rearm)'),('cancel-stops-capture','.stop(stop)','.stop(stop | queue_cancel)'),('live-tag','.in_tag(capture_tag)','.in_tag(rearm_tag)'),('tick-lanes','.in_ticks(capture_ticks)','.in_ticks({capture_ticks[63:0],capture_ticks[255:64]})')]
for name,old,new in changes:
 assert source.count(old)==1;path=O/(name+'.sv');path.write_text(source.replace(old,new),encoding='utf-8');argv=[sys.executable,'-B','-X','utf8',str(D/'main_run2.py'),'--name','mutant-'+name,'--mutant',str(path)];put(O/(name+'.intent.json'),{'argv':argv,'mutation':{'old':old,'new':new},'source_sha256':h,'mutant_sha256':sha(path)})
 p=subprocess.run(argv,cwd=R,capture_output=True);(O/(name+'.stdout.bin')).write_bytes(p.stdout);(O/(name+'.stderr.bin')).write_bytes(p.stderr);put(O/(name+'.exit.json'),{'exit_code':p.returncode});assert p.returncode==0,(name,p.stderr.decode());r=json.loads((E/('mutant-'+name)/'RESULT.json').read_bytes());assert r['status']=='EXPECTED_COMPILED_REJECTION' and r['score']['first_mismatch'];rows.append({'name':name,'mutant_sha256':sha(path),'result':r})
assert sha(rtl)==h;put(O/'RESULT.json',{'actual_compiled_mutants':4,'rows':rows,'production_unchanged':True});print(json.dumps({'mutants':[{k:v for k,v in r.items() if k!='result'}|{'rejection':r['result']['score']['first_mismatch']} for r in rows],'production_unchanged':True}))
