"""Independent bounded public-behavior model, written before worker39 source inspection.
Uses the fixed main interface and inspected pinned capture/queue contracts; no B model imports.
This covers sampled simulation behavior, not exhaustive32bit counter/sequence saturation.
"""
from collections import deque
import hashlib,json,random,subprocess
from pathlib import Path
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/acquisition/buffered-scan-20261024-39/main/preinspection-01'
FIELDS=['rst','stop','rearm','queue_cancel','sample_strobe','rearm_tag','sample_channel','sample_data','sample_tick','sample_quality','out_ready']
OUTPUTS=['out_valid','out_data','out_ticks','out_quality','out_first_seq','out_last_seq','out_tag','capture_armed','capture_partial_len','capture_next_seq','capture_seq_exhausted','capture_order_error_event','capture_overrun_event','capture_seq_exhaust_event','capture_stat_events','capture_stat_scans','capture_stat_retired','capture_stat_discarded_samples','capture_stat_order_errors','capture_stat_overruns','queue_level','queue_stat_accepted','queue_stat_retired','queue_stat_aborted']
PINS={'fpga/acquisition/deepeye_sample_scan_capture.sv':'fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d','fpga/acquisition/deepeye_raw_scan_queue.sv':'630e14803d82b3379517d91626de4ad7e7d3c509ad14363b3164031a5f633ee4'}
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def sat(v):return min(v,0xffffffff)
class Model:
 def __init__(self):self.q=deque();self.qstats=[0,0,0];self.clear_capture(False,0)
 def clear_capture(self,armed,tag):self.armed=int(armed);self.tag=tag;self.partial=[];self.slot=None;self.seq=0;self.exhaust=0;self.ev=[0,0,0];self.stats=[0]*6
 def outputs(self,x):
  valid=int(bool(self.q) and not(x['rst'] or x['queue_cancel']));record=self.q[0] if self.q else [0]*6
  return [valid,*record,self.armed,len(self.partial),self.seq,self.exhaust,*self.ev,*self.stats,len(self.q),*self.qstats]
 def step(self,x):
  oldslot=self.slot;ready=not(x['rst'] or x['queue_cancel']) and len(self.q)<4
  transfer=oldslot is not None and not(x['rst'] or x['stop'] or x['rearm']) and ready
  pop=bool(self.q) and not(x['rst'] or x['queue_cancel']) and x['out_ready']
  if x['rst']:self.q.clear();self.qstats=[0,0,0]
  elif x['queue_cancel']:self.qstats[2]=sat(self.qstats[2]+len(self.q));self.q.clear()
  else:
   if pop:self.q.popleft();self.qstats[1]=sat(self.qstats[1]+1)
   if transfer:self.q.append(oldslot);self.qstats[0]=sat(self.qstats[0]+1)
  if x['rst'] or x['stop'] or x['rearm']:
   self.clear_capture(bool(x['rearm'] and not(x['rst'] or x['stop'])),x['rearm_tag'] if x['rearm'] and not(x['rst'] or x['stop']) else 0);return
  self.ev=[0,0,0]
  if transfer:self.slot=None;self.stats[2]=sat(self.stats[2]+1)
  if not(self.armed and x['sample_strobe']):return
  self.stats[0]=sat(self.stats[0]+1);ch=x['sample_channel'];point=(x['sample_data'],x['sample_tick'],x['sample_quality'],self.seq)
  if ch==len(self.partial):self.partial.append(point)
  else:
   self.ev[0]=1;self.stats[4]=sat(self.stats[4]+1);self.stats[3]=sat(self.stats[3]+len(self.partial)+(ch!=0));self.partial=[point] if ch==0 else []
  if len(self.partial)==4:
   self.stats[1]=sat(self.stats[1]+1)
   if self.slot is None:
    z=self.partial;self.slot=[sum(v[0]<<(16*i) for i,v in enumerate(z)),sum(v[1]<<(64*i) for i,v in enumerate(z)),sum(v[2]<<(8*i) for i,v in enumerate(z)),z[0][3],z[0][3]+3,self.tag]
   else:self.ev[1]=1;self.stats[5]=sat(self.stats[5]+1);self.stats[3]=sat(self.stats[3]+4)
   self.partial=[]
  if self.seq==0xffffffff:
   self.ev[2]=1;self.exhaust=1;self.armed=0;self.stats[3]=sat(self.stats[3]+len(self.partial));self.partial=[]
  else:self.seq+=1
def build():
 E.mkdir(parents=True,exist_ok=False);rows=[];tags=0;scenario=[]
 def add(**kw):
  n=len(rows);x=dict(zip(FIELDS,[0,0,0,0,0,0xa3b48712,0,(n*317+0x7259)&65535,(0xf123abcd98760000+n*0x10203)&((1<<64)-1),(n*79+3)&255,0]));x.update(kw);rows.append(x)
 def scan():
  for c in range(4):add(sample_strobe=1,sample_channel=c)
 def prep(phase):
  add(rst=1);add(rearm=1,rearm_tag=(0x90000000+len(rows)))
  for _ in range([0,0,0,1,4,5,5][phase]):scan();add()
  for c in range([0,1,3,0,0,0,2][phase]):add(sample_strobe=1,sample_channel=c)
 for phase in range(7):
  for ctrl in range(16):
   for ready in range(2):
    prep(phase);at=len(rows);add(rst=ctrl&1,stop=(ctrl>>1)&1,rearm=(ctrl>>2)&1,queue_cancel=(ctrl>>3)&1,out_ready=ready,sample_strobe=1,sample_channel=2,rearm_tag=0x125689ab);scenario.append({'cycle':at,'phase':phase,'control':ctrl,'ready':ready})
    for _ in range(8):add(out_ready=1)
    add(rearm=1,rearm_tag=0xe1239876);scan()
    for _ in range(8):add(out_ready=1)
 add(rst=1);add(rearm=1)
 # Long bursts ensure queue backpressure and overrun, distinct sequence/records and recovery.
 for k in range(100):
  scan()
  if k%9==0:add(queue_cancel=1,sample_strobe=1,sample_channel=0)
  for _ in range(k%5):add(out_ready=(k%3==0))
 rng=random.Random(0xB0392026)
 for n in range(5000):
  add(rst=int(n%401==0),stop=int(rng.randrange(211)==0),rearm=int(rng.randrange(53)==0),queue_cancel=int(rng.randrange(97)==0),rearm_tag=rng.getrandbits(32),sample_strobe=int(rng.randrange(5)!=0),sample_channel=rng.randrange(4),sample_data=rng.getrandbits(16),sample_tick=rng.getrandbits(64),sample_quality=rng.getrandbits(8),out_ready=int(rng.randrange(3)==0))
 add(rst=1);add(rearm=1,rearm_tag=0x123abcde);scan()
 for _ in range(12):add(out_ready=1)
 for path,h in PINS.items():assert sha(P/path)==h
 contract=json.loads(subprocess.check_output(['git','-C',str(W),'show','f5989cd5defce561f9ba98e6b18fc2682945f0a2:docs/competition/deepeye-2026/immutable_scope.json']));h=hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
 (E/'main_reference.py').write_bytes(Path(__file__).read_bytes());(E/'stimulus.txt').write_text(''.join(' '.join(format(x[k],'x') for k in FIELDS)+'\n' for x in rows),encoding='ascii')
 model=Model();expected=[]
 for i,x in enumerate(rows):
  pre=model.outputs(x);model.step(x);post=model.outputs(x);expected.append({'cycle':i,'pre':pre,'post':post})
 for name,obj in [('vectors.json',{'fields':FIELDS,'outputs':OUTPUTS,'rows':rows,'scenarios':scenario,'expected':expected}),('FREEZE.json',{'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-BUFFERED-SCAN-MAIN-REFERENCE-20261024-39-v1','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','requirements_sha256':h,'author39_source_inspected':False,'pins':PINS,'main_spec_sha256':sha(D/'MAIN_SPEC.md'),'model_sha256':sha(E/'main_reference.py'),'stimulus_sha256':sha(E/'stimulus.txt'),'cycles':len(rows),'directed_control_cases':len(scenario),'scope':'Independent deque/sample-history model after inspecting unchanged dependencies and fixedspec; no author39 code/model imported; no32bit saturation/exhaustive proof.'})]:
  with (E/name).open('x',encoding='utf-8') as f:json.dump(obj,f,indent=2)
 print(json.dumps({'cycles':len(rows),'control_cases':len(scenario),'reference_sha256':sha(E/'main_reference.py')}))
if __name__=='__main__':build()
