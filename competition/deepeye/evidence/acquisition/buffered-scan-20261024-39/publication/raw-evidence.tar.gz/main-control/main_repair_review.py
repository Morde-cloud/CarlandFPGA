from pathlib import Path
import ast,datetime,hashlib,importlib.util,json,os,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent
E=P/'evidence/acquisition/buffered-scan-20261024-39';Q=E/'qualification-repair1';O=E/'main/qualifier-review-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def save(name,value):(O/name).write_text(json.dumps(value,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
started=datetime.datetime.now(datetime.timezone.utc).isoformat()
result={'status':'RUNNING','pid':os.getpid(),'argv':sys.argv,'started_utc':started,'work_id':'B-BUFFERED-SCAN-QUALIFIER-MAIN-20261024-v1','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82'}
save('RESULT.json',result)
try:
 contract=json.loads(subprocess.check_output(['git','-C',str(R),'show','f5989cd5defce561f9ba98e6b18fc2682945f0a2:docs/competition/deepeye-2026/immutable_scope.json']))
 h=hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()
 assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
 term=get(D/'repair1-native-terminal.json')[0];assert term['terminal'] and term['status']=='completed' and not term['stale']
 tr=json.loads(term['result']['text']);assert sha(Path(tr['evidence']))==tr['result_sha256']
 verified={}
 for name,value in get(Q/'artifact_sha256_before_native_complete.json').items():
  p=Q/name;assert sha(p)==value['sha256'] and p.stat().st_size==value['bytes'],name;verified[name]=value
 protected=get(Q/'protected_before.json');assert protected==get(Q/'protected_after.json')
 for name,value in protected.items():assert sha(Path(name))==value['sha256'],name
 runner=P/'tools/acquisition/run_buffered_scan_capture.py';assert sha(runner)==tr['new_runner_sha256']=='f5a9aa7e1d9d93d9147a1d84fba43c75dc1688c30cf3246dd2aa9b90e18d350d'
 old=E/'main/qualifier-red-01/runner-original.py'
 def nodes(p):return {getattr(x,'name','node-'+str(i)):ast.dump(x,include_attributes=False) for i,x in enumerate(ast.parse(p.read_bytes()).body)}
 a,b=nodes(old),nodes(runner);assert a.keys()==b.keys();changed=[n for n in a if a[n]!=b[n]];assert set(changed)=={'parse_trace','negative_controls','main'},changed
 spec=importlib.util.spec_from_file_location('main39_checked_repair',runner);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
 base=E/'author/attempt-03';raw=(base/'commands/13-vsim.stdout.bin').read_bytes();assert hashlib.sha256(raw).hexdigest()==tr['saved_raw_sha256']
 plan=[m.Vector(x['label'],{k:v for k,v in x.items() if k!='label'}) for x in get(base/'stimulus.json')]
 score=m.parse_trace(raw,plan);before=get(base/'trace_checks.json');assert {k:v for k,v in score.items() if k!='simulator_termination'}==before
 rows=[]
 for c in get(Q/'RESULT.json')['cases']:
  p=Path(c['path']);assert sha(p)==c['sha256'];kw={} if c['declared_finish_source']=='default_pinned_attempt03' else {'finish_source':c['declared_finish_source']}
  try:m.parse_trace(p.read_bytes(),plan,**kw);actual='pass';error=None
  except (ValueError,AssertionError) as ex:actual='reject';error=str(ex)
  rows.append({'name':c['name'],'expected':c['expected'],'actual':actual,'sha256':sha(p),'error':error})
 assert len(rows)==93 and all(x['expected']==x['actual'] for x in rows)
 # New main-derived probes operate on actual saved bytes, not a fabricated pass log.
 rawlf=raw.replace(b'\r\n',b'\n');lines=rawlf.splitlines(keepends=True)
 i=next(i for i,x in enumerate(lines) if x.startswith(b'# ** Note: $finish'))
 probes={}
 for n in range(6):
  probes['missing_footer_%d'%n]=b''.join(lines[:i+n]+lines[i+n+1:])
  probes['duplicate_footer_%d'%n]=b''.join(lines[:i+n+1]+[lines[i+n]]+lines[i+n+1:])
 probes.update({
  'warn_nonzero':rawlf.replace(b'Errors: 0, Warnings: 0',b'Errors: 0, Warnings: 1'),
  'negative_errors':rawlf.replace(b'Errors: 0, Warnings: 0',b'Errors: -1, Warnings: 0'),
  'time_microseconds':rawlf.replace(b'Time: 38016 ns',b'Time: 38016 us'),
  'different_instance':rawlf.replace(b'Instance: /tb_buffered_scan_capture',b'Instance: /forged/tb_buffered_scan_capture'),
  'elapsed_mismatch':rawlf.replace(b'Elapsed time: 0:00:03',b'Elapsed time: 0:00:04'),
  'finish_case_change':rawlf.replace(b'# ** Note: $finish',b'# ** Note: $FINISH'),
  'footer_suffix':rawlf.replace(b'Errors: 0, Warnings: 0\n',b'Errors: 0, Warnings: 0 extra\n'),
  'embedded_unicode_separator':rawlf.replace(b'# SCAN_FINAL',b'\xe2\x80\xa8# SCAN_FINAL'),
  'leading_terminal_zero':b'# Errors: 0, Warnings: 0\n'+rawlf,
  'premature_finish':lines[i]+rawlf,
  'summary_swapped':b''.join(lines[:i+4]+[lines[i+5],lines[i+4]]),
 })
 independent=[];(O/'negative-fixtures').mkdir()
 for name,data in probes.items():
  assert data!=rawlf;p=O/'negative-fixtures'/(name+'.stdout.bin');p.write_bytes(data)
  try:m.parse_trace(data,plan);accepted=True;error=None
  except (ValueError,AssertionError) as ex:accepted=False;error=str(ex)
  independent.append({'name':name,'accepted':accepted,'sha256':sha(p),'error':error})
 assert not any(x['accepted'] for x in independent),[x for x in independent if x['accepted']]
 assert m.parse_trace(rawlf,plan)['simulator_termination']['line_endings']=='LF'
 assert sha(runner)==tr['new_runner_sha256']
 for name,value in protected.items():assert sha(Path(name))==value['sha256'],name
 save('REPLAYED_CASES.json',rows);save('INDEPENDENT_NEGATIVES.json',independent);save('VERIFIED_REPAIR_ARTIFACTS.json',verified)
 prior=get(E/'main/software-review-01/RESULT.json');assert prior['status']=='RTL_BOUNDED_SOFTWARE_CHECKS_PASS_RUNNER_QUALIFICATION_REJECTED'
 result.update(status='PASS_BOUNDED_RTL_AND_REPAIRED_QUALIFIER',requirements_sha256=h,requirements_ids=['H%02d'%i for i in range(1,16)],replayed_saved_cases=len(rows),new_independent_negatives=len(independent),extra_lf_positive=True,protected_unchanged=len(protected),repair_artifacts_rehashed=len(verified),changed_functions=changed,runner_sha256=sha(runner),source_tb_unchanged=True,prior_main_software_review_sha256=sha(E/'main/software-review-01/RESULT.json'),positive=score,terminal_binding={k:term[k] for k in ('job_id','native_agent_id','status','terminal','stale','updated_at')},scope='Checker qualification against saved ModelSim10.7 bytes only; original main independent RTL 13600cycles/523218port checks/4compiled mutants retained. No new vendor rerun; source/snapshot paths must be explicitly supplied when moved. Not arbitrary transcript provenance authentication.',formal_cards='all29not_run',limits='No39synthesis/implementation/timingclosure/CDC_RDC/board/system. Fixed32bit sequence/saturation limits not reached. A-onlyphysicalboard.')
except Exception as ex:
 result.update(status='REJECTED_OR_FAILED',error=repr(ex));raise
finally:
 result['finished_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();save('RESULT.json',result)
 print(json.dumps({k:v for k,v in result.items() if k in ('status','error','replayed_saved_cases','new_independent_negatives','protected_unchanged','repair_artifacts_rehashed')}))
