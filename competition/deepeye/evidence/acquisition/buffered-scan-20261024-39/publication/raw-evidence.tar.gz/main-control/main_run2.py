from pathlib import Path
import argparse,datetime,hashlib,json,re,subprocess,time
import main_reference as m
P=m.P;D=Path(__file__).parent;E=m.E.parent
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def command(out,name,argv):
 argv=list(map(str,argv));put(out/(name+'.intent.json'),{'argv':argv,'cwd':str(out),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});t=time.monotonic();p=subprocess.Popen(argv,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(out/(name+'.started.json'),{'pid':p.pid});timed=False
 try:b,e=p.communicate(timeout=90)
 except subprocess.TimeoutExpired:timed=True;p.kill();b,e=p.communicate()
 (out/(name+'.stdout.bin')).write_bytes(b);(out/(name+'.stderr.bin')).write_bytes(e);put(out/(name+'.command.json'),{'argv':argv,'pid':p.pid,'exit_code':p.returncode,'timeout':timed,'elapsed':time.monotonic()-t,'stdout_sha256':m.sha(out/(name+'.stdout.bin')),'stderr_sha256':m.sha(out/(name+'.stderr.bin'))});assert p.returncode==0 and not timed;return b.decode()+e.decode()
def score(out):
 vectors=get(out/'inputs/vectors.json');freeze=get(out/'inputs/TB_FREEZE2.json');widths=freeze['output_fields'];lines=(out/'trace.txt').read_text().splitlines();assert len(lines)==2*len(vectors['expected']);comparisons=0;transfers=0;first=None
 for i,line in enumerate(lines):
  a=line.split();phase='P' if i%2==0 else 'Q';cycle=i//2;assert len(a)==26 and a[0]==phase and int(a[1])==cycle
  expected=vectors['expected'][cycle]['pre' if phase=='P' else 'post'];assert len(expected)==24
  for j,(name,bits) in enumerate(widths.items()):
   v=a[j+2];assert re.fullmatch('[0-9a-fxXzZ]{'+str((bits+3)//4)+'}',v)
   if 1<=j<=6 and not expected[0]:continue
   comparisons+=1
   if re.search('[xXzZ]',v) or int(v,16)!=expected[j]:
    if first is None:first={'cycle':cycle,'phase':phase,'port':name,'expected':hex(expected[j]),'actual':v}
  if phase=='P' and expected[0] and vectors['rows'][cycle]['out_ready']:transfers+=1
 return {'cycles':len(vectors['expected']),'trace_rows':len(lines),'public_comparisons':comparisons,'record_retirements':transfers,'first_mismatch':first}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--name',required=True);ap.add_argument('--mutant',type=Path);a=ap.parse_args();assert re.fullmatch('[a-zA-Z0-9_-]+',a.name);out=E/a.name;out.mkdir(exist_ok=False);snap=out/'inputs';snap.mkdir();freeze=get(m.E/'FREEZE.json');tbf=get(m.E/'TB_FREEZE2.json')
 assert m.sha(m.E/'main_reference.py')==freeze['model_sha256'] and m.sha(m.E/'stimulus.txt')==freeze['stimulus_sha256'];assert m.sha(Path(tbf['source']))==tbf['sha256'] and m.sha(m.E/'vectors.json')==tbf['vectors_sha256']
 for n,h in freeze['pins'].items():assert m.sha(P/n)==h;(snap/Path(n).name).write_bytes((P/n).read_bytes())
 rtl=a.mutant or P/'fpga/acquisition/deepeye_buffered_scan_capture.sv';(snap/'deepeye_buffered_scan_capture.sv').write_bytes(rtl.read_bytes())
 for p in [Path(tbf['source']),m.E/'main_reference.py',m.E/'stimulus.txt',m.E/'vectors.json',m.E/'TB_FREEZE2.json',Path(__file__)]: (snap/p.name).write_bytes(p.read_bytes())
 put(out/'INPUTS.json',{p.name:{'sha256':m.sha(p),'bytes':p.stat().st_size} for p in snap.iterdir()});result={'status':'RUNNING','mutant':bool(a.mutant)}
 try:
  tool=Path('D:/modelsim1/win64');command(out,'version',[tool/'vsim.exe','-version']);command(out,'vlib',[tool/'vlib.exe','lib']);compilelog=command(out,'vlog',[tool/'vlog.exe','-sv','-work','lib',snap/'deepeye_sample_scan_capture.sv',snap/'deepeye_raw_scan_queue.sv',snap/'deepeye_buffered_scan_capture.sv',snap/'main_tb_buffered_scan_capture.sv']).replace('\r\n','\n');assert re.findall(r'^Errors: (\d+), Warnings: (\d+)$',compilelog,re.M)==[('0','0')]
  raw=command(out,'vsim',[tool/'vsim.exe','-c','-work','lib','-l',out/'transcript.txt','-wlf',out/'sim.wlf','-do','run -all; quit -f','main_buffered_scan_capture','+VECTORS='+str(snap/'stimulus.txt'),'+TRACE='+str(out/'trace.txt')]).replace('\r\n','\n');assert re.findall(r'^# MAIN39_DONE cycles=(\d+)$',raw,re.M)==[str(freeze['cycles'])] and len([s for s in raw.splitlines() if 'MAIN39_DONE' in s])==1;assert re.findall(r'^# Errors: (\d+), Warnings: (\d+)$',raw,re.M)==[('0','0')] and not re.search(r'\*\* (Error|Warning|Fatal)',raw)
  v=score(out);assert bool(v['first_mismatch'])==bool(a.mutant),v;result.update(status='EXPECTED_COMPILED_REJECTION' if a.mutant else 'PASS',score=v,trace_sha256=m.sha(out/'trace.txt'),rtl_sha256=m.sha(rtl),tb_sha256=tbf['sha256'],commands=4)
 except Exception as ex:result.update(status='FAILED',error=repr(ex));raise
 finally:put(out/'RESULT.json',result);print(json.dumps(result))
if __name__=='__main__':main()
