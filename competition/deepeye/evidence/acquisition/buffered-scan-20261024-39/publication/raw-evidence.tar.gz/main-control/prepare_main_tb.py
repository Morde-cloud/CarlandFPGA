from pathlib import Path
import hashlib,json
import main_reference as m
P=m.P;E=m.E
inputs=dict(zip(m.FIELDS,[1,1,1,1,1,32,2,16,64,8,1]));outputs=dict(zip(m.OUTPUTS,[1,64,256,32,32,32,32,1,3,32,1,1,1,1,32,32,32,32,32,32,3,32,32,32]));p=P/'tests/rtl/acquisition/main_tb_buffered_scan_capture.sv'
assert not p.exists()
decl=lambda n,w:f'logic {"" if w==1 else "["+str(w-1)+":0] "}{n};'
s='`timescale 1ns/1ps\nmodule main_buffered_scan_capture;\nlogic clk=0; always #5 clk=~clk;\n'+'\n'.join(decl(n,w) for n,w in (inputs|outputs).items())+'\ndeepeye_buffered_scan_capture dut(.*);\ninteger vf,tf,rc,cycle;string vp,tp;\n'
s+='task dump(input string phase);begin\n$fwrite(tf,"%s %0d '+ ' '.join(['%h']*len(outputs))+'\\n",phase,cycle,'+','.join(outputs)+');\nend endtask\ninitial begin\n'
s+='\n'.join(n+'=0;' for n in inputs)+'\nrst=1;cycle=0;\nif(!$value$plusargs("VECTORS=%s",vp)||!$value$plusargs("TRACE=%s",tp))$fatal(1,"ARGS");\nvf=$fopen(vp,"r");tf=$fopen(tp,"w");if(!vf||!tf)$fatal(1,"FILES");\n'
s+='while(!$feof(vf))begin\n@(negedge clk);rc=$fscanf(vf,"'+' '.join(['%h']*len(inputs))+'\\n",'+','.join(inputs)+');\nif(rc!='+str(len(inputs))+')$fatal(1,"VECTOR");\n#1;dump("P");@(posedge clk);#1;dump("Q");cycle=cycle+1;\nend\n$fclose(vf);$fclose(tf);$display("MAIN39_DONE cycles=%0d",cycle);$finish;\nend\nendmodule\n'
p.write_text(s,encoding='ascii');(E/p.name).write_bytes(p.read_bytes())
with (E/'TB_FREEZE.json').open('x',encoding='utf-8') as f:json.dump({'source':str(p),'sha256':m.sha(p),'input_fields':inputs,'output_fields':outputs,'source38inspected':False,'author39_source_inspected':False,'method':'Public raw preedge and postedge outputs; independent Python deque/sample-history expectation. Invalid queue payloads preserved but excluded from value comparison.'},f,indent=2)
print(json.dumps({'tb_sha256':m.sha(p),'ports':len(outputs)}))
