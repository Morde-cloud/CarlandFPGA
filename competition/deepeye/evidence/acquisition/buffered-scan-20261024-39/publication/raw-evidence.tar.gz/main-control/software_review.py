from pathlib import Path
import datetime,hashlib,json
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/acquisition/buffered-scan-20261024-39';M=E/'main';O=M/'software-review-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
terminal=get(D/'native-terminal.json');tr=json.loads(terminal['result']['text']);assert terminal['terminal'] and not terminal['stale'] and sha(Path(tr['evidence']))==tr['result_sha256']
positive=get(M/'positive-02/RESULT.json');mutants=get(M/'compiled-mutants-01/RESULT.json');assert positive['status']=='PASS' and positive['score']['first_mismatch'] is None and mutants['actual_compiled_mutants']==4
assert sha(P/'fpga/acquisition/deepeye_buffered_scan_capture.sv')==positive['rtl_sha256']==tr['source_pins']['fpga/acquisition/deepeye_buffered_scan_capture.sv']['sha256']
commands=[];files={}
for name in ['positive-01','positive-02']+['mutant-'+x['name'] for x in mutants['rows']]:
 base=M/name;out=get(base/'RESULT.json')
 for cp in sorted(base.glob('*.command.json')):
  c=get(cp);assert c['pid']>0 and c['exit_code']==0 and not c['timeout']
  for stream in ('stdout','stderr'):assert sha(base/(cp.name.removesuffix('.command.json')+'.'+stream+'.bin'))==c[stream+'_sha256']
  commands.append({'path':cp.relative_to(E).as_posix(),'sha256':sha(cp),'exit_code':c['exit_code']})
 if name!='positive-01':assert sha(base/'trace.txt')==out['trace_sha256'] and out['commands']==4
 for p in base.rglob('*'):
  if p.is_file() and not any(n in ('lib','work','__pycache__') for n in p.relative_to(base).parts) and p.suffix.lower()!='.wlf':files[p.relative_to(E).as_posix()]={'sha256':sha(p),'bytes':p.stat().st_size}
assert len(commands)==23 and get(M/'positive-01/RESULT.json')['status']=='FAILED'
assert [(x['result']['score']['first_mismatch']['cycle'],x['result']['score']['first_mismatch']['port']) for x in mutants['rows']]==[(2555,'out_valid'),(386,'capture_armed'),(16,'out_tag'),(16,'out_ticks')]
result={'status':'RTL_BOUNDED_SOFTWARE_CHECKS_PASS_RUNNER_QUALIFICATION_REJECTED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'operation_id':'B-DEEPEYE-BUFFERED-SCAN-CAPTURE-20261024-39','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','requirements_sha256':get(M/'preinspection-01/FREEZE.json')['requirements_sha256'],'main_positive':positive,'compiled_mutants':mutants,'commands':commands,'verified_main_artifacts':files,'author_terminal':{k:terminal[k] for k in ('job_id','native_agent_id','status','terminal','stale','updated_at')},'source_review':['Thin86line stateless instantiation only; fixed constants and independent controls match main specification.','All six records and diagnostics directly wired; no new arithmetic/state/domain/provenance claim.','Main deque/sample-history oracle was frozen before worker39 source inspection; inspected existing stage RTL/spec disclosed.','First main attempt compiled successfully but stopped on CRLF summary-parser assumption before vsim. Corrected main_run2 and new positive02 retained original;5actualsimulations+initial3commandattempt=23commands.'],'runner_rejection':{'evidence':'main/qualifier-red-01/RESULT.json','false_accepts':5,'repair_job':'child-9e993043aced46a8aa0019b784d969ee','status':'new_explicit_saved_log_repair_dispatched'},'limits':'No final39handoff acceptance until checker repair/main review. Fixed32bit saturation/exhaustion not reached. No39synthesis/implementation/timing/CDC_RDC/board/system. All29formal not_run, A-onlyboard.'}
with (O/'RESULT.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
print(json.dumps({'status':result['status'],'main_commands':23,'main_artifacts':len(files)}))
