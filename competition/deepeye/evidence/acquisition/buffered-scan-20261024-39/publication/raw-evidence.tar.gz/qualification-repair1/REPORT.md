Checker-only repair1 completed; main retains independent review and acceptance.

parse_trace now requires a complete, unique ordered ModelSim 10.7 termination envelope: Start, SCAN records and completion, pinned $finish source/line, finish time/instance, Break/Stopped locations, End with consistent elapsed time, and exact Errors: 0, Warnings: 0. Duplicate, missing, conflicting or trailing data is rejected. Existing public trace/model/statistics checks are preserved.

The expected finish line is derived from pinned TB bytes (line 153), not the log. Both current TB and declared compile-input snapshot must match the fixed TB SHA. The actual saved run ends at 38016 ns in /tb_buffered_scan_capture. Strict UTF-8 and consistently CRLF or LF are supported; malformed line endings, NUL and forbidden controls/separators are rejected.

One saved-file Python verification pass: 93/93 matched (4 positive, 89 negative). This includes the actual saved positive, LF/CRLF normalization, an explicitly declared UTF-8 source-path derivation, all 26 original negatives, all five main-red fixtures, and targeted footer/source/time/text cases. The frozen original checker again accepted the five main-red fixtures. All 247 original evidence/dependency files rehashed identically before and after.

Original actual ModelSim execution remains under the old runner. This repair ran no vendor tool, RTL simulation, synthesis, implementation or board operation. Original author/main records and all RTL/TB/notes remain unchanged.

Runtime assumptions: default parse_trace provenance explicitly names the retained local author/attempt-03 compile-input TB snapshot. Future runner calls pass their actual retained compile-input snapshot path through finish_source. Both local source files must exist and match the pinned bytes. Relocated saved logs must retain or explicitly declare their matching source provenance; the parser never trusts a path/line supplied by the transcript. The supported footer is the observed local ModelSim 10.7 grammar.

Old runner SHA256: 014b9a4dacfa4234d8302d7e197d7d5c272da8ef0b8ddb83a0fe214989819436
New runner SHA256: f5a9aa7e1d9d93d9147a1d84fba43c75dc1688c30cf3246dd2aa9b90e18d350d
Pinned TB SHA256: 53f4949732af0b913d28b0118c91f285510d020e466cb4a2f63bbab4ba5cf057
Saved vsim raw SHA256: d767fe2271b3014326ce5080fb0cf09bad5b789a3ab990ed996eba2a582ea7b9

Actual command: D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe -B -X utf8 D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/buffered-scan-20261024-39/qualification-repair1/verify_saved_logs.py verify
Actual verification PID 33912, exit 0. Full raw stdout/stderr and command receipt are saved as verify.*. Exact code diff: runner-exact.diff. Individual fixture hashes/errors are in RESULT.json; original malformed logs are referenced at their unchanged paths.

H01-H15 retained at f5989cd5defce561f9ba98e6b18fc2682945f0a2, requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804; frozen design 1011259415a0916054eb580687612580bc1e5f09. All 29 formal cards remain not_run; A alone operates the board. Main has not yet accepted/published this repaired source.
