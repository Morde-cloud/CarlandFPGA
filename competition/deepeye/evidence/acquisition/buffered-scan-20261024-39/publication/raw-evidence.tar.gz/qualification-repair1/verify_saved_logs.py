"""Single bounded saved-file qualification pass; no vendor tools are invoked."""
import argparse
from datetime import datetime, timezone
import difflib
import hashlib
import importlib.util
import json
from pathlib import Path
import platform
import sys
import traceback

OUT = Path(__file__).resolve().parent
ROOT = OUT.parents[3]
EVIDENCE = OUT.parent
AUTHOR = EVIDENCE / "author"
RED = EVIDENCE / "main/qualifier-red-01"
RUNNER = ROOT / "tools/acquisition/run_buffered_scan_capture.py"
TB_REL = "tests/rtl/acquisition/tb_buffered_scan_capture.sv"
TB = ROOT / TB_REL
FINISH_SOURCE = AUTHOR / "attempt-03/inputs" / TB_REL
RAW = AUTHOR / "attempt-03/commands/13-vsim.stdout.bin"
OLD_SHA = "014b9a4dacfa4234d8302d7e197d7d5c272da8ef0b8ddb83a0fe214989819436"
TB_SHA = "53f4949732af0b913d28b0118c91f285510d020e466cb4a2f63bbab4ba5cf057"
RAW_SHA = "d767fe2271b3014326ce5080fb0cf09bad5b789a3ab990ed996eba2a582ea7b9"
REQ_SHA = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
SPEC = Path("D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/buffered-scan-20261024-39/QUALIFIER_REPAIR1.md")

def digest(data):
    return hashlib.sha256(data).hexdigest()

def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as file:
        file.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def pin(path):
    data = path.read_bytes()
    return {"sha256": digest(data), "bytes": len(data)}

def inventory():
    files = list(AUTHOR.rglob("*")) + list(RED.iterdir())
    files += [ROOT / rel for rel in [
        "fpga/acquisition/deepeye_buffered_scan_capture.sv",
        "fpga/acquisition/buffered_scan_capture_candidate.md", TB_REL,
        "fpga/acquisition/deepeye_sample_scan_capture.sv",
        "fpga/acquisition/deepeye_raw_scan_queue.sv",
        "tests/rtl/acquisition/tb_raw_scan_queue.sv",
    ]]
    return {str(p.resolve()): pin(p) for p in sorted(set(files)) if p.is_file()}

def prepare():
    assert digest(RUNNER.read_bytes()) == OLD_SHA
    assert digest((RED / "runner-original.py").read_bytes()) == OLD_SHA
    assert digest(TB.read_bytes()) == digest(FINISH_SOURCE.read_bytes()) == TB_SHA
    assert digest(RAW.read_bytes()) == RAW_SHA
    main = json.loads((RED / "RESULT.json").read_text(encoding="utf-8"))
    for rel, expected in main["verified_author_files"].items():
        assert pin(AUTHOR / rel) == expected, rel
    assert len(main["probes"]) == 5 and all(row["accepted"] for row in main["probes"])
    for row in main["probes"]:
        assert digest((RED / (row["name"] + ".stdout.bin")).read_bytes()) == row["sha256"]
    original_negatives = json.loads((AUTHOR / "attempt-03/parser-negative-controls/RESULT.json").read_text())
    assert len(original_negatives) == 26
    for row in original_negatives:
        assert digest((AUTHOR / "attempt-03/parser-negative-controls" / (row["name"] + ".stdout.bin")).read_bytes()) == row["sha256"]
    contract = json.loads((AUTHOR / "attempt-03/inputs/immutable_scope.json").read_text(encoding="utf-8"))
    requirements_hash = digest(json.dumps(contract["requirements"], ensure_ascii=False,
                                         sort_keys=True, separators=(",", ":")).encode())
    assert requirements_hash == REQ_SHA and [r["id"] for r in contract["requirements"]] == [f"H{n:02d}" for n in range(1, 16)]
    for name, source in [("runner-original.py", RUNNER), ("testbench-pinned.sv", TB),
                         ("QUALIFIER_REPAIR1.md", SPEC), ("immutable_scope.json", AUTHOR / "attempt-03/inputs/immutable_scope.json")]:
        with (OUT / "inputs" / name).open("xb") as file:
            file.write(source.read_bytes())
    before = inventory()
    save(OUT / "protected_before.json", before)
    save(OUT / "PREPARE.json", {"status": "snapshot_prepared_no_checker_test_yet", "old_runner_sha256": OLD_SHA,
         "tested_tb_sha256": TB_SHA, "saved_vsim_raw_sha256": RAW_SHA,
         "requirements_ids": [f"H{n:02d}" for n in range(1, 16)], "requirements_sha256": requirements_hash,
         "protected_files": len(before), "main_record_rehashed_author_files": len(main["verified_author_files"]),
         "original_negative_fixtures": 26, "main_red_fixtures": 5,
         "spec_sha256": digest(SPEC.read_bytes()), "argv": sys.argv, "python": sys.version,
         "prepared_utc": datetime.now(timezone.utc).isoformat()})
    print(json.dumps({"stage": "prepare", "status": "prepared", "protected_files": len(before)}))

def load_module(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module

def verify():
    result = {"schema": "deepeye.buffered-scan.qualifier-repair1.v1", "status": "running",
        "task_id": "DEEPEYE-IMPLEMENTATION-20261014/v1",
        "work_id": "B-BUFFERED-SCAN-QUALIFIER-REPAIR1-20261024-v1",
        "canonical_agent_id": "01a16a27-3458-7103-a4ab-cd06fd084da7",
        "job_id": "child-9e993043aced46a8aa0019b784d969ee",
        "parent_main": "01a13b55-095b-7461-8dd5-5476a130bd82",
        "requirements_ids": [f"H{n:02d}" for n in range(1, 16)], "requirements_sha256": REQ_SHA,
        "contract_commit": "f5989cd5defce561f9ba98e6b18fc2682945f0a2",
        "frozen_design": "1011259415a0916054eb580687612580bc1e5f09",
        "old_runner_sha256": OLD_SHA, "new_runner_sha256": digest(RUNNER.read_bytes()),
        "tested_tb_sha256": TB_SHA, "raw_vsim_sha256": RAW_SHA,
        "started_utc": datetime.now(timezone.utc).isoformat(), "argv": sys.argv,
        "python_executable": sys.executable, "python_version": sys.version, "platform": platform.platform(),
        "vendor_execution": "not_run_saved_bytes_only", "formal_cards": {"count": 29, "status": "not_run"},
        "main_acceptance": "pending_main_retains", "cases": []}
    try:
        prepared = json.loads((OUT / "PREPARE.json").read_text())
        assert prepared["old_runner_sha256"] == OLD_SHA
        assert result["new_runner_sha256"] != OLD_SHA
        assert digest(TB.read_bytes()) == TB_SHA
        assert digest(RAW.read_bytes()) == RAW_SHA
        original = load_module(OUT / "inputs/runner-original.py", "scan39_original_qualifier")
        repaired = load_module(RUNNER, "scan39_repaired_qualifier")
        plan = repaired.make_plan()
        saved_vectors = json.loads((AUTHOR / "attempt-03/stimulus.json").read_text())
        assert [dict(label=v.label, **v.values) for v in plan] == saved_vectors
        raw = RAW.read_bytes()
        reference = original.parse_trace(raw, original.make_plan())
        fixtures = OUT / "fixtures"
        fixtures.mkdir(exist_ok=False)

        def check(name, data, expected, category, source_path=None, finish_source=None):
            if source_path is None:
                source_path = fixtures / (name + ".stdout.bin")
                with source_path.open("xb") as file:
                    file.write(data)
            else:
                assert source_path.read_bytes() == data
            row = dict(name=name, category=category, path=str(source_path), sha256=digest(data),
                       bytes=len(data), expected=expected,
                       declared_finish_source=str(finish_source) if finish_source else "default_pinned_attempt03")
            try:
                checked = repaired.parse_trace(data, plan, **({"finish_source": finish_source} if finish_source else {}))
            except (ValueError, OSError) as exc:
                row.update(actual="reject", error_type=type(exc).__name__, error=str(exc))
            else:
                row.update(actual="pass", termination=checked["simulator_termination"])
                # All old public trace, marker, statistics and disposition checks remain exact.
                assert {k: v for k, v in checked.items() if k != "simulator_termination"} == reference
            result["cases"].append(row)
            print(json.dumps(row, ensure_ascii=False), flush=True)

        check("positive_actual_crlf", raw, "pass", "positive_actual_saved", RAW)
        lf = raw.replace(b"\r\n", b"\n")
        check("positive_lf_normalization", lf, "pass", "positive_normalization")
        check("positive_crlf_roundtrip", lf.replace(b"\n", b"\r\n"), "pass", "positive_normalization")
        unicode_source = OUT / "fixtures" / "源 ü 路径" / "tb_buffered_scan_capture.sv"
        unicode_source.parent.mkdir()
        with unicode_source.open("xb") as file:
            file.write(TB.read_bytes())
        unicode_raw = raw.replace(FINISH_SOURCE.as_posix().encode(), unicode_source.as_posix().encode())
        check("positive_utf8_declared_source", unicode_raw, "pass", "positive_declared_utf8_path", finish_source=unicode_source)
        for path in sorted((AUTHOR / "attempt-03/parser-negative-controls").glob("*.stdout.bin")):
            check("original_" + path.stem, path.read_bytes(), "reject", "original_26_saved_negatives", path)
        for path in sorted(RED.glob("*.stdout.bin")):
            # Reproduce main's five real false accepts with the frozen original checker.
            original.parse_trace(path.read_bytes(), original.make_plan())
            check("main_red_" + path.stem, path.read_bytes(), "reject", "main_5_saved_red_old_checker_accepts", path)

        lines = raw.splitlines(keepends=True)
        starts = {
            "start": b"# Start time:", "finish": b"# ** Note: $finish", "time": b"#    Time:",
            "break": b"# Break at ", "stopped": b"# Stopped at ", "end": b"# End time:", "summary": b"# Errors:",
        }
        positions = {name: next(i for i, line in enumerate(lines) if line.startswith(prefix))
                     for name, prefix in starts.items()}
        mutated = []
        def mutation(name, fn):
            altered = list(lines)
            fn(altered)
            mutated.append((name, b"".join(altered)))
        for name, i in positions.items():
            mutation("missing_" + name, lambda ls, i=i: ls.pop(i))
            mutation("duplicate_" + name, lambda ls, i=i: ls.insert(i, ls[i]))
            mutation("suffix_" + name, lambda ls, i=i: ls.__setitem__(i, ls[i].rstrip(b"\r\n") + b" trailing\r\n"))
        mutation("summary_errors", lambda ls: ls.__setitem__(positions["summary"], b"# Errors: 1, Warnings: 0\r\n"))
        mutation("summary_warnings", lambda ls: ls.__setitem__(positions["summary"], b"# Errors: 0, Warnings: 1\r\n"))
        mutation("conflicting_duplicate_summary_crlf", lambda ls: ls.append(b"# Errors: 9, Warnings: 0\r\n"))
        for name in ["finish", "break", "stopped"]:
            i = positions[name]
            mutation("wrong_source_" + name, lambda ls, i=i: ls.__setitem__(i, ls[i].replace(b"tb_buffered_scan_capture.sv", b"other_source.sv")))
            mutation("wrong_line_" + name, lambda ls, i=i: ls.__setitem__(i, ls[i].replace(b"153", b"154")))
        for name, old, new in [
            ("finish_time", b"38016 ns", b"38017 ns"), ("finish_units", b"38016 ns", b"38016 ps"),
            ("finish_iteration", b"Iteration: 0", b"Iteration: 1"),
            ("finish_instance", b"/tb_buffered_scan_capture", b"/other_instance"),
        ]:
            mutation(name, lambda ls, old=old, new=new: ls.__setitem__(positions["time"], ls[positions["time"]].replace(old, new)))
        mutation("elapsed_conflict", lambda ls: ls.__setitem__(positions["end"], ls[positions["end"]].replace(b"0:00:03", b"0:00:04")))
        mutation("end_before_start", lambda ls: ls.__setitem__(positions["end"], ls[positions["end"]].replace(b"16:02:27", b"16:02:23")))
        mutation("invalid_start_clock", lambda ls: ls.__setitem__(positions["start"], ls[positions["start"]].replace(b"16:02:24", b"25:02:24")))
        mutation("invalid_end_calendar", lambda ls: ls.__setitem__(positions["end"], ls[positions["end"]].replace(b"Oct 24,2026", b"Feb 30,2026")))
        mutation("reordered_terminal", lambda ls: ls.__setitem__(slice(positions["finish"], positions["time"] + 1), [ls[positions["time"]], ls[positions["finish"]]]))
        mutation("prefix_start", lambda ls: ls.__setitem__(positions["start"], b"prefix " + ls[positions["start"]]))
        mutation("prefix_summary", lambda ls: ls.__setitem__(positions["summary"], b"prefix " + ls[positions["summary"]]))
        for name, data in mutated:
            check(name, data, "reject", "targeted_saved_log_derivation")
        byte_mutations = {
            "trailing_plaintext": raw + b"trailing data\r\n",
            "trailing_blankline": raw + b"\r\n",
            "trailing_tab": raw + b"\t\r\n",
            "trailing_nul": raw + b"\0\r\n",
            "interior_nul": raw.replace(b"Reading ", b"Reading \0", 1),
            "interior_vertical_tab": raw.replace(b"Reading ", b"Reading \x0b", 1),
            "interior_escape": raw.replace(b"Reading ", b"Reading \x1b", 1),
            "interior_delete": raw.replace(b"Reading ", b"Reading \x7f", 1),
            "invalid_utf8": raw.replace(b"Reading ", b"Reading \xff", 1),
            "unicode_line_separator": raw.replace(b"Reading ", "Reading \u2028".encode(), 1),
            "bare_cr": raw.replace(b"\r\n", b"\r", 1),
            "lf_cr": raw.replace(b"\r\n", b"\n\r", 1),
            "mixed_line_endings": raw.replace(b"\r\n", b"\n", 1),
            "no_final_newline": raw[:-2],
            "truncated_final_footer": raw[:raw.index(b"# ** Note: $finish")],
            "utf8_source_without_declared_provenance": unicode_raw,
        }
        for name, data in byte_mutations.items():
            check(name, data, "reject", "targeted_encoding_or_terminal_derivation")
        bad_source = fixtures / "modified_tb.sv"
        with bad_source.open("xb") as file:
            file.write(TB.read_bytes() + b"\n")
        check("declared_tb_hash_mismatch", raw, "reject", "targeted_provenance_binding", finish_source=bad_source)
        failures = [row["name"] for row in result["cases"] if row["actual"] != row["expected"]]
        result["failed_cases"] = failures
        result["old_main_false_accepts_reproduced"] = 5
        result["case_totals"] = dict(total=len(result["cases"]),
            positive=sum(r["expected"] == "pass" for r in result["cases"]),
            negative=sum(r["expected"] == "reject" for r in result["cases"]),
            matched=sum(r["actual"] == r["expected"] for r in result["cases"]))
        result["runtime_assumptions"] = [
            "Default parse_trace provenance is the explicitly pinned local author/attempt-03 input TB snapshot, not a transcript-supplied path",
            "Future runner calls pass their own retained compile-input snapshot path explicitly; its bytes must match fixed TB SHA",
            "The verifier requires the local pinned source/snapshot files to exist; moved saved logs must declare the matching retained source path",
            "Only strict UTF-8 and consistently LF or CRLF line endings are accepted; ModelSim 10.7's actual local footer grammar is qualified",
        ]
        result["diff_scope"] = "parse_trace simulator termination qualification and explicit finish-source propagation only"
        before_bytes = (OUT / "inputs/runner-original.py").read_bytes()
        after_bytes = RUNNER.read_bytes()
        diff = "".join(difflib.unified_diff(before_bytes.decode().splitlines(keepends=True),
                after_bytes.decode().splitlines(keepends=True), fromfile="runner-original.py", tofile="run_buffered_scan_capture.py"))
        with (OUT / "runner-exact.diff").open("x", encoding="utf-8", newline="") as file:
            file.write(diff)
        with (OUT / "inputs/runner-repaired.py").open("xb") as file:
            file.write(after_bytes)
        result["exact_diff_sha256"] = digest((OUT / "runner-exact.diff").read_bytes())
        if failures:
            raise AssertionError("saved-log qualifier failures: " + ", ".join(failures))
        result["status"] = "saved_log_qualification_checks_passed_pending_main"
    except Exception as exc:
        result.update(status="blocked_after_single_bounded_pass", error_type=type(exc).__name__, error=str(exc))
        with (OUT / "verification.exception.stderr.txt").open("x", encoding="utf-8") as file:
            file.write(traceback.format_exc())
    finally:
        after = inventory()
        before = json.loads((OUT / "protected_before.json").read_text())
        save(OUT / "protected_after.json", after)
        result["protected_before_after_equal"] = before == after
        result["protected_file_count"] = len(before)
        if before != after:
            result.update(status="blocked_after_single_bounded_pass", protected_file_error="original evidence or dependency bytes changed")
        result["finished_utc"] = datetime.now(timezone.utc).isoformat()
        save(OUT / "RESULT.json", result)
    print(json.dumps({"status": result["status"], "case_totals": result.get("case_totals"),
                      "protected_before_after_equal": result["protected_before_after_equal"], "error": result.get("error")}, ensure_ascii=False), flush=True)
    return 0 if result["status"] == "saved_log_qualification_checks_passed_pending_main" else 1

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", choices=["prepare", "verify"])
    args = parser.parse_args()
    if args.stage == "prepare":
        prepare()
    else:
        raise SystemExit(verify())
