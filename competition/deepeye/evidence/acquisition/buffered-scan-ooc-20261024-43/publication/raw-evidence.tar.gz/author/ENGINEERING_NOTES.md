Exact one op43 OOC command completed with exit 0; 12 original job processes observed, zero active at completion, and no remaining Vivado process in the final OS audit.

Resources: 625 Slice LUTs (actual report label Slice LUTs*), 1111 Slice Registers, 0 BRAM tiles, 0 DSPs. Post-synthesis 10 ns diagnostic WNS +3.632 ns, TNS 0.000 ns. This is not a place/route timing result.

Seven actual warning messages are preserved in ACTUAL_MESSAGES.json and full raw logs. One DRC violation is ZPS7-1, Warning, PS7 block required. check_timing reports 128 ports without input delays and 779 without output delays. These gaps and warnings are not waived.

Exact source/tool/Tcl/command/environment-override/PID/exit and all report/log/DCP hashes are recorded in RESULT.json, PROCESS.json and HANDOFF.json. The original Tcl bytes are unchanged; its operation33 comment maps explicitly to this operation43 invocation. The source list contains only the three authorized snapshots, with no parameters.

The copied and original DCP SHA256 both equal 0cdf897736d30c5e3e3cb98a68de068ec21770b6c5e323707c67cd2776b9f19c. Main later independently reopens the exact DCP and owns evaluation and acceptance. No other synthesis, ModelSim, place/route, bitstream, board, credentials/service or publication operation was performed. All H01-H15 and all29 formal not_run remain preserved.
