Operation43 author result: ooc_artifacts_complete_pending_main

Exactly one three-source OOC invocation was permitted; actual launch count: 1
Synthesis completed: True; report/checkpoint artifact completion: True
Actual process details, source/tool/Tcl hashes, markers and warning/error text are in RESULT.json and PROCESS.json.

Unchanged Tcl originally comments operation33; this invocation maps it explicitly to operation43/run b43.

Diagnostic timing: {"clock_period_ns": "10.000", "stage": "post_synthesis_only", "wns_ns": "3.632", "tns_ns": "0.000", "acceptance": "not_assessed", "no_input_output_delays": true}
Utilization: {"Slice LUTs": {"used": "625", "actual_label": "Slice LUTs*", "raw_line": "| Slice LUTs*                |  625 |     0 |          0 |     53200 |  1.17 |"}, "Slice Registers": {"used": "1111", "actual_label": "Slice Registers", "raw_line": "| Slice Registers            | 1111 |     0 |          0 |    106400 |  1.04 |"}, "Block RAM Tile": {"used": "0", "actual_label": "Block RAM Tile", "raw_line": "| Block RAM Tile |    0 |     0 |          0 |       140 |  0.00 |"}, "DSPs": {"used": "0", "actual_label": "DSPs", "raw_line": "| DSPs      |    0 |     0 |          0 |       220 |  0.00 |"}, "Bonded IOB": {"used": "0", "actual_label": "Bonded IOB", "raw_line": "| Bonded IOB                  |    0 |     0 |          0 |       125 |  0.00 |"}}
Message counts: {"warning": 7, "critical_warning": 0, "error": 0, "latch_related": 0, "multidriver_related": 0}
DRC violations: 1

Raw artifacts are preserved under .local/b43 and copied byte-for-byte into author/artifacts. No old outputs were removed or vendor command replayed.

post-synthesis 10ns diagnostic only; no place/route/timing closure claim
No input/output delay qualification; DRC and warnings are preserved, not waived
No CDC/RDC, ModelSim rerun, bitstream, board, source clock/rate authenticity, full B01/B06/R03 or product acceptance
All H01-H15 preserved; all29 formal not_run; main independently reopens/evaluates exact DCP
