"""Operation 43: one pinned three-source Vivado OOC command, no retries."""
from datetime import datetime, timezone
import ctypes as C
from ctypes import wintypes as W
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback

AUTHOR = Path(__file__).resolve().parent
ROOT = AUTHOR.parents[3]
WORKTREE = ROOT.parents[1]
REPO = Path("D:/pynq/CarlandFPGA")
RUN = REPO / ".local/b43"
SPEC = REPO / ".local/deployment/node-b/evidence/buffered-scan-ooc-20261024-43/MAIN_SPEC.md"
TOP = "deepeye_buffered_scan_capture"
SOURCES = [
    "fpga/acquisition/deepeye_buffered_scan_capture.sv",
    "fpga/acquisition/deepeye_sample_scan_capture.sv",
    "fpga/acquisition/deepeye_raw_scan_queue.sv",
]
PINS = dict(zip(SOURCES, [
    "c8a540db8122b8f5520582a0f1fa9be0c43cb54a62f03c7c4edc893906f28411",
    "fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d",
    "630e14803d82b3379517d91626de4ad7e7d3c509ad14363b3164031a5f633ee4",
]))
TCL_REL = "fpga/build_qualification/ooc_qualification.tcl"
EXAMPLE_REL = "tools/build/run_ooc_qualification.py"
PINS.update({TCL_REL: "54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9",
             EXAMPLE_REL: "04a47aee3ce44c7576c8d879baf27a8701b5cde3e17a3ef0000954c8b0c3ea11"})
TOOL = Path("D:/pynq/AMD2026/2026.1/Vivado")
WRAPPER = TOOL / "bin/vivado.bat"
EXE = TOOL / "bin/unwrapped/win64.o/vivado.exe"
TOOL_PINS = {WRAPPER: "a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b",
             EXE: "3a4e9e3f03d20cd1994dc2eff44566af7a10eaaae04429e9d460bffe3b0e86e4"}
CONTRACT_HASH = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
CMD = Path(os.environ.get("SystemRoot", "C:/Windows")) / "System32/cmd.exe"
SI = subprocess.STARTUPINFO()
SI.dwFlags |= subprocess.STARTF_USESHOWWINDOW
SI.wShowWindow = subprocess.SW_HIDE
HIDDEN = subprocess.CREATE_NO_WINDOW

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def file_record(path):
    data = path.read_bytes()
    return {"path": str(path.resolve()), "bytes": len(data), "sha256": sha(data)}

def save(path, value):
    with path.open("x", encoding="utf-8", newline="\n") as file:
        file.write(json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def note(event, **fields):
    print(json.dumps(dict(event=event, utc=now(), **fields), ensure_ascii=False), flush=True)

def command(label, argv, cwd, timeout=30):
    output = AUTHOR / (label + ".stdout.bin")
    error = AUTHOR / (label + ".stderr.bin")
    record = dict(argv=[str(x) for x in argv], cwd=str(cwd), hidden=True, started_utc=now())
    with output.open("xb") as out, error.open("xb") as err:
        process = subprocess.Popen(record["argv"], cwd=cwd, stdin=subprocess.DEVNULL,
            stdout=out, stderr=err, startupinfo=SI, creationflags=HIDDEN)
        record["pid"] = process.pid
        record["parent_pid"] = os.getpid()
        record["exit_code"] = process.wait(timeout=timeout)
    record.update(finished_utc=now(), stdout=file_record(output), stderr=file_record(error))
    save(AUTHOR / (label + ".command.json"), record)
    if record["exit_code"] != 0:
        raise RuntimeError(f"{label} failed with exit {record['exit_code']}")
    return output.read_bytes()

def processes(label):
    script = "$taskProcesses = @(Get-CimInstance Win32_Process -Filter \"Name='vivado.exe' OR Name='cmd.exe'\" | Where-Object { $_.Name -ieq 'vivado.exe' -or ($_.Name -ieq 'cmd.exe' -and $_.CommandLine -match 'Vivado[\\\\/]bin[\\\\/]vivado\\.bat') } | Select-Object ProcessId,ParentProcessId,CreationDate,ExecutablePath,CommandLine); ConvertTo-Json -InputObject $taskProcesses -Depth 4"
    data = command(label, ["powershell.exe", "-NoLogo", "-NoProfile", "-NonInteractive", "-Command", script], REPO)
    result = json.loads(data.decode("utf-8-sig"))
    if not isinstance(result, list):
        raise ValueError("process audit did not return a JSON array")
    return result

K = C.WinDLL("kernel32", use_last_error=True)
K.CreateJobObjectW.argtypes = [C.c_void_p, W.LPCWSTR]
K.CreateJobObjectW.restype = W.HANDLE
K.AssignProcessToJobObject.argtypes = [W.HANDLE, W.HANDLE]
K.AssignProcessToJobObject.restype = W.BOOL
K.QueryInformationJobObject.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD, C.c_void_p]
K.QueryInformationJobObject.restype = W.BOOL
K.TerminateJobObject.argtypes = [W.HANDLE, W.UINT]
K.TerminateJobObject.restype = W.BOOL
K.CreateIoCompletionPort.argtypes = [W.HANDLE, W.HANDLE, C.c_size_t, W.DWORD]
K.CreateIoCompletionPort.restype = W.HANDLE
K.SetInformationJobObject.argtypes = [W.HANDLE, C.c_int, C.c_void_p, W.DWORD]
K.SetInformationJobObject.restype = W.BOOL
K.GetQueuedCompletionStatus.argtypes = [W.HANDLE, C.POINTER(W.DWORD), C.POINTER(C.c_size_t), C.POINTER(C.c_void_p), W.DWORD]
K.GetQueuedCompletionStatus.restype = W.BOOL
K.OpenProcess.argtypes = [W.DWORD, W.BOOL, W.DWORD]
K.OpenProcess.restype = W.HANDLE
K.WaitForSingleObject.argtypes = [W.HANDLE, W.DWORD]
K.WaitForSingleObject.restype = W.DWORD
K.CloseHandle.argtypes = [W.HANDLE]
K.CloseHandle.restype = W.BOOL

class Accounting(C.Structure):
    _fields_ = [(n, C.c_longlong) for n in ["user", "kernel", "period_user", "period_kernel"]] + [
        (n, W.DWORD) for n in ["faults", "total", "active", "terminated"]]

class Association(C.Structure):
    _fields_ = [("key", C.c_void_p), ("port", W.HANDLE)]

class WindowsJob:
    """Job membership and kernel completion messages track the original tree."""
    def __init__(self):
        self.handle = K.CreateJobObjectW(None, None)
        if not self.handle:
            raise C.WinError(C.get_last_error())
        self.port = K.CreateIoCompletionPort(W.HANDLE(-1), None, 0, 1)
        if not self.port:
            raise C.WinError(C.get_last_error())
        assoc = Association(C.c_void_p(1), self.port)
        if not K.SetInformationJobObject(self.handle, 7, C.byref(assoc), C.sizeof(assoc)):
            raise C.WinError(C.get_last_error())
        self.events = []

    def attach(self, process):
        if not K.AssignProcessToJobObject(self.handle, W.HANDLE(int(process._handle))):
            raise C.WinError(C.get_last_error())

    def accounting(self):
        values = Accounting()
        if not K.QueryInformationJobObject(self.handle, 1, C.byref(values), C.sizeof(values), None):
            raise C.WinError(C.get_last_error())
        return dict(total_processes=values.total, active_processes=values.active,
                    terminated_processes=values.terminated)

    def drain(self, timeout_ms=0):
        while True:
            message, key, overlapped = W.DWORD(), C.c_size_t(), C.c_void_p()
            ok = K.GetQueuedCompletionStatus(self.port, C.byref(message), C.byref(key), C.byref(overlapped), timeout_ms)
            if not ok:
                if C.get_last_error() == 258:
                    return
                raise C.WinError(C.get_last_error())
            self.events.append(dict(message=message.value, process_id=overlapped.value,
                                    completion_key=key.value, observed_utc=now()))
            timeout_ms = 0

    def terminate(self):
        if not K.TerminateJobObject(self.handle, 124):
            raise C.WinError(C.get_last_error())

    def wait_empty(self, seconds):
        deadline = time.monotonic() + seconds
        while self.accounting()["active_processes"]:
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                return False
            self.drain(min(1000, max(1, int(remaining * 1000))))
        self.drain()
        return True

    def close(self):
        K.CloseHandle(self.port)
        K.CloseHandle(self.handle)

def gate_vendor():
    before = processes("vendor-gate-before")
    record = dict(before=before, wait_limit_seconds=300, original42_waits=[])
    if before:
        if any(not re.search(r"(?i)(?:^|[/\\\"\s])b42(?:[/\\\"\s]|$)", row.get("CommandLine") or "") for row in before):
            save(AUTHOR / "VENDOR_GATE.json", dict(record, outcome="blocked_other_vivado"))
            raise RuntimeError("another Vivado process is active; no op43 launch")
        note("original42_os_wait_begin", process_ids=[row["ProcessId"] for row in before], limit_seconds=300)
        deadline = time.monotonic() + 300
        for row in before:
            handle = K.OpenProcess(0x00100000, False, row["ProcessId"])
            entry = dict(pid=row["ProcessId"], started_utc=now())
            if handle:
                entry["wait_return"] = int(K.WaitForSingleObject(handle, max(0, int((deadline - time.monotonic()) * 1000))))
                K.CloseHandle(handle)
            else:
                entry["open_process_error"] = C.get_last_error()
            entry["finished_utc"] = now()
            record["original42_waits"].append(entry)
        record["after_wait"] = processes("vendor-gate-after-wait")
        if record["after_wait"]:
            save(AUTHOR / "VENDOR_GATE.json", dict(record, outcome="blocked_still_busy"))
            raise RuntimeError("Vivado remains active after the bounded OS wait; no op43 launch")
    record["outcome"] = "no_other_vivado_active"
    save(AUTHOR / "VENDOR_GATE.json", record)
    note("vendor_gate_clear", original42_waited=bool(before))

def parse_outputs(result, snapshots):
    stdout = (RUN / "vivado.stdout.bin").read_bytes()
    stderr = (RUN / "vivado.stderr.bin").read_bytes()
    lines = stdout.decode("utf-8", errors="strict").splitlines()
    errors = []
    rows = []
    for n, line in enumerate(lines, 1):
        if "B06_OOC_" not in line:
            continue
        if not line.startswith("B06_OOC_"):
            errors.append(f"unanchored Tcl marker line {n}")
            continue
        tokens = line.split("|")
        fields = {}
        for token in tokens[1:]:
            if not re.fullmatch(r"[a-z][a-z0-9_]*=[^|\r\n]+", token):
                raise ValueError("malformed marker field: " + line)
            key, value = token.split("=", 1)
            if key in fields:
                raise ValueError("duplicate marker field: " + line)
            fields[key] = value
        rows.append((tokens[0], fields))
    expected = ["BEGIN", "USER_DATA", "VERSION", "PART", "THREADS"] + ["SOURCE_READ"] * 3 + [
        "SOURCE_COUNT", "SYNTH_BEGIN", "SYNTH_DONE", "DESIGN", "CLOCK"] + ["REPORT"] * 4 + ["CHECKPOINT", "END"]
    if [kind for kind, _ in rows] != ["B06_OOC_" + kind for kind in expected]:
        errors.append("exact one-top three-source Tcl marker sequence differs")
    result["synthesis_completed"] = sum(kind == "B06_OOC_SYNTH_DONE" and fields == {"top": TOP, "status": "complete"} for kind, fields in rows) == 1
    def same(value, path):
        return value.replace("\\", "/").casefold() == path.resolve().as_posix().casefold()
    if not errors:
        fields = [fields for _, fields in rows]
        expected_fields = {
            0: {"run_id": "b43", "top": TOP, "clock_mode": "clock:clk"},
            2: {"value": "2026.1"}, 3: {"requested": "xc7z020clg400-1", "matched": "1"},
            4: {"requested": "2", "actual": "2"}, 8: {"count": "3"},
            9: {"top": TOP, "mode": "out_of_context", "part": "xc7z020clg400-1"},
            10: {"top": TOP, "status": "complete"},
            12: {"name": "clk", "port": "clk", "period_ns": "10.000", "status": "created"},
            18: {"run_id": "b43", "top": TOP, "status": "artifact_complete"},
        }
        for index, exact in expected_fields.items():
            if fields[index] != exact:
                errors.append(f"marker fields differ at index {index}")
        if set(fields[1]) != {"mode", "path"} or fields[1].get("mode") != "owned_cache" or not same(fields[1].get("path", ""), RUN / "cache"):
            errors.append("cache provenance differs")
        for index, source in enumerate(snapshots, 5):
            if set(fields[index]) != {"index", "path"} or fields[index].get("index") != str(index - 4) or not same(fields[index].get("path", ""), source):
                errors.append("source snapshot path/index differs")
        if set(fields[11]) != {"part", "port_count"} or fields[11].get("part") != "xc7z020clg400-1" or not re.fullmatch(r"[1-9][0-9]*", fields[11].get("port_count", "")):
            errors.append("design metadata differs")
        result["design_port_count"] = fields[11].get("port_count")
        for index, kind in enumerate(["utilization", "timing_summary", "check_timing", "drc"], 13):
            allowed = {"kind", "status", "path"} | ({"diagnostic_only"} if kind in {"timing_summary", "check_timing"} else set()) | ({"violation_count"} if kind == "drc" else set())
            report = fields[index]
            if set(report) != allowed or report.get("kind") != kind or report.get("status") != "written" or not same(report.get("path", ""), RUN / "reports" / (kind + ".rpt")):
                errors.append("report provenance differs: " + kind)
            if "diagnostic_only" in allowed and report.get("diagnostic_only") != "1":
                errors.append("diagnostic-only qualifier missing")
        if not re.fullmatch(r"[0-9]+", fields[16].get("violation_count", "")):
            errors.append("DRC count is malformed")
        else:
            result["drc_violation_count"] = int(fields[16]["violation_count"])
        if set(fields[17]) != {"status", "path"} or fields[17].get("status") != "written" or not same(fields[17].get("path", ""), RUN / "ooc.dcp"):
            errors.append("checkpoint provenance differs")
    all_lines = lines + stderr.decode("utf-8", errors="replace").splitlines()
    messages = {"warning": [], "critical_warning": [], "error": [], "latch_related": [], "multidriver_related": []}
    for line in all_lines:
        stripped = line.lstrip()
        if stripped.startswith("WARNING:"): messages["warning"].append(line)
        if stripped.startswith("CRITICAL WARNING:"): messages["critical_warning"].append(line)
        if stripped.startswith(("ERROR:", "FATAL:", "B06_OOC_TCL_ERROR|")): messages["error"].append(line)
        if "latch" in line.lower(): messages["latch_related"].append(line)
        if any(word in line.lower() for word in ["multiple driver", "multi-driven"]): messages["multidriver_related"].append(line)
    if "B06_OOC_" in stderr.decode("utf-8", errors="replace"):
        errors.append("Tcl marker/error text on stderr")
    save(AUTHOR / "ACTUAL_MESSAGES.json", messages)
    result["messages"] = messages
    result["message_counts"] = {kind: len(value) for kind, value in messages.items()}
    result["markers"] = [{"kind": kind, "fields": fields} for kind, fields in rows]
    result["marker_errors"] = errors
    required = [RUN / "reports" / (name + ".rpt") for name in ["utilization", "timing_summary", "check_timing", "drc"]] + [RUN / "ooc.dcp", RUN / "vivado.log", RUN / "vivado.jou"]
    result["outputs"] = {p.name: file_record(p) for p in required if p.is_file()}
    result["missing_or_empty_outputs"] = [str(p) for p in required if not p.is_file() or p.stat().st_size == 0]
    if (RUN / "reports/utilization.rpt").is_file():
        utilization = {}
        pattern = re.compile(r"^\|\s*(Slice LUTs\*?|Slice Registers|Block RAM Tile|DSPs|Bonded IOB)\s*\|\s*([0-9.]+)\s*\|")
        for line in (RUN / "reports/utilization.rpt").read_text(encoding="utf-8").splitlines():
            if match := pattern.match(line):
                key = match[1].rstrip("*")
                if key in utilization:
                    errors.append("duplicate utilization metric " + key)
                utilization[key] = {"used": match[2], "actual_label": match[1], "raw_line": line}
        result["utilization"] = utilization
        if "Slice LUTs" not in utilization: errors.append("Slice LUTs metric missing")
    if (RUN / "reports/timing_summary.rpt").is_file():
        timing = (RUN / "reports/timing_summary.rpt").read_text(encoding="utf-8")
        match = re.search(r"WNS\(ns\).*?\n\s*-+[^\n]*\n\s*([-+]?\d+(?:\.\d+)?)\s+([-+]?\d+(?:\.\d+)?)", timing, re.S)
        result["timing_diagnostic"] = {"clock_period_ns": "10.000", "stage": "post_synthesis_only",
            "wns_ns": match[1] if match else None, "tns_ns": match[2] if match else None,
            "acceptance": "not_assessed", "no_input_output_delays": True}
    result["artifact_complete"] = bool(result["synthesis_completed"] and not errors and not messages["error"] and not result["missing_or_empty_outputs"] and result["process"]["exit_code"] == 0 and result["process"]["terminal"])

def main():
    result = dict(schema="deepeye.buffered-scan.ooc.author.v1", task_id="DEEPEYE-IMPLEMENTATION-20261014/v1",
        work_id="B-BUFFERED-SCAN-OOC-20261024-43-v1", operation_id="B-DEEPEYE-BUFFERED-SCAN-OOC-20261024-43",
        canonical_agent_id="01a16a27-3458-7103-a4ab-cd06fd084da7", job_id="child-fef84edc48684e87947867ca42bedac6",
        parent_main="01a13b55-095b-7461-8dd5-5476a130bd82", status="running", vendor_launches=0,
        base_pr30_head="bfbb09523acc2266f33b8c08345460aaee18a378", top=TOP, source_count=3,
        no_parameters=True, part="xc7z020clg400-1", max_threads=2, timeout_seconds=600,
        scope="one local OOC artifact command; main independently evaluates DCP/resources/timing",
        tcl_comment_mapping="Unchanged pinned Tcl comments name operation33; this exclusive invocation is operation43, run_id b43",
        started_utc=now(), python_executable=sys.executable, python_version=sys.version,
        driver_pid=os.getpid(), driver_parent_pid=os.getppid(), driver_argv=sys.argv,
        formal_cards={"count": 29, "status": "not_run"}, board="not_run", place_route="not_run", bitstream="not_run",
        acceptance="main_retains_not_claimed", synthesis_completed=False, artifact_complete=False)
    source_paths = {rel: ROOT / rel for rel in PINS}
    source_paths.update({"MAIN_SPEC.md": SPEC})
    before = {}
    process = job = None
    snapshots = []
    try:
        if RUN.exists() or RUN.is_symlink():
            raise FileExistsError("exclusive short output already exists; no run")
        for rel, path in source_paths.items():
            before[rel] = file_record(path)
            if rel in PINS and before[rel]["sha256"] != PINS[rel]:
                raise ValueError("fixed input pin differs: " + rel)
        if before["MAIN_SPEC.md"]["sha256"] != "83d678ef81026101b75414a6e55563b2e4ff15186c847de80dee4cb5bf302423":
            raise ValueError("main spec pin differs")
        for path, expected in TOOL_PINS.items():
            if file_record(path)["sha256"] != expected:
                raise ValueError("Vivado executable/wrapper pin differs")
        result["tool_pins_before"] = {str(path): file_record(path) for path in TOOL_PINS}
        save(AUTHOR / "SOURCE_PINS_BEFORE.json", before)
        inputs = AUTHOR / "inputs"
        inputs.mkdir(exist_ok=False)
        for rel, path in source_paths.items():
            copy = inputs / rel
            copy.parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(path, copy)
        contract = command("contract", ["git", "show", "f5989cd5defce561f9ba98e6b18fc2682945f0a2:docs/competition/deepeye-2026/immutable_scope.json"], WORKTREE)
        requirements = json.loads(contract)["requirements"]
        assert sha(json.dumps(requirements, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()) == CONTRACT_HASH
        assert [r["id"] for r in requirements] == [f"H{n:02d}" for n in range(1, 16)]
        result["human_contract"] = dict(ids=[r["id"] for r in requirements], requirements_sha256=CONTRACT_HASH,
            commit="f5989cd5defce561f9ba98e6b18fc2682945f0a2", frozen_design="1011259415a0916054eb580687612580bc1e5f09")
        (inputs / "immutable_scope.json").write_bytes(contract)
        terminal_paths = [ROOT / "evidence/acquisition/buffered-scan-20261024-39/author/native-complete.stdout.json",
                          ROOT / "evidence/acquisition/buffered-scan-20261024-39/qualification-repair1/native-complete.response.json"]
        terminals = []
        for path in terminal_paths:
            obj = json.loads(path.read_text(encoding="utf-8"))
            if "content" in obj:
                obj = json.loads(next(c["text"] for c in obj["content"] if c["type"] == "text"))
            assert obj["status"] == "completed" and obj["terminal"] is True and obj["stale"] is False
            terminals.append(dict(job_id=obj["job_id"], status=obj["status"], terminal=True, receipt=file_record(path)))
        result["original39_and_repair_terminal"] = terminals
        result["actual_local_head_at_start"] = command("head", ["git", "rev-parse", "HEAD"], WORKTREE).decode().strip()
        # The output is created once, after all required pins and terminals.
        RUN.mkdir(exist_ok=False)
        for name in ["work", "tmp", "cache", "s"]:
            (RUN / name).mkdir(exist_ok=False)
        for rel in SOURCES:
            dest = RUN / "s" / Path(rel).name
            shutil.copyfile(inputs / rel, dest)
            assert file_record(dest)["sha256"] == PINS[rel]
            snapshots.append(dest)
        tcl = RUN / "ooc.tcl"
        shutil.copyfile(inputs / TCL_REL, tcl)
        source_list = RUN / "sources.txt"
        source_list.write_text("".join(p.resolve().as_posix() + "\n" for p in snapshots), encoding="utf-8")
        result["source_snapshots"] = [file_record(path) for path in snapshots]
        result["tcl_snapshot"] = file_record(tcl)
        gate_vendor()
        job = WindowsJob()
        child_env = os.environ.copy()
        overrides = {name: str((RUN / "tmp").resolve()) for name in ["TEMP", "TMP", "TMPDIR"]}
        overrides["XILINX_LOCAL_USER_DATA"] = str((RUN / "cache").resolve())
        child_env.update(overrides)
        argv = [str(CMD), "/d", "/c", str(WRAPPER), "-mode", "batch", "-notrace",
            "-log", str(RUN / "vivado.log"), "-journal", str(RUN / "vivado.jou"),
            "-source", str(tcl), "-tclargs", str(RUN), TOP, str(source_list), "clock:clk"]
        receipt = dict(argv=argv, command_line=subprocess.list2cmdline(argv), cwd=str(RUN / "work"),
            parent_pid=os.getpid(), hidden=True, shell=False, creationflags=HIDDEN | subprocess.CREATE_NEW_PROCESS_GROUP,
            environment_overrides=overrides, environment_policy="inherit parent, override only four child paths; no global changes or secret-value dump",
            exact_child_environment_sha256=sha(json.dumps(child_env, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode()),
            started_utc=now(), timeout_seconds=600, timed_out=False)
        with (RUN / "vivado.stdout.bin").open("xb") as out, (RUN / "vivado.stderr.bin").open("xb") as err:
            start = time.monotonic()
            process = subprocess.Popen(argv, cwd=RUN / "work", env=child_env, stdin=subprocess.DEVNULL,
                stdout=out, stderr=err, startupinfo=SI, creationflags=receipt["creationflags"])
            result["vendor_launches"] = 1
            receipt["pid"] = process.pid
            result["process"] = receipt
            job.attach(process)
            receipt["assigned_to_original_windows_job"] = True
            save(AUTHOR / "PROCESS_STARTED.json", receipt)
            note("op43_vivado_started", pid=process.pid, parent_pid=os.getpid(), timeout_seconds=600)
            try:
                receipt["exit_code"] = process.wait(timeout=max(.001, 600 - (time.monotonic() - start)))
            except subprocess.TimeoutExpired:
                receipt["timed_out"] = True
                receipt["state_at_timeout"] = job.accounting()
                job.terminate()
                receipt["timeout_action"] = "terminate only original op43 Windows job; no relaunch"
                receipt["exit_code"] = process.wait(timeout=30)
            receipt["terminal"] = job.wait_empty(30)
            receipt["job_accounting_final"] = job.accounting()
            receipt["job_process_messages"] = job.events
            receipt["finished_utc"] = now()
            receipt["duration_seconds"] = round(time.monotonic() - start, 6)
        receipt["stdout"] = file_record(RUN / "vivado.stdout.bin")
        receipt["stderr"] = file_record(RUN / "vivado.stderr.bin")
        save(AUTHOR / "PROCESS.json", receipt)
        save(RUN / "PROCESS.json", receipt)
        result["vivado_processes_after"] = processes("vendor-audit-after")
        result["all_original_job_processes_stopped"] = receipt["terminal"] and receipt["job_accounting_final"]["active_processes"] == 0
        note("op43_vivado_terminal", pid=process.pid, exit_code=receipt["exit_code"], job_active=receipt["job_accounting_final"]["active_processes"])
        parse_outputs(result, snapshots)
        result["status"] = "ooc_artifacts_complete_pending_main" if result["artifact_complete"] and not receipt["timed_out"] else "ooc_incomplete_no_retry"
    except Exception as exc:
        result.update(status="blocked_or_failed_no_retry", error_type=type(exc).__name__, error=str(exc))
        (AUTHOR / "exception.stderr.txt").write_text(traceback.format_exc(), encoding="utf-8")
        if process is not None and job is not None:
            try:
                if process.poll() is None and not result.get("process", {}).get("assigned_to_original_windows_job"):
                    # Assignment failed: stop only this still-live owned root
                    # and descendants, retaining the actual taskkill receipt.
                    command("owned-root-assignment-failure-stop", [CMD.parent / "taskkill.exe", "/PID", str(process.pid), "/T", "/F"], REPO)
                if job.accounting()["active_processes"]:
                    job.terminate()
                process.wait(timeout=30)
                result["failure_cleanup_job_terminal"] = job.wait_empty(30)
                result["failure_cleanup_accounting"] = job.accounting()
                result["failure_cleanup_job_messages"] = job.events
            except Exception as cleanup:
                result["actual_cleanup_error"] = repr(cleanup)
    finally:
        after = {rel: file_record(path) for rel, path in source_paths.items() if path.is_file()}
        save(AUTHOR / "SOURCE_PINS_AFTER.json", after)
        result["source_pins_before"] = before
        result["source_pins_after"] = after
        result["all_protected_source_inputs_unchanged"] = bool(before) and before == after
        result["tool_pins_after"] = {str(path): file_record(path) for path in TOOL_PINS}
        if not result["all_protected_source_inputs_unchanged"] or result.get("tool_pins_before") != result["tool_pins_after"]:
            result["status"] = "blocked_or_failed_no_retry"
            result["pin_error"] = "protected source/tool bytes changed"
        if job is not None:
            job.close()
        artifacts = AUTHOR / "artifacts"
        artifacts.mkdir(exist_ok=False)
        if RUN.is_dir():
            for path in [RUN / "vivado.stdout.bin", RUN / "vivado.stderr.bin", RUN / "vivado.log", RUN / "vivado.jou", RUN / "ooc.dcp", *sorted((RUN / "reports").glob("*.rpt"))]:
                if path.is_file():
                    shutil.copyfile(path, artifacts / path.name)
            result["short_output_file_inventory"] = [file_record(p) for p in sorted(RUN.rglob("*")) if p.is_file()]
        result["finished_utc"] = now()
        result["limits"] = ["post-synthesis 10ns diagnostic only; no place/route/timing closure claim",
            "No input/output delay qualification; DRC and warnings are preserved, not waived",
            "No CDC/RDC, ModelSim rerun, bitstream, board, source clock/rate authenticity, full B01/B06/R03 or product acceptance",
            "All H01-H15 preserved; all29 formal not_run; main independently reopens/evaluates exact DCP"]
        save(AUTHOR / "RESULT.json", result)
        report = [f"Operation43 author result: {result['status']}", "",
            "Exactly one three-source OOC invocation was permitted; actual launch count: " + str(result["vendor_launches"]),
            "Synthesis completed: " + str(result["synthesis_completed"]) + "; report/checkpoint artifact completion: " + str(result["artifact_complete"]),
            "Actual process details, source/tool/Tcl hashes, markers and warning/error text are in RESULT.json and PROCESS.json.",
            "", "Unchanged Tcl originally comments operation33; this invocation maps it explicitly to operation43/run b43.",
            "", "Diagnostic timing: " + json.dumps(result.get("timing_diagnostic"), ensure_ascii=False),
            "Utilization: " + json.dumps(result.get("utilization"), ensure_ascii=False),
            "Message counts: " + json.dumps(result.get("message_counts"), ensure_ascii=False),
            "DRC violations: " + str(result.get("drc_violation_count")),
            "", "Raw artifacts are preserved under .local/b43 and copied byte-for-byte into author/artifacts. No old outputs were removed or vendor command replayed.",
            "", *result["limits"]]
        (AUTHOR / "REPORT.md").write_text("\n".join(report) + "\n", encoding="utf-8")
        save(AUTHOR / "ARTIFACT_SHA256.json", {p.relative_to(AUTHOR).as_posix(): file_record(p) for p in sorted(AUTHOR.rglob("*")) if p.is_file()})
    note("op43_author_done", status=result["status"], evidence=str(AUTHOR / "RESULT.json"))
    return 0 if result["status"] == "ooc_artifacts_complete_pending_main" else 1

if __name__ == "__main__":
    raise SystemExit(main())
