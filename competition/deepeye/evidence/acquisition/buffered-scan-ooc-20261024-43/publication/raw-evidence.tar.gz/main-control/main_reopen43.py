from pathlib import Path
import ast,datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/acquisition/buffered-scan-ooc-20261024-43';A=E/'author';O=E/'main/reopen-01';O.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
t=get(D/'native-terminal.json')[0];tr=json.loads(t['result']['text']);assert t['terminal'] and not t['stale'] and t['status']=='completed' and sha(Path(tr['evidence']))==tr['result_sha256'];a=get(A/'RESULT.json')
assert a['vendor_launches']==1 and a['all_protected_source_inputs_unchanged'] and a['synthesis_completed'] and a['artifact_complete']
assert a['all_original_job_processes_stopped'] and a['process']['terminal'] and not a['process']['timed_out'] and a['process']['exit_code']==0 and a['process']['job_accounting_final']['active_processes']==0
verified={}
for n,v in get(A/'ARTIFACT_SHA256_BEFORE_NATIVE_COMPLETE.json').items():assert sha(A/n)==v['sha256'] and (A/n).stat().st_size==v['bytes'];verified[n]=v
tr['source_sha256']={'fpga/acquisition/'+Path(x['path']).name:x['sha256'] for x in tr['source_snapshots']}
helper=R/'.local/deployment/node-b/evidence/b06-ooc-20261024-33/main_audit_and_reopen.py';nodes=[n for n in ast.parse(helper.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ('table','timing')];assert len(nodes)==2;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'));(O/'source_report_helper.py').write_bytes(helper.read_bytes())
dcp=A/'artifacts/ooc.dcp';assert sha(dcp)==tr['dcp']['sha256']=='0cdf897736d30c5e3e3cb98a68de068ec21770b6c5e323707c67cd2776b9f19c';source=A/'artifacts';resource=table(source/'utilization.rpt');times=timing(source/'timing_summary.rpt');assert resource=={'Slice LUTs':625,'Slice Registers':1111,'Block RAM Tile':0,'DSPs':0} and times['WNS']=='3.632';ports=int(a['design_port_count']);assert ports==909
for n,h in tr['source_sha256'].items():assert sha(P/n)==h
q=lambda p:'{'+p.as_posix()+'}';script=O/'reopen.tcl';script.write_text('\n'.join(['set_param general.maxThreads 2','puts "MAIN43_REOPEN_BEGIN"','open_checkpoint '+q(dcp),'puts "MAIN43_DESIGN|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"','foreach c [get_clocks] {puts "MAIN43_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}','report_utilization -file '+q(O/'utilization.rpt'),'report_timing_summary -file '+q(O/'timing_summary.rpt'),'report_timing -delay_type max -max_paths 10 -path_type full_clock_expanded -input_pins -file '+q(O/'critical_paths.rpt'),'close_design','puts "MAIN43_REOPEN_END"','exit 0'])+'\n')
env=os.environ.copy()
for n in ['work','tmp','cache']:(O/n).mkdir()
for k in ['TEMP','TMP','TMPDIR']:env[k]=str(O/'tmp')
env['XILINX_LOCAL_USER_DATA']=str(O/'cache');tool=Path('D:/pynq/AMD2026/2026.1/Vivado/bin/vivado.bat');assert sha(tool)=='a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b';argv=[r'C:\Windows\System32\cmd.exe','/d','/c',str(tool),'-mode','batch','-nojournal','-nolog','-notrace','-source',str(script)];put(O/'INTENT.json',{'argv':argv,'cwd':str(O/'work'),'script_sha256':sha(script),'dcp_sha256':sha(dcp),'scope':'Read/reopen exact DCP and reports only; no synthesis or implementation.'});started=time.monotonic();p=subprocess.Popen(argv,cwd=O/'work',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(O/'STARTED.json',{'pid':p.pid});timed=False
try:b,e=p.communicate(timeout=240)
except subprocess.TimeoutExpired:timed=True;p.kill();b,e=p.communicate()
(O/'stdout.bin').write_bytes(b);(O/'stderr.bin').write_bytes(e);put(O/'PROCESS.json',{'pid':p.pid,'exit_code':p.returncode,'timed_out':timed,'elapsed':time.monotonic()-started,'stdout_sha256':sha(O/'stdout.bin'),'stderr_sha256':sha(O/'stderr.bin')});assert p.returncode==0 and not timed;raw=b.decode();assert not re.search(r'^\s*(ERROR:|CRITICAL WARNING:)',raw,re.M)
assert [l for l in raw.splitlines() if l.startswith('MAIN43_')]==['MAIN43_REOPEN_BEGIN','MAIN43_DESIGN|part=xc7z020clg400-1|ports=909|clocks=1','MAIN43_CLOCK|name=clk|period=10.000','MAIN43_REOPEN_END']
assert table(O/'utilization.rpt')==resource and timing(O/'timing_summary.rpt')==times and sha(dcp)==tr['dcp']['sha256']
drc=re.findall(r'^\s*([A-Z][A-Z0-9]+-\d+)#\d+\s+(Warning|Error|Critical Warning)\s*$',(source/'drc.rpt').read_text(),re.M);assert len(drc)==1
result={'status':'OOC_ARTIFACTS_VERIFIED_DIAGNOSTIC_TIMING_MET','operation_id':'B-DEEPEYE-BUFFERED-SCAN-OOC-20261024-43','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','resources':resource,'timing':times,'drc':drc,'actual_synthesis_runs':1,'actual_main_dcp_reopens':1,'dcp_sha256':sha(dcp),'main_process_exit':0,'verified_author_files':verified,'source_sha256':tr['source_sha256'],'critical_paths_sha256':sha(O/'critical_paths.rpt'),'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','scope':'One10ns post-synthesis OOC diagnostic; +3.632ns positive slack, not timingclosure. 7synthesiswarnings/1ZPS7-1DRC and128input/779outputdelay gaps retained. No route/implementation/CDC_RDC/board/system; all29/B01/B06/R03not_run.'};put(O/'RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='verified_author_files'}))
