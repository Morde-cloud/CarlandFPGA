from pathlib import Path
import ast
D=Path(__file__).parent;s=(D.parent/'trace-payload-ooc-20261024-40/main_reopen.py').read_text()
s=s.replace('evidence/codec/trace-payload-ooc-20261024-40','evidence/acquisition/buffered-scan-ooc-20261024-43').replace('B-DEEPEYE-TRACE-PAYLOAD-OOC-20261024-40','B-DEEPEYE-BUFFERED-SCAN-OOC-20261024-43').replace('MAIN40','MAIN43')
a=s.index("t=get(D/'native-terminal.json')");b=s.index('helper=R/',a)
s=s[:a]+'''t=get(D/'native-terminal.json')[0];tr=json.loads(t['result']['text']);assert t['terminal'] and not t['stale'] and t['status']=='completed' and sha(Path(tr['evidence']))==tr['result_sha256'];a=get(A/'RESULT.json')
assert a['vendor_launches']==1 and a['all_protected_source_inputs_unchanged'] and a['synthesis_completed'] and a['artifact_complete']
assert a['all_original_job_processes_stopped'] and a['process']['terminal'] and not a['process']['timed_out'] and a['process']['exit_code']==0 and a['process']['job_accounting_final']['active_processes']==0
verified={}
for n,v in get(A/'ARTIFACT_SHA256_BEFORE_NATIVE_COMPLETE.json').items():assert sha(A/n)==v['sha256'] and (A/n).stat().st_size==v['bytes'];verified[n]=v
tr['source_sha256']={'fpga/acquisition/'+Path(x['path']).name:x['sha256'] for x in tr['source_snapshots']}
'''+s[b:]
s=s.replace("dcp=A/'run/ooc.dcp'","dcp=A/'artifacts/ooc.dcp'").replace("source=A/'run/reports'","source=A/'artifacts'").replace('261b1d5a5363596659366277437e80206f4ccc7dbfb851fc011fef2785a1ff7e','0cdf897736d30c5e3e3cb98a68de068ec21770b6c5e323707c67cd2776b9f19c')
s=s.replace("'Slice LUTs':2273,'Slice Registers':2743,'Block RAM Tile':0,'DSPs':2","'Slice LUTs':625,'Slice Registers':1111,'Block RAM Tile':0,'DSPs':0").replace("times['WNS']=='-4.073'","times['WNS']=='3.632'").replace("int(a['observed']['design']['port_count'])","int(a['design_port_count'])").replace('ports==319','ports==909').replace('ports=319','ports=909').replace("sha(A/'inputs'/n)","sha(P/n)").replace('len(drc)==7','len(drc)==1').replace('OOC_ARTIFACTS_VERIFIED_TIMING_NOT_MET','OOC_ARTIFACTS_VERIFIED_DIAGNOSTIC_TIMING_MET').replace('One10ns post-synthesis OOC diagnostic; -4.073ns does not meet timing. 7unwaivedDRC/I/Ogaps retained.','One10ns post-synthesis OOC diagnostic; +3.632ns positive slack, not timingclosure. 7synthesiswarnings/1ZPS7-1DRC and128input/779outputdelay gaps retained.')
ast.parse(s);(D/'main_reopen43.py').write_text(s,encoding='utf-8',newline='\n');print('Prepared43 read-only DCP audit')
