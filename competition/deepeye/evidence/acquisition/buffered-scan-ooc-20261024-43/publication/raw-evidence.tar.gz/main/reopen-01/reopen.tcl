set_param general.maxThreads 2
puts "MAIN43_REOPEN_BEGIN"
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/buffered-scan-ooc-20261024-43/author/artifacts/ooc.dcp}
puts "MAIN43_DESIGN|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN43_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/buffered-scan-ooc-20261024-43/main/reopen-01/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/buffered-scan-ooc-20261024-43/main/reopen-01/timing_summary.rpt}
report_timing -delay_type max -max_paths 10 -path_type full_clock_expanded -input_pins -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/buffered-scan-ooc-20261024-43/main/reopen-01/critical_paths.rpt}
close_design
puts "MAIN43_REOPEN_END"
exit 0
