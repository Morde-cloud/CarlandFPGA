# Raw scan queue author result

Operation: `B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23`  
Work: `B-RAW-SCAN-QUEUE-RTL-20261022-23-v1`  
Baseline: `94571d2cd9a68bd030c878c406f19a1be6ec53d7`

## Result

- Bounded author suite: **PASS**, 27/27 selected cases.
- Queue function: 8/8 depths 1-8, including non-power depths 1, 3, 5, 6, 7.
- Composition: 5/5; overrun, wrong order, same-tag rearm, terminal exhaustion,
  and unarmed drain are represented in retained traces/checks.
- Parameter guards: 11/11; ten one-invalid probes plus DEPTH-priority control.
- Healthy control: 1/1; compiled and passed at minimal legal bounds.
- Compiled mutants: 2/2 rejected with numeric counterexamples
  (`data 4096 -> 4100`; `level 0 -> 5`).
- Synthetic runner self-test: PASS; parser negatives and actual Python process
  timeout/nonzero propagation retained separately.
- Raw ModelSim streams, transcripts, source snapshots, argv, cwd, environment,
  exit, timeout and stream hashes are retained. ModelSim SE-64 10.7/2017.12.

## Not run

Independent main review/acceptance, synthesis, implementation, timing, CDC/RDC,
all29, B02, B03, G05, B06, R03, physical board, and full-system testing were
not run. Vivado is absent on this node and was not installed or invoked.

This is bounded author evidence, not product acceptance.
