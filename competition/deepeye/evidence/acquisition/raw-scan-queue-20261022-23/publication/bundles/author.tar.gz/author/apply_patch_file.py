#!/usr/bin/env python3
import subprocess
import sys

EXE = 'D:/pynq/CarlandFPGA/.local/deployment/node-b/.local/node-b/codex-runtime/0b6fba6bfc1dab27e38653497d8fe6c6ff055277868a4c9b36096bc555dc8c45/codex.exe'
patch = open(sys.argv[1], encoding='utf-8').read().rstrip('\n')
raise SystemExit(subprocess.run([EXE, '--codex-run-as-apply-patch', patch]).returncode)
