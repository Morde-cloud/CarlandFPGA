#!/usr/bin/env python3
"""Freeze recovered-start, input, dependency and environment evidence."""

from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import tempfile
from datetime import datetime, timezone
from typing import Any


HERE = Path(__file__).resolve().parent
WORKTREE = (HERE / "../../../../../..").resolve()
REPO = Path("D:/pynq/CarlandFPGA").resolve()
SCOPE_DIR = REPO / ".local/deployment/node-b/evidence/raw-scan-queue-20261022-23"
DECISION_DIR = (
    REPO / ".local/deployment/node-b/evidence/main-continuation-20261019-v1/"
    "raw-scan-queue-20261022-23"
)
EXPECTED = {
    "scope_md": "a8a48893e71f9642d8cbbdf7c5c23b06f8dfc24c37554cab13421776be33ddc1",
    "continue_consumed": (
        "af0de802d4420845185bfb8544674f38a0e6be37c4a6b5ce80d1bf79991e16c0"
    ),
    "decision": "4f7fd365647e3e6c084d72d972f75efe46b2e5675e40abaa4e214340f49c7a17",
    "requirements": (
        "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
    ),
    "collector": (
        "fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d"
    ),
    "prior_runner": (
        "a47dcfb493316f23578d4b10e8d832e3bc48512377e4df07c54f27ec11081547"
    ),
    "protected_codec": (
        "6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8"
    ),
}
CONTRACT_COMMIT = "f5989cd5defce561f9ba98e6b18fc2682945f0a2"
FROZEN_DESIGN = "1011259415a0916054eb580687612580bc1e5f09"
BASELINE_HEAD = "94571d2cd9a68bd030c878c406f19a1be6ec53d7"
COLLECTOR_REL = "competition/deepeye/fpga/acquisition/deepeye_sample_scan_capture.sv"
PRIOR_RUNNER_REL = "competition/deepeye/tools/acquisition/run_sample_scan_capture.py"
QUEUE_RTL_REL = "competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv"
TB_REL = "competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv"
CANDIDATE_REL = "competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md"
RUNNER_REL = "competition/deepeye/tools/acquisition/run_raw_scan_queue.py"
PROTECTED_REL = "handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def run(argv: list[str], *, timeout: int = 60) -> dict[str, Any]:
    started = utc_now()
    completed = subprocess.run(
        argv,
        cwd=str(WORKTREE),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        timeout=timeout,
        check=False,
        creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
    )
    return {
        "argv": argv,
        "cwd": str(WORKTREE),
        "exit": completed.returncode,
        "started_at_utc": started,
        "ended_at_utc": utc_now(),
        "stdout": completed.stdout.decode("utf-8", errors="replace"),
        "stderr": completed.stderr.decode("utf-8", errors="replace"),
    }


def file_entry(path: Path, expected: str | None = None) -> dict[str, Any]:
    actual = sha256_file(path)
    return {
        "path": str(path),
        "bytes": path.stat().st_size,
        "sha256": actual,
        "expected_sha256": expected,
        "matches_expected": expected is None or actual == expected,
    }


def canonical_requirements_hash(path: Path) -> tuple[str, list[str]]:
    document = json.loads(path.read_text(encoding="utf-8"))
    requirements = document["requirements"]
    canonical = json.dumps(
        requirements,
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    return sha256_bytes(canonical), [item["id"] for item in requirements]


def main() -> int:
    environment = {
        "python_executable": sys.executable,
        "python_version": sys.version,
        "platform": platform.platform(),
        "cwd": str(Path.cwd()),
        "script": str(Path(__file__).resolve()),
        "tempfile_gettempdir": tempfile.gettempdir(),
        "environment": {
            key: os.environ.get(key)
            for key in (
                "TMP", "TEMP", "TMPDIR", "PYTHONDONTWRITEBYTECODE",
                "PYTHONPYCACHEPREFIX",
            )
        },
    }
    write_json(HERE / "ENVIRONMENT.json", environment)

    author_files = [path for path in HERE.rglob("*") if path.is_file()]
    earliest = min(
        (path.stat().st_mtime for path in author_files),
        default=None,
    )
    start = {
        "schema": 1,
        "task_id": "DEEPEYE-IMPLEMENTATION-20261014",
        "task_version": 1,
        "work_id": "B-RAW-SCAN-QUEUE-RTL-20261022-23-v1",
        "operation_id": "B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23",
        "author_role": "one DeepSeek Flash/max execution child",
        "parent_owner": "Astra-B / product main 01a13b55-095b-7461-8dd5-5476a130bd82",
        "start_record_status": "RECOVERED_FROM_EXISTING_AUTHOR_EVIDENCE",
        "start_not_fabricated": True,
        "recovered_earliest_author_file_utc": (
            None if earliest is None else
            datetime.fromtimestamp(earliest, timezone.utc).isoformat()
        ),
        "initialization_recorded_at_utc": utc_now(),
        "baseline_head": BASELINE_HEAD,
        "contract": {
            "id": "DEEPEYE-HUMAN-LOCK-20261014/revision1",
            "source_commit": CONTRACT_COMMIT,
            "requirements_sha256": EXPECTED["requirements"],
            "all_H01_H15_required": True,
        },
        "frozen_design_commit": FROZEN_DESIGN,
        "board_policy": "A-only; no board operation by this child",
        "not_run": [
            "all29", "B02", "B03", "G05", "B06", "R03", "full_product",
            "system", "CDC_RDC", "board",
        ],
    }
    write_json(HERE / "START.json", start)

    scope_path = SCOPE_DIR / "SCOPE.md"
    consumed_path = SCOPE_DIR / "COORDINATOR_CONTINUE_CONSUMED.json"
    decision_path = DECISION_DIR / "SCOPE_REVIEW_DECISION.json"
    immutable_path = SCOPE_DIR / "inputs/immutable_scope.json"
    requirements_hash, requirement_ids = canonical_requirements_hash(immutable_path)

    contract_probe = run(
        ["git", "show", f"{CONTRACT_COMMIT}:docs/competition/deepeye-2026/immutable_scope.json"]
    )
    contract_source_hash = None
    contract_source_ids: list[str] = []
    if contract_probe["exit"] == 0:
        contract_document = json.loads(contract_probe["stdout"])
        canonical = json.dumps(
            contract_document["requirements"], ensure_ascii=False,
            sort_keys=True, separators=(",", ":"),
        ).encode("utf-8")
        contract_source_hash = sha256_bytes(canonical)
        contract_source_ids = [item["id"] for item in contract_document["requirements"]]
    design_probe = run(["git", "cat-file", "-e", f"{FROZEN_DESIGN}^{{commit}}"])
    head_probe = run(["git", "rev-parse", "HEAD"])

    inputs = {
        "schema": 1,
        "scope_md": file_entry(scope_path, EXPECTED["scope_md"]),
        "coordinator_continue_consumed": file_entry(
            consumed_path, EXPECTED["continue_consumed"]
        ),
        "coordinator_decision": file_entry(decision_path, EXPECTED["decision"]),
        "immutable_requirements": file_entry(immutable_path, EXPECTED["requirements"]),
        "canonical_requirements_recomputed": requirements_hash,
        "requirement_ids": requirement_ids,
        "contract_source_probe": contract_probe,
        "contract_source_canonical_requirements": contract_source_hash,
        "contract_source_requirement_ids": contract_source_ids,
        "frozen_design_probe": design_probe,
        "worktree_head_probe": head_probe,
    }
    write_json(HERE / "INPUTS.json", inputs)

    dependency_paths = [
        ("collector", WORKTREE / COLLECTOR_REL, EXPECTED["collector"]),
        ("prior_runner_read_only", WORKTREE / PRIOR_RUNNER_REL, EXPECTED["prior_runner"]),
        ("protected_codec_input", WORKTREE / PROTECTED_REL, EXPECTED["protected_codec"]),
        ("queue_rtl", WORKTREE / QUEUE_RTL_REL, None),
        ("candidate_document", WORKTREE / CANDIDATE_REL, None),
        ("testbench", WORKTREE / TB_REL, None),
        ("runner", WORKTREE / RUNNER_REL, None),
    ]
    dependencies = {
        "schema": 1,
        "worktree": str(WORKTREE),
        "files": {},
    }
    for label, path, expected in dependency_paths:
        dependencies["files"][label] = file_entry(path, expected)
    dependencies["encoded_frame_queue_distinction"] = file_entry(
        WORKTREE / "competition/deepeye/fpga/stream/deepeye_encoded_frame_queue.sv",
        "68f9b655794a722a5cb285ac1c87749ea7acea7dcd6c1650536d1f1094c2e76a",
    )
    dependencies["block_stream_distinction"] = file_entry(
        WORKTREE / "competition/deepeye/fpga/stream/deepeye_block_stream.sv",
        "c8f8c0d99769efc64a91402ee23e7157368ff90ec765db5c413f02546715fff4",
    )
    write_json(HERE / "DEPENDENCIES.json", dependencies)

    modelsim = Path("D:/modelsim1/win64")
    tool_runs = {}
    for tool in ("vlib", "vlog", "vsim"):
        executable = modelsim / f"{tool}.exe"
        invocation = run([str(executable), "-version"], timeout=30)
        tool_runs[tool] = {
            "executable": str(executable),
            "sha256": sha256_file(executable),
            "invocation": invocation,
        }
    write_json(HERE / "TOOL_VERSIONS.json", {"modelsim": str(modelsim), "tools": tool_runs})

    candidates = [
        shutil.which("vivado"),
        r"D:\Xilinx\Vivado\2022.2\bin\vivado.bat",
        r"C:\Xilinx\Vivado\2022.2\bin\vivado.bat",
    ]
    found = [value for value in candidates if value and Path(value).exists()]
    vivado = {
        "schema": 1,
        "searched": candidates,
        "found": found,
        "status": "not_run_absent" if not found else "found_not_run",
        "blocked": not found,
        "note": (
            "No synthesis or implementation is in this operation. No tool was "
            "installed or invoked beyond path discovery."
        ),
        "recorded_at_utc": utc_now(),
    }
    write_json(HERE / "VIVADO_STATUS.json", vivado)

    ok = (
        head_probe["exit"] == 0
        and head_probe["stdout"].strip() == BASELINE_HEAD
        and design_probe["exit"] == 0
        and contract_source_hash == EXPECTED["requirements"]
        and requirements_hash == EXPECTED["requirements"]
        and requirement_ids == [f"H{index:02d}" for index in range(1, 16)]
        and all(item["matches_expected"] for item in dependencies["files"].values())
    )
    result = {
        "ok": ok,
        "requirements_hash": requirements_hash,
        "contract_source_hash": contract_source_hash,
        "baseline_head": head_probe["stdout"].strip(),
        "vivado_status": vivado["status"],
        "note": (
            "Bounded author initialization evidence only; no product acceptance, "
            "synthesis, board or system result."
        ),
    }
    write_json(HERE / "INIT_RESULT.json", result)
    print(json.dumps(result, ensure_ascii=False, sort_keys=True))
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
