#!/usr/bin/env python3
"""Audit the bounded author evidence and emit a sealed hash manifest."""

from __future__ import annotations

import gzip
import hashlib
import json
import os
from pathlib import Path
import platform
import re
import sys
from datetime import datetime, timezone
from typing import Any


HERE = Path(__file__).resolve().parent
WORKTREE = HERE.parents[5]
REPO = Path("D:/pynq/CarlandFPGA").resolve()
FULL = HERE / "results/full-01"
SELFTEST = HERE / "results/selftest-final-01"

EXPECTED = {
    "scope_md": "a8a48893e71f9642d8cbbdf7c5c23b06f8dfc24c37554cab13421776be33ddc1",
    "continue_consumed": "af0de802d4420845185bfb8544674f38a0e6be37c4a6b5ce80d1bf79991e16c0",
    "decision": "4f7fd365647e3e6c084d72d972f75efe46b2e5675e40abaa4e214340f49c7a17",
    "requirements": "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804",
    "collector": "fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d",
    "prior_runner": "a47dcfb493316f23578d4b10e8d832e3bc48512377e4df07c54f27ec11081547",
    "protected_codec": "6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8",
    "encoded_queue": "68f9b655794a722a5cb285ac1c87749ea7acea7dcd6c1650536d1f1094c2e76a",
    "block_stream": "c8f8c0d99769efc64a91402ee23e7157368ff90ec765db5c413f02546715fff4",
}
BASELINE = "94571d2cd9a68bd030c878c406f19a1be6ec53d7"
RTL = WORKTREE / "competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv"
DOC = WORKTREE / "competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md"
TB = WORKTREE / "competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv"
RUNNER = WORKTREE / "competition/deepeye/tools/acquisition/run_raw_scan_queue.py"
COLLECTOR = WORKTREE / "competition/deepeye/fpga/acquisition/deepeye_sample_scan_capture.sv"
PRIOR_RUNNER = WORKTREE / "competition/deepeye/tools/acquisition/run_sample_scan_capture.py"
PROTECTED = WORKTREE / "handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json"
ENC_QUEUE = WORKTREE / "competition/deepeye/fpga/stream/deepeye_encoded_frame_queue.sv"
BLOCK_STREAM = WORKTREE / "competition/deepeye/fpga/stream/deepeye_block_stream.sv"

QUEUE_CASES = {
    "queue_d1": 1, "queue_d2": 2, "queue_d3": 3,
    "queue_d4_defaults": 4, "queue_d5": 5, "queue_d6": 6,
    "queue_d7": 7, "queue_d8_stat2": 8,
}
COMP_CASES = ["comp_d1", "comp_d3", "comp_d4_defaults", "comp_d5", "comp_exhaust"]
GUARDS = {
    "guard_depth_0": "DEPTH",
    "guard_depth_9": "DEPTH",
    "guard_seq_w_1": "SEQ_W",
    "guard_seq_w_33": "SEQ_W",
    "guard_tick_w_0": "TICK_W",
    "guard_tick_w_65": "TICK_W",
    "guard_tag_w_0": "TAG_W",
    "guard_tag_w_65": "TAG_W",
    "guard_stat_w_1": "STAT_W",
    "guard_stat_w_33": "STAT_W",
    "guard_priority_depth": "DEPTH",
    "guard_healthy": None,
}
CASE_ORDER = (
    list(QUEUE_CASES) + COMP_CASES + list(GUARDS) +
    ["mutant_wrap_depth5", "mutant_cancel_depth5"]
)
EXPECTED_CLASS = {
    **{name: "pass" for name in QUEUE_CASES},
    **{name: "pass" for name in COMP_CASES},
    **{name: "dut_guard_rejected" for name in GUARDS if name != "guard_healthy"},
    "guard_healthy": "healthy",
    "mutant_wrap_depth5": "mutant_rejected",
    "mutant_cancel_depth5": "mutant_rejected",
}
PORTS = [
    "clk", "rst", "cancel", "in_valid", "in_ready", "in_data", "in_ticks",
    "in_quality", "in_first_seq", "in_last_seq", "in_tag", "out_valid",
    "out_ready", "out_data", "out_ticks", "out_quality", "out_first_seq",
    "out_last_seq", "out_tag", "level", "stat_accepted", "stat_retired",
    "stat_aborted",
]
PRODUCT_FILES = [RTL, DOC, TB, RUNNER]
ROOT_EVIDENCE = [
    "START.json", "START_ASSESSMENT.json", "ENVIRONMENT.json", "INPUTS.json", "DEPENDENCIES.json",
    "TOOL_VERSIONS.json", "VIVADO_STATUS.json", "INIT_RESULT.json",
    "evidence_init.py", "run_selftest.ps1", "run_suite.ps1",
    "finalize_evidence.py", "results/evidence-init-01.stdout.log",
    "config/modelsim.ini",
]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def load(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, value: Any) -> None:
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + "\n",
        encoding="utf-8",
        newline="\n",
    )


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def inside(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


class Audit:
    def __init__(self) -> None:
        self.failures: list[str] = []
        self.notes: list[str] = []

    def require(self, condition: bool, message: str) -> bool:
        if not condition:
            self.failures.append(message)
        return condition

    def note(self, message: str) -> None:
        self.notes.append(message)


def trace_fields(line: str) -> dict[str, str]:
    return {
        token.split("=", 1)[0]: token.split("=", 1)[1]
        for token in line.split()[1:]
        if "=" in token
    }


def integer_field(fields: dict[str, str], name: str) -> int | None:
    value = fields.get(name)
    if value is None or value.lower() == "x":
        return None
    try:
        return int(value)
    except ValueError:
        return None


def verify_stream(
    audit: Audit,
    directory: Path,
    label: str,
    stream: dict[str, Any],
) -> dict[str, Any]:
    path = directory / stream["path"]
    audit.require(inside(path, HERE), f"{label}: stream path outside author evidence")
    audit.require(path.is_file(), f"{label}: missing stream {path}")
    if not path.is_file():
        return {}
    raw = path.read_bytes()
    if stream["compressed"]:
        expanded = gzip.decompress(raw)
        audit.require(
            len(expanded) == stream["bytes"],
            f"{label}: {path.name} expanded byte count mismatch",
        )
        audit.require(
            sha256_bytes(expanded) == stream["sha256"],
            f"{label}: {path.name} expanded hash mismatch",
        )
        audit.require(
            len(raw) == stream["compressed_bytes"],
            f"{label}: {path.name} compressed byte count mismatch",
        )
        audit.require(
            sha256_bytes(raw) == stream["compressed_sha256"],
            f"{label}: {path.name} compressed hash mismatch",
        )
    else:
        audit.require(
            sha256_bytes(raw) == stream["sha256"],
            f"{label}: {path.name} file hash mismatch",
        )
        audit.require(
            len(raw) == stream["bytes"],
            f"{label}: {path.name} stored byte count mismatch",
        )
    return {
        "path": str(path),
        "sha256": stream["sha256"],
        "bytes": stream["bytes"],
        "compressed": stream["compressed"],
        "compressed_sha256": stream.get("compressed_sha256"),
        "compressed_bytes": stream.get("compressed_bytes"),
    }


def main() -> int:
    audit = Audit()
    products = {path.name: sha256_file(path) for path in PRODUCT_FILES}
    for path in PRODUCT_FILES:
        audit.require(path.is_file(), f"missing product file {path}")

    inputs = load(HERE / "INPUTS.json")
    init_result = load(HERE / "INIT_RESULT.json")
    dependencies = load(HERE / "DEPENDENCIES.json")
    tools = load(HERE / "TOOL_VERSIONS.json")
    vivado = load(HERE / "VIVADO_STATUS.json")
    start = load(HERE / "START.json")
    start_assessment = load(HERE / "START_ASSESSMENT.json")
    environment = load(HERE / "ENVIRONMENT.json")

    audit.require(init_result.get("ok") is True, "initializer did not pass")
    audit.require(
        inputs.get("canonical_requirements_recomputed") == EXPECTED["requirements"],
        "canonical requirements hash mismatch",
    )
    audit.require(
        inputs.get("contract_source_canonical_requirements") == EXPECTED["requirements"],
        "contract-commit requirements hash mismatch",
    )
    audit.require(
        inputs.get("requirement_ids") == [f"H{i:02d}" for i in range(1, 16)],
        "H01-H15 identity mismatch",
    )
    audit.require(
        inputs.get("worktree_head_probe", {}).get("stdout", "").strip() == BASELINE,
        "baseline HEAD mismatch",
    )
    for input_key, expected_key in (
        ("scope_md", "scope_md"),
        ("coordinator_continue_consumed", "continue_consumed"),
        ("coordinator_decision", "decision"),
    ):
        audit.require(
            inputs.get(input_key, {}).get("sha256") == EXPECTED[expected_key],
            f"input hash mismatch: {input_key}",
        )
        audit.require(
            inputs.get(input_key, {}).get("matches_expected") is True,
            f"input not marked verified: {input_key}",
        )

    dep_files = dependencies.get("files", {})
    dep_expectations = {
        "collector": EXPECTED["collector"],
        "prior_runner_read_only": EXPECTED["prior_runner"],
        "protected_codec_input": EXPECTED["protected_codec"],
    }
    for label, expected in dep_expectations.items():
        audit.require(
            dep_files.get(label, {}).get("sha256") == expected,
            f"dependency hash mismatch: {label}",
        )
    audit.require(
        dependencies.get("encoded_frame_queue_distinction", {}).get("sha256") == EXPECTED["encoded_queue"],
        "encoded-frame-queue distinction hash mismatch",
    )
    audit.require(
        dependencies.get("block_stream_distinction", {}).get("sha256") == EXPECTED["block_stream"],
        "block-stream distinction hash mismatch",
    )
    audit.require(sha256_file(COLLECTOR) == EXPECTED["collector"], "collector changed after init")
    audit.require(sha256_file(PRIOR_RUNNER) == EXPECTED["prior_runner"], "prior runner changed")
    audit.require(sha256_file(PROTECTED) == EXPECTED["protected_codec"], "protected codec input changed")
    audit.require(sha256_file(ENC_QUEUE) == EXPECTED["encoded_queue"], "encoded queue changed")
    audit.require(sha256_file(BLOCK_STREAM) == EXPECTED["block_stream"], "block stream changed")
    for label, path in (
        ("queue_rtl", RTL), ("candidate_document", DOC),
        ("testbench", TB), ("runner", RUNNER),
    ):
        audit.require(
            dep_files.get(label, {}).get("sha256") == sha256_file(path),
            f"initial dependency snapshot differs from final file: {label}",
        )

    vlog_banner = "Model Technology ModelSim SE-64 vlog 10.7 Compiler 2017.12 Dec  7 2017"
    vsim_banner = "Model Technology ModelSim SE-64 vsim 10.7 Simulator 2017.12 Dec  7 2017"
    audit.require(
        vlog_banner in tools["tools"]["vlog"]["invocation"]["stdout"],
        "vlog version mismatch",
    )
    audit.require(
        vsim_banner in tools["tools"]["vsim"]["invocation"]["stdout"],
        "vsim version mismatch",
    )
    audit.require(vivado.get("blocked") is True, "Vivado is unexpectedly available")
    audit.require(vivado.get("status") == "not_run_absent", "Vivado status is not not_run_absent")

    rtl_text = RTL.read_text(encoding="utf-8")
    port_block = rtl_text.split(") (", 1)[1].split(");", 1)[0]
    found_ports = re.findall(
        r"\b(?:input|output)\s+logic(?:\s*\[[^]]+\])?\s+([A-Za-z_]\w*)",
        port_block,
    )
    audit.require(found_ports == PORTS, "RTL public port names/order do not match SCOPE")
    params = dict(re.findall(r"\bparameter\s+int\s+(\w+)\s*=\s*(\d+)", rtl_text))
    audit.require(
        params == {
            "DEPTH": "4", "SEQ_W": "32", "TICK_W": "64",
            "TAG_W": "32", "STAT_W": "32",
        },
        "RTL public parameter defaults/names mismatch",
    )
    for name, default in (("DEPTH_E", "1"), ("SEQ_E", "2"), ("TICK_E", "1"),
                          ("TAG_E", "1"), ("STAT_E", "2")):
        audit.require(f"localparam int {name}" in rtl_text, f"missing safe clamp {name}")
    audit.require(
        "localparam int LEVEL_W = (DEPTH_E <= 1) ? 1 : $clog2(DEPTH_E + 1)" in rtl_text,
        "LEVEL_W definition mismatch",
    )
    for message in [
        "deepeye_raw_scan_queue: DEPTH out of range",
        "deepeye_raw_scan_queue: SEQ_W out of range",
        "deepeye_raw_scan_queue: TICK_W out of range",
        "deepeye_raw_scan_queue: TAG_W out of range",
        "deepeye_raw_scan_queue: STAT_W out of range",
    ]:
        audit.require(rtl_text.count(f'$fatal(1, "{message}")') == 1,
                      f"fatal body missing or duplicated: {message}")

    selftest = load(SELFTEST / "self_test_summary.json")
    audit.require(selftest.get("ok") is True, "synthetic self-test did not pass")
    audit.require(selftest.get("synthetic") is True, "self-test synthetic marker missing")
    entries = selftest.get("entry_negatives", [])
    audit.require(len(entries) == 13, "self-test entry coverage is not 13 cases")
    audit.require(all(item.get("ok") is True for item in entries),
                  "one or more self-test entries failed")
    audit.require(selftest.get("timeout_process", {}).get("ok") is True,
                  "timeout propagation failed")
    audit.require(selftest.get("timeout_process", {}).get("timed_out") is True,
                  "timeout was not observed")
    audit.require(selftest.get("nonzero_process", {}).get("exit") == 9,
                  "nonzero child exit not preserved")
    audit.require(selftest.get("nonzero_process", {}).get("classification_ok") is False,
                  "nonzero child was incorrectly classified as success")
    audit.require(all(selftest.get("direct_checks", {}).values()),
                  "one or more direct runner checks failed")
    selftest_status = load(HERE / "scratch/invoke-selftest-final-01/status.json")
    audit.require(selftest_status.get("exit") == 0, "self-test wrapper exit nonzero")
    audit.require(selftest_status.get("timed_out") is False, "self-test wrapper timed out")

    run_request = load(FULL / "run_request.json")
    summary = load(FULL / "summary.json")
    audit.require(
        Path(run_request["containment_root"]).resolve() == HERE,
        "run containment root mismatch",
    )
    audit.require(
        inside(Path(run_request["tempfile_gettempdir"]), HERE),
        "runner tempdir is outside author evidence",
    )
    audit.require(run_request.get("selected") == CASE_ORDER,
                  "full-suite case list/order mismatch")
    audit.require(summary.get("ok") is True, "full-suite summary is not ok")
    audit.require(summary.get("failed") == [], "full suite has failed cases")
    audit.require(summary.get("missing") == [], "full suite has missing cases")
    audit.require(summary.get("unexpected") == [], "full suite has unexpected cases")
    audit.require(summary.get("selected") == CASE_ORDER, "summary selection mismatch")
    results = summary.get("results", {})
    audit.require(set(results) == set(CASE_ORDER), "summary result keys mismatch")
    audit.require(
        vlog_banner in summary.get("tool_versions", {}).get("vlog", {}).get("standard_output", []),
        "run did not record exact vlog banner",
    )
    audit.require(
        vsim_banner in summary.get("tool_versions", {}).get("vsim", {}).get("standard_output", []),
        "run did not record exact vsim banner",
    )

    case_audit: dict[str, Any] = {}
    coverage = {
        "queue_depths_1_through_8": True,
        "nonpower_depth_wrap": True,
        "same_edge_push_pop": False,
        "full_no_same_edge_credit": False,
        "empty_no_bypass": False,
        "reset_abort_masks_handshakes": False,
        "cancel_abort_masks_handshakes": False,
        "payload_stable_under_stall": False,
        "depth8_stat2_saturates_old_level8": False,
        "composition_overrun_seen": False,
        "composition_wrong_order_seen": False,
        "composition_same_tag_rearm_seen": False,
        "composition_exhaustion_seen": False,
        "composition_unarmed_drain_seen": False,
    }
    for name in CASE_ORDER:
        case_dir = FULL / "cases" / name
        case = load(case_dir / "case.json")
        result = load(case_dir / "result.json")
        expected_class = EXPECTED_CLASS[name]
        audit.require(result.get("ok") is True, f"{name}: result is not ok")
        audit.require(result.get("classification") == expected_class,
                      f"{name}: classification {result.get('classification')} != {expected_class}")
        audit.require(result.get("reasons") == [], f"{name}: result reasons are nonempty")
        audit.require(case.get("name") == name, f"{name}: case name mismatch")
        audit.require(case.get("params", {}).get("DEPTH") ==
                      (QUEUE_CASES.get(name) or case.get("params", {}).get("DEPTH")),
                      f"{name}: DEPTH record mismatch")
        snapshots = case.get("inputs", {})
        audit.require(snapshots.get("rtl_source", {}).get("sha256") == products[RTL.name],
                      f"{name}: RTL source snapshot mismatch")
        if name.startswith("mutant_"):
            audit.require(snapshots.get("mutation") is True,
                          f"{name}: mutation marker missing")
            audit.require(snapshots.get("rtl_input", {}).get("sha256") != products[RTL.name],
                          f"{name}: mutant input unexpectedly equals baseline RTL")
        else:
            audit.require(snapshots.get("rtl_input", {}).get("sha256") == products[RTL.name],
                          f"{name}: RTL input snapshot mismatch")
        audit.require(snapshots.get("tb_source", {}).get("sha256") == products[TB.name],
                      f"{name}: TB source snapshot mismatch")
        audit.require(snapshots.get("tb_input", {}).get("sha256") == products[TB.name],
                      f"{name}: TB input snapshot mismatch")
        if name in COMP_CASES:
            audit.require(
                snapshots.get("collector_source", {}).get("sha256") == EXPECTED["collector"],
                f"{name}: collector source mismatch",
            )
            audit.require(
                snapshots.get("collector_input", {}).get("sha256") == EXPECTED["collector"],
                f"{name}: collector snapshot mismatch",
            )
            audit.require(
                snapshots.get("collector_source", {}).get("pinned") is True,
                f"{name}: collector pin missing",
            )

        stream_records: dict[str, Any] = {}
        for process_name in ("vlib", "vlog", "vsim"):
            process = case.get("processes", {}).get(process_name, {})
            audit.require(process.get("exit") == 0,
                          f"{name}: {process_name} exit {process.get('exit')}")
            audit.require(process.get("timed_out") is False,
                          f"{name}: {process_name} timed out")
            audit.require(inside(Path(process.get("cwd", HERE / "missing")), HERE),
                          f"{name}: {process_name} cwd outside author evidence")
            env = process.get("environment", {})
            for key in ("TMP", "TEMP", "TMPDIR"):
                audit.require(inside(Path(env.get(key, HERE / "missing")), HERE),
                              f"{name}: {process_name} {key} outside author evidence")
            audit.require(env.get("PYTHONDONTWRITEBYTECODE") == "1",
                          f"{name}: {process_name} bytecode guard missing")
            streams = process.get("streams", {})
            audit.require(
                streams.get("stderr", {}).get("bytes") == 0,
                f"{name}: {process_name} stderr is nonempty",
            )
            stream_records[process_name] = {
                key: verify_stream(audit, case_dir, f"{name}/{process_name}", value)
                for key, value in streams.items()
            }

        transcript_path = case_dir / "transcript"
        audit.require(transcript_path.is_file(), f"{name}: transcript missing")
        text = transcript_path.read_text(encoding="utf-8", errors="replace")
        audit.require("** Warning" not in text, f"{name}: warning diagnostic present")
        vlog_path = case_dir / "vlog.stdout.bin"
        vlog_text = vlog_path.read_text(encoding="utf-8", errors="replace")
        audit.require("** Error" not in vlog_text and "** Warning" not in vlog_text,
                      f"{name}: compile diagnostics contain error/warning")

        if name in GUARDS:
            token = GUARDS[name]
            if token is None:
                audit.require("RAW_SCAN_GUARD_ALIVE" in text,
                              "guard_healthy: alive control marker missing")
                audit.require("RAW_SCAN_PASS" in text,
                              "guard_healthy: pass marker missing")
            else:
                message = f"deepeye_raw_scan_queue: {token} out of range"
                fatal_line = f"# ** Fatal: {message}\n"
                audit.require(text.count(fatal_line) == 1,
                              f"{name}: exact own fatal not observed once")
                audit.require(text.count("# ** Fatal:") == 1,
                              f"{name}: unrelated fatal present")
            audit.require("** Error" not in text,
                          f"{name}: unrelated runtime error present")
        else:
            audit.require("** Fatal" not in text or name.startswith("mutant_"),
                          f"{name}: unexpected fatal in passing simulation")

        if expected_class in ("pass", "healthy"):
            stats = result.get("stats", {})
            audit.require(stats.get("errors") == 0, f"{name}: stats errors nonzero")
            marker = "RAW_SCAN_COMP_" if name in COMP_CASES else "RAW_SCAN_"
            trace_token = f"# {marker}TRACE "
            trace_count = sum(1 for line in text.splitlines() if line.startswith(trace_token))
            audit.require(trace_count == result.get("trace_rows"),
                          f"{name}: trace row count mismatch")
            audit.require(text.count(f"# {marker}STATS ") == 1,
                          f"{name}: stats marker not unique")
            audit.require(text.count(f"# {marker}PASS") == 1,
                          f"{name}: pass marker not unique")
            audit.require(f"# {marker}FAIL" not in text,
                          f"{name}: fail marker present")
            audit.require(f"# {marker}MISMATCH" not in text,
                          f"{name}: mismatch marker present in passing case")
        elif name in GUARDS:
            audit.require(result.get("trace_rows") is None,
                          f"{name}: guard unexpectedly has trace rows")
            audit.require(result.get("stats") is None,
                          f"{name}: guard unexpectedly has stats")
        else:
            mismatches = result.get("mismatches", [])
            audit.require(len(mismatches) > 0, f"{name}: no behavioral mismatches")
            audit.require(result.get("stats", {}).get("errors", 0) > 0,
                          f"{name}: stats errors do not reflect mutation")
            audit.require("# RAW_SCAN_FAIL" in text,
                          f"{name}: mutation run lacks fail marker")

        if name in QUEUE_CASES:
            stats = result["stats"]
            audit.require(stats.get("depth") == QUEUE_CASES[name],
                          f"{name}: directed depth mismatch")
            lines = [line for line in text.splitlines() if line.startswith("# RAW_SCAN_TRACE ")]
            parsed = [trace_fields(line) for line in lines]
            for index in range(0, len(parsed) - 1, 2):
                pre, post = parsed[index], parsed[index + 1]
                if pre.get("side") != "pre" or post.get("side") != "post":
                    continue
                level = integer_field(pre, "level")
                depth = QUEUE_CASES[name]
                if level is not None and 0 < level < depth:
                    if (pre.get("in_valid") == "1" and pre.get("in_ready") == "1"
                            and pre.get("out_valid") == "1" and pre.get("out_ready") == "1"):
                        coverage["same_edge_push_pop"] = True
                if (level == depth and pre.get("out_ready") == "1"
                        and pre.get("in_valid") == "1"
                        and pre.get("in_ready") == "0"):
                    coverage["full_no_same_edge_credit"] = True
                if level == 0 and pre.get("out_ready") == "1" and pre.get("out_valid") == "0":
                    coverage["empty_no_bypass"] = True
                if pre.get("rst") == "1" and pre.get("in_ready") == "0" and pre.get("out_valid") == "0":
                    coverage["reset_abort_masks_handshakes"] = True
                if pre.get("cancel") == "1" and pre.get("in_ready") == "0" and pre.get("out_valid") == "0":
                    coverage["cancel_abort_masks_handshakes"] = True
                if (pre.get("out_valid") == "1" and pre.get("out_ready") == "0"
                        and pre.get("rst") == "0" and pre.get("cancel") == "0"):
                    same = all(post.get(key) == pre.get(key) for key in (
                        "out_data", "out_ticks", "out_quality",
                        "out_first_seq", "out_last_seq", "out_tag"))
                    coverage["payload_stable_under_stall"] |= same
            if name == "queue_d8_stat2":
                coverage["depth8_stat2_saturates_old_level8"] = any(
                    integer_field(fields, "stat_aborted") == 3
                    and integer_field(fields, "level") == 0
                    for fields in parsed
                )
            if QUEUE_CASES[name] in (1, 3, 5, 6, 7):
                if stats.get("wrap_writes", 0) == 0 or stats.get("wrap_reads", 0) == 0:
                    coverage["nonpower_depth_wrap"] = False
            if name == "queue_d1" and stats.get("wrap_writes", 0) == 0:
                coverage["nonpower_depth_wrap"] = False

        if name in COMP_CASES:
            parsed = [trace_fields(line) for line in text.splitlines()
                      if line.startswith("# RAW_SCAN_COMP_TRACE ")]
            coverage["composition_overrun_seen"] |= any(
                fields.get("c_overrun_event") == "1" for fields in parsed)
            coverage["composition_wrong_order_seen"] |= any(
                fields.get("c_order_event") == "1" for fields in parsed)
            rearm_tags = [
                fields.get("rearm_tag") for fields in parsed
                if fields.get("rearm") == "1" and fields.get("rearm_tag") not in (None, "x")
            ]
            if any(rearm_tags.count(tag) >= 2 for tag in set(rearm_tags)):
                coverage["composition_same_tag_rearm_seen"] = True
            if name == "comp_exhaust":
                stats = result["stats"]
                coverage["composition_exhaustion_seen"] |= stats.get("c_exhausted") == 1
                coverage["composition_unarmed_drain_seen"] |= any(
                    fields.get("c_armed") == "0"
                    and fields.get("sample_strobe") == "1"
                    and fields.get("consumer_ready") == "1"
                    for fields in parsed)

        case_audit[name] = {
            "ok": result.get("ok"),
            "classification": result.get("classification"),
            "params": case.get("params"),
            "stats": result.get("stats"),
            "trace_rows": result.get("trace_rows"),
            "mismatch_count": len(result.get("mismatches", [])) if name.startswith("mutant_") else 0,
            "transcript_sha256": sha256_file(transcript_path),
            "transcript_bytes": transcript_path.stat().st_size,
            "streams": stream_records,
        }

    audit.require(coverage["queue_depths_1_through_8"], "not all depths 1..8 exercised")
    audit.require(coverage["nonpower_depth_wrap"], "nonpower wrap coverage missing")
    for key in (
        "same_edge_push_pop", "full_no_same_edge_credit", "empty_no_bypass",
        "reset_abort_masks_handshakes", "cancel_abort_masks_handshakes",
        "payload_stable_under_stall", "depth8_stat2_saturates_old_level8",
        "composition_overrun_seen", "composition_wrong_order_seen",
        "composition_same_tag_rearm_seen", "composition_exhaustion_seen",
        "composition_unarmed_drain_seen",
    ):
        audit.require(coverage[key] is True, f"coverage predicate failed: {key}")

    wrap_result = load(FULL / "cases/mutant_wrap_depth5/result.json")
    audit.require(
        any(row == ["data", 4096, 4100] for row in wrap_result.get("mismatches", [])),
        "wrap mutant lacks numeric data 4096 -> 4100 counterexample",
    )
    cancel_result = load(FULL / "cases/mutant_cancel_depth5/result.json")
    audit.require(
        any(row == ["level", 0, 5] for row in cancel_result.get("mismatches", [])),
        "cancel mutant lacks numeric level 0 -> 5 counterexample",
    )

    generated = utc_now()
    final_audit = {
        "schema": 1,
        "task_id": "DEEPEYE-IMPLEMENTATION-20261014",
        "task_version": 1,
        "work_id": "B-RAW-SCAN-QUEUE-RTL-20261022-23-v1",
        "operation_id": "B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23",
        "generated_at_utc": generated,
        "ok": not audit.failures,
        "failures": audit.failures,
        "notes": audit.notes,
        "baseline_head": BASELINE,
        "contract": {
            "id": "DEEPEYE-HUMAN-LOCK-20261014",
            "revision": 1,
            "source_commit": "f5989cd5defce561f9ba98e6b18fc2682945f0a2",
            "frozen_design_commit": "1011259415a0916054eb580687612580bc1e5f09",
            "requirements_sha256": EXPECTED["requirements"],
            "requirement_ids": [f"H{i:02d}" for i in range(1, 16)],
        },
        "products": products,
        "dependencies": {
            "collector": EXPECTED["collector"],
            "prior_runner_read_only": EXPECTED["prior_runner"],
            "protected_codec_input": EXPECTED["protected_codec"],
            "encoded_frame_queue_distinction": EXPECTED["encoded_queue"],
            "block_stream_distinction": EXPECTED["block_stream"],
        },
        "tools": {
            "vlog": vlog_banner,
            "vsim": vsim_banner,
            "vlib_version_invocation_exit": tools["tools"]["vlib"]["invocation"]["exit"],
            "vivado": vivado,
        },
        "environment": {
            "python": environment.get("python_version"),
            "platform": environment.get("platform"),
            "tempfile_gettempdir": environment.get("tempfile_gettempdir"),
            "environment": environment.get("environment"),
            "contained": inside(Path(environment.get("tempfile_gettempdir", "")), HERE),
        },
        "start": start,
        "start_assessment": start_assessment,
        "selftest": {
            "ok": selftest.get("ok"),
            "synthetic": selftest.get("synthetic"),
            "entry_count": len(entries),
            "actual_python_entry_negatives": len(selftest.get("actual_python_entry_negatives", [])),
            "timeout": selftest.get("timeout_process"),
            "nonzero": selftest.get("nonzero_process"),
            "direct_checks": selftest.get("direct_checks"),
            "summary_sha256": sha256_file(SELFTEST / "self_test_summary.json"),
        },
        "preflight": {
            "requirements_hash": inputs.get("canonical_requirements_recomputed"),
            "contract_source_hash": inputs.get("contract_source_canonical_requirements"),
            "scope_md": inputs.get("scope_md"),
            "continue_consumed": inputs.get("coordinator_continue_consumed"),
            "coordinator_decision": inputs.get("coordinator_decision"),
        },
        "full_suite": {
            "case_count": len(results),
            "classification_counts": {
                cls: sum(1 for item in results.values() if item.get("classification") == cls)
                for cls in sorted(set(item.get("classification") for item in results.values()))
            },
            "coverage": coverage,
            "cases": case_audit,
            "summary_sha256": sha256_file(FULL / "summary.json"),
            "run_request_sha256": sha256_file(FULL / "run_request.json"),
            "runner_status": load(HERE / "scratch/invoke-full-01/status.json"),
        },
        "not_run": [
            "independent main model/vector review and acceptance",
            "Vivado synthesis",
            "implementation and timing",
            "CDC/RDC analysis",
            "all29, B02, B03, G05, B06, R03",
            "physical board and full-system tests",
        ],
        "claim_boundary": (
            "Bounded author execution evidence only. This is not full product, "
            "all29, synthesis, timing, CDC/RDC, board or system acceptance."
        ),
    }
    write_json(HERE / "FINAL_AUDIT.json", final_audit)
    if audit.failures:
        print(json.dumps({"ok": False, "failures": audit.failures}, indent=2))
        return 1

    commands = {
        "schema": 1,
        "generated_at_utc": generated,
        "evidence_init": {
            "argv": [
                r"D:\pynq\CarlandFPGA\.local\venv\Scripts\python.exe",
                "-B", "-X", "utf8", str(HERE / "evidence_init.py"),
            ],
            "cwd": str(HERE),
            "environment": environment.get("environment"),
            "exit": 0 if init_result.get("ok") else 1,
            "stdout_log": str(HERE / "results/evidence-init-01.stdout.log"),
            "stdout_log_sha256": sha256_file(HERE / "results/evidence-init-01.stdout.log"),
        },
        "selftest": selftest_status,
        "full_suite": {
            "wrapper": str(HERE / "run_suite.ps1"),
            "wrapper_args": ["-OutName", "full-01", "-Suite", "all"],
            "runner_argv": [
                r"D:\pynq\CarlandFPGA\.local\venv\Scripts\python.exe",
                "-B", "-X", "utf8", str(RUNNER), "--root", str(WORKTREE),
                "--out", str(FULL), "--modelsim", r"D:\modelsim1\win64",
                "--modelsim-ini", str(HERE / "config/modelsim.ini"),
                "--containment-root", str(HERE), "--suite", "all",
            ],
            "status": load(HERE / "scratch/invoke-full-01/status.json"),
            "selected_cases": CASE_ORDER,
        },
        "tool_version_probes": tools,
    }
    write_json(HERE / "FINAL_COMMANDS.json", commands)

    summary_md = f"""# Raw scan queue author result

Operation: `B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23`  
Work: `B-RAW-SCAN-QUEUE-RTL-20261022-23-v1`  
Baseline: `{BASELINE}`

## Result

- Bounded author suite: **PASS**, 27/27 selected cases.
- Queue function: 8/8 depths 1-8, including non-power depths 1, 3, 5, 6, 7.
- Composition: 5/5; overrun, wrong order, same-tag rearm, terminal exhaustion,
  and unarmed drain are represented in retained traces/checks.
- Parameter guards: 11/11; ten one-invalid probes plus DEPTH-priority control.
- Healthy control: 1/1; compiled and passed at minimal legal bounds.
- Compiled mutants: 2/2 rejected with numeric counterexamples
  (`data 4096 -> 4100`; `level 0 -> 5`).
- Synthetic runner self-test: PASS; parser negatives and actual Python process
  timeout/nonzero propagation retained separately.
- Raw ModelSim streams, transcripts, source snapshots, argv, cwd, environment,
  exit, timeout and stream hashes are retained. ModelSim SE-64 10.7/2017.12.

## Not run

Independent main review/acceptance, synthesis, implementation, timing, CDC/RDC,
all29, B02, B03, G05, B06, R03, physical board, and full-system testing were
not run. Vivado is absent on this node and was not installed or invoked.

This is bounded author evidence, not product acceptance.
"""
    (HERE / "FINAL_RUN_SUMMARY.md").write_text(summary_md, encoding="utf-8", newline="\n")

    selected: dict[Path, str] = {}
    for path in PRODUCT_FILES:
        selected[path.resolve()] = sha256_file(path)
    for rel in ROOT_EVIDENCE:
        path = HERE / rel
        if path.is_file():
            selected[path.resolve()] = sha256_file(path)
    for result_dir in (HERE / "results").iterdir():
        if not result_dir.is_dir():
            continue
        for path in result_dir.rglob("*"):
            if not path.is_file():
                continue
            if path.parent == (HERE / "results") and path.name.startswith("finalize-"):
                continue
            parts = set(path.parts)
            if parts.intersection({"work", "lib", "cache", "tmp"}):
                continue
            selected[path.resolve()] = sha256_file(path)
    for invoke_dir in (HERE / "scratch").glob("invoke-*"):
        for path in invoke_dir.rglob("*"):
            if path.is_file() and path.suffix.lower() in {".json", ".log"}:
                selected[path.resolve()] = sha256_file(path)
    for name in ("FINAL_AUDIT.json", "FINAL_COMMANDS.json", "FINAL_RUN_SUMMARY.md"):
        path = HERE / name
        selected[path.resolve()] = sha256_file(path)

    def display_path(path: Path) -> str:
        try:
            return path.relative_to(WORKTREE).as_posix()
        except ValueError:
            return path.as_posix()

    ordered = {
        display_path(path): digest
        for path, digest in sorted(selected.items(), key=lambda item: display_path(item[0]))
    }
    file_hashes = {
        "schema": 1,
        "generated_at_utc": generated,
        "worktree": str(WORKTREE),
        "file_count": len(ordered),
        "files": ordered,
        "excluded_from_manifest": [
            "derived ModelSim work/library directories",
            "cache/tmp directories",
            "FINAL_FILE_HASHES.json, SHA256SUMS.txt and FINAL_MANIFEST_SEAL.json",
        ],
    }
    write_json(HERE / "FINAL_FILE_HASHES.json", file_hashes)
    manifest_lines = [f"{digest}  {path}" for path, digest in ordered.items()]
    manifest = "\n".join(manifest_lines) + "\n"
    (HERE / "SHA256SUMS.txt").write_text(manifest, encoding="utf-8", newline="\n")
    seal = {
        "schema": 1,
        "generated_at_utc": generated,
        "file_hashes_sha256": sha256_file(HERE / "FINAL_FILE_HASHES.json"),
        "sha256sums_sha256": sha256_file(HERE / "SHA256SUMS.txt"),
        "file_hashes_bytes": (HERE / "FINAL_FILE_HASHES.json").stat().st_size,
        "sha256sums_bytes": (HERE / "SHA256SUMS.txt").stat().st_size,
        "file_count": len(ordered),
    }
    write_json(HERE / "FINAL_MANIFEST_SEAL.json", seal)
    print(json.dumps({"ok": True, **seal}, indent=2, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
