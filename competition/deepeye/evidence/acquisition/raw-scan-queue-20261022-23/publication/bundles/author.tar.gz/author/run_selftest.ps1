param(
    [Parameter(Mandatory=$true)][string]$OutName
)

$ErrorActionPreference = 'Stop'
$authorRoot = Split-Path -Parent $PSCommandPath
$worktreeRoot = (Resolve-Path (Join-Path $authorRoot '..\..\..\..\..\..\')).Path
$runner = Join-Path $worktreeRoot 'competition\deepeye\tools\acquisition\run_raw_scan_queue.py'
$results = Join-Path $authorRoot 'results'
$invokeRoot = Join-Path $authorRoot ('scratch\invoke-' + $OutName)
$tempRoot = Join-Path $authorRoot 'tmp'
$cacheRoot = Join-Path $authorRoot 'cache\pycache'
$out = Join-Path $results $OutName
New-Item -ItemType Directory -Force -Path $results,$invokeRoot,$tempRoot,$cacheRoot | Out-Null

$env:TMP = $tempRoot
$env:TEMP = $tempRoot
$env:TMPDIR = $tempRoot
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONPYCACHEPREFIX = $cacheRoot

$argv = @(
    'D:\pynq\CarlandFPGA\.local\venv\Scripts\python.exe',
    '-B', '-X', 'utf8', $runner,
    '--self-test',
    '--self-test-out', $out
)
$started = Get-Date
Push-Location $invokeRoot
try {
    & $argv[0] @($argv[1..($argv.Count - 1)]) 1>selftest.stdout.log 2>selftest.stderr.log
    $exitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
$ended = Get-Date
$stdoutPath = Join-Path $invokeRoot 'selftest.stdout.log'
$stderrPath = Join-Path $invokeRoot 'selftest.stderr.log'
$status = [ordered]@{
    suite = 'self-test'
    out = $out
    argv = $argv
    exit = $exitCode
    timed_out = $false
    started_at = $started.ToString('o')
    ended_at = $ended.ToString('o')
    cwd = $invokeRoot
    output_root = $results
    TMP = $env:TMP
    TEMP = $env:TEMP
    TMPDIR = $env:TMPDIR
    PYTHONDONTWRITEBYTECODE = $env:PYTHONDONTWRITEBYTECODE
    PYTHONPYCACHEPREFIX = $env:PYTHONPYCACHEPREFIX
    stdout = $stdoutPath
    stderr = $stderrPath
    stdout_bytes = (Get-Item -LiteralPath $stdoutPath).Length
    stderr_bytes = (Get-Item -LiteralPath $stderrPath).Length
    stdout_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $stdoutPath).Hash.ToLowerInvariant()
    stderr_sha256 = (Get-FileHash -Algorithm SHA256 -LiteralPath $stderrPath).Hash.ToLowerInvariant()
}
$status | ConvertTo-Json -Depth 5 | Set-Content -Encoding utf8 (Join-Path $invokeRoot 'status.json')
Get-Content -LiteralPath $stdoutPath
Get-Content -LiteralPath $stderrPath
exit $exitCode
