param(
    [Parameter(Mandatory=$true)][string]$OutName,
    [Parameter(Mandatory=$true)][ValidateSet('core','guards','mutants','all')][string]$Suite,
    [string]$Case = ''
)

$ErrorActionPreference = 'Stop'
$authorRoot = Split-Path -Parent $PSCommandPath
$worktreeRoot = (Resolve-Path (Join-Path $authorRoot '..\..\..\..\..\..\')).Path
$runner = Join-Path $worktreeRoot 'competition\deepeye\tools\acquisition\run_raw_scan_queue.py'
$results = Join-Path $authorRoot 'results'
$invokeRoot = Join-Path $authorRoot ('scratch\invoke-' + $OutName)
$tempRoot = Join-Path $authorRoot 'tmp'
$cacheRoot = Join-Path $authorRoot 'cache\pycache'
New-Item -ItemType Directory -Force -Path $results,$invokeRoot,$tempRoot,$cacheRoot | Out-Null

$env:TMP = $tempRoot
$env:TEMP = $tempRoot
$env:TMPDIR = $tempRoot
$env:PYTHONDONTWRITEBYTECODE = '1'
$env:PYTHONPYCACHEPREFIX = $cacheRoot

$out = Join-Path $results $OutName
$runnerArgs = @(
    '-B', '-X', 'utf8', $runner,
    '--root', $worktreeRoot,
    '--out', $out,
    '--modelsim', 'D:\modelsim1\win64',
    '--modelsim-ini', (Join-Path $authorRoot 'config\modelsim.ini'),
    '--containment-root', $authorRoot,
    '--suite', $Suite
)
if ($Case -ne '') {
    $runnerArgs += @('--case', $Case)
}

$started = Get-Date
Push-Location $invokeRoot
try {
    & 'D:\pynq\CarlandFPGA\.local\venv\Scripts\python.exe' @runnerArgs 1>suite.stdout.log 2>suite.stderr.log
    $exitCode = $LASTEXITCODE
}
finally {
    Pop-Location
}
$ended = Get-Date
$status = [ordered]@{
    suite = $Suite
    case = $Case
    out = $out
    exit = $exitCode
    started_at = $started.ToString('o')
    ended_at = $ended.ToString('o')
    cwd = $invokeRoot
    TMP = $env:TMP
    TEMP = $env:TEMP
    TMPDIR = $env:TMPDIR
    PYTHONDONTWRITEBYTECODE = $env:PYTHONDONTWRITEBYTECODE
    PYTHONPYCACHEPREFIX = $env:PYTHONPYCACHEPREFIX
    stdout = (Join-Path $invokeRoot 'suite.stdout.log')
    stderr = (Join-Path $invokeRoot 'suite.stderr.log')
}
$status | ConvertTo-Json | Set-Content -Encoding utf8 (Join-Path $invokeRoot 'status.json')
Get-Content (Join-Path $invokeRoot 'suite.stdout.log')
Get-Content (Join-Path $invokeRoot 'suite.stderr.log')
exit $exitCode
