module scratch_param #(
    parameter int A = 4,
    localparam int AE = (A < 1) ? 1 : A,
    localparam int LW = (AE <= 1) ? 1 : $clog2(AE + 1)
) (
    input logic [LW-1:0] x,
    output logic [LW-1:0] y
);
    assign y = x;
endmodule
