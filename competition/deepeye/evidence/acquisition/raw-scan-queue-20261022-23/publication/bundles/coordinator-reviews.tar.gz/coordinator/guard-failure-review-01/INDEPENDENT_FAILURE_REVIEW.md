# Op23 guard-clamp failure: confirmed REVISE with one bounded repair

The existing coordinator independently confirms OP23-GUARD-CLAMP01 at final local RTL SHA256 5a72ef652ad0ba803504ec69a63c819404376090df5e968b182434ef8150c4af. The frozen candidate scope SHA256 a8a48893e71f9642d8cbbdf7c5c23b06f8dfc24c37554cab13421776be33ddc1 explicitly selects the lower safe fallback for every illegal requested value. The implementation and its author's testbench instead select the maximum legal value for upper-invalid requests. This is a real scope-conformance defect, not an independent-parser false negative.

The coordinator read the complete RTL, both author testbench declaration sections, candidate parameter documentation, main frozen fixture and the five original guard streams. All five compile normally and exit the saved simulator process with code0, but produce vsim-3015 warnings before their exact own fatal. Their warning counts are1/4/2/2/3 for DEPTH9/SEQ33/TICK65/TAG65/STAT33. The requested guard contract rejects such warnings. In particular DEPTH9 makes DUT level four bits while the frozen fixture correctly supplies one bit. A fatal substring or process exit0 cannot turn this into a clean guard pass.

FAILURE_VERIFICATION.json verifies all1020 local main-manifest artifacts, all48 predispatch freeze files, four current author source hashes, the five sets of vlib/vlog/vsim original stdout/stderr hashes and exact source snapshots, the original baseline-result hash, original mutant result hashes, prior CONTINUE consumption pins, protected codec and six cancelled-audit file bytes. It independently confirms the author is completed/terminal/nonstale, pool0/no active job/no repair-work duplicate, local HEAD unchanged and index/unmerged empty. No simulator, product tests, network request or publication ran in this coordination review.

The main's17 positive cases/87836 edges remain valid saved observations at the old exact RTL hash. The coordinator consumed their classifications and file integrity but did not independently recalculate every trace edge here. They do not override five mandatory guard failures or qualify the corrected source in advance. Author27/27 remains author-only evidence. Full independent qualification of the separate author runner is still outstanding. The earlier delayed CONTINUE consumption file is now actually read and verified; the previous bounded-wait receipt remains an honest historical pending observation.

## Exactly authorized correction

Retain DEEPEYE-IMPLEMENTATION-20261014/v1, existing product thread, worktree, parent work and unpublished product operation23. Use one fresh explicit correction author work B-RAW-SCAN-QUEUE-GUARD-REPAIR-20261022-23-v1, instruction B-OP23-GUARD-CLAMP01-REPAIR-20261022-v1. This is a new remaining-work assignment, not a replay of the completed author job. No new product root, native worker or public operation is created.

The sole new Flash/max author may edit only:

1. competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv — only the five effective-constant initializer expressions.
2. competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv — only matching effective declaration fallback expressions where needed; do not change legal test behavior or acceptance rules.
3. competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md — accurately document legal-range selection and lower safe fallbacks; no broader scope or acceptance claim.
4. competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/author/repair01/ — new correction-only evidence, snapshots and contained tool work.

All paths are relative to the existing implementation worktree. The author runner at dbba5297accb6cbd9f64c2ca2b07651a929f75658593cee0cbbca141dce7ba85 is read-only in this correction assignment. Old author evidence, original FINAL_FILE_HASHES, main frozen oracle/TB/vectors, private FINAL_RECEIPT and main REVIEW/REVIEW_DECISION/LOCAL_REVIEW_MANIFEST are immutable. The product main uses fresh main/repair01/ and private repair01/ subtrees, retains its already authorized handoff ownership and snapshots old canonical source bytes before editing. Historical manifests remain historical: use original source snapshots to resolve their old hashes, not rewritten manifests or a claim that the now-edited canonical path is unchanged.

Required expressions are semantically exactly:

```
DEPTH_E = (DEPTH >= 1 && DEPTH <= 8) ? DEPTH : 1
SEQ_E   = (SEQ_W >= 2 && SEQ_W <= 32) ? SEQ_W : 2
TICK_E  = (TICK_W >= 1 && TICK_W <= 64) ? TICK_W : 1
TAG_E   = (TAG_W >= 1 && TAG_W <= 64) ? TAG_W : 1
STAT_E  = (STAT_W >= 2 && STAT_W <= 32) ? STAT_W : 2
```

Keep non-overridable local constants, all legal parameter declarations and data/control logic, exact own-fatal messages and priority unchanged. An illegal requested value still fails its time-zero guard; the safe fallback is only for clean diagnostic elaboration. No main fixture widening, parser relaxation, warning suppression, acceptance-marker change, extra feature or old collector edit is authorized.

## Remaining validation and completion

Before dispatch, the product quality main freezes the repair inputs, permitted diff, exact old hashes, required guard outcomes and ownership. Set actual child temporary/cache/work directories before running helpers. Child's new results must bind corrected source and new paths; original assignment timestamp limitations stay explicit.

The child runs the affected guard fixture plus its legal control on corrected bytes into a new repair output. The product main independently reviews the exact diff and legal-range equivalence, and runs its unchanged30-case baseline once against the corrected source:17 positive queue/composition cases, ten individual illegal probes, two legal controls and competing-invalid priority. This new-source regression is justified by changed parameter declarations; it is not a historical suite replay. Freeze the new run intent and source binding, retain all failed originals, and keep main oracle/vectors/TB/parser unchanged.

Retain the existing numeric M_WRAP/M_CANCEL counterexamples and independent classifier qualification. No automatic replay of unchanged classifier tests or old mutants is required merely to increase counts. If new-source mutant binding is needed, the quality main must identify that specific purpose and preserve a distinct new result; never label old mutant bytes as a fresh run. Any changed classifier or additional functional RTL change would require reassessment before claiming old qualification transfers.

Complete the already-required independent qualification of the author's separate product runner after the guard repair. Use independently defined direct and actual-entry process/parser negative controls, exact guard/failure/warning behavior and preserved raw streams; do not promote author self-tests alone. Expectations frozen now are a new qualification freeze, not falsely dated before the original author. The correction child does not edit that runner. If qualification finds another concrete blocking defect, return that evidence for a bounded follow-up; do not spawn another correction worker, broaden this repair or publish a failed candidate.

Only after all mandatory gates actually pass may the existing main publish op23 once on PR30 with a new source/request/manifest. Use a new repair final receipt location; preserve original FINAL_RECEIPT REVISE. Unknown writes are reconciled, never replayed. Return actual repaired completion or concrete failure through the supported App route to the existing coordinator. Accepted completion also goes once to the retained original desktop. No scope-only reapproval or human continuation question is needed for this exact correction.

H01-H15, DEEPEYE-HUMAN-LOCK-20261014/revision1, requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804, pin f5989cd5defce561f9ba98e6b18fc2682945f0a2 and design1011259415a0916054eb580687612580bc1e5f09 are unchanged. All29/B02/B03/G05/B06/R03/full-product simulation/synthesis/implementation/timing/CDC_RDC/board/system remain not_run. Only the reported bounded internal RTL observations exist; board A-only and no public ABI/source/clock/DMA/PS/freshness/motion authority.
