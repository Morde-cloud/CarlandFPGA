# Op23 repair02: explicit main recovery after reconciled failed assignment

Decision: retain REVISE and authorize the existing product quality main to perform one bounded local recovery covering OP23-GUARD-CLAMP01, OP23-RUNNER-TRACE01 and OP23-RUNNER-COUNT01. No publication is authorized by this recovery instruction. Return a concrete repaired candidate and evidence for coordinator review before commit/publication.

Task remains DEEPEYE-IMPLEMENTATION-20261014/v1, product thread01a13b55-095b-7461-8dd5-5476a130bd82, parent B-LOCAL-RAW-SCAN-QUEUE-CONTINUE-20261022-v1, product operation B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23. New recovery instruction B-OP23-GUARD-RUNNER-MAIN-RECOVERY-20261022-v1; stable main work B-RAW-SCAN-QUEUE-MAIN-RECOVERY-20261022-23-v1. The original scope SHA256 a8a48893e71f9642d8cbbdf7c5c23b06f8dfc24c37554cab13421776be33ddc1 and functional interface do not change.

## Reconciliation and execution choice

child-9eb5998637bd410db4320f7dbc76f311 is actually failed, terminal and nonstale. It produced only its intake JSON and patch; the four canonical source hashes are unchanged. Its original TimeoutError is preserved. Creation-to-terminal elapsed time is8729.066351seconds; the error mentions3600seconds, but the internal timing/root cause is not established. This review neither retries the failed work ID nor claims a corrected source exists.

The coordinator verified all743 repair01 manifest artifacts, exact source/intake bytes, four false-positive direct/CLI records and two successful normal-main subprocess entries carrying corrupted evidence. Current supported status has no active implementation job and no Flash pool instance. It also contains an unrelated reserved DEEPEYE-PHYSICAL-CONCEPT-20261021/projectbook-page-layout-03 job with no declared file ownership. Do not call this global zero-active state or touch that reservation. A scoped process observation found no ModelSim processes or Python helpers matching op23/failed-turn paths; it is a bounded observation, not a universal proof of all possible writers.

Before taking writes, the existing product main must freshly verify failed terminal/no active overlapping writer and inspect any concrete lingering external process evidence. Do not kill/restart a service, change SQL/queues/locks, or infer release from timeout alone. If a real overlapping writer remains, report that exact blocker. Otherwise persist a MAIN_TAKEOVER receipt with old/new owner, release evidence, exact paths and hashes. The prior failed child and its evidence stay unchanged.

No new execution child is authorized in this phase. The ordinary Flash route was actually attempted; the remaining work now includes critical evidence-validator design and failure recovery, which belongs to the quality main. The same existing product main performs the small guard correction and validator repair under a new explicit work, with no second root, native lease/App worker or failed-job replay. This is a bounded ownership transfer after reconciliation, not a general replacement of the Flash route.

## Exact ownership and preservation

Existing worktree: D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014.

The product main may modify only these four canonical files for the described defects:

1. competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv — only five effective-width initializer expressions; old SHA2565a72ef652ad0ba803504ec69a63c819404376090df5e968b182434ef8150c4af.
2. competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv — matching declaration fallbacks; strictly necessary evidence/coverage instrumentation only under a separately frozen rationale, never legal stimulus, DUT behavior or weakened expectations. Old SHA256ff95ada740ef39bebd176eba11d8b7f0e7720fdaa2424fa0e7036ce8081dacd0.
3. competition/deepeye/tools/acquisition/run_raw_scan_queue.py — trace grammar/history/statistics qualification and corresponding coherent self-test fixtures. Old SHA256dbba5297accb6cbd9f64c2ca2b07651a929f75658593cee0cbbca141dce7ba85.
4. competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md — exact fallback and evidence-validation semantics, with honest main-authored repair provenance. Old SHA2565230ff2f0a05edae452444940cc78ba7f68ff534d3eff763aa107870430a62e8.

New helpers, snapshots, fixtures, logs, work libraries and review artifacts belong only under competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/main/repair02/ and D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/raw-scan-queue-20261022-23/repair02/. The repaired public runner must not depend at runtime on B-private files, main-only oracle code or unshipped helpers. Keep it self-contained in its authorized canonical file where practical.

All author directories, original and repair01 receipts/manifests/failures, original main oracle/TB/vectors/expected outputs/classifier and old08–22 sources remain read-only. Preserve protected codec rawSHA6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8 and six misplaced cancelled-audit files. Capture old canonical bytes in repair02 before edits, retaining an explicit old-path/hash-to-snapshot map. Do not rewrite historical manifests to point at new sources. Source/authorship/time claims remain exact.

## Repair requirements

### Guard fallback

Use legal-range selection with lower safe fallback: DEPTH1..8 else1; SEQ_W2..32 else2; TICK_W1..64 else1; TAG_W1..64 else1; STAT_W2..32 else2. Preserve non-overridable effective constants, all legal data/control logic, exact time-zero fatal strings and priority. Do not widen the frozen independent main fixture or suppress its warnings.

### Complete trace validation

Replace row-count-only acceptance with a real parser for both queue and composition records. Freeze the exact supported field sets, numeric bases/widths, case/parameter binding, side ordering and cycle pairing before editing. The current TB emits pre cycleN followed by post cycleN+1; do not impose a different convention accidentally. Reject missing/duplicate/unknown fields, malformed or trailing token text, wrong case, duplicate/missing/reordered phases/cycles, incorrect row multiplicity and inconsistent identities. A marker plus any arbitrary body or the correct number of truncated rows is never a complete record.

Validate two-state control/counter values and legal ranges wherever the contract defines them. Preserve unknown-bit spellings in fields that are legitimately unspecified: invalid output payload and registered state before the first applied reset must not be silently converted to numeric zero or rejected under an invented power-up guarantee. Freeze and test the bootstrap and invalid-payload policy against the actual contract and genuine traces; after reset, defined fields must be checked. Legal all64-bit tags/ticks and full-width packed payloads must not be parsed through signed or floating-point shortcuts.

### History-bound statistics

Compute expected ready/valid, transfers, occupancy and cumulative queue counts from independent parsed input/control history and prior reference state, not from ref_* fields or final reported counters. Respect rst>cancel, old-full bubble, no bypass, aborted old occupancy and saturation. Keep queue counters since reset and collector counters since rst/stop/rearm distinct. For composition, account for actual sample events, order recovery, complete-slot retirement/overrun, terminal ordinal and unarmed drain from the specified public semantics; do not adopt the author TB's ref_* numbers as the oracle.

Compare final true counts and saturated public counters with reconstructed history. Validate reported stalls and write/read circuits against actual observed eligible segments/handshakes, not just a loose upper bound or minimum. The existing author TB reports a selected long stall and selected continuous transfer segment; it does not report every stall or every lifetime wrap. Freeze an unambiguous, deterministic mapping to those segments from the current trace. If extra evidence markers are necessary to disambiguate them, limit TB changes to that instrumentation, freeze its schema first and obtain fresh genuine captures. Never fabricate missing historic markers or call transformed old logs new vendor output. Checks/assertion invocation totals remain metadata, not independent-case counts.

Do not solve COUNT01 solely by adding count<=cycles or wrap<=cycles: plausible but wrong counts below those bounds must also fail when the trace disagrees. Do not special-case the four red fixture names, hashes or literal values. Retain expected-guard and expected-numeric-mutant modes separately from positive traces; enforcing positive-history success on an intended mutant would be the wrong criterion. Mutant acceptance still needs a genuine numeric public-port contradiction, not a malformed trace, warning, X-only failure or tool error.

### Process propagation and self-tests

Keep existing strict own-fatal/foreign-fatal, warnings, nonzero exit, timeout, version and marker/stat uniqueness behavior. A trace/history failure must propagate through direct classification, --verify-transcript and normal main/run_case/aggregation to failed summary/nonzero status. Do not bypass these paths in tests. Preserve intended vendor argv versus actual synthetic emitter argv.

The old runner's synthetic "valid" self-test transcript contains impossible coverage values. Replace such helper fixtures with complete coherent finite histories; label them synthetic. This is not permission to weaken minimum coverage for real cases. Preserve the old self-test source/bytes and explicitly report changed fixture provenance. The original main bare-CR duplicate-key fixture remains invalid for its intended purpose and excluded; the separately corrected same-row duplicate is a valid rejection control.

## Frozen validation and local return gate

Before changing code, persist repair02 CONSUMED, release/takeover, a precise implementation/validation plan, exact source snapshots, supported trace schema/metric origins, negative fixtures and expected outcomes. This is a new post-author recovery freeze, not the original pre-author freeze. No extra scope-only callback is required for this already bounded work.

Reuse repair01 real transcript inputs and valid independent controls as immutable baselines. New parser/runner qualification must run against corrected bytes, with genuine healthy queue/composition/guard/mutant controls as appropriate, all four existing red cases rejected, and the two false-positive normal-main entries failing. Add targeted general-property controls for missing/duplicate/unknown fields, cycle/side duplication or swapping with unchanged total rows, active X/Z versus permitted inactive payloads, full-width fields, plausible-but-wrong counts below cycle bounds, wrong reset/cancel/window accounting and claimed circuits inconsistent with actual transfers. Freeze these independently of the repair implementation. Do not duplicate unrelated old suites.

Complete the previously authorized unchanged30-case main RTL baseline once on the corrected RTL, with original oracle/TB/vectors/checker bytes unchanged. New wrapper/path adaptation under repair02 is allowed only with explicit equivalence and source binding; it must not alter expected behavior. Fresh author-runner vendor cases are justified where needed to validate changed runner/TB/guard source; record why each selected run is needed instead of blindly repeating all historical evidence. Prior numeric mutants retain original source IDs; new-source binding, if needed, is a distinct justified run. No old08–22 replay.

The main must not import its frozen independent oracle into the repaired public runner and then claim both are independent. The main-authored patch and its role in qualification must be disclosed. The original independent oracle remains frozen and separate. Preserve all repair failures and exact commands/versions/stdout/stderr/exit/source snapshots; actual subprocess tests remain distinct from ModelSim simulation.

After local repair and validation, return REPAIR02_READY_FOR_REVIEW to coordinator01a154de-abd8-7590-b9a3-2819249458e3 with exact four source hashes, bounded diff, schema/expectation freeze hashes, original+new evidence and a new immutable repair02 final receipt/local manifest. Do not commit, push, publish/comment PR30, send peers or create a public handoff request before the coordinator consumes this repaired candidate. Publication will be a later concrete decision on the same op23 after independent review. If a real blocker remains, return its exact evidence, with no additional worker or scope expansion.

All processes use explicit owner-contained absolute cwd/TMP/TEMP/TMPDIR/cache/library/output paths, resolved tempfile receipts and Python-B/PYTHONDONTWRITEBYTECODE. No service/credential/config/SQL/queue/lock change or human-only action is required by this decision. Idle waiting is event-driven; no model polling, Goal, automation, empty READY or automatic replay.

H01-H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 requirementsSHA256c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804, contractpinf5989cd5defce561f9ba98e6b18fc2682945f0a2 and design1011259415a0916054eb580687612580bc1e5f09 remain fixed. Full3D/UI/hidden truth/causal observations/PC AI and bothH12 paths remain mandatory. All29/B02/B03/G05/B06/R03/full-product simulation/synthesis/implementation/timing/CDC_RDC/board/system remain not_run. Only bounded internal simulations may be claimed. Board A-only; no public ABI/source/clock/DMA/PS/freshness/motion authority.
