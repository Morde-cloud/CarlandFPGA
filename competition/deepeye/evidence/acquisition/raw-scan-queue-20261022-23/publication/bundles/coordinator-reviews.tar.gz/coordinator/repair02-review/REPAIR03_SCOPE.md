# Op23: narrow mixed-unknown hexadecimal width correction

Decision: REVISE the exact local repair02 candidate. Its guards and previously identified four false-positive fixtures are corrected in the checked evidence, but OP23-RUNNER-UNKNOWN-WIDTH01 remains. No publication is authorized.

Keep DEEPEYE-IMPLEMENTATION-20261014/v1 and sole product main thread01a13b55-095b-7461-8dd5-5476a130bd82. Parent B-LOCAL-RAW-SCAN-QUEUE-CONTINUE-20261022-v1; product operation B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23; new instruction B-OP23-RUNNER-UNKNOWN-WIDTH-REPAIR-20261022-v1; new main work B-RAW-SCAN-QUEUE-UNKNOWN-WIDTH-RECOVERY-20261022-23-v1. Continue directly as the existing quality main; no execution child, new root/native/App worker or failed-job replay.

## Concrete independent failure

The coordinator independently checked all3383 local manifest entries, exact four canonical sources and diffs,178 repair02 frozen inputs,48 original frozen inputs,382 expanded/hash/line-count-bound invocation streams and256 result receipts. Thirty original independent RTL cases and58+10 saved runner outcomes are supported by the checked evidence. No coordinator vendor run or old-suite replay occurred.

Final runner SHA25652f0cb0430ae43ce04ef1247fce63c0a44a27ed5a745dffedd2f3d1134056057, function _parse_trace_row, lines505–508, checks only the number of hexadecimal digits for a word containing X/Z. A mixed word can fit ceil(width/4) digits while known bits in its top digit exceed the field width.

The genuine composition fixture has SEQ_W5. At post cycle1, c_out_valid=q_out_valid=0 after the applied reset. Two separate synthetic corruptions set c_out_first_seq=2x or q_out_last_seq=2z. The known leading2 fixes bit5 to1, outside a five-bit field. The following unknown low nibble cannot make that encoding width-valid. Both complete transcripts were falsely accepted by direct classification and by the actual --verify-transcript CLI with exit0. Unchanged genuine control and legal mixed unknown1x/x1 controls passed. This finding concerns complete record encoding; it does not impose a value on an inactive payload or claim a functional RTL failure.

The exact immutable coordinator evidence is under D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/main-continuation-20261019-v1/raw-scan-queue-20261022-23/repair02-review/padding-probe/. EXPECTATIONS.json SHA256a7d6042212cfe101c019f72b28a515ec4f92fb77de18ebcd8dd7ca5416ecac4a was frozen before execution. RESULT.json SHA256754e3b21177371858f8179feb85135fa6e742ea3ef79a5ec8358ef8a6cc9256f binds five direct and actual CLI observations. Candidate snapshot, exact synthetic inputs, CLI argv/cwd/env intent, exits/stdout/stderr/result JSON are retained. These are parser qualification cases, not new ModelSim results or human/board measurements. No normal-main false-pass claim is made for these new variants; prior58+10 normal-main evidence remains separately scoped.

## Ownership and permitted change

Continue in D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014. Before writes, record actual new App turn, decision/spec/input hashes and no overlapping writer in private repair03/CONSUMED.json. Keep repair02 source snapshots, failures, freezes and receipts immutable. Save the current canonical runner and candidate documentation as the repair03 pre-change snapshots.

Only these canonical paths may change:

1. competition/deepeye/tools/acquisition/run_raw_scan_queue.py — narrowly add known-bit overflow validation for mixed X/Z hexadecimal words, with bounded corresponding public selftest coverage if needed. Preserve unknown spellings and all currently legal inactive/bootstrap values. Reject known set bits beyond the declared field width even if another nibble is unknown. Do not special-case field names, fixture hashes or literal2x/2z. Do not replace X/Z with numeric zero as the returned value. A temporary known-bit mask or minimum numeric value may be used to validate width while returning the unchanged symbolic spelling.
2. competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md — only update exact parser qualification semantics/provenance if needed; current SHA256392edfdab0798fa8b7004acfb803d5326050f9e0246e97f6dd59d715b1405806.

New helpers/fixtures/snapshots/logs/receipts only under competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/main/repair03/ and D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/raw-scan-queue-20261022-23/repair03/.

RTL630e14803d82b3379517d91626de4ad7e7d3c509ad14363b3164031a5f633ee4 and authorTBe38944f5340cd4f17c9f6a2481ed4150cf82d3902031dec3ac7f6db3790f0ad0 are read-only. Do not change history reconstruction, queue/collector semantics, selected metrics, mutant label mapping, diagnostics/process policy, parameter limits or independent main oracle/TB/vectors/checker. Preserve all author, original, repair01 and repair02 evidence; old08–22, protected codec6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8 and six cancelled-audit files stay untouched.

## Required bounded validation and local return

Freeze the new expected properties before canonical edits. Cover non-nibble-aligned supported widths, including ordinal, tag and sample-tick schemas; known high padding bits with mixed lower X/Z must reject, while valid known leading bits and unknown top partial nibble remain allowed. Include uppercase/lowercase X/Z, full-width64-bit positive values, all-known overflow rejection and existing active-unknown rejection. These can be finite parser/actual transcript cases; no vendor execution is necessary for the parser-only correction.

Requalify the five coordinator fixtures on the corrected source with exact provenance. Reclassify the existing frozen58 direct/CLI cases against the new runner; label this changed-runner qualification, not new simulation. Verify the changed rejection through an actual normal-main composition entry using the unchanged main/run_case/aggregation path and a clearly identified synthetic vendor seam, with a genuine positive composition control. Freeze that new entry adaptation and record intended vendor argv separately from actual emitter argv. Preserve all original fixture bytes. Do not call a direct function test a normal-main process result.

No repeat of the30-case RTL baseline, no new ModelSim suite and no old08–22 replay are needed because RTL/TB and frozen oracle stay byte-identical. Check the source hashes to prove that boundary. Keep the earlier recovery alias false-negative and its final qualification intact. Do not overwrite or relabel old final receipts/manifests.

Return REPAIR03_READY_FOR_REVIEW locally, once, to coordinator01a154de-abd8-7590-b9a3-2819249458e3 by the existing supported App entry, with exact source hashes/diff, new expectation freeze, actual process outputs and immutable local final receipt/manifest. If a new concrete blocker appears, return its evidence without broadening scope or adding a worker. No extra scope-only callback or human continuation question is needed for this narrow authorized correction. No commit/push/PR30 comment/publication, public request, peer or desktop completion announcement before independent coordinator acceptance. No next increment.

Use owner-contained absolute cwd/temp/cache/output paths and Python-B/PYTHONDONTWRITEBYTECODE. No service/config/credential/SQL/queue/lock change, Goal/automation, empty READY, model polling or automatic replay. Only actual results/failures trigger the next review.

H01-H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 requirementsSHA256c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804, pinf5989cd5defce561f9ba98e6b18fc2682945f0a2, design1011259415a0916054eb580687612580bc1e5f09 unchanged. All full3D/UI/hidden truth/causal observations/PC AI and bothH12 paths remain mandatory. All29/B02/B03/G05/B06/R03/full-product simulation/synthesis/implementation/timing/CDC_RDC/board/system not_run. Physical board A-only; no public ABI/source/clock/DMA/PS/freshness/ENABLE/motion authority.
