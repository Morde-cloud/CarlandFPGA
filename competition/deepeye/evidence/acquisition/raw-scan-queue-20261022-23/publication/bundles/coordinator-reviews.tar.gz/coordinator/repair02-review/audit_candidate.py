from pathlib import Path
from datetime import datetime, timezone
import ast, hashlib, json, difflib, subprocess

R=Path('D:/pynq/CarlandFPGA')
W=R/'.local/worktrees/deepeye-implementation-20261014'
M=W/'competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/main/repair02'
P=R/'.local/deployment/node-b/evidence/raw-scan-queue-20261022-23/repair02'
O=R/'.local/deployment/node-b/evidence/main-continuation-20261019-v1/raw-scan-queue-20261022-23/repair02-review'
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p): return json.loads(Path(p).read_bytes())
def ref(p):
    p=Path(p);return {'path':str(p),'sha256':digest(p),'bytes':p.stat().st_size}
def check_ref(x):
    p=Path(x['path']);assert digest(p)==x['sha256'],str(p)
    if 'bytes' in x: assert p.stat().st_size==x['bytes'],str(p)
def ast_functions(p):
    return {n.name:ast.dump(n,include_attributes=False) for n in ast.parse(Path(p).read_text(encoding='utf8')).body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))}

final=read(P/'FINAL_RECEIPT.json');decision=read(M/'REVIEW_DECISION.json');manifest=read(M/'LOCAL_REVIEW_MANIFEST.json')
assert len(manifest['artifacts'])==3383
paths=set()
for item in manifest['artifacts']:
    key=str(Path(item['path']).resolve()).casefold();assert key not in paths;paths.add(key);check_ref(item)
assert manifest['decision_sha256']==digest(M/'REVIEW_DECISION.json')
for item in decision['source_snapshots']:
    for k in ('new','diff','old_snapshot'):check_ref(item[k])
    assert digest(W/item['canonical'])==item['new']['sha256']==final['source_hashes'][item['canonical']]
    a=Path(item['old_snapshot']['path']).read_text(encoding='utf8').splitlines(keepends=True)
    b=Path(item['new']['path']).read_text(encoding='utf8').splitlines(keepends=True)
    expected=''.join(difflib.unified_diff(a,b,fromfile='old/'+item['canonical'],tofile='repair02/'+item['canonical']))
    assert Path(item['diff']['path']).read_text(encoding='utf8')==expected,item['canonical']

# Derive the permitted declarations independently from old source; no replacement of legal logic.
for filename,suffix,expected_count in [('deepeye_raw_scan_queue.sv','E',5),('tb_raw_scan_queue.sv','R',10)]:
    old=(M/'snapshots'/filename).read_text(encoding='utf8');new=(M/'final-source'/filename).read_text(encoding='utf8');count=0
    import re
    for name,lo,hi in [('DEPTH',1,8),('SEQ_W',2,32),('TICK_W',1,64),('TAG_W',1,64),('STAT_W',2,32)]:
        target={'DEPTH':'DEPTH','SEQ_W':'SEQ','TICK_W':'TICK','TAG_W':'TAG','STAT_W':'STAT'}[name]+'_'+suffix
        pattern=r'(?m)^(\s*localparam int '+target+r'\s*= )[^;\n,]+([,;])$'
        replacement=lambda m:f'{m[1]}({name} >= {lo} && {name} <= {hi}) ? {name} : {lo}{m[2]}'
        old,n=re.subn(pattern,replacement,old);count+=n
    assert count==expected_count and old==new,(filename,count)

oldf=ast_functions(M/'snapshots/run_raw_scan_queue.py');newf=ast_functions(M/'final-source/run_raw_scan_queue.py')
for name in decision['unchanged_public_functions']:assert oldf[name]==newf[name],name
imports=[ast.unparse(n) for n in ast.parse((M/'final-source/run_raw_scan_queue.py').read_text(encoding='utf8')).body if isinstance(n,(ast.Import,ast.ImportFrom))]

freeze=read(M/'EXPECTATION_FREEZE.json')
for item in freeze['files']:check_ref(item)
assert len(freeze['files'])==178 and freeze['cases']==58
for item in read(M/'EXECUTION_ADAPTATION.json')['records']:
    assert digest(item['original'])==item['original_sha256']
    if 'relocated' in item:assert digest(item['relocated'])==item['relocated_sha256']
    else:assert digest(item['new'])==item['new_sha256']
for name in ['CONSUMED.json','MAIN_TAKEOVER.json']:
    data=read(P/name)
    for p,h in data.get('pins',data.get('release_evidence',{})).items():assert digest(p)==h

baseline=read(M/'runs/baseline02/RESULT.json')
assert baseline['all_pass'] and baseline['complete'] and baseline['executed']==30 and baseline['verified_complete_trace_edges']==87836
assert len(baseline['results'])==30 and sum(x['kind']=='positive' for x in baseline['results'])==17
assert all(x['pass'] and x['simulation']['ok'] and x['compile']['ok'] and x['library_ok'] for x in baseline['results'])
for row in baseline['results']:
    for snapshot in row['source_snapshots']:check_ref(snapshot)
    if row['kind']=='positive':assert row['comparison']['pass'] and row['comparison']['first_mismatch'] is None
assert sum(x['comparison']['edges'] for x in baseline['results'] if x['kind']=='positive')==87836

qualification=read(M/'qualification-final/RESULT.json')
assert qualification['runner_sha256']==digest(M/'final-source/run_raw_scan_queue.py') and qualification['pass']
assert len(qualification['direct_and_cli'])==58 and len(qualification['normal_main_entries'])==10
qualification_receipts=[]
for row in qualification['direct_and_cli']:
    assert row['match'] and row['expected_ok']==row['direct_ok']==row['actual_cli_ok']
    folder=M/'qualification-final'/row['evidence'];proc=read(folder/'actual-cli.result.json');result=read(folder/'spec.result.json')
    assert proc['exit']==row['actual_cli_exit']==(0 if row['expected_ok'] else 1)
    assert result['ok']==row['expected_ok']
    for stream in ('stdout','stderr'):assert digest(proc[stream+'_path'])==proc[stream+'_sha256']
    qualification_receipts.append({'case':row['name'],'expected_ok':row['expected_ok'],'actual_exit':proc['exit'],'result':ref(folder/'spec.result.json')})
for row in qualification['normal_main_entries']:
    assert row['match'] and row['expected_exit']==row['actual_exit']
    folder=M/'qualification-final'/row['evidence'];proc=read(folder/'main-process.result.json');summary=read(folder/'run/summary.json')
    assert proc['exit']==row['actual_exit'] and summary['ok']==row['summary_ok']
    for stream in ('stdout','stderr'):assert digest(proc[stream+'_path'])==proc[stream+'_sha256']

saved=read(M/'final-saved/RESULT.json');assert saved['all_pass'] and len(saved['saved_vendor_cases'])==24 and all(x['exit']==0 and x['ok'] for x in saved['saved_vendor_cases'])
assert saved['six_alias_tuple_control_exit']==0 and saved['unsubstantiated_payload_exit']==1 and saved['new_vendor_runs']==0
raw_streams=set();process_receipts=[]
for p in M.rglob('*.json'):
    j=read(p)
    if not isinstance(j,dict):continue
    if 'argv' in j and ('exit' in j or 'exit_code' in j):process_receipts.append(str(p))
    for stream in ('stdout','stderr'):
        if stream+'_path' in j and stream+'_sha256' in j:
            stream_path=Path(j[stream+'_path']);assert digest(stream_path)==j[stream+'_sha256'];raw_streams.add(str(stream_path))

git=[]
for name,args in [('head',['rev-parse','HEAD']),('index',['diff','--cached','--name-only']),('unmerged',['ls-files','--unmerged'])]:
    argv=['git','-c','core.longpaths=true','-C',str(W)]+args
    c=subprocess.run(argv,capture_output=True);assert c.returncode==0
    (O/(name+'.stdout.bin')).write_bytes(c.stdout);(O/(name+'.stderr.bin')).write_bytes(c.stderr)
    assert c.stdout.decode().strip()==('94571d2cd9a68bd030c878c406f19a1be6ec53d7' if name=='head' else '')
    git.append({'argv':argv,'exit':c.returncode,'stdout':ref(O/(name+'.stdout.bin')),'stderr':ref(O/(name+'.stderr.bin'))})
protected=W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json';assert digest(protected)=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'ALL_CHECKED_IDENTITIES_AND_RECORDED_RESULTS_MATCH','manifest':ref(M/'LOCAL_REVIEW_MANIFEST.json'),'manifest_artifacts':len(paths),'unique_hash_bound_raw_streams_found':len(raw_streams),'top_level_argv_process_receipts_found':len(process_receipts),'guard_diff':'Exactly5 RTL and10 TB allowed lower fallback expressions, remaining bytes unchanged','unchanged_public_function_ASTs':decision['unchanged_public_functions'],'runner_imports':imports,'freeze_inputs_verified':len(freeze['files']),'main_baseline_cases':30,'main_positive_edges':87836,'qualification':qualification_receipts,'normal_main_entries':qualification['normal_main_entries'],'saved_vendor_reclassification_cases':24,'coordinator_vendor_runs':0,'protected_codec':ref(protected),'git':git,'limits':['Hash verification is identity evidence, not proof of algorithm correctness.','Stored vendor/synthetic process receipts remain distinct; no old suite was replayed.','Historical full manifests1686/1020/743 were not recursively rehashed again by this coordinator; new3383 manifest and its present references were checked.']}
with (O/'CANDIDATE_IDENTITY_AUDIT.json').open('x',encoding='utf8') as f:json.dump(result,f,ensure_ascii=False,indent=2)
print(json.dumps({'result':ref(O/'CANDIDATE_IDENTITY_AUDIT.json'),'manifest_artifacts':len(paths),'raw_streams':len(raw_streams),'process_receipts':len(process_receipts),'qualification':58,'baseline':30},ensure_ascii=False))
