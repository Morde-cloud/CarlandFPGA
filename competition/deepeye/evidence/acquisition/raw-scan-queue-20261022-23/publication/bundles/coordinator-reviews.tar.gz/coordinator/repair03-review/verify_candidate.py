from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,ast,difflib,gzip,re,subprocess,sys,os,tempfile,time,importlib.util
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014'
M=W/'competition/deepeye/evidence/acquisition/raw-scan-queue-20261022-23/main/repair03'
O=R/'.local/deployment/node-b/evidence/main-continuation-20261019-v1/raw-scan-queue-20261022-23/repair03-review'
C=O.parent/'repair02-review/padding-probe'
def read(p):return json.loads(Path(p).read_bytes())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def ref(p):return {'path':str(p),'bytes':Path(p).stat().st_size,'sha256':sha(p)}
def seal(p,j):
    with p.open('x',encoding='utf8') as f:json.dump(j,f,ensure_ascii=False,indent=2)
def check(x):
    assert sha(x['path'])==x['sha256'],x['path']
    if 'bytes' in x:assert Path(x['path']).stat().st_size==x['bytes'],x['path']
manifest=read(M/'LOCAL_REVIEW_MANIFEST.json');assert len(manifest['files'])==749
assert len({x['path'].lower() for x in manifest['files']})==749
for x in manifest['files']:check(x)
freeze=read(M/'EXPECTATION_FREEZE.json');assert len(freeze['files'])==207
for x in freeze['files']:check(x)
decision=read(M/'REVIEW_DECISION.json')
for p,h in decision['unchanged_readonly_canonical'].items():assert sha(p)==h
runner=W/'competition/deepeye/tools/acquisition/run_raw_scan_queue.py';doc=W/'competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md'
assert sha(runner)==sha(M/'final-source/run_raw_scan_queue.py')=='9a06a7a368313dc96b6941fdaa8dfc4bcda27ed426bf5e75e00e2a1072b39996'
assert sha(doc)==sha(M/'final-source/raw_scan_queue_candidate.md')=='57f81585986e785277a4b5ecceebc6720fe5dfac341b68f368e9d731506b3ee9'
old=(M/'snapshots/run_raw_scan_queue.py').read_text(encoding='utf8');new=runner.read_text(encoding='utf8')
insertion='''            if base == 16 and width is not None:
                # The minimum value checks known padding bits only; keep X/Z
                # symbolic below so inactive/bootstrap semantics are unchanged.
                known_bits = int(re.sub(r"[xXzZ]", "0", word), 16)
                if known_bits >= 1 << width:
                    raise ValueError("out-of-width known trace bits " + key)
'''
assert new.count(insertion)==1 and new.replace(insertion,'')==old
def fns(t):return {x.name:ast.dump(x,include_attributes=False) for x in ast.parse(t).body if isinstance(x,ast.FunctionDef)}
a,b=fns(old),fns(new);assert set(a)==set(b) and [k for k in a if a[k]!=b[k]]==['_parse_trace_row']
expected_diff=''
for name in ('run_raw_scan_queue.py','raw_scan_queue_candidate.md'):
    left=(M/'snapshots'/name).read_text(encoding='utf8');right=(M/'final-source'/name).read_text(encoding='utf8')
    expected_diff+=''.join(difflib.unified_diff(left.splitlines(True),right.splitlines(True),fromfile='repair02/'+name,tofile='repair03/'+name))
assert (M/'final-source/source.diff').read_text(encoding='utf8')==expected_diff
assert doc.read_text(encoding='utf8').startswith((M/'snapshots/raw_scan_queue_candidate.md').read_text(encoding='utf8'))
props=read(M/'PROPERTY_CASES.json')['cases'];green=read(M/'PROPERTY_GREEN.json');red=read(M/'PROPERTY_RED.json')
assert len(props)==len(green['rows'])==len(red['rows'])==45412
assert green['source_sha256']==sha(runner) and red['source_sha256']==sha(M/'snapshots/run_raw_scan_queue.py')
false_accept=0;coverage={}
for i,(c,g,r) in enumerate(zip(props,green['rows'],red['rows'])):
    word=c['word'];width=64 if c['field'] in ('c_out_data','q_out_data') else c['width']
    bits=''.join('????' if ch in 'xXzZ' else format(int(ch,16),'04b') for ch in word)
    excess=max(0,len(bits)-width)
    expected=len(word)<=(width+3)//4 and '1' not in bits[:excess]
    assert c['expected_ok']==expected
    assert g['index']==r['index']==i and g['actual_ok']==expected and g['match'] and g['symbolic_preserved']
    false_accept+=bool(r['actual_ok'] and not expected)
    coverage.setdefault(c['field'],set()).add(width)
assert false_accept==23504 and green['false_accepts']==green['false_rejects']==0
assert read(M/'properties-red.process.json')['exit']==2 and read(M/'properties-green.process.json')['exit']==0
qualification=read(M/'qualification/RESULT.json');assert qualification['pass_all'] and qualification['runner_sha256']==sha(runner)
assert len(qualification['direct_and_cli'])==63 and len(qualification['normal_main_entries'])==3
for row in qualification['direct_and_cli']:
    p=M/'qualification/fixtures'/row['name'];direct=read(p/'direct.json');cli=read(p/'spec.result.json');proc=read(p/'actual-cli.result.json')
    assert row['match'] and row['direct_ok']==row['actual_cli_ok']==row['expected_ok']==direct['ok']==cli['ok']
    assert proc['exit']==row['actual_exit']==(0 if row['expected_ok'] else 1)
for row in qualification['normal_main_entries']:
    p=M/'qualification/entries'/row['name'];proc=read(p/'main-process.result.json');summary=read(p/'run/summary.json')
    assert row['match'] and proc['exit']==row['actual_exit']==row['expected_exit'] and summary['ok']==row['summary_ok']
process_count=0
for p in M.rglob('*.result.json'):
    j=read(p)
    if 'stdout_path' in j and 'stdout_sha256' in j:
        for key in ('stdout','stderr'):assert sha(j[key+'_path'])==j[key+'_sha256']
        process_count+=1
assert process_count==66
invocations=streams=0
for p in M.rglob('*.invocation.json'):
    j=read(p);assert j['synthetic_vendor_seam'] and Path(j['argv'][0]).name=='python.exe' and Path(j['argv'][4]).name=='emitter.py'
    assert j['argv']!=j['vendor_intended_argv'] and j['exit']==0 and not j['timed_out'];invocations+=1
    for info in j['streams'].values():
        raw=(p.parent/info['path']).read_bytes()
        if info.get('compressed'):assert hashlib.sha256(raw).hexdigest()==info['compressed_sha256'];raw=gzip.decompress(raw)
        assert len(raw)==info['bytes'] and hashlib.sha256(raw).hexdigest()==info['sha256']
        assert (0 if not raw else raw.count(b'\n')+(not raw.endswith(b'\n')))==info['line_count'];streams+=1
assert invocations==15 and streams==30
matrix=read(M/'qualification/MATRIX.json')
for c in matrix['cases']:
    source=Path(c['origin']).parent;target=M/'qualification'/c['spec']
    for n in ('spec.json','stdout.txt','stderr.txt'):assert (source/n).read_bytes()==(target.parent/n).read_bytes()

# The exact five prior coordinator fixtures are rerun only because the candidate changed.
probe=O/'closure-probe';probe.mkdir();(probe/'tmp').mkdir();(probe/'candidate.py').write_bytes(runner.read_bytes())
expect=read(C/'EXPECTATIONS.json')
seal(probe/'BINDING.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'candidate':ref(probe/'candidate.py'),'original_expectations':ref(C/'EXPECTATIONS.json'),'purpose':'Changed-source independent closure of two false accepts plus three legal controls; no vendor or old-suite run.'})
for k in ('TMP','TEMP','TMPDIR'):os.environ[k]=str(probe/'tmp')
os.environ['PYTHONDONTWRITEBYTECODE']='1';tempfile.tempdir=None;assert Path(tempfile.gettempdir())==probe/'tmp'
s=importlib.util.spec_from_file_location('coordinator_repair03',probe/'candidate.py');mod=importlib.util.module_from_spec(s);sys.modules[s.name]=mod;s.loader.exec_module(mod)
outcomes=[]
for c in expect['cases']:
    p=probe/c['name'];p.mkdir()
    for n in ('spec.json','stdout.txt','stderr.txt'):(p/n).write_bytes((C/c['name']/n).read_bytes())
    spec=read(p/'spec.json');direct=mod.classify_composition_output(stdout=(p/'stdout.txt').read_text(encoding='utf8'),stderr=(p/'stderr.txt').read_text(encoding='utf8'),**spec['args']);seal(p/'direct.json',direct)
    argv=[sys.executable,'-B','-X','utf8',str(probe/'candidate.py'),'--verify-transcript',str(p/'spec.json')]
    seal(p/'CLI_INTENT.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'argv':argv,'cwd':str(p),'source_sha256':sha(probe/'candidate.py'),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR'],'expected_ok':c['expected_ok']})
    t=time.monotonic();r=subprocess.run(argv,cwd=p,capture_output=True,timeout=20,env=os.environ.copy());(p/'stdout.bin').write_bytes(r.stdout);(p/'stderr.bin').write_bytes(r.stderr)
    seal(p/'CLI_RESULT.json',{'ended_utc':datetime.now(timezone.utc).isoformat(),'exit':r.returncode,'elapsed':time.monotonic()-t,'stdout':ref(p/'stdout.bin'),'stderr':ref(p/'stderr.bin')})
    cli=read(p/'spec.result.json');assert direct['ok']==cli['ok']==c['expected_ok'] and r.returncode==(0 if c['expected_ok'] else 1)
    outcomes.append({'name':c['name'],'expected_ok':c['expected_ok'],'direct_ok':direct['ok'],'actual_CLI_ok':cli['ok'],'actual_CLI_exit':r.returncode,'reasons':direct['reasons']})
seal(probe/'RESULT.json',{'candidate_sha256':sha(probe/'candidate.py'),'results':outcomes,'all_match':True,'new_vendor_runs':0})
git=[]
for name,args in [('head',['rev-parse','HEAD']),('index',['diff','--cached','--name-only']),('unmerged',['ls-files','--unmerged'])]:
    argv=['git','-c','core.longpaths=true','-C',str(W)]+args;r=subprocess.run(argv,capture_output=True);assert r.returncode==0
    (O/(name+'.stdout.bin')).write_bytes(r.stdout);(O/(name+'.stderr.bin')).write_bytes(r.stderr)
    assert r.stdout.decode().strip()==('94571d2cd9a68bd030c878c406f19a1be6ec53d7' if name=='head' else '')
    git.append({'argv':argv,'exit':r.returncode,'stdout':ref(O/(name+'.stdout.bin')),'stderr':ref(O/(name+'.stderr.bin'))})
result={'at_utc':datetime.now(timezone.utc).isoformat(),'status':'PASS','manifest_files':749,'new_freeze_inputs':207,'exact_six_line_parser_change':True,'other_module_source_unchanged':True,'documentation_append_only':True,'property_expectations_independently_recomputed':45412,'old_false_accepts_recounted':23504,'new_property_mismatches':0,'width_coverage':{k:sorted(v) for k,v in coverage.items()},'saved_direct_and_CLI':63,'normal_main_exits':[x['actual_exit'] for x in qualification['normal_main_entries']],'raw_process_results':process_count,'actual_synthetic_emitter_processes':invocations,'expanded_synthetic_streams':streams,'all63inputs_equal_immutable_origins':True,'coordinator_closure_probe':ref(probe/'RESULT.json'),'protected_inputs':decision['unchanged_readonly_canonical'],'git':git,'new_vendor_runs':0,'historical_limit':'7216 historical-file sweep remains product-main evidence; coordinator did not duplicate that full sweep in this turn. Prior coordinator review remains exact-source evidence for repair02 and original RTL baseline.'}
seal(O/'CANDIDATE_VERIFICATION.json',result)
print(json.dumps({'verification':ref(O/'CANDIDATE_VERIFICATION.json'),'closure_probe':ref(probe/'RESULT.json'),'normal_main_exits':result['normal_main_exits'],'property_expectations':45412,'status':'PASS'},ensure_ascii=False))
