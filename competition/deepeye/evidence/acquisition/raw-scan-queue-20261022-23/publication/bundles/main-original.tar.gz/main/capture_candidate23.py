import hashlib,json,os,tempfile
from pathlib import Path
from datetime import datetime,timezone
M=Path(__file__).resolve().parent
W=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014')
assert Path(tempfile.gettempdir()).resolve()==M/'tmp'
source=W/'competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv'
raw=source.read_bytes();h=hashlib.sha256(raw).hexdigest()
out=M/'candidate01';out.mkdir()
with (out/'q.sv').open('xb') as f:f.write(raw)
receipt={'at_utc':datetime.now(timezone.utc).isoformat(),'source_path':str(source),'snapshot_path':str(out/'q.sv'),'sha256':h,'bytes':len(raw),'author_job':'child-8054ea77c7e64902a1ae1e4704721c99','author_terminal_not_yet_consumed':True,'binding':'Provisional immutable candidate; no acceptance until actual terminal source reconciles','environment':{'cwd':os.getcwd(),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR'],'resolved_temp':tempfile.gettempdir()}}
with (out/'CAPTURE.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
