import gzip,hashlib,json,os,subprocess,tempfile
from pathlib import Path
from datetime import datetime,timezone
M=Path(__file__).resolve().parent
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014'
O=R/'.local/deployment/node-b/evidence/raw-scan-queue-20261022-23'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
assert all(Path(os.environ[k]).resolve()==M/'tmp' for k in ['TMP','TEMP','TMPDIR'])
assert Path(tempfile.gettempdir()).resolve()==M/'tmp' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
put(M/'freeze_oracle_environment.json',{'cwd':os.getcwd(),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR'],'resolved_temp':tempfile.gettempdir(),'PYTHONDONTWRITEBYTECODE':'1'})
assert sha(O/'SCOPE.md')=='a8a48893e71f9642d8cbbdf7c5c23b06f8dfc24c37554cab13421776be33ddc1'
assert sha(O/'COORDINATOR_CONTINUE_CONSUMED.json')=='af0de802d4420845185bfb8544674f38a0e6be37c4a6b5ce80d1bf79991e16c0'
scope=json.loads((O/'SCOPE_FROZEN.json').read_bytes())
assert all(not Path(p).exists() for p in scope['eventual_author_ownership'])
assert subprocess.check_output(['git','-C',str(W),'rev-parse','HEAD']).decode().strip()==scope['baseline']['head']
assert not subprocess.check_output(['git','-C',str(W),'diff','--cached','--name-only'])
assert sha(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
manifest=json.loads((M/'VECTOR_MANIFEST.json').read_bytes())
assert sha(M/'oracle23.py')==manifest['oracle_sha256'] and sha(M/'make_vectors23.py')==manifest['generator_sha256']
checks=[]
for case in manifest['cases']:
    stim=M/'vectors'/case['stimulus']['path'];expected=M/'vectors'/case['expected']['path']
    assert sha(stim)==case['stimulus']['sha256'] and sha(expected)==case['expected']['sha256']
    digest=hashlib.sha256();rows=0
    with gzip.open(expected,'rb') as f:
        for line in f:
            digest.update(line);item=json.loads(line);assert item['index']==rows;rows+=1
    assert rows==case['edges']==sum(1 for _ in stim.open('rb')) and digest.hexdigest()==case['expected']['expanded_sha256']
    checks.append({'case':case['name'],'rows':rows,'expanded_sha256':digest.hexdigest()})
assert sum(x['rows'] for x in checks)==manifest['exact_positive_edges']==87836<=500000
files=[]
for p in sorted(M.rglob('*')):
    if p.is_file() and not p.is_relative_to(M/'tmp'):
        # The running wrapper output streams are finalized after this receipt.
        if p.name.startswith('oracle-freeze.') and p.suffix=='.txt':continue
        files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for p in [W/'competition/deepeye/tests/rtl/acquisition/main_tb_raw_scan_queue.sv',W/'competition/deepeye/tools/acquisition/main_verify_raw_scan_queue.py']:
    files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
put(M/'PREDISPATCH_FREEZE.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-LOCAL-RAW-SCAN-QUEUE-CONTINUE-20261022-v1','operation_id':'B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23','actual_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','actual_turn':'01a16293-6187-7df0-9227-cc3c0e7daa6b','scope_sha256':sha(O/'SCOPE.md'),'continue_consumed_sha256':sha(O/'COORDINATOR_CONTINUE_CONSUMED.json'),'contract':scope['contract'],'baseline':scope['baseline'],'files':files,'vectors_verified':checks,'case_count':17,'exact_positive_edges':87836,'cap':500000,'independence':'Oracle expected ready/valid/occupancy from list and abort controls; composition from independent prefix/slot and literal events; actual handshakes checked afterward','author_paths_all_absent':True,'author_dispatched':False,'author_implementation_read':False,'main_rtl_simulation':'not_run','mutant_intents':manifest['mutation_intents'],'parameter_guards':manifest['parameter_guards'],'limits':'Byte integrity and manual oracle sanity only; no RTL, formal, physical or product acceptance'})
print(json.dumps({'freeze_sha256':sha(M/'PREDISPATCH_FREEZE.json'),'files':len(files),'cases':17,'exact_positive_edges':87836,'author_paths_absent':5}))
