"""Create exact literal stimuli and expected public-port values before author work."""
import gzip
import hashlib
import itertools
import json
import os
import tempfile
from dataclasses import asdict
from pathlib import Path
from oracle23 import Config, FIELDS, INPUTS, Oracle, compare, input_row, mask

M = Path(__file__).resolve().parent
V = M / 'vectors'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def dump(p, data):
    with p.open('x', encoding='utf-8', newline='\n') as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
        f.write('\n')

def record(cfg, n):
    # Frozen output files contain the literal expanded words, not merely this seed.
    values = (0x8001000200040008 ^ (n * 0x100010001),
              sum(((mask(cfg.tick)-n-3*i) & mask(cfg.tick)) << (i*cfg.tick) for i in range(4)),
              0x80402010 ^ (n * 0x01010101), n * 7, mask(cfg.seq)-n, n % 3)
    return tuple(v & mask(w) for v, w in zip(values, cfg.widths))

class Case:
    def __init__(self, name, cfg):
        self.name, self.cfg, self.model = name, cfg, Oracle(cfg)
        self.stim = (V / (name + '.stim')).open('x', encoding='ascii', newline='\n')
        self.raw = (V / (name + '.expected.jsonl.gz')).open('xb')
        self.exp = gzip.GzipFile(filename='', mode='wb', fileobj=self.raw, mtime=0)
        self.raw_hash = hashlib.sha256()
        self.controls, self.segments = set(), []
        self.samples = self.accepts = self.retires = 0
        self.number = 0
        self.emit(rst=1)

    def emit(self, rec=None, **kw):
        if rec is not None:
            kw.update(dict(zip(FIELDS, rec)))
        row = input_row(**kw)
        expected = self.model.edge(row)
        if 'level' in expected['pre']:
            self.controls.add((expected['pre']['level'], row['rst'], row['cancel'], row['iv'], row['ready']))
        self.samples += row['strobe']
        self.accepts += expected['accepted']
        self.retires += expected['retired']
        self.stim.write(' '.join(format(row[k], 'x') for k in INPUTS) + '\n')
        data = (json.dumps(expected, separators=(',', ':'), sort_keys=True) + '\n').encode('ascii')
        self.exp.write(data)
        self.raw_hash.update(data)
        self.number += 1
        return expected

    def reset(self):
        self.emit(rst=1)

    def fill(self, count=None):
        count = self.cfg.depth if count is None else count
        for _ in range(count):
            self.emit(iv=1, rec=record(self.cfg, self.number))

    def drain(self):
        for _ in range(self.cfg.depth + 2):
            self.emit(ready=1)
        assert not self.model.queue.records

    def send(self, rec):
        # This loop uses solely reference state to generate a bounded literal schedule.
        for _ in range(self.cfg.depth + 2):
            x = self.emit(iv=1, ready=1, rec=rec)
            if x['accepted']:
                return
        raise AssertionError('reference did not admit')

    def event(self, ch, ready=0):
        i = self.number
        self.emit(strobe=1, channel=ch, sample_data=(0x8000+i*13)&65535,
                  sample_tick=(mask(self.cfg.tick)-i)&mask(self.cfg.tick), sample_quality=(128+i*7)&255, ready=ready)

    def scan(self, ready=0):
        for ch in range(4):
            self.event(ch, ready)

    def close(self):
        self.stim.close()
        self.exp.close()
        self.raw.close()
        return {'name': self.name, 'parameters': asdict(self.cfg), 'edges': self.number,
                'accepted_handshakes': self.accepts, 'retired_handshakes': self.retires,
                'sample_strobes': self.samples, 'segments': self.segments,
                'stimulus': {'path': self.name+'.stim', 'sha256': sha(V/(self.name+'.stim'))},
                'expected': {'path': self.name+'.expected.jsonl.gz', 'sha256': sha(V/(self.name+'.expected.jsonl.gz')),
                             'expanded_sha256': self.raw_hash.hexdigest(), 'rows': self.number}}

def queue_case(depth):
    cfg = Config(depth=depth) if depth == 4 else Config(depth=depth, seq=7, tick=13, tag=17, stat=3)
    c = Case('queue_depth'+str(depth), cfg)
    # Independent prefixes set every occupancy before each complete control cross.
    control_goals = set(itertools.product(range(depth+1), (0,1), (0,1), (0,1), (0,1)))
    for level, rst, cancel, iv, ready in sorted(control_goals):
        c.reset()
        c.fill(level)
        c.emit(rst=rst, cancel=cancel, iv=iv, ready=ready, rec=record(cfg, c.number))
    assert control_goals <= c.controls
    c.reset()
    start = c.number
    for _ in range(1000):
        c.fill()
        for _ in range(depth):
            c.emit(ready=1)
    assert c.model.queue.accepted == c.model.queue.retired == 1000*depth
    c.segments.append({'kind': 'continuous_wraps', 'start': start, 'end_exclusive': c.number,
                       'accepted': 1000*depth, 'retired': 1000*depth, 'read_circuits': 1000, 'write_circuits': 1000})
    c.fill()
    rec = record(cfg, c.number)
    start = c.number
    for _ in range(4096):
        c.emit(iv=1, rec=rec)
    c.segments.append({'kind': 'nonempty_stall', 'start': start, 'end_exclusive': c.number, 'cycles': 4096})
    c.send(rec)  # Preserves the held input through the intentional old-full bubble.
    c.drain()
    if depth > 1:
        c.fill(1)
        for _ in range(100):
            c.send(record(cfg, c.number))
        c.drain()
    # Cumulative accepted, retired and aborted reach saturation through real traffic.
    for _ in range(12):
        c.fill()
        c.emit(cancel=1, iv=1, ready=1, rec=rec)
        c.emit(cancel=1, iv=1, ready=1, rec=rec)
        c.emit(cancel=1)
    c.fill()
    c.drain()
    # ABA/multiplicity: repeated identical records, then an intervening flush.
    duplicate = tuple(mask(w) for w in cfg.widths)
    for _ in range(12):
        c.send(duplicate)
    c.drain()
    c.fill()
    c.emit(cancel=1)
    for _ in range(depth*4):
        c.send(duplicate)
    c.drain()
    result = c.close()
    result['occupancy_control_combinations'] = len(control_goals)
    return result

def width_case(name, cfg):
    c = Case(name, cfg)
    # Every payload bit separately walks high and low, including all64 tag bits.
    all_ones = tuple(mask(w) for w in cfg.widths)
    c.send((0,)*6)
    c.send(all_ones)
    for field, width in enumerate(cfg.widths):
        for bit in range(width):
            one = [0]*6
            one[field] = 1 << bit
            c.send(tuple(one))
            c.send(tuple(a ^ b for a, b in zip(all_ones, one)))
    # Each lane's ticks: equal, descending, rollover and zero are transported literally.
    for tick in [0, 1, mask(cfg.tick), 0, mask(cfg.tick)-1, mask(cfg.tick)-1]:
        rec = list(record(cfg, c.number))
        rec[1] = sum(tick << (i*cfg.tick) for i in range(4))
        rec[3], rec[4], rec[5] = mask(cfg.seq), 0, 0
        c.send(tuple(rec))
    c.drain()
    for _ in range(12):
        c.fill()
        c.emit(cancel=1)
        c.emit(cancel=1)
    for _ in range(20):
        c.send(all_ones)
    c.drain()
    return c.close()

def composition_case(depth, seq=8, tick=64, tag=64, stat=3):
    cfg = Config(depth=depth, seq=seq, tick=tick, tag=tag, stat=stat, mode=1)
    c = Case('composition_d'+str(depth)+'_s'+str(seq), cfg)
    fixed_tag = mask(tag)
    c.emit(rearm=1, rearm_tag=fixed_tag)
    # Literal channel history tests prefix restart, repeated/wrong channel and recovery.
    for ch in [2, 0, 1, 1, 0, 1, 0, 1, 2, 2, 0, 1, 2, 3]:
        c.event(ch, 1)
    for _ in range(depth+3):
        c.emit(ready=1)
    c.emit(rearm=1, rearm_tag=fixed_tag)
    # Process every ordinal including last while consumer stalls. Complete records drain unarmed.
    start = c.number
    for ordinal in range(1 << seq):
        c.event(ordinal % 4)
    assert not c.model.collector.armed and c.model.collector.exhausted
    assert c.model.collector.counts['events'] == 1 << seq
    if (1 << seq)//4 > depth+1:
        assert c.model.collector.counts['overruns'] > 0
    c.segments.append({'kind': 'collector_exhaustion', 'start': start, 'end_exclusive': c.number,
                       'events': 1 << seq, 'depth': depth, 'overruns': c.model.collector.counts['overruns']})
    for _ in range(depth+5):
        c.emit(ready=1)
    assert not c.model.queue.records and c.model.collector.slot is None
    # Abort with queued records, slot and prefix. Same tag is deliberately reused.
    for control in ['stop', 'rearm', 'rst', 'all']:
        c.emit(rearm=1, rearm_tag=fixed_tag)
        for _ in range(depth+2):
            c.scan()
        for ch in [0,1,2]:
            c.event(ch)
        kw = {'rst': 1, 'stop': 1, 'rearm': 1} if control == 'all' else {control: 1}
        c.emit(**kw, strobe=1, channel=3, ready=1, rearm_tag=fixed_tag)
        c.emit(**kw, ready=1, rearm_tag=fixed_tag)
        assert not c.model.queue.records and c.model.collector.slot is None and not c.model.collector.prefix
        c.emit(rearm=1, rearm_tag=fixed_tag)
        c.scan(1)
        for _ in range(depth+4):
            c.emit(ready=1)
    # Terminal prefix discard, including repeated channel0 on the final event.
    for terminal_channel in [0, 1, 2]:
        c.emit(rearm=1, rearm_tag=0)
        for ordinal in range((1 << seq)-1):
            c.event(ordinal % 4, 1)
        c.event(terminal_channel, 1)
        for _ in range(depth+4):
            c.emit(ready=1)
        assert not c.model.collector.prefix and c.model.collector.exhausted
    if seq >= 8:
        # All tag bits enter via collector rearm; repeat tag after fully populated windows.
        for bit in range(tag):
            for value in [1 << bit, mask(tag) ^ (1 << bit)]:
                c.emit(rearm=1, rearm_tag=value)
                c.scan(1)
                for _ in range(depth+3):
                    c.emit(ready=1)
    return c.close()

def sanity():
    cfg = Config(depth=1, seq=2, tick=1, tag=1, stat=2)
    q = Oracle(cfg)
    q.edge(input_row(rst=1))
    a = (1, 2, 3, 0, 1, 1)
    x = q.edge(input_row(iv=1, **dict(zip(FIELDS,a))))
    assert x['pre']['ir'] == 1 and x['pre']['ov'] == 0 and x['post']['level'] == 1
    x = q.edge(input_row(iv=1, ready=1, **dict(zip(FIELDS,a))))
    assert x['pre']['ir'] == 0 and x['pre']['o_data'] == 1 and x['post']['level'] == 0
    x = q.edge(input_row(iv=1, ready=1, **dict(zip(FIELDS,a))))
    assert x['post']['accepted'] == 2 and x['post']['retired'] == 1
    x = q.edge(input_row(cancel=1))
    assert x['post']['aborted'] == 1 and x['post']['accepted'] == 2
    # Discriminator tests: an always-low DUT offer is rejected against a fixed reference.
    observed = {'pre': dict(x['pre']), 'post': dict(x['post'])}
    assert compare(x, observed) is None
    observed['post']['level'] = 1
    assert compare(x, observed)['numeric']
    y = q.edge(input_row())
    observed = {'pre': dict(y['pre']), 'post': dict(y['post'])}
    observed['pre']['ir'] = 0
    assert compare(y, observed)['port'] == 'ir'
    c = Oracle(Config(depth=3, seq=3, tick=8, tag=8, stat=3, mode=1))
    c.edge(input_row(rst=1)); c.edge(input_row(rearm=1,rearm_tag=9))
    for i in range(4):
        c.edge(input_row(strobe=1,channel=i,sample_data=i+1,sample_tick=10+i,sample_quality=20+i))
    assert c.collector.slot == (0x0004000300020001,0x0d0c0b0a,0x17161514,0,3,9)
    x = c.edge(input_row())
    assert x['post']['level'] == 1 and x['post']['c_retired'] == 1
    x = c.edge(input_row(rearm=1,rearm_tag=9))
    assert x['post']['level'] == 0 and x['post']['aborted'] == 1 and x['post']['c_retired'] == 0
    return {'manual_queue_and_collector_examples': 'passed', 'wrong_offer_and_stale_level_discriminators': 'passed', 'no_DUT_or_author_source_read': True}

def main():
    assert all(Path(os.environ[k]).resolve() == M/'tmp' for k in ['TMP','TEMP','TMPDIR'])
    assert Path(tempfile.gettempdir()).resolve() == M/'tmp' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
    dump(M/'vector_process_environment.json', {'cwd':os.getcwd(),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR'],'resolved_temp':tempfile.gettempdir(),'dont_write_bytecode':True})
    V.mkdir()
    dump(M/'oracle_sanity.json', sanity())
    cases = [queue_case(d) for d in [1,2,3,4,5,8]]
    cases += [width_case('payload64',Config(depth=4,tag=64)),
              width_case('depth8_stat2',Config(depth=8,seq=2,tick=1,tag=1,stat=2)),
              width_case('depth8_stat3',Config(depth=8,seq=3,tick=2,tag=2,stat=3))]
    cases += [width_case('supplement_depth'+str(d),Config(depth=d,seq=5,tick=3,tag=4,stat=3)) for d in [6,7]]
    cases += [composition_case(d) for d in [1,3,4,5]]
    cases += [composition_case(1,seq=2,tick=1,tag=1,stat=2),composition_case(3,seq=3,tick=16,tag=8,stat=3)]
    total = sum(c['edges'] for c in cases)
    assert total <= 500000
    manifest = {'cases': cases, 'case_count':len(cases), 'exact_positive_edges':total, 'cap':500000,
                'input_columns':INPUTS, 'expected_semantics':'independent pre/post public ports; offers from reference list, not DUT',
                'parameter_guards':[{'parameter':p,'value':v,'expected_fatal':'deepeye_raw_scan_queue: '+p+' out of range'} for p,vs in [('DEPTH',[0,9]),('SEQ_W',[1,33]),('TICK_W',[0,65]),('TAG_W',[0,65]),('STAT_W',[1,33])] for v in vs],
                'legal_guard_controls':[{'DEPTH':1,'SEQ_W':2,'TICK_W':1,'TAG_W':1,'STAT_W':2},{'DEPTH':8,'SEQ_W':32,'TICK_W':64,'TAG_W':64,'STAT_W':32}],
                'competing_guard':{'DEPTH':0,'SEQ_W':1,'expected_fatal':'deepeye_raw_scan_queue: DEPTH out of range'},
                'mutation_intents':[{'id':'M_WRAP','intent':'Change nonpower2 wrap/order to produce finite numeric output/level mismatch under queue_depth3 or5; compiler/X-only not a kill'}, {'id':'M_CANCEL','intent':'Retain/re-expose pre-cancel stored record to produce finite numeric valid/level/payload mismatch under queue_depth3; foreign error not a kill'}],
                'freeze_before_author':True,'author_source_read':False,'oracle_sha256':sha(M/'oracle23.py'),'generator_sha256':sha(Path(__file__))}
    dump(M/'VECTOR_MANIFEST.json',manifest)
    print(json.dumps({'cases':len(cases),'exact_positive_edges':total,'manifest_sha256':sha(M/'VECTOR_MANIFEST.json')}))

if __name__ == '__main__':
    main()
