"""Independent list/event semantics, written before any op23 author dispatch.

No DUT reads, pointer model, author import, simulator feedback or dynamic oracle
repair. Expected offers are computed before transitions, never from observed DUT.
"""
from dataclasses import dataclass

FIELDS = ('data', 'ticks', 'quality', 'first_seq', 'last_seq', 'tag')
INPUTS = ('rst', 'cancel', 'iv', 'ready', *FIELDS, 'stop', 'rearm', 'rearm_tag', 'strobe', 'channel', 'sample_data', 'sample_tick', 'sample_quality')

@dataclass(frozen=True)
class Config:
    depth: int = 4
    seq: int = 32
    tick: int = 64
    tag: int = 32
    stat: int = 32
    mode: int = 0

    def __post_init__(self):
        assert 1 <= self.depth <= 8 and 2 <= self.seq <= 32
        assert 1 <= self.tick <= 64 and 1 <= self.tag <= 64
        assert 2 <= self.stat <= 32 and self.mode in (0, 1)

    @property
    def widths(self):
        return (64, 4*self.tick, 32, self.seq, self.seq, self.tag)

def mask(width):
    return (1 << width) - 1

def payload(row):
    return tuple(row[k] for k in FIELDS)

def input_row(**kwargs):
    row = {key: 0 for key in INPUTS}
    assert set(kwargs) <= set(row)
    row.update(kwargs)
    return row

def put_record(target, prefix, record):
    for key, value in zip(FIELDS, record):
        target[prefix + key] = value

class Queue:
    def __init__(self, cfg):
        self.cfg = cfg
        self.records = []
        self.accepted = self.retired = self.aborted = 0

    def offers(self, rst, cancel):
        return (int(not (rst or cancel) and len(self.records) < self.cfg.depth),
                int(not (rst or cancel) and bool(self.records)))

    def view(self, rst, cancel):
        ir, ov = self.offers(rst, cancel)
        cap = mask(self.cfg.stat)
        result = {'ir': ir, 'ov': ov, 'level': len(self.records),
                  'accepted': min(self.accepted, cap), 'retired': min(self.retired, cap), 'aborted': min(self.aborted, cap)}
        if ov:
            put_record(result, 'o_', self.records[0])
        return result

    def step(self, rst, cancel, iv, record, ready):
        ir, ov = self.offers(rst, cancel)
        accepted, retired = int(bool(iv and ir)), int(bool(ready and ov))
        if rst:
            self.records.clear()
            self.accepted = self.retired = self.aborted = 0
        elif cancel:
            self.aborted += len(self.records)
            self.records.clear()
        else:
            if retired:
                self.records.pop(0)
                self.retired += 1
            if accepted:
                assert len(record) == 6
                assert all(0 <= n <= mask(w) for n, w in zip(record, self.cfg.widths))
                self.records.append(tuple(record))
                self.accepted += 1
        assert 0 <= len(self.records) <= self.cfg.depth
        assert self.accepted == self.retired + self.aborted + len(self.records)
        return accepted, retired

class Collector:
    """Semantic event history: prefix events carry (ordinal,data,tick,quality)."""
    COUNTS = ('events', 'scans', 'retired', 'discarded', 'order_errors', 'overruns')

    def __init__(self, cfg):
        self.cfg = cfg
        self.clear()

    def clear(self):
        self.prefix = []
        self.slot = None
        self.armed = self.exhausted = self.ordinal = self.tag = 0
        self.counts = dict.fromkeys(self.COUNTS, 0)
        self.pulses = [0, 0, 0]

    def valid(self, row):
        return int(self.slot is not None and not (row['rst'] or row['stop'] or row['rearm']))

    def view(self, row):
        valid = self.valid(row)
        out = {'cv': valid, 'c_armed': self.armed, 'c_partial': len(self.prefix), 'c_next': self.ordinal,
               'c_exhausted': self.exhausted, 'c_order_event': self.pulses[0],
               'c_overrun_event': self.pulses[1], 'c_exhaust_event': self.pulses[2]}
        out.update({'c_' + k: min(v, mask(self.cfg.stat)) for k, v in self.counts.items()})
        if valid:
            put_record(out, 'c_', self.slot)
        return out

    def step(self, row, queue_credit):
        if row['rst'] or row['stop'] or row['rearm']:
            self.clear()
            if row['rearm'] and not (row['rst'] or row['stop']):
                self.armed, self.tag = 1, row['rearm_tag']
            return
        self.pulses = [0, 0, 0]
        if self.slot is not None and queue_credit:
            self.slot = None
            self.counts['retired'] += 1
        if not (self.armed and row['strobe']):
            return
        ordinal = self.ordinal
        event = (ordinal, row['sample_data'], row['sample_tick'], row['sample_quality'])
        self.counts['events'] += 1
        channel = row['channel']
        if channel == len(self.prefix):
            self.prefix.append(event)
        else:
            self.counts['order_errors'] += 1
            self.pulses[0] = 1
            self.counts['discarded'] += len(self.prefix) + int(channel != 0)
            self.prefix = [event] if channel == 0 else []
        if len(self.prefix) == 4:
            seq = self.prefix
            record = (sum(e[1] << (16*i) for i, e in enumerate(seq)),
                      sum(e[2] << (self.cfg.tick*i) for i, e in enumerate(seq)),
                      sum(e[3] << (8*i) for i, e in enumerate(seq)), seq[0][0], seq[-1][0], self.tag)
            self.counts['scans'] += 1
            if self.slot is None:
                self.slot = record
            else:
                self.counts['overruns'] += 1
                self.counts['discarded'] += 4
                self.pulses[1] = 1
            self.prefix = []
        if ordinal == mask(self.cfg.seq):
            self.armed, self.exhausted = 0, 1
            self.pulses[2] = 1
            self.counts['discarded'] += len(self.prefix)
            self.prefix = []
        else:
            self.ordinal += 1

class Oracle:
    def __init__(self, cfg):
        self.cfg = cfg
        self.queue = Queue(cfg)
        self.collector = Collector(cfg) if cfg.mode else None
        self.index = 0
        self.held = None
        self.last_out = None

    def abort(self, row):
        return int(bool(row['stop'] or row['rearm'])) if self.cfg.mode else row['cancel']

    def view(self, row):
        out = self.queue.view(row['rst'], self.abort(row))
        if self.collector:
            out.update(self.collector.view(row))
        return out

    def edge(self, row):
        assert set(row) == set(INPUTS)
        for key in ('rst', 'cancel', 'iv', 'ready', 'stop', 'rearm', 'strobe'):
            assert row[key] in (0, 1)
        assert 0 <= row['channel'] < 4
        assert 0 <= row['sample_data'] < 2**16 and 0 <= row['sample_quality'] < 256
        assert 0 <= row['sample_tick'] <= mask(self.cfg.tick) and 0 <= row['rearm_tag'] <= mask(self.cfg.tag)
        pre = self.view(row)
        abort = row['rst'] or self.abort(row)
        iv = self.collector.valid(row) if self.collector else row['iv']
        record = self.collector.slot if self.collector else payload(row)
        if not abort and self.held is not None:
            assert iv and record == self.held, ('upstream-stability', self.index)
        self.held = tuple(record) if iv and not pre['ir'] and not abort else None
        if not abort and self.last_out is not None:
            assert pre['ov'] and tuple(pre['o_'+k] for k in FIELDS) == self.last_out
        self.last_out = tuple(pre['o_'+k] for k in FIELDS) if pre['ov'] and not row['ready'] else None
        if abort:
            self.last_out = None
        taken, given = self.queue.step(row['rst'], self.abort(row), iv, record, row['ready'])
        if self.collector:
            self.collector.step(row, pre['ir'])
        post = self.view(row)
        # Registers before the first reset edge are unspecified; offers are not.
        if self.index == 0:
            assert row['rst'] == 1
            pre = {k: v for k, v in pre.items() if k in ('ir', 'ov', 'cv')}
        result = {'index': self.index, 'pre': pre, 'post': post, 'accepted': taken, 'retired': given,
                  'true_queue_counts': [self.queue.accepted, self.queue.retired, self.queue.aborted]}
        self.index += 1
        return result

def compare(expected, observed):
    """Numeric public-port comparison, with no adaptation to DUT handshakes."""
    for phase in ('pre', 'post'):
        for key, value in expected[phase].items():
            got = observed.get(phase, {}).get(key)
            if type(got) is not int or got != value:
                return {'index': expected['index'], 'phase': phase, 'port': key, 'expected': value, 'actual': got,
                        'numeric': type(got) is int}
    return None
