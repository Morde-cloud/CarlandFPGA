import hashlib,json,tempfile
from pathlib import Path
from datetime import datetime,timezone
M=Path(__file__).resolve().parent
assert Path(tempfile.gettempdir()).resolve()==M/'tmp'
source=M/'candidate01/q.sv';raw=source.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='5a72ef652ad0ba803504ec69a63c819404376090df5e968b182434ef8150c4af'
root=M/'mutants01';root.mkdir()
mutations=[('M_WRAP',b"            next_rd_ptr = '0;",b"            next_rd_ptr = 1;"),
           ('M_CANCEL',b"            level_q         <= {LEVEL_W{1'b0}};",b"            level_q         <= level_q;")]
records=[]
for name,old,new in mutations:
    assert raw.count(old)==1
    changed=raw.replace(old,new);out=root/(name+'.sv')
    with out.open('xb') as f:f.write(changed)
    records.append({'id':name,'source_sha256':hashlib.sha256(raw).hexdigest(),'old':old.decode(),'new':new.decode(),'anchor_count':1,'mutant_path':str(out),'mutant_sha256':hashlib.sha256(changed).hexdigest(),'case':'queue_depth3','criterion':'Compiled DUT and successful process/trace capture followed by finite numeric public-port discrepancy; compile/X-only failures do not qualify'})
receipt={'at_utc':datetime.now(timezone.utc).isoformat(),'predispatch_freeze_sha256':'f18bc6100f942fe9b6ae99e69bbc1aaaea88ee46375b338868ab03f877ba1159','intent_before_mutant_execution':True,'mutants':records,'source_status':'Provisional candidate with five known upper-guard failures; mutation checks do not grant whole operation acceptance','resolved_temp':tempfile.gettempdir()}
with (root/'INTENT.json').open('x',encoding='utf-8') as f:json.dump(receipt,f,indent=2);f.write('\n')
print(json.dumps(receipt))
