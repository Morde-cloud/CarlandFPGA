"""Owned subprocess receipts and strict classifier for the main's new driver.

Reuses the exact op22 compile/diagnostic/version functions read-only. New Q23
markers and real CLI propagation are independently qualified before acceptance.
"""
import argparse,hashlib,importlib.util,json,os,re,subprocess,sys,tempfile,time
from datetime import datetime,timezone
from pathlib import Path
M=Path(__file__).resolve().parent
W=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014')
OLD=W/'competition/deepeye/tools/acquisition/run_sample_scan_capture.py'
OLD_HASH='a47dcfb493316f23578d4b10e8d832e3bc48512377e4df07c54f27ec11081547'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,obj):
    assert p.resolve().is_relative_to(M)
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(obj,f,ensure_ascii=False,indent=2);f.write('\n')
assert sha(OLD)==OLD_HASH
spec=importlib.util.spec_from_file_location('op22_readonly',OLD)
old=importlib.util.module_from_spec(spec);spec.loader.exec_module(old)

def classify(kind,record,case=None,edges=None,own=None,tool=None):
    reasons=[]
    if record.get('timed_out'):reasons.append('timeout')
    if record.get('exception_type'):reasons.append('process exception')
    if type(record.get('exit')) is not int or record['exit']!=0:reasons.append('nonzero/absent process exit')
    stdout=record.get('stdout_text','');stderr=record.get('stderr_text','')
    if not isinstance(stdout,str) or not isinstance(stderr,str):return {'ok':False,'reasons':['nontext streams']}
    if kind=='version':
        if tool not in ('vlog','vsim'):reasons.append('unknown version tool')
        else:reasons+=old._version_failure_reasons(tool,record)
    elif kind=='compile':
        reasons+=old.classify_compile(record.get('exit'),stdout,stderr)['reasons']
    elif kind in ('positive','guard','guard_control'):
        if kind=='guard' and own not in ['deepeye_raw_scan_queue: '+p+' out of range' for p in ['DEPTH','SEQ_W','TICK_W','TAG_W','STAT_W']]:
            reasons.append('foreign own fatal');own=None
        reasons+=old._strict_diagnostics(stdout,stderr,own if kind=='guard' else None)
        rows=[]
        for origin,text in [('stdout',stdout),('stderr',stderr)]:
            for line in text.splitlines():
                line=line.strip()
                if line.startswith('# '):line=line[2:]
                if 'Q23_' in line:
                    if origin!='stdout':reasons.append('marker on stderr')
                    rows.append(line)
        if kind=='positive':
            if not isinstance(case,str) or not re.fullmatch('[a-zA-Z0-9_]+',case):reasons.append('invalid case identity')
            if type(edges) is not int or edges<=0:reasons.append('invalid edge bound')
            expected=[f'Q23_STATS case={case} edges={edges} trace_rows={2*edges if type(edges) is int else -1}',f'Q23_PASS case={case} edges={edges}']
            if rows!=expected:reasons.append('markers missing/duplicated/malformed/inconsistent')
        elif kind=='guard_control':
            if rows!=['Q23_GUARD_ALIVE']:reasons.append('legal guard control not uniquely alive')
        elif rows:reasons.append('guard reached driver completion or unexpected marker')
    else:reasons.append('unknown classifier kind')
    return {'ok':not reasons,'reasons':reasons,'kind':kind}

def run(argv,cwd,label,timeout=60,inputs=None):
    cwd=Path(cwd).resolve();assert cwd.is_relative_to(M) and cwd.is_dir()
    temp=cwd/'tmp';temp.mkdir(exist_ok=True)
    env=dict(os.environ)
    for key in ('TMP','TEMP','TMPDIR'):env[key]=str(temp)
    env['PYTHONDONTWRITEBYTECODE']='1';env['GIT_OPTIONAL_LOCKS']='0'
    stamp=datetime.now(timezone.utc).isoformat()
    intent={'argv':[str(x) for x in argv],'cwd':str(cwd),'timeout_seconds':timeout,'started_utc':stamp,
            'TMP':str(temp),'TEMP':str(temp),'TMPDIR':str(temp),'PYTHONDONTWRITEBYTECODE':'1',
            'parent_resolved_temp':tempfile.gettempdir(),'child_expected_temp':str(temp),
            'executable_sha256':sha(Path(argv[0])),'inputs':inputs or [],'helper_sha256':sha(Path(__file__))}
    put(cwd/(label+'.intent.json'),intent)
    start=time.monotonic()
    try:
        p=subprocess.run([str(x) for x in argv],cwd=cwd,env=env,stdin=subprocess.DEVNULL,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                         timeout=timeout,check=False,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0))
        record={'exit':p.returncode,'timed_out':False};out,err=p.stdout,p.stderr
    except subprocess.TimeoutExpired as e:
        record={'exit':None,'timed_out':True,'exception_type':type(e).__name__};out,err=e.stdout or b'',e.stderr or b''
    except OSError as e:
        record={'exit':None,'timed_out':False,'exception_type':type(e).__name__,'exception_message':str(e)};out,err=b'',b''
    for suffix,data in [('stdout',out),('stderr',err)]:
        with (cwd/(label+'.'+suffix+'.bin')).open('xb') as f:f.write(data)
    record.update(argv=intent['argv'],cwd=str(cwd),ended_utc=datetime.now(timezone.utc).isoformat(),elapsed=time.monotonic()-start,
                  stdout_sha256=hashlib.sha256(out).hexdigest(),stderr_sha256=hashlib.sha256(err).hexdigest(),
                  stdout_path=str(cwd/(label+'.stdout.bin')),stderr_path=str(cwd/(label+'.stderr.bin')))
    put(cwd/(label+'.result.json'),record)
    return dict(record,stdout_text=out.decode('utf-8',errors='replace'),stderr_text=err.decode('utf-8',errors='replace'))

def main():
    p=argparse.ArgumentParser();p.add_argument('--classify',type=Path,required=True);args=p.parse_args()
    try:
        request=json.loads(args.classify.read_bytes())
        result=classify(**request)
        result['process_environment']={'cwd':os.getcwd(),'TMP':os.environ.get('TMP'),'TEMP':os.environ.get('TEMP'),'TMPDIR':os.environ.get('TMPDIR'),'resolved_temp':tempfile.gettempdir(),'PYTHONDONTWRITEBYTECODE':os.environ.get('PYTHONDONTWRITEBYTECODE')}
        print(json.dumps(result))
        return 0 if result['ok'] else 2
    except Exception as e:
        print(json.dumps({'ok':False,'exception':type(e).__name__+': '+str(e)}));return 3
if __name__=='__main__':raise SystemExit(main())
