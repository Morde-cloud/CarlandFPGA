import json,os,sys,tempfile,time
from pathlib import Path
x=json.loads(Path(sys.argv[1]).read_bytes())
Path('resolved_env.json').write_text(json.dumps({'resolved_temp':tempfile.gettempdir(),'cwd':os.getcwd(),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR']}))
print(x['stdout'],end='',flush=True)
time.sleep(x['sleep'])
sys.exit(x['exit'])
