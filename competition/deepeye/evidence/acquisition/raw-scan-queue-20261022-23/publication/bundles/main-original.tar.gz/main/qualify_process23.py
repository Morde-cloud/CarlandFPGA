"""Synthetic qualification only; no simulator or DUT claims."""
import copy,gzip,importlib.util,json,os,sys,tempfile
from pathlib import Path
from process23 import M,W,put,run,classify,sha
PY=Path('D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe')
Q=M/'qualification'
def rec(text,**kw):return dict(exit=0,timed_out=False,stdout_text=text,stderr_text='',**kw)
def main():
    assert Path(tempfile.gettempdir()).resolve()==M/'tmp'
    Q.mkdir();put(Q/'environment.json',{'cwd':os.getcwd(),'resolved_temp':tempfile.gettempdir(),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR']})
    pos='Q23_STATS case=fixture edges=2 trace_rows=4\nQ23_PASS case=fixture edges=2\nErrors: 0, Warnings: 0\n'
    guard='** Fatal: deepeye_raw_scan_queue: DEPTH out of range\nErrors: 1, Warnings: 0\n'
    bases=[{'kind':'positive','record':rec(pos),'case':'fixture','edges':2},
           {'kind':'compile','record':rec('Errors: 0, Warnings: 0\n')},
           {'kind':'guard','record':rec(guard),'own':'deepeye_raw_scan_queue: DEPTH out of range'},
           {'kind':'guard_control','record':rec('Q23_GUARD_ALIVE\nErrors: 0, Warnings: 0\n')},
           {'kind':'version','record':rec('Model Technology ModelSim SE-64 vlog 10.7 Compiler 2017.12 Dec 7 2017\n'),'tool':'vlog'},
           {'kind':'version','record':rec('Model Technology ModelSim SE-64 vsim 10.7 Simulator 2017.12 Dec 7 2017\n'),'tool':'vsim'}]
    matrix=[]
    for i,b in enumerate(bases):
        matrix.append((f'positive_{i}',copy.deepcopy(b),True))
        for tag,value in [('exit',7),('timed_out',True),('exception_type','OSError')]:
            x=copy.deepcopy(b);x['record'][tag]=value;matrix.append((f'base{i}_{tag}',x,False))
        for stream,text in [('stdout_text','** Error: injected\n'),('stderr_text','** Warning: injected\n')]:
            x=copy.deepcopy(b);x['record'][stream]+=text;matrix.append((f'base{i}_{stream}',x,False))
    replacements=[('missingpass',pos.replace('Q23_PASS case=fixture edges=2\n','')),
        ('duplicatepass',pos+'Q23_PASS case=fixture edges=2\n'),('substring',pos.replace('Q23_PASS','NOT_Q23_PASS')),
        ('duplicatestats',pos+'Q23_STATS case=fixture edges=2 trace_rows=4\n'),
        ('conflictstats',pos+'Q23_STATS case=fixture edges=3 trace_rows=6\n'),
        ('badnumber',pos.replace('trace_rows=4','trace_rows=x')),
        ('wrongcase',pos.replace('case=fixture','case=other')),
        ('extrafield',pos.replace('edges=2\n','edges=2 extra=0\n')),
        ('missingsummary',pos.replace('Errors: 0, Warnings: 0\n','')),
        ('dupsummary',pos+'Errors: 0, Warnings: 0\n'),
        ('badsummary',pos.replace('Warnings: 0','Warnings: 1'))]
    for name,text in replacements:
        x=copy.deepcopy(bases[0]);x['record']['stdout_text']=text;matrix.append((name,x,False))
    for name,text in [('foreignfatal',guard.replace('raw_scan_queue','sample_scan_capture')),
                      ('dupfatal',guard+guard),('badguardsummary',guard.replace('Errors: 1','Errors: 0')),
                      ('guardalive',guard+'Q23_GUARD_ALIVE\n'),('guardsubstring',guard.replace('** Fatal:','** Fatal: prefix'))]:
        x=copy.deepcopy(bases[2]);x['record']['stdout_text']=text;matrix.append((name,x,False))
    x=copy.deepcopy(bases[0]);x['record']['stdout_text']=pos.splitlines()[-1]+'\n';x['record']['stderr_text']='\n'.join(pos.splitlines()[:-1])+'\n';matrix.append(('markersstderr',x,False))
    put(Q/'MATRIX_FROZEN.json',{'cases':[{'name':n,'request':x,'expected_ok':e} for n,x,e in matrix],'process_helper_sha256':sha(M/'process23.py'),'synthetic':True})
    results=[]
    for i,(name,request,ok) in enumerate(matrix):
        d=Q/f'c{i:03}';d.mkdir();put(d/'request.json',request)
        direct=classify(**request);assert direct['ok']==ok,(name,direct)
        actual=run([PY,'-B','-X','utf8',M/'process23.py','--classify',d/'request.json'],d,'entry',30)
        parsed=json.loads(actual['stdout_text']);assert actual['exit']==(0 if ok else 2) and parsed['ok']==ok,(name,actual)
        assert Path(parsed['process_environment']['resolved_temp']).resolve()==d/'tmp'
        results.append({'name':name,'expected':ok,'direct':direct,'entry_exit':actual['exit']})
    # Actual child process failure/timeout, not just a fabricated timed_out field.
    emitter=Q/'emitter.py'
    emitter.write_text("import json,os,sys,tempfile,time\nfrom pathlib import Path\nx=json.loads(Path(sys.argv[1]).read_bytes())\nPath('resolved_env.json').write_text(json.dumps({'resolved_temp':tempfile.gettempdir(),'cwd':os.getcwd(),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR']}))\nprint(x['stdout'],end='',flush=True)\ntime.sleep(x['sleep'])\nsys.exit(x['exit'])\n",encoding='utf-8')
    real=[]
    for name,code,sleep,timeout,ok in [('success',0,0,30,True),('exit7',7,0,30,False),('timeout',0,3,1,False)]:
        d=Q/name;d.mkdir();put(d/'input.json',{'stdout':pos,'exit':code,'sleep':sleep})
        actual=run([PY,'-B','-X','utf8',emitter,d/'input.json'],d,'emitter',timeout)
        classified=classify('positive',actual,case='fixture',edges=2)
        assert classified['ok']==ok,(name,classified)
        if name=='timeout':assert actual['timed_out']
        assert Path(json.loads((d/'resolved_env.json').read_bytes())['resolved_temp']).resolve()==d/'tmp'
        real.append({'name':name,'exit':actual['exit'],'timeout':actual['timed_out'],'classification':classified})
    # Public-port trace decoder/CLI qualification. These are constructed traces,
    # explicitly not RTL runs or numeric compiled mutant kills.
    verifier=W/'competition/deepeye/tools/acquisition/main_verify_raw_scan_queue.py'
    spec=importlib.util.spec_from_file_location('q23_verify',verifier);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    man=json.loads((M/'VECTOR_MANIFEST.json').read_bytes());case=next(c for c in man['cases'] if c['name']=='composition_d1_s2')
    expected=[json.loads(x) for x in gzip.open(M/'vectors'/case['expected']['path'],'rb')]
    stimuli=[dict(zip(module.INPUT_COLUMNS,[int(x,16) for x in line.split()])) for line in (M/'vectors'/case['stimulus']['path']).read_text().splitlines()]
    lines=[]
    for item,row in zip(expected,stimuli):
        for phase in ['pre','post']:
            values=dict.fromkeys(module.COLUMNS,0);values.update(item[phase]);values.update({'i_'+k:v for k,v in row.items()})
            lines.append(phase.upper()+' '+str(item['index'])+' '+' '.join(format(values[k],'x') for k in module.COLUMNS)+'\n')
    trace_matrix=[('positive',lines,0),('missing',lines[:-1],2),('duplicate',lines+[lines[-1]],2)]
    changed=lines.copy();words=changed[0].split();words[2]='1';changed[0]=' '.join(words)+'\n';trace_matrix.append(('wrongready',changed,1))
    changed=lines.copy();words=changed[1].split();words[2+module.COLUMNS.index('level')]='1';changed[1]=' '.join(words)+'\n';trace_matrix.append(('stalelevel',changed,1))
    changed=lines.copy();words=changed[0].split();words[2]='invalid';changed[0]=' '.join(words)+'\n';trace_matrix.append(('badnumeric',changed,2))
    traces=[]
    for name,content,exit_code in trace_matrix:
        d=Q/('trace_'+name);d.mkdir();path=d/'ports.txt';path.write_text(''.join(content),encoding='ascii',newline='\n')
        actual=run([PY,'-B','-X','utf8',verifier,'--main',M,'--case',case['name'],'--trace',path],d,'verify',30)
        assert actual['exit']==exit_code,(name,actual)
        parsed=json.loads(actual['stdout_text'])
        if exit_code==1:assert parsed['first_mismatch']['numeric']
        traces.append({'name':name,'actual_exit':actual['exit'],'result':parsed})
    put(Q/'RESULT.json',{'synthetic_classifier_cases':len(matrix),'direct_checks':len(results),'actual_classifier_entries':len(results),'actual_subprocess_failure_controls':real,'synthetic_trace_decoder_entries':traces,'results':results,'all_pass':True,'not_RTL_evidence':True})
    print(json.dumps({'classifier_cases':len(matrix),'direct_and_actual_entry_pass':True,'actual_failure_controls':len(real),'synthetic_trace_entries':len(traces),'result_sha256':sha(Q/'RESULT.json')}))
if __name__=='__main__':main()
