`timescale 1ns/1ps
// Public-port driver only. Expected values live in the frozen independent oracle.
module main_tb_raw_scan_queue #(
    parameter integer D=4, S=32, T=64, G=32, K=32, MODE=0
);
    localparam integer DE=(D>=1 && D<=8)?D:1;
    localparam integer SE=(S>=2 && S<=32)?S:2;
    localparam integer TE=(T>=1 && T<=64)?T:1;
    localparam integer GE=(G>=1 && G<=64)?G:1;
    localparam integer KE=(K>=2 && K<=32)?K:2;
    localparam integer LW=($clog2(DE+1)>0)?$clog2(DE+1):1;
    reg clk=0, rst=1, cancel=0, iv=0, ready=0, stop=0, rearm=0, strobe=0;
    reg [63:0] data=0;
    reg [4*TE-1:0] ticks=0;
    reg [31:0] quality=0;
    reg [SE-1:0] first_seq=0,last_seq=0;
    reg [GE-1:0] tag=0,rearm_tag=0;
    reg [1:0] channel=0;
    reg [15:0] sample_data=0;
    reg [TE-1:0] sample_tick=0;
    reg [7:0] sample_quality=0;
    wire ir,ov;
    wire [LW-1:0] level;
    wire [KE-1:0] accepted,retired,aborted;
    wire [63:0] o_data;
    wire [4*TE-1:0] o_ticks;
    wire [31:0] o_quality;
    wire [SE-1:0] o_first_seq,o_last_seq;
    wire [GE-1:0] o_tag;
    wire cv,c_armed,c_exhausted,c_order_event,c_overrun_event,c_exhaust_event;
    wire [2:0] c_partial;
    wire [SE-1:0] c_next;
    wire [KE-1:0] c_events,c_scans,c_retired,c_discarded,c_order_errors,c_overruns;
    wire [63:0] c_data;
    wire [4*TE-1:0] c_ticks;
    wire [31:0] c_quality;
    wire [SE-1:0] c_first_seq,c_last_seq;
    wire [GE-1:0] c_tag;
    generate if (MODE==1) begin: composition
        deepeye_sample_scan_capture #(.SEQ_W(S),.TICK_W(T),.TAG_W(G),.STAT_W(K)) collector (
            .clk(clk),.rst(rst),.stop(stop),.rearm(rearm),.rearm_tag(rearm_tag),
            .sample_strobe(strobe),.sample_channel(channel),.sample_data(sample_data),
            .sample_tick(sample_tick),.sample_quality(sample_quality),.out_ready(ir),
            .out_valid(cv),.out_data(c_data),.out_ticks(c_ticks),.out_quality(c_quality),
            .out_first_seq(c_first_seq),.out_last_seq(c_last_seq),.out_tag(c_tag),
            .armed(c_armed),.partial_len(c_partial),.next_seq(c_next),.seq_exhausted(c_exhausted),
            .order_error_event(c_order_event),.overrun_event(c_overrun_event),.seq_exhaust_event(c_exhaust_event),
            .stat_events(c_events),.stat_scans(c_scans),.stat_retired(c_retired),
            .stat_discarded_samples(c_discarded),.stat_order_errors(c_order_errors),.stat_overruns(c_overruns)
        );
    end else begin: queue_only
        assign cv=0; assign c_armed=0; assign c_partial=0; assign c_next=0;
        assign c_exhausted=0; assign c_order_event=0; assign c_overrun_event=0; assign c_exhaust_event=0;
        assign c_events=0; assign c_scans=0; assign c_retired=0; assign c_discarded=0;
        assign c_order_errors=0; assign c_overruns=0;
        assign c_data=0; assign c_ticks=0; assign c_quality=0;
        assign c_first_seq=0; assign c_last_seq=0; assign c_tag=0;
    end endgenerate
    deepeye_raw_scan_queue #(.DEPTH(D),.SEQ_W(S),.TICK_W(T),.TAG_W(G),.STAT_W(K)) queue_dut (
        .clk(clk),.rst(rst),.cancel((MODE==1)?(stop|rearm):cancel),
        .in_valid((MODE==1)?cv:iv),.in_ready(ir),
        .in_data((MODE==1)?c_data:data),.in_ticks((MODE==1)?c_ticks:ticks),
        .in_quality((MODE==1)?c_quality:quality),
        .in_first_seq((MODE==1)?c_first_seq:first_seq),.in_last_seq((MODE==1)?c_last_seq:last_seq),
        .in_tag((MODE==1)?c_tag:tag),.out_valid(ov),.out_ready(ready),
        .out_data(o_data),.out_ticks(o_ticks),.out_quality(o_quality),
        .out_first_seq(o_first_seq),.out_last_seq(o_last_seq),.out_tag(o_tag),
        .level(level),.stat_accepted(accepted),.stat_retired(retired),.stat_aborted(aborted)
    );
    integer input_fd,trace_fd,rc,edge_index=0;
    string stim_path,trace_path,case_name;
    task automatic capture(input string phase_name);
        $fdisplay(trace_fd,"%s %0d %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h",
            phase_name,edge_index,ir,ov,level,accepted,retired,aborted,o_data,o_ticks,o_quality,o_first_seq,o_last_seq,o_tag,cv,c_armed,c_partial,c_next,c_exhausted,c_order_event,c_overrun_event,c_exhaust_event,c_events,c_scans,c_retired,c_discarded,c_order_errors,c_overruns,c_data,c_ticks,c_quality,c_first_seq,c_last_seq,c_tag,rst,cancel,iv,ready,data,ticks,quality,first_seq,last_seq,tag,stop,rearm,rearm_tag,strobe,channel,sample_data,sample_tick,sample_quality);
    endtask
    initial begin
        if ($test$plusargs("GUARD")) begin
            #3;
            $display("Q23_GUARD_ALIVE");
            $finish;
        end else begin
            if (!$value$plusargs("STIM=%s",stim_path) || !$value$plusargs("TRACE=%s",trace_path) || !$value$plusargs("CASE=%s",case_name))
                $fatal(1,"Q23_DRIVER missing arguments");
            input_fd=$fopen(stim_path,"r"); trace_fd=$fopen(trace_path,"w");
            if (!input_fd || !trace_fd) $fatal(1,"Q23_DRIVER file open");
            while (!$feof(input_fd)) begin
                rc=$fscanf(input_fd,"%h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h %h\n",rst,cancel,iv,ready,data,ticks,quality,first_seq,last_seq,tag,stop,rearm,rearm_tag,strobe,channel,sample_data,sample_tick,sample_quality);
                if (rc == -1 && $feof(input_fd)) break;
                if (rc != 18) $fatal(1,"Q23_DRIVER malformed stimulus");
                #2; capture("PRE");
                clk=1; #1; capture("POST");
                clk=0; #1;
                edge_index=edge_index+1;
            end
            $fclose(input_fd); $fclose(trace_fd);
            $display("Q23_STATS case=%s edges=%0d trace_rows=%0d",case_name,edge_index,2*edge_index);
            $display("Q23_PASS case=%s edges=%0d",case_name,edge_index);
            $finish;
        end
    end
endmodule
