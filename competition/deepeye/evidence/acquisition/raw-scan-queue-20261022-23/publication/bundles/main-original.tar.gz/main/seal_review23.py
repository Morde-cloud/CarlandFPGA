import hashlib,json,os,subprocess,tempfile
from datetime import datetime,timezone
from pathlib import Path
M=Path(__file__).resolve().parent;R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014'
O=R/'.local/deployment/node-b/evidence/raw-scan-queue-20261022-23';A=M.parent/'author'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
assert Path(tempfile.gettempdir()).resolve()==M/'tmp' and os.environ['PYTHONDONTWRITEBYTECODE']=='1'
terminal=json.loads((O/'JOB_AFTER_WAIT_HOST_FAILURE.json').read_bytes())['job']
assert terminal['job_id']=='child-8054ea77c7e64902a1ae1e4704721c99' and terminal['status']=='completed' and terminal['terminal'] and not terminal['stale']
assert terminal['result']['model']=='deepseek-flash' and terminal['result']['reasoning_effort']=='max'
source_paths={'competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv':'5a72ef652ad0ba803504ec69a63c819404376090df5e968b182434ef8150c4af','competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv':'ff95ada740ef39bebd176eba11d8b7f0e7720fdaa2424fa0e7036ce8081dacd0','competition/deepeye/tools/acquisition/run_raw_scan_queue.py':'dbba5297accb6cbd9f64c2ca2b07651a929f75658593cee0cbbca141dce7ba85','competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md':'5230ff2f0a05edae452444940cc78ba7f68ff534d3eff763aa107870430a62e8'}
for p,h in source_paths.items():assert sha(W/p)==h
assert sha(A/'FINAL_FILE_HASHES.json')=='cd51d45c4a78344af49c5f00b5197af00e34334778330b1219702c11196cb4ef'
assert sha(A/'SHA256SUMS.txt')=='8cfa1fc2c094d42cfdafe17535748c8f920ec32202f2095dd4eb3184127a8c6f'
author=json.loads((A/'FINAL_FILE_HASHES.json').read_bytes());assert author['file_count']==len(author['files'])==1686
for p,h in author['files'].items():
    path=(W/p).resolve();assert path.is_relative_to(A) or p in source_paths
    assert sha(path)==h,p
freeze=json.loads((M/'PREDISPATCH_FREEZE.json').read_bytes())
for row in freeze['files']:assert sha(Path(row['path']))==row['sha256'],row['path']
for row in json.loads((O/'FREEZE_CHECKS.json').read_bytes())['old_audit_files']:assert sha(Path(row['path']))==row['sha256']
assert sha(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
for path,h in json.loads((O/'CONSUMED.json').read_bytes())['read_pins'].items():assert sha(Path(path))==h
def git(*a):return subprocess.check_output(['git','-c','core.longpaths=true','-C',str(W),*a])
head=git('rev-parse','HEAD').decode().strip();assert head==freeze['baseline']['head']
assert not git('diff','--cached','--name-only') and not git('ls-files','--unmerged')
status=git('status','--porcelain=v1','--untracked-files=all');(M/'FINAL_GIT_STATUS.txt').write_bytes(status)
base=json.loads((M/'runs/baseline01/RESULT.json').read_bytes());assert base['executed']==30 and not base['all_pass']
assert all(x['pass'] for x in base['results'][:17])
failed=[x for x in base['results'] if not x['pass']];assert [x['name'] for x in failed]==['guard01','guard03','guard05','guard07','guard09']
assert all(x['compile']['ok'] and x['kind']=='guard' for x in failed)
cov=json.loads((M/'runs/baseline01/ACTUAL_COVERAGE.json').read_bytes());assert cov['coverage_checks_passed'] and cov['actual_complete_positive_edges']==87836 and not cov['whole_operation_all_pass']
mutants=[]
for name in ['mwrap01','mcancel01']:
    result=json.loads((M/'runs'/name/'RESULT.json').read_bytes());assert result['all_pass'] and result['phase']=='mutant'
    item=result['results'][0];assert item['comparison']['first_mismatch']['numeric'] and not item['comparison']['pass']
    mutants.append({'run':name,'result_sha256':sha(M/'runs'/name/'RESULT.json'),'counterexample':item['comparison']['first_mismatch']})
decision={'at_utc':datetime.now(timezone.utc).isoformat(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-LOCAL-RAW-SCAN-QUEUE-CONTINUE-20261022-v1','operation_id':'B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23','actual_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','actual_turn':'01a16293-6187-7df0-9227-cc3c0e7daa6b','decision':'REVISE','finding':'OP23-GUARD-CLAMP01','final_author_source_hashes':source_paths,'author_terminal_record_sha256':sha(O/'JOB_AFTER_WAIT_HOST_FAILURE.json'),'author_manifest_sha256':sha(A/'FINAL_FILE_HASHES.json'),'author_manifest_files_verified':1686,'baseline_head':head,'new_source_commit':None,'request_hash':None,'published_handoff_manifest':None,'local_only':True,'scope_sha256':sha(O/'SCOPE.md'),'predispatch_freeze_sha256':sha(M/'PREDISPATCH_FREEZE.json'),'review_sha256':sha(M/'REVIEW.md'),'positive_cases':17,'positive_edges':87836,'guard_failures':failed,'compiled_mutants':mutants,'main_classifier_qualification_sha256':sha(M/'qualification/RESULT.json'),'actual_coverage_sha256':sha(M/'runs/baseline01/ACTUAL_COVERAGE.json'),'contract':freeze['contract'],'not_run':['all29','B02','B03','G05','B06','R03','full_product_simulation','synthesis','implementation','timing','CDC_RDC','board','system'],'deferred':'Full independent qualification of author product runner; not promoted from author self-tests after RTL mandatory guard failure','next_required':'Correct five invalid effective declaration fallbacks within original ownership and bind/test corrected source; no correction job dispatched','known_wait_tool_errors':['code-mode host timed out waiting for wait response','cell172 belongs to stale host generation'],'no_service_change_or_job_replay':True,'board':'A-only'}
put(M/'REVIEW_DECISION.json',decision)
files=[]
for p in sorted(M.rglob('*')):
    if not p.is_file():continue
    rel=p.relative_to(M)
    if any(x in ['tmp','work','cache'] for x in rel.parts) or p.suffix.lower()=='.wlf':continue
    if p.name.startswith('seal-review.') and p.suffix=='.txt':continue
    files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for rel in source_paths:
    p=W/rel;files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
for name in ['FINAL_FILE_HASHES.json','SHA256SUMS.txt','START_ASSESSMENT.json']:
    p=A/name;files.append({'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)})
put(M/'LOCAL_REVIEW_MANIFEST.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'operation_id':decision['operation_id'],'kind':'Local rejected-candidate review manifest; not a published handoff','artifacts':files,'author_transitive_manifest_files_verified':1686,'excluded':'Derived work libraries, tmp/cache and WLF remain local; all raw public-port traces and command/source records included','decision_sha256':sha(M/'REVIEW_DECISION.json')})
receipt={k:decision[k] for k in ['task_id','task_version','work_id','operation_id','actual_thread','actual_turn','decision','finding','baseline_head','new_source_commit','request_hash','published_handoff_manifest','local_only','positive_cases','positive_edges','contract','not_run']}
receipt.update(at_utc=datetime.now(timezone.utc).isoformat(),review_path=str(M/'REVIEW.md'),review_sha256=sha(M/'REVIEW.md'),decision_path=str(M/'REVIEW_DECISION.json'),decision_sha256=sha(M/'REVIEW_DECISION.json'),local_manifest_path=str(M/'LOCAL_REVIEW_MANIFEST.json'),local_manifest_sha256=sha(M/'LOCAL_REVIEW_MANIFEST.json'),local_artifact_count=len(files),author_verified_file_count=1686,final_rtl_sha256=source_paths['competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv'],author_terminal=True,author_pool_reclaimed_receipt_sha256=sha(O/'AUTHOR_RECLAIM.json'),no_publication=True,no_correction_dispatched=True,callback='Concrete failure to coordinator only; actual accepted completion callback to retained desktop not due',ownership='Original product director and explicit paths retained; no additional writer')
put(O/'FINAL_RECEIPT.json',receipt)
print(json.dumps({'decision':'REVISE','finding':decision['finding'],'receipt_sha256':sha(O/'FINAL_RECEIPT.json'),'review_sha256':receipt['review_sha256'],'decision_sha256':receipt['decision_sha256'],'manifest_sha256':receipt['local_manifest_sha256'],'artifact_count':len(files),'author_hashes_verified':1686,'head':head}))
