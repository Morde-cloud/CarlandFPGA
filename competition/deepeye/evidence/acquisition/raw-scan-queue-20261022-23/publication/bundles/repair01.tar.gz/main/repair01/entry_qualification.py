"""Execute unchanged author main with only a synthetic real vendor-process seam."""
import importlib.util,json,os,sys,tempfile
from pathlib import Path
N=Path(__file__).resolve().parent;Q=N/'runner-qualification'
matrix=json.loads((Q/'MATRIX.json').read_bytes());cfg=next(x for x in matrix['entry_cases'] if x['name']==sys.argv[1])
assert Path(tempfile.gettempdir()).resolve().is_relative_to(N)
spec=importlib.util.spec_from_file_location('qualified_candidate',matrix['runner']);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
assert r.sha256_file(Path(matrix['runner']))==matrix['runner_sha256']
actual=r._run_hidden; serial=0
def vendor_seam(argv,cwd,timeout,env):
    global serial
    serial+=1;name=Path(argv[0]).stem;effect='normal'
    if '-version' in argv:
        text=(Q/(name+'-version.txt')).read_bytes()
        if name=='vlog' and cfg['effect'].startswith('version_'):
            effect=cfg['effect'].removeprefix('version_')
            if effect=='error':text+=b'** Error: synthetic version failure\n';effect='normal'
    elif name=='vlib':text=b''
    elif name=='vlog':text=b'# Errors: 0, Warnings: 0\n'
    else:
        assert name=='vsim';text=(Q/'fixtures'/cfg['stream_case']/'stdout.txt').read_bytes()
        if cfg['effect'] in ('nonzero','timeout'):effect=cfg['effect']
    target=cwd/f'synthetic-emission-{serial:02}.bin';target.write_bytes(text)
    executed=[sys.executable,'-B','-X','utf8',str(N/'emitter.py'),str(target),effect]
    limit=0.75 if effect=='timeout' else 10
    receipt=actual(executed,cwd,limit,env)
    receipt.update(synthetic_vendor_seam=True,vendor_intended_argv=argv,vendor_intended_timeout=timeout,actual_emitter_sha256=r.sha256_file(N/'emitter.py'),actual_timeout_seconds=limit)
    return receipt
r._run_hidden=vendor_seam
out=Q/'entries'/cfg['name']/'run'
rc=r.main(['--root',str(Q/'root'),'--out',str(out),'--modelsim','D:/modelsim1/win64','--modelsim-ini',str(Q/'modelsim.ini'),'--containment-root',str(N),'--case',cfg['case']])
raise SystemExit(rc)
