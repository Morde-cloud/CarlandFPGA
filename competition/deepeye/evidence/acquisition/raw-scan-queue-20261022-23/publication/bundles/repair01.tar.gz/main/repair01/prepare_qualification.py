"""Freeze independent post-author runner expectations; do not execute candidate."""
import gzip,hashlib,json,re,sys,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent; M=N.parent
W=next(p for p in N.parents if p.name=='deepeye-implementation-20261014')
A=M.parent/'author'; Q=N/'runner-qualification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
Q.mkdir();(Q/'fixtures').mkdir();(Q/'tmp').mkdir()
runner=W/'competition/deepeye/tools/acquisition/run_raw_scan_queue.py'
assert sha(runner)=='dbba5297accb6cbd9f64c2ca2b07651a929f75658593cee0cbbca141dce7ba85'
bases={};pins=[]
for key,case,mode in [('h','guard_healthy','healthy'),('q','queue_d1','queue'),('c','comp_d1','composition'),('g','guard_depth_0','guard'),('m','mutant_cancel_depth5','mutant')]:
    d=A/'results/full-01/cases'/case; report=json.loads((d/'case.json').read_bytes()); proc=report['processes']['vsim']; streams={}
    assert proc['exit']==0 and not proc['timed_out'] and report['result']['ok']
    for stream,row in proc['streams'].items():
        p=d/row['path'];b=p.read_bytes();b=gzip.decompress(b) if row['compressed'] else b
        assert hashlib.sha256(b).hexdigest()==row['sha256'] and len(b)==row['bytes']
        streams[stream]=b.decode('utf-8');pins.append({'path':str(p),'sha256':sha(p),'expanded_sha256':row['sha256']})
    args={'sim_exit':0,'expected_case':report['case_arg'],'params':report['params']}
    if mode=='guard':args={'sim_exit':0,'compile_exit':0,'family':'DEPTH'}
    if mode=='mutant':args.update(compile_exit=0,required=[])
    bases[key]={'mode':mode,'args':args,**streams}
    pins.append({'path':str(d/'case.json'),'sha256':sha(d/'case.json')})
cases=[]
def add(name,key,ok,reason,edit=None,args=None,err=None):
    b=bases[key];out=edit(b['stdout']) if edit else b['stdout'];stderr=b['stderr'] if err is None else err
    d=Q/'fixtures'/name;d.mkdir();(d/'stdout.txt').write_text(out,encoding='utf-8',newline='\n');(d/'stderr.txt').write_text(stderr,encoding='utf-8',newline='\n')
    a=dict(b['args']);a.update(args or {})
    spec={'stdout':'stdout.txt','stderr':'stderr.txt','mode':b['mode'],'args':a}
    put(d/'spec.json',spec);cases.append({'name':name,'expected_ok':ok,'reason':reason,'base':key,'spec':str((d/'spec.json').relative_to(Q))})
def drop(s,key):return ''.join(x for x in s.splitlines(True) if re.match(r'^\s*(?:# )?'+key+r'(?: |\s*$)',x))
def remove(s,key):return ''.join(x for x in s.splitlines(True) if not re.match(r'^\s*(?:# )?'+key+r'(?: |\s*$)',x))
def val(s,key,value):return re.sub(r'(?m)^(# )?RAW_SCAN_STATS (.*)$',lambda m:(m[1] or '')+'RAW_SCAN_STATS '+re.sub(r'\b'+key+r'=\S+',key+'='+str(value),m[2]),s)
for name,key in [('healthy','h'),('queue','q'),('composition','c'),('guard','g'),('mutant','m')]:add(name+'_genuine',key,True,'Unmodified genuinely completed author transcript, original source/time binding retained')
add('nonzero','h',False,'Success text cannot replace exit0',args={'sim_exit':9})
add('timeout_status','h',False,'No terminal success exit',args={'sim_exit':None})
add('missing_pass','h',False,'Unique completion required',lambda s:remove(s,'RAW_SCAN_PASS'))
add('duplicate_pass','h',False,'Unique completion required',lambda s:s+'# RAW_SCAN_PASS\n')
add('substring_pass','h',False,'Full marker required',lambda s:s.replace('# RAW_SCAN_PASS','# NOT_RAW_SCAN_PASS_MARKER'))
add('malformed_pass','h',False,'Full marker required',lambda s:s.replace('# RAW_SCAN_PASS','# RAW_SCAN_PASS extra'))
add('missing_stats','h',False,'Complete stats required',lambda s:remove(s,'RAW_SCAN_STATS'))
add('duplicate_stats','h',False,'Unique stats required',lambda s:s+drop(s,'RAW_SCAN_STATS'))
add('conflicting_stats','h',False,'Conflicting stats forbidden',lambda s:s+val(drop(s,'RAW_SCAN_STATS'),'errors',7))
add('numeric_stats','h',False,'Integer stats required',lambda s:val(s,'checks','NaN'))
add('duplicate_key','h',False,'Unique stat fields required',lambda s:re.sub(r'(?m)(RAW_SCAN_STATS .*?)$',r'\1 checks=1',s))
add('wrong_case','h',False,'Bind exact case',lambda s:val(s,'case','wrong_case'))
add('wrong_param','h',False,'Bind exact parameter',lambda s:val(s,'depth',8))
add('unbalanced','h',False,'Consistent conservation required',lambda s:val(s,'true_accepted',999))
add('warning','h',False,'Unexpected warning forbidden',lambda s:s+'# ** Warning: injected diagnostic\n')
add('error','h',False,'Unexpected error forbidden',lambda s:s+'# ** Error: injected diagnostic\n')
add('stderr_pass','h',False,'Markers on stderr forbidden',err='# RAW_SCAN_PASS\n')
add('duplicate_summary','h',False,'Unique diagnostic summary',lambda s:s+'# Errors: 0, Warnings: 0\n')
add('trace_loss','h',False,'Incomplete original trace forbidden',lambda s:s.replace(drop(s,'RAW_SCAN_TRACE').splitlines(True)[0],'',1))
add('trace_malformed_same_count','h',False,'Raw port rows must contain records; retaining only row count is not complete evidence',lambda s:re.sub(r'(?m)^# RAW_SCAN_TRACE .*$', '# RAW_SCAN_TRACE truncated',s))
def impossible(s):
    row=drop(s,'RAW_SCAN_STATS');cycles=int(re.search(r'\bcycles=(\d+)',row)[1]);sw=int(re.search(r'\bstat_w=(\d+)',row)[1])
    for k,v in {'true_accepted':cycles+1,'true_retired':cycles+1,'true_aborted':0,'accepted':min(cycles+1,(1<<sw)-1),'retired':min(cycles+1,(1<<sw)-1),'aborted':0}.items():s=val(s,k,v)
    return s
add('impossible_event_counts','h',False,'One-edge queue cannot accept or retire more than total recorded cycles; same-count raw transcript preserved',impossible)
add('impossible_wrap_count','q',False,'A full write circuit needs at least one acceptance and clock; wrap circuits cannot exceed cycles',lambda s:val(s,'wrap_writes',1000000000))
add('comp_trace_malformed','c',False,'Composition port records must remain complete',lambda s:re.sub(r'(?m)^# RAW_SCAN_COMP_TRACE .*$', '# RAW_SCAN_COMP_TRACE truncated',s))
add('comp_duplicate_stats','c',False,'Unique composition stats',lambda s:s+drop(s,'RAW_SCAN_COMP_STATS'))
add('foreign_fatal','g',False,'Only expected guard fatal allowed',lambda s:s.replace('DEPTH out of range','SEQ_W out of range'))
add('duplicate_fatal','g',False,'Unique own fatal',lambda s:s+'# ** Fatal: deepeye_raw_scan_queue: DEPTH out of range\n')
add('guard_warning','g',False,'Guard must be diagnostic clean apart from own fatal',lambda s:s+'# ** Warning: injected\n')
add('guard_compile_failure','g',False,'Compile failure is not guard evidence',args={'compile_exit':7})
add('guard_nonzero','g',False,'Actual guard termination contract',args={'sim_exit':7})
add('mutant_compile_failure','m',False,'Compile failure is not a behavioral mutant',args={'compile_exit':7})
add('mutant_nonzero','m',False,'Unexpected process failure is not behavioral counterexample',args={'sim_exit':7})
add('mutant_nonnumeric','m',False,'Require a finite numeric counterexample',lambda s:re.sub(r'(?m)^(# )?RAW_SCAN_MISMATCH .*$', '# RAW_SCAN_MISMATCH field=level expected=0 actual=x',s))
add('mutant_pass','m',False,'A passing mutant is not killed',lambda s:s+'# RAW_SCAN_PASS\n')
entry_cases=[{'name':n,'case':'guard_healthy','stream_case':s,'effect':e,'expected_exit':x} for n,s,e,x in [
    ('healthy_entry','healthy_genuine','normal',0),('nonzero_entry','healthy_genuine','nonzero',1),('timeout_entry','healthy_genuine','timeout',1),
    ('substring_entry','substring_pass','normal',1),('conflicting_stats_entry','conflicting_stats','normal',1),
    ('impossible_counts_entry','impossible_event_counts','normal',1),('malformed_trace_entry','trace_malformed_same_count','normal',1),
    ('version_error','healthy_genuine','version_error',2),('version_nonzero','healthy_genuine','version_nonzero',2),('version_timeout','healthy_genuine','version_timeout',2)]]
for tool in ['vlog','vsim']:
    d=A/'results/full-01/tool-check';meta=json.loads((d/(tool+'.invocation.json')).read_bytes());row=meta['streams']['stdout'];data=(d/row['path']).read_bytes();assert hashlib.sha256(data).hexdigest()==row['sha256']
    (Q/(tool+'-version.txt')).write_bytes(data);pins.append({'path':str(d/row['path']),'sha256':sha(d/row['path'])})
put(Q/'MATRIX.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'provenance':'Independent main expectations frozen AFTER original author completion and source inspection, BEFORE qualification execution. Not original pre-author oracle. Synthetic corruptions remain separate from actual vendor observations.','runner':str(runner),'runner_sha256':sha(runner),'bases':pins,'cases':cases,'entry_cases':entry_cases,'entry_seam':'Only vendor process call is replaced by a main-owned real emitter process; unchanged main/run_case/aggregation used. No new vendor simulation is claimed by this qualification.'})
files=[{'path':str(p.relative_to(Q)),'sha256':sha(p)} for p in sorted(Q.rglob('*')) if p.is_file()]
put(Q/'FREEZE.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'generator_sha256':sha(Path(__file__)),'files':files,'candidate_not_executed':True})
print(json.dumps({'cases':len(cases),'entry_cases':len(entry_cases),'freeze_sha256':sha(Q/'FREEZE.json')}))
