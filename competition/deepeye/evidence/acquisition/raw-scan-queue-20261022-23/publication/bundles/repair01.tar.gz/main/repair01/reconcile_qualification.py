"""Validate red fixtures; preserve one malformed main fixture and correct it once."""
import importlib.util,json,re,sys,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;Q=N/'runner-qualification'
sys.path.insert(0,str(M));from process23 import sha,put,run
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
matrix=json.loads((Q/'MATRIX.json').read_bytes());runner=Path(matrix['runner']);assert sha(runner)==matrix['runner_sha256']
def text(name):return (Q/'fixtures'/name/'stdout.txt').read_bytes().decode('utf-8')
def lines(name):return text(name).replace('\r\n','\n').replace('\r','\n').splitlines()
def stats(name,key='RAW_SCAN_STATS'):
    row=[x for x in lines(name) if x.startswith('# '+key+' ')];assert len(row)==1
    return dict(x.split('=',1) for x in row[0].split()[2:])
# Validate concrete reds independently, without invoking candidate helper functions.
proof=[]
for name,key,base in [('trace_malformed_same_count','RAW_SCAN_TRACE','healthy_genuine'),('comp_trace_malformed','RAW_SCAN_COMP_TRACE','composition_genuine')]:
    old=[x for x in lines(base) if x.startswith('# '+key+' ')];new=[x for x in lines(name) if x.startswith('# '+key+' ')]
    assert len(new)==len(old)>0 and all(x=='# '+key+' truncated' for x in new)
    proof.append({'name':name,'original_rows':len(old),'new_rows':len(new),'all_port_fields_lost':True,'raw_sha256':sha(Q/'fixtures'/name/'stdout.txt')})
s=stats('impossible_event_counts');base=stats('healthy_genuine')
assert int(s['true_accepted'])==int(s['true_retired'])==int(s['cycles'])+1
assert s['cycles']==base['cycles']
assert [x for x in lines('impossible_event_counts') if x.startswith('# RAW_SCAN_TRACE ')]==[x for x in lines('healthy_genuine') if x.startswith('# RAW_SCAN_TRACE ')]
proof.append({'name':'impossible_event_counts','cycles':int(s['cycles']),'accepted':int(s['true_accepted']),'retired':int(s['true_retired']),'raw_ports_unchanged':True,'violation':'At most one queue admission and one retirement per rising edge; resets cannot increase the cumulative maximum.'})
s=stats('impossible_wrap_count');assert int(s['wrap_writes'])>int(s['cycles'])
proof.append({'name':'impossible_wrap_count','cycles':int(s['cycles']),'reported_write_circuits':int(s['wrap_writes']),'violation':'DEPTH>=1; a full write circuit needs at least one distinct successful edge.'})
# Original duplicate_key fixture accidentally put checks=1 after a bare CR.
old=text('duplicate_key');original_line=next(x for x in lines('duplicate_key') if x.startswith('# RAW_SCAN_STATS '))
assert '\r checks=1' in old and original_line.count('checks=')==1
d=Q/'fixtures/duplicate_key_corrected';d.mkdir()
fixed=text('healthy_genuine').replace('\r\n','\n').replace('\r','\n')
fixed=re.sub(r'(?m)^(# RAW_SCAN_STATS [^\n]*)$',r'\1 checks=1',fixed)
line=next(x for x in fixed.splitlines() if x.startswith('# RAW_SCAN_STATS '));assert line.count('checks=')==2
(d/'stdout.txt').write_text(fixed,encoding='utf-8',newline='\n');(d/'stderr.txt').write_bytes(b'')
oldspec=json.loads((Q/'fixtures/duplicate_key/spec.json').read_bytes());put(d/'spec.json',oldspec)
put(d/'EXPECTATION.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'expected_ok':False,'expected_exit':1,'reason':'Two checks keys on the same normalized stats row','stdout_sha256':sha(d/'stdout.txt'),'spec_sha256':sha(d/'spec.json'),'old_fixture_sha256':sha(Q/'fixtures/duplicate_key/stdout.txt'),'old_fixture_invalid_for_duplicate_key_purpose':True,'old_fixture_and_results_preserved':True,'generator_sha256':sha(Path(__file__))})
spec=importlib.util.spec_from_file_location('candidate_duplicate_check',runner);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
a=oldspec['args'];result=r.classify_queue_output(a['sim_exit'],fixed,'',a['expected_case'],a['params'],healthy=True);put(d/'direct.json',result)
p=run([sys.executable,'-B','-X','utf8',runner,'--verify-transcript',d/'spec.json'],d,'actual-cli',60)
cli=json.loads((d/'spec.result.json').read_bytes());assert not result['ok'] and not cli['ok'] and p['exit']==1
summary={'at_utc':datetime.now(timezone.utc).isoformat(),'red_fixture_proofs':proof,'original_duplicate_key':{'valid_for_intended_purpose':False,'reason':'Main fixture generator inserted a CR before extra key; not a duplicate key on normalized row','original_expected_outcome_mismatch_is_not_product_finding':True,'immutable_result_sha256':sha(Q/'RESULT.json')},'corrected_duplicate_key':{'direct_ok':result['ok'],'actual_cli_exit':p['exit'],'expected_rejection_verified':True,'evidence':str(d)},'valid_original_direct_and_cli_cases':37,'corrected_direct_and_cli_cases':1,'total_valid_distinct_direct_and_cli_cases':38,'actual_normal_main_entries':10,'confirmed_red_direct_and_cli':4,'confirmed_red_normal_main_entries':2,'runner_still_sha256':sha(runner),'acceptance':'REVISE; no author runner modification authorized'}
put(Q/'QUALIFICATION_RECONCILIATION.json',summary);print(json.dumps(summary))
