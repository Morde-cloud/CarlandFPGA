"""Read-only reconciliation and append-only failed-repair review sealing."""
import hashlib,json,os,shutil,subprocess,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;A=M.parent/'author';R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014'
O=R/'.local/deployment/node-b/evidence/raw-scan-queue-20261022-23';P=O/'repair01';Q=N/'runner-qualification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def info(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
freeze=json.loads((N/'REPAIR_FREEZE.json').read_bytes());contract=json.loads((O/'inputs/immutable_scope.json').read_bytes())
canonical=hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert canonical=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
for rel,h in freeze['old_sources'].items():assert sha(W/rel)==h,rel
author=json.loads((A/'FINAL_FILE_HASHES.json').read_bytes());assert len(author['files'])==1686
for rel,h in author['files'].items():assert sha(W/rel)==h,rel
oldmain=json.loads((M/'LOCAL_REVIEW_MANIFEST.json').read_bytes());assert len(oldmain['artifacts'])==1020
for row in oldmain['artifacts']:assert sha(Path(row['path']))==row['sha256'],row['path']
for row in json.loads((O/'FREEZE_CHECKS.json').read_bytes())['old_audit_files']:assert sha(Path(row['path']))==row['sha256']
assert sha(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
assert sha(O/'FINAL_RECEIPT.json')=='954838ee55f22fdc3b923b83af8fd55454cb64b5af33e70ab102674b3fe4a2ab'
for row in json.loads((M/'PREDISPATCH_FREEZE.json').read_bytes())['files']:assert sha(Path(row['path']))==row['sha256']
terminal=json.loads(json.loads((P/'AUTHOR_TERMINAL.json').read_bytes())['content'][0]['text'])[0]
assert terminal['status']=='failed' and terminal['terminal'] and not terminal['stale']
status=json.loads((P/'STATUS_AFTER_FAILURE.json').read_bytes());assert all(j['terminal'] for j in status['jobs'])
reclaimed=json.loads(json.loads((P/'POOL_RECLAIM.json').read_bytes())['content'][0]['text']);assert not reclaimed['instances']
assert not json.loads((P/'POST_FAILURE_PROCESS_SNAPSHOT.json').read_bytes())['modelsim_processes']
repairfiles=[info(p) for p in sorted((A/'repair01').rglob('*')) if p.is_file()]
assert len(repairfiles)==2 and {Path(r['path']).name for r in repairfiles}=={'TASK_RECEIPT.json','apply_task_receipt.patch'}
gitexe=shutil.which('git');gd=N/'git-audit';gd.mkdir()
def git(name,args):
    cmd=[gitexe,'-c','core.longpaths=true','-C',str(W),*args]
    put(gd/(name+'.intent.json'),{'argv':cmd,'cwd':str(N),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR'],'PYTHONDONTWRITEBYTECODE':os.environ['PYTHONDONTWRITEBYTECODE'],'git_sha256':sha(Path(gitexe)),'at_utc':datetime.now(timezone.utc).isoformat()})
    p=subprocess.run(cmd,cwd=N,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=30,check=False,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(gd/(name+'.stdout.bin')).write_bytes(p.stdout);(gd/(name+'.stderr.bin')).write_bytes(p.stderr)
    put(gd/(name+'.result.json'),{'exit':p.returncode,'stdout_sha256':sha(gd/(name+'.stdout.bin')),'stderr_sha256':sha(gd/(name+'.stderr.bin')),'at_utc':datetime.now(timezone.utc).isoformat()});assert p.returncode==0;return p.stdout
head=git('head',['rev-parse','HEAD']).decode().strip();assert head=='94571d2cd9a68bd030c878c406f19a1be6ec53d7'
assert not git('staged',['diff','--cached','--name-only']) and not git('unmerged',['ls-files','--unmerged'])
git('status',['status','--porcelain=v1','--untracked-files=all'])
qual=json.loads((Q/'QUALIFICATION_RECONCILIATION.json').read_bytes());assert qual['confirmed_red_direct_and_cli']==4 and qual['confirmed_red_normal_main_entries']==2
decision={'at_utc':datetime.now(timezone.utc).isoformat(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'parent_work':'B-LOCAL-RAW-SCAN-QUEUE-CONTINUE-20261022-v1','instruction':'B-OP23-GUARD-CLAMP01-REPAIR-20261022-v1','operation_id':'B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23','actual_thread':freeze['actual_thread'],'actual_turn':freeze['actual_turn'],'decision':'REVISE','execution':'FAILED_NO_CORRECTED_SOURCE','findings':['OP23-GUARD-CLAMP01 remains open','OP23-RUNNER-TRACE01','OP23-RUNNER-COUNT01'],'repair_job':terminal,'current_source_hashes':freeze['old_sources'],'repair_source_changes':0,'new_baseline':'not_run; corrected source absent; old tests not replayed','author_repair_files':repairfiles,'old_author_manifest_verified_files':1686,'old_main_manifest_verified_artifacts':1020,'protected_codec_and_cancelled_audit_files_unchanged':True,'main_qualification':qual,'baseline_head':head,'new_source_commit':None,'request_hash':None,'published_handoff_manifest':None,'publication':'local/unpublished','contract':freeze['contract'],'not_run':['all29','B02','B03','G05','B06','R03','full_product_simulation','synthesis','implementation','timing','CDC_RDC','board','system'],'board':'A-only','new_worker_dispatched_after_failure':False,'read_only_runner_preserved':True,'pool':0,'review':info(N/'REVIEW.md'),'original_REVISE_unchanged':True,'needs_desktop_turn':'Review concrete timeout reconciliation and new runner blockers before next bounded work; no human-only action established'}
put(N/'REVIEW_DECISION.json',decision)
artifacts=[]
for root in [N,P,A/'repair01']:
    for p in sorted(root.rglob('*')):
        if not p.is_file():continue
        parts=p.relative_to(root).parts
        if 'tmp' in parts or 'cache' in parts or 'work' in parts:continue
        if p.name.startswith('seal-failure.') and p.suffix=='.txt':continue
        artifacts.append(info(p))
for p in [M/'LOCAL_REVIEW_MANIFEST.json',A/'FINAL_FILE_HASHES.json',O/'FINAL_RECEIPT.json']+[W/x for x in freeze['old_sources']]:artifacts.append(info(p))
put(N/'LOCAL_REVIEW_MANIFEST.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'kind':'local failed-repair/runner-qualification evidence, not published handoff','operation_id':decision['operation_id'],'artifacts':artifacts,'old_transitive_author_files_verified':1686,'old_transitive_main_artifacts_verified':1020,'excluded':'derived temporary/cache/work paths and live seal stdout; all substantive raw streams and fixture bytes included','decision_sha256':sha(N/'REVIEW_DECISION.json')})
receipt={k:decision[k] for k in ['task_id','task_version','parent_work','instruction','operation_id','actual_thread','actual_turn','decision','execution','findings','baseline_head','new_source_commit','request_hash','published_handoff_manifest','publication','contract','not_run','pool','new_baseline']}
receipt.update(at_utc=datetime.now(timezone.utc).isoformat(),review=info(N/'REVIEW.md'),review_decision=info(N/'REVIEW_DECISION.json'),manifest=info(N/'LOCAL_REVIEW_MANIFEST.json'),artifact_count=len(artifacts),terminal=info(P/'AUTHOR_TERMINAL.json'),reconciliation=info(Q/'QUALIFICATION_RECONCILIATION.json'),needs_desktop_turn=decision['needs_desktop_turn'],callback='One concrete-failure return to existing coordinator; accepted-completion target not due; no peer or group report')
put(P/'FINAL_RECEIPT.json',receipt);print(json.dumps({'receipt':info(P/'FINAL_RECEIPT.json'),'decision':info(N/'REVIEW_DECISION.json'),'manifest':info(N/'LOCAL_REVIEW_MANIFEST.json'),'artifact_count':len(artifacts)}))
