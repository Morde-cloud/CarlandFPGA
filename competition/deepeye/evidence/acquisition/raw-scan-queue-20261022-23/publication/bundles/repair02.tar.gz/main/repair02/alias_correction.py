"""Freeze and apply the narrow reported-label/public-port mapping correction."""
import difflib,gzip,hashlib,json,shutil,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent;W=next(p for p in N.parents if p.name=='deepeye-implementation-20261014');D=N/'alias-correction';D.mkdir()
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
runner=W/'competition/deepeye/tools/acquisition/run_raw_scan_queue.py';assert sha(runner)=='c0e630cb9c9768cce8af005133838420b60113a83697600154a622579d557775'
shutil.copyfile(runner,D/'runner_before.py');failure=N/'vendor01/cases/mutant_wrap_depth5/result.json';r=json.loads(failure.read_bytes());assert not r['ok'] and not r['trace_history']['reasons']
mapping={k:'out_'+k for k in ['data','ticks','quality','first_seq','last_seq','tag']}
expect=[['data',4096,4100],['ticks',6324352,14779012],['quality',4096,4100],['first_seq',0,4],['last_seq',31,27],['tag',0,4]]
put(D/'MAPPING_FREEZE.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'cause':'Main-added history uses public out_* names; unchanged TB check_rec reports six unprefixed payload names. Numeric tuples already agree; this is a false negative, not a missing DUT counterexample.','old_runner_sha256':sha(runner),'failed_result_sha256':sha(failure),'TB_sha256':sha(W/'competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv'),'mapping':mapping,'unchanged':'No history/parser/metrics/guard/process logic; no RTL/TB edit; preserve all old failed receipts','expected_corroborated_tuples':expect,'negative':'A reported data mismatch without an actual out_data numeric contradiction must remain rejected','validation':'Final58+10 qualification; all24 saved vendor cases reclassified under final runner; new wrap mutant vendor execution only; coherent selftest on final standalone copy; no baseline RTL replay'})
text=runner.read_text(encoding='utf-8');old='''    if history is None or not history["numeric_counterexamples"].intersection(observed):
        reasons.append("reported mutant mismatch lacks numeric trace corroboration")
    if history is not None:
        for required_tuple in required:
            if required_tuple not in history["numeric_counterexamples"]:
                reasons.append(f"required mutant counterexample absent in trace: {required_tuple}")
'''
new='''    # check_rec uses payload names without the public out_ prefix. Map only
    # those six declared labels; values and all other port names stay exact.
    def trace_tuple(item):
        field, expected_value, actual_value = item
        return (("out_" + field) if field in _RECORD_FIELDS else field,
                expected_value, actual_value)
    if history is None or not history["numeric_counterexamples"].intersection(trace_tuple(item) for item in observed):
        reasons.append("reported mutant mismatch lacks numeric trace corroboration")
    if history is not None:
        for required_tuple in required:
            if trace_tuple(required_tuple) not in history["numeric_counterexamples"]:
                reasons.append(f"required mutant counterexample absent in trace: {required_tuple}")
'''
assert text.count(old)==1;text=text.replace(old,new)
(D/'mapping.patch').write_text(''.join(difflib.unified_diff(runner.read_text(encoding='utf-8').splitlines(True),text.splitlines(True),fromfile='before',tofile='after')),encoding='utf-8',newline='\n')
runner.write_text(text,encoding='utf-8',newline='\n')
put(D/'APPLIED.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'runner_sha256':sha(runner),'mapping_freeze_sha256':sha(D/'MAPPING_FREEZE.json'),'patch_sha256':sha(D/'mapping.patch')});print(json.dumps({'runner_sha256':sha(runner),'freeze_sha256':sha(D/'MAPPING_FREEZE.json')}))
