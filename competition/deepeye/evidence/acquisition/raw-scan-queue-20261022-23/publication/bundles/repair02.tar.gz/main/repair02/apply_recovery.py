import difflib,hashlib,json,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;W=next(p for p in N.parents if p.name=='deepeye-implementation-20261014')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
freeze=json.loads((N/'EXPECTATION_FREEZE.json').read_bytes())
for row in freeze['files']:assert sha(Path(row['path']))==row['sha256']
old=json.loads((M/'repair01/REPAIR_FREEZE.json').read_bytes())['old_sources'];new={}
for rel,h in old.items():assert sha(W/rel)==h
for name,rel in [('deepeye_raw_scan_queue.sv','competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv'),('tb_raw_scan_queue.sv','competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv')]:
    new[rel]=(M/'repair01/expected'/name).read_bytes()
runnerrel='competition/deepeye/tools/acquisition/run_raw_scan_queue.py'
text=(N/'snapshots/run_raw_scan_queue.py').read_text(encoding='utf-8')
start=text.index('def _check_trace_count(');end=text.index('def classify_queue_output(',start)
text=text[:start]+(N/'validator_impl.py').read_text(encoding='utf-8')+'\n\n'+text[end:]
for func,nextfunc,marker,mutant in [('classify_queue_output','classify_composition_output','RAW_SCAN_TRACE',False),('classify_composition_output','_compile_ok','RAW_SCAN_COMP_TRACE',False),('classify_mutant_output','sha256_bytes','RAW_SCAN_TRACE',True)]:
    start=text.index('def '+func+'(');end=text.index('def '+nextfunc+'(',start);part=text[start:end]
    part=part.replace('    stats = None\n','    stats = None\n    history = None\n',1)
    needle=f'reasons += _check_trace_count(rows, "{marker}", stats)';assert part.count(needle)==1
    part=part.replace(needle,f'history = _trace_history(rows, "{marker}", stats, params, mutant={mutant})\n        reasons += history["reasons"]')
    if mutant:
        anchor='    return _result(\n';assert part.count(anchor)==1
        extra='''    if history is None or not history["numeric_counterexamples"].intersection(observed):
        reasons.append("reported mutant mismatch lacks numeric trace corroboration")
    if history is not None:
        for required_tuple in required:
            if required_tuple not in history["numeric_counterexamples"]:
                reasons.append(f"required mutant counterexample absent in trace: {required_tuple}")
'''
        part=part.replace(anchor,extra+anchor).replace('        classification="mutant_rejected",','        classification="mutant_rejected",\n        trace_history=None if history is None else _history_report(history),')
    else:
        part=part.replace('trace_rows=len(rows["'+marker+'"]))','trace_rows=len(rows["'+marker+'"]),\n                   trace_history=None if history is None else _history_report(history))')
    text=text[:start]+part+text[end:]
start=text.index('def _valid_queue_transcript()');end=text.index('def _verify_transcript(',start)
text=text[:start]+(N/'synthetic_fixture_impl.py').read_text(encoding='utf-8')+text[end:]
start=text.index('def _run_self_test(');end=text.index('\nif __name__',start);part=text[start:end]
a=part.index('    mutant_stats = (');b=part.index('    hello = ',a)
part=part[:a]+'''    numeric_mutant = _synthetic_queue_fixture(mutant=True)
    x_mutant = numeric_mutant.replace("expected=0 actual=1", "expected=0 actual=x", 1)
'''+part[b:]
part=part.replace('_params(DEPTH=5, SEQ_W=5, TICK_W=7, TAG_W=9, STAT_W=4)','_params(DEPTH=1, SEQ_W=2, TICK_W=1, TAG_W=1, STAT_W=2)').replace('[["level", 0, 5]]','[["level", 0, 1]]').replace('[("level", 0, 5)]','[("level", 0, 1)]')
text=text[:start]+part+text[end:];new[runnerrel]=text.encode()
mdrel='competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md';doc=(N/'snapshots/raw_scan_queue_candidate.md').read_text(encoding='utf-8');start=doc.index('## Parameters and clamped declarations');end=doc.index('## Ports',start)
doc=doc[:start]+'''## Parameters and clamped declarations

Legal ranges are DEPTH1..8, SEQ_W2..32, TICK_W1..64, TAG_W1..64,
STAT_W2..32. Each legal request selects itself; every illegal request uses
the lower declaration fallback1/2/1/1/2 respectively, before the unchanged
own-fatal diagnostic at time zero. Effective constants remain localparams.
This declaration accommodation never makes an illegal request acceptable.

'''+doc[end:]
doc+='''
## Main-authored repair02 evidence validation

After the original author and failed Flash guard-repair assignment, the existing
quality main repaired only the initializer rules and evidence validator under
B-RAW-SCAN-QUEUE-MAIN-RECOVERY-20261022-23-v1. The author TB receives only the
matching declaration corrections; legal stimulus and coverage expectations are
unchanged. Old source snapshots and rejected evidence remain separate.

The standalone runner now requires complete case/width-bound records paired as
pre cycle N / post cycle N+1. It reconstructs a record list and collector event
history from inputs, not ref_* values. Counters follow their distinct reset or
collector-window origins and exact saturation. Unknown registered state before
the first applied reset and invalid payload spellings remain unspecified;
defined positive observations must be known. No X is coerced to zero.

Reported stalls select the longest contiguous nonabort input-idle, consumer-held
nonempty interval. Reported circuits select the longest contiguous nonabort
in_valid/out_ready interval; reference admissions/retirements in exactly that
interval are divided by DEPTH. Earliest interval wins ties. These are selected
segments, not total lifetime stalls/wraps; original4096/1000 minima still apply.
Mutant evidence requires a finite numeric contradiction corroborated in complete
captured ports; positive-history success is not required of an intended mutant.
Synthetic selftest fixtures now contain coherent full histories and remain
explicitly distinct from simulator runs. No private/main oracle is imported.

This remains a local candidate pending independent coordinator review, with no
public ABI, board, source-clock, freshness, DMA/PS or movement authority.
''';new[mdrel]=doc.encode()
intent={'at_utc':datetime.now(timezone.utc).isoformat(),'work_id':'B-RAW-SCAN-QUEUE-MAIN-RECOVERY-20261022-23-v1','freeze_sha256':sha(N/'EXPECTATION_FREEZE.json'),'helpers':{k:sha(N/k) for k in ['apply_recovery.py','validator_impl.py','synthetic_fixture_impl.py']},'files':[]}
for rel,data in new.items():
    before=(W/rel).read_bytes();intent['files'].append({'path':rel,'old_sha256':hashlib.sha256(before).hexdigest(),'expected_sha256':hashlib.sha256(data).hexdigest()})
    (N/(Path(rel).name+'.patch')).write_text(''.join(difflib.unified_diff(before.decode().splitlines(True),data.decode().splitlines(True),fromfile='old/'+rel,tofile='repair02/'+rel)),encoding='utf-8',newline='\n')
put(N/'PATCH_INTENT.json',intent)
for rel,data in new.items():(W/rel).write_bytes(data)
put(N/'PATCH_APPLIED.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'files':{rel:sha(W/rel) for rel in new}})
print(json.dumps({'files':{rel:sha(W/rel) for rel in new}}))
