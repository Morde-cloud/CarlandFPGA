"""Count achieved coverage from actual public-port trace rows after exact comparison."""
import argparse,importlib.util,json,tempfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from process23 import M,W,put,sha
from oracle23 import FIELDS,mask
spec=importlib.util.spec_from_file_location('coverage_trace_columns',W/'competition/deepeye/tools/acquisition/main_verify_raw_scan_queue.py')
columns=importlib.util.module_from_spec(spec);spec.loader.exec_module(columns)

def rows(path):
    with path.open(encoding='ascii') as f:
        index=0
        while True:
            first=f.readline()
            if not first:return
            result={}
            for phase,line in [('pre',first),('post',f.readline())]:
                words=line.split();assert len(words)==len(columns.COLUMNS)+2 and words[:2]==[phase.upper(),str(index)]
                values={}
                for key,word in zip(columns.COLUMNS,words[2:]):
                    try:values[key]=int(word,16)
                    except ValueError:values[key]=word
                result[phase]=values
            yield index,result['pre'],result['post'];index+=1

def main():
    p=argparse.ArgumentParser();p.add_argument('--run',type=Path,required=True);args=p.parse_args()
    assert Path(tempfile.gettempdir()).resolve()==M/'repair02/tmp'
    run=args.run.resolve();assert run.is_relative_to(M)
    result=json.loads((run/'RESULT.json').read_bytes());assert result['phase']=='baseline'
    manifest=json.loads((M/'VECTOR_MANIFEST.json').read_bytes());records=[];total=0
    assert all(x['pass'] for x in result['results'][:len(manifest['cases'])])
    for n,case in enumerate(manifest['cases']):
        source=run/f'c{n:02}'/'ports.txt';params=case['parameters'];depth=params['depth'];mode=params['mode'];cap=mask(params['stat'])
        compared=result['results'][n]['comparison'];assert compared['pass'] and sha(source)==compared['trace_sha256']
        observed=list(rows(source));assert len(observed)==case['edges'];total+=len(observed)
        controls=set();inputs=[];retired=[];sat_seen=set();after_all_sat_flow=0;all_saturated=False;wide_abort=[];max_complete=0;origins=0;overrun=False;exhaust_drain=0
        for index,pre,post in observed:
            iv=pre['cv'] if mode else pre['i_iv'];take=bool(pre['ir'] and iv);give=bool(pre['ov'] and pre['i_ready'])
            if all(type(pre[k]) is int for k in ['level','i_rst','i_cancel','i_iv','i_ready']):controls.add(tuple(pre[k] for k in ['level','i_rst','i_cancel','i_iv','i_ready']))
            if take:inputs.append(tuple(pre[('c_' if mode else 'i_')+k] for k in FIELDS))
            if give:retired.append(tuple(pre['o_'+k] for k in FIELDS))
            for k in ['accepted','retired','aborted']:
                if post[k]==cap:sat_seen.add(k)
            if all_saturated:after_all_sat_flow+=int(take)+int(give)
            if all(post[k]==cap for k in ['accepted','retired','aborted']):all_saturated=True
            if not mode and not pre['i_rst'] and pre['i_cancel'] and pre['level']>cap:
                assert post['aborted']==cap and post['accepted']==pre['accepted'] and post['retired']==pre['retired']
                wide_abort.append({'edge':index,'old_level':pre['level'],'pre_aborted':pre['aborted'],'post_aborted':post['aborted']})
            if mode:
                if type(pre['level']) is int:max_complete=max(max_complete,pre['level']+pre['cv'])
                overrun|=bool(post['c_overruns'])
                if pre['c_exhausted']==1 and give:exhaust_drain+=1
                if pre['i_rearm'] and not (pre['i_rst'] or pre['i_stop']):
                    assert post['c_events']==post['c_retired']==0 and post['accepted']==pre['accepted'] and post['retired']==pre['retired']
                    origins+=1
        facts={'case':case['name'],'trace_sha256':sha(source),'edges':len(observed),'actual_admissions':len(inputs),'actual_retirements':len(retired),'observed_control_combinations':len(controls),'saturated_fields':sorted(sat_seen),'flow_after_all_saturated':after_all_sat_flow,'wide_abort':wide_abort,'max_complete_records':max_complete,'collector_window_origin_checks':origins,'overrun_seen':overrun,'retirements_while_exhausted':exhaust_drain}
        if 'occupancy_control_combinations' in case:
            goals={(level,rst,cancel,iv,ready) for level in range(depth+1) for rst in [0,1] for cancel in [0,1] for iv in [0,1] for ready in [0,1]}
            assert goals<=controls
        segments=[]
        for segment in case['segments']:
            part=observed[segment['start']:segment['end_exclusive']]
            if segment['kind']=='continuous_wraps':
                takes=sum(bool(pre['ir'] and pre['i_iv']) for _,pre,_ in part)
                gives=sum(bool(pre['ov'] and pre['i_ready']) for _,pre,_ in part)
                assert all(not pre['i_rst'] and not pre['i_cancel'] for _,pre,_ in part)
                assert takes==gives==1000*depth
                segments.append({'kind':'actual_wrap_circuits','accepted':takes,'retired':gives,'read_circuits':gives//depth,'write_circuits':takes//depth})
            elif segment['kind']=='nonempty_stall':
                assert len(part)==4096 and all(pre['ov']==1 and pre['i_ready']==0 for _,pre,_ in part)
                payloads={tuple(pre['o_'+k] for k in FIELDS) for _,pre,_ in part};assert len(payloads)==1
                segments.append({'kind':'actual_stall','cycles':len(part),'unique_output_payloads':len(payloads)})
        facts['segments']=segments
        if case['name']=='payload64':
            widths=[64,256,32,32,32,64];seen=set(inputs);allones=tuple(mask(w) for w in widths)
            for j,width in enumerate(widths):
                for bit in range(width):
                    one=[0]*6;one[j]=1<<bit
                    assert tuple(one) in seen and tuple(a^b for a,b in zip(allones,one)) in seen
            facts['actual_payload_walking_bits']=sum(widths)
            facts['literal_and_complement_records_present']=True
        if case['name'] in ['depth8_stat2','depth8_stat3']:
            assert set(sat_seen)=={'accepted','retired','aborted'} and after_all_sat_flow>0
        if case['name']=='depth8_stat2':assert any(x['old_level']==8 and x['pre_aborted']==0 and x['post_aborted']==3 for x in wide_abort)
        if mode and params['seq']==8:
            assert max_complete==depth+1 and overrun and exhaust_drain>0 and origins>0
        records.append(facts)
    assert total==87836 and total<=500000
    target=run/'ACTUAL_COVERAGE.json'
    put(target,{'result_sha256':sha(run/'RESULT.json'),'actual_complete_positive_edges':total,'cases':records,'method':'Counts recomputed from captured public input/output ports after frozen independent model equality; no hierarchy','coverage_checks_passed':True,'whole_operation_all_pass':result['all_pass'],'limits':'Positive trace coverage only; separate guard failures remain failures'})
    print(json.dumps({'coverage':str(target),'sha256':sha(target),'actual_edges':total,'coverage_checks_passed':True,'whole_operation_all_pass':result['all_pass']}))
if __name__=='__main__':main()
