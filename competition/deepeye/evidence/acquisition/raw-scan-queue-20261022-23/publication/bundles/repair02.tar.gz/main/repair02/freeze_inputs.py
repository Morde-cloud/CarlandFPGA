import hashlib,json,re,shutil,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;Q=N/'qualification';OLD=M/'repair01/runner-qualification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
Q.mkdir();(Q/'fixtures').mkdir();(Q/'tmp').mkdir()
tb=(N/'snapshots/tb_raw_scan_queue.sv').read_text(encoding='utf-8');schemas={}
for prefix in ['RAW_SCAN_TRACE','RAW_SCAN_COMP_TRACE']:
    fmt=re.search(r'\$display\("'+prefix+r' ([^"\n]+)"',tb)[1]
    schemas[prefix]={'fields':dict(item.split('=') for item in fmt.split()),'pair':'pre cycle N; post cycle N+1; N starts0','origin':'exact existing trace display field names/formats; no RTL expectation logic imported'}
put(N/'TRACE_SCHEMA.json',schemas)
oldmatrix=json.loads((OLD/'MATRIX.json').read_bytes());matrix=[]
for case in oldmatrix['cases']:
    name=case['name'];source=OLD/'fixtures'/('duplicate_key_corrected' if name=='duplicate_key' else name);dest=Q/'fixtures'/name;dest.mkdir()
    for f in ['stdout.txt','stderr.txt','spec.json']:shutil.copyfile(source/f,dest/f)
    matrix.append(dict(case,spec=str((dest/'spec.json').relative_to(Q)),origin=str(source),origin_hashes={f:sha(source/f) for f in ['stdout.txt','stderr.txt','spec.json']},expected_ok=case['expected_ok']))
def add(name,base,expected,edit,why):
    src=Q/'fixtures'/base;d=Q/'fixtures'/name;d.mkdir();s=(src/'stdout.txt').read_text(encoding='utf-8');s=edit(s)
    (d/'stdout.txt').write_text(s,encoding='utf-8',newline='\n');shutil.copyfile(src/'stderr.txt',d/'stderr.txt');shutil.copyfile(src/'spec.json',d/'spec.json')
    matrix.append({'name':name,'spec':str((d/'spec.json').relative_to(Q)),'expected_ok':expected,'reason':why,'base':base})
def change_trace(s,fn,prefix='RAW_SCAN_TRACE'):
    return '\n'.join(fn(x) if x.startswith('# '+prefix+' ') else x for x in s.splitlines())+'\n'
add('field_missing','healthy_genuine',False,lambda s:change_trace(s,lambda x:re.sub(r' in_data=\S+','',x)),'Exact field set')
add('field_duplicate','healthy_genuine',False,lambda s:change_trace(s,lambda x:x+' in_valid=0'),'Duplicate field')
add('field_unknown','healthy_genuine',False,lambda s:change_trace(s,lambda x:x+' unrecognized=0'),'Unknown field')
add('field_trailing','healthy_genuine',False,lambda s:change_trace(s,lambda x:x+' debris'),'Trailing non-key text')
add('phase_duplicate','healthy_genuine',False,lambda s:change_trace(s,lambda x:x.replace('side=post','side=pre')),'Same count wrong phase')
add('cycle_duplicate','healthy_genuine',False,lambda s:change_trace(s,lambda x:re.sub(r'cycle=\d+','cycle=0',x)),'Same count wrong cycle')
add('cycle_side_swap','healthy_genuine',False,lambda s:change_trace(s,lambda x:x.replace('side=pre','side=post') if 'side=pre' in x else x.replace('side=post','side=pre')),'Same count swapped phases')
add('active_x','healthy_genuine',False,lambda s:change_trace(s,lambda x:re.sub(r'out_data=\S+','out_data=xxxxxxxxxxxxxxxx',x) if 'out_valid=1 ' in x else x),'Unknown active output')
add('inactive_xz','healthy_genuine',True,lambda s:change_trace(s,lambda x:re.sub(r'out_data=\S+','out_data=xzxzxzxzxzxzxzxz',x) if 'out_valid=0 ' in x else x),'Unspecified inactive payload preserved')
add('ref_metadata_only','healthy_genuine',True,lambda s:change_trace(s,lambda x:re.sub(r'ref_(level|accepted|retired|aborted)=\d+',lambda m:m[0].split('=')[0]+'=1',x)),'Ref fields cannot act as oracle')
def stats_change(s,k,v):return re.sub(r'(?m)^(# RAW_SCAN_STATS .*?)$',lambda m:re.sub(r'\b'+k+r'=\S+',k+'='+str(v),m[1]),s)
add('plausible_counts','healthy_genuine',False,lambda s:stats_change(stats_change(stats_change(stats_change(s,'true_accepted',2),'true_retired',2),'accepted',2),'retired',2),'Wrong balanced totals2 within5cycles must fail history')
add('plausible_circuits','queue_genuine',False,lambda s:stats_change(s,'wrap_writes',1001),'Plausible circuit count below cycles but inconsistent selected segment')
add('reset_history','healthy_genuine',False,lambda s:change_trace(s,lambda x:x.replace('rst=1','rst=0')),'No reset anchor invalidates reconstruction')
add('cancel_history','healthy_genuine',False,lambda s:change_trace(s,lambda x:x.replace('cancel=0','cancel=1') if ('cycle=3 ' in x and 'side=pre ' in x) or ('cycle=4 ' in x and 'side=post ' in x) else x),'Unexpected cancel must change abort history')
add('composition_window','composition_genuine',False,lambda s:change_trace(s,lambda x:x.replace('rearm=1','rearm=0'),'RAW_SCAN_COMP_TRACE'),'Window controls bind collector origin')
add('composition_ref_only','composition_genuine',True,lambda s:change_trace(s,lambda x:re.sub(r'ref_\w+=\d+',lambda m:m[0].split('=')[0]+'=1',x),'RAW_SCAN_COMP_TRACE'),'Composition ref metadata is not oracle')
# A distinct manual five-edge full-width healthy fixture. No candidate or old main oracle import.
fields=list(schemas['RAW_SCAN_TRACE']['fields']);widths={'data':64,'ticks':256,'quality':32,'first_seq':32,'last_seq':32,'tag':64}
rec={k:(1<<v)-1 for k,v in widths.items()};rec['last_seq']=0
queue=[];ac=rt=ab=0;rows=[];controls=[(1,0,0,0),(0,0,1,0),(0,0,0,0),(0,0,0,1),(0,1,0,0)]
for n,(rst,cancel,iv,ready) in enumerate(controls):
    for side in ['pre','post']:
        if side=='post':
            if rst:queue=[];ac=rt=ab=0
            elif cancel:ab+=len(queue);queue=[]
            elif queue and ready:queue.pop(0);rt+=1
            elif iv:queue.append(dict(rec));ac+=1
        d={'side':side,'case':'guard_healthy','cycle':str(n+(side=='post')),'rst':str(rst),'cancel':str(cancel),'in_valid':str(iv),'in_ready':str(int(not(rst or cancel) and not queue)),'out_valid':str(int(not(rst or cancel) and bool(queue))),'out_ready':str(ready),'level':str(len(queue)),'stat_accepted':str(ac),'stat_retired':str(rt),'stat_aborted':str(ab),'ref_level':str(len(queue)),'ref_accepted':str(ac),'ref_retired':str(rt),'ref_aborted':str(ab)}
        for key in widths:d['in_'+key]=format(rec[key] if iv else 0,'x');d['out_'+key]=format(queue[0][key] if queue else 0,'x')
        rows.append('# RAW_SCAN_TRACE '+' '.join(k+'='+d[k] for k in fields))
body='\n'.join(rows)+'\n# RAW_SCAN_STATS case=guard_healthy depth=1 seq_w=32 tick_w=64 tag_w=64 stat_w=32 checks=1 errors=0 level=0 accepted=1 retired=1 aborted=0 true_accepted=1 true_retired=1 true_aborted=0 cycles=5 resets=1 cancels=1 stalls=1 wrap_writes=0 wrap_reads=0\n# RAW_SCAN_GUARD_ALIVE\n# RAW_SCAN_PASS\n# Errors: 0, Warnings: 0\n'
d=Q/'fixtures/full_width';d.mkdir();(d/'stdout.txt').write_text(body,encoding='utf-8',newline='\n');(d/'stderr.txt').write_bytes(b'');put(d/'spec.json',{'stdout':'stdout.txt','stderr':'stderr.txt','mode':'healthy','args':{'sim_exit':0,'expected_case':'guard_healthy','params':{'DEPTH':1,'SEQ_W':32,'TICK_W':64,'TAG_W':64,'STAT_W':32}}});matrix.append({'name':'full_width','spec':'fixtures/full_width/spec.json','expected_ok':True,'reason':'Manual full-width synthetic controls, no DUT/vendor claim'})
add('bootstrap_unknown','full_width',True,lambda s:change_trace(s,lambda x:re.sub(r'\b(level|stat_accepted|stat_retired|stat_aborted)=\d+',lambda m:m[1]+'=x',x) if 'side=pre ' in x and 'cycle=0 ' in x else x),'Registered state before first reset unspecified')
add('post_reset_x','full_width',False,lambda s:change_trace(s,lambda x:x.replace('level=0','level=x') if 'side=post ' in x and 'cycle=1 ' in x else x),'Defined registered state after reset must be known')
add('full_width_overflow','full_width',False,lambda s:change_trace(s,lambda x:re.sub(r'in_tag=\S+','in_tag=10000000000000000',x) if 'in_valid=1 ' in x else x),'Reject 65th tag bit, no truncation')
put(Q/'MATRIX.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'cases':matrix,'entry_cases':oldmatrix['entry_cases'],'provenance':'Post-author main recovery expectations frozen before canonical changes','old_runner_sha256':oldmatrix['runner_sha256']})
files=[{'path':str(p),'sha256':sha(p)} for p in sorted(Q.rglob('*')) if p.is_file()]+[{'path':str(N/k),'sha256':sha(N/k)} for k in ['PLAN.md','TRACE_SCHEMA.json','freeze_inputs.py']]
put(N/'EXPECTATION_FREEZE.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'kind':'post-author recovery freeze; no canonical edits yet','files':files,'cases':len(matrix),'no_oracle_import':True})
print(json.dumps({'cases':len(matrix),'freeze_sha256':sha(N/'EXPECTATION_FREEZE.json'),'schema_sha256':sha(N/'TRACE_SCHEMA.json'),'plan_sha256':sha(N/'PLAN.md')}))
