import difflib,hashlib,json,tempfile
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;W=next(p for p in N.parents if p.name=='deepeye-implementation-20261014');Q=N/'qualification'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
records=[]
for name in ['run_main23.py','audit_coverage23.py']:
    old=(M/name).read_text(encoding='utf-8');new=old.replace('from process23 import','import sys\nsys.path.insert(0,str(Path(__file__).resolve().parent.parent))\nfrom process23 import',1)
    new=new.replace("Path(tempfile.gettempdir()).resolve()==M/'tmp'","Path(tempfile.gettempdir()).resolve()==M/'repair02/tmp'")
    if name=='run_main23.py':new=new.replace("out=M/'runs'/args.label","out=M/'repair02/runs'/args.label")
    (N/name).write_text(new,encoding='utf-8',newline='\n');(N/(name+'.relocation.patch')).write_text(''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile=str(M/name),tofile=str(N/name))),encoding='utf-8',newline='\n')
    records.append({'original':str(M/name),'original_sha256':sha(M/name),'relocated':str(N/name),'relocated_sha256':sha(N/name),'changes':'Only import path, temp expectation and output root; original main inputs/algorithm unchanged'})
runner=W/'competition/deepeye/tools/acquisition/run_raw_scan_queue.py'
put(Q/'EXECUTION_BINDING.json',{'runner':str(runner),'runner_sha256':sha(runner),'expectation_freeze_sha256':sha(N/'EXPECTATION_FREEZE.json'),'corrected_sources':json.loads((N/'PATCH_APPLIED.json').read_bytes())['files']})
for name in ['run_qualification.py','entry_qualification.py','emitter.py']:
    old=(M/'repair01'/name).read_text(encoding='utf-8');new=old.replace("Q=N/'runner-qualification'","Q=N/'qualification'")
    if name=='run_qualification.py':
        new=new.replace("freeze=json.loads((Q/'FREEZE.json').read_bytes())","freeze=json.loads((N/'EXPECTATION_FREEZE.json').read_bytes())").replace("sha(Q/row['path'])","sha(Path(row['path']))").replace("matrix=json.loads((Q/'MATRIX.json').read_bytes());runner=Path(matrix['runner'])","matrix=json.loads((Q/'MATRIX.json').read_bytes());matrix.update(json.loads((Q/'EXECUTION_BINDING.json').read_bytes()));runner=Path(matrix['runner'])")
        new=new.replace("sha(Q/'FREEZE.json')","sha(N/'EXPECTATION_FREEZE.json')")
        new=new.replace("N/'snapshots/deepeye_raw_scan_queue.sv'","W/r.RTL_RELATIVE").replace("N/'snapshots/tb_raw_scan_queue.sv'","W/r.TB_RELATIVE")
    if name=='entry_qualification.py':new=new.replace("matrix=json.loads((Q/'MATRIX.json').read_bytes());cfg=","matrix=json.loads((Q/'MATRIX.json').read_bytes());matrix.update(json.loads((Q/'EXECUTION_BINDING.json').read_bytes()));cfg=")
    (N/name).write_text(new,encoding='utf-8',newline='\n');records.append({'original':str(M/'repair01'/name),'original_sha256':sha(M/'repair01'/name),'new':str(N/name),'new_sha256':sha(N/name),'purpose':'Same execution machinery; new immutable fixtures and candidate binding, new output only'})
for tool in ['vlog','vsim']:
    source=M/'repair01/runner-qualification'/(tool+'-version.txt');(Q/source.name).write_bytes(source.read_bytes())
put(N/'EXECUTION_ADAPTATION.json',{'records':records,'expectation_freeze_sha256':sha(N/'EXPECTATION_FREEZE.json'),'no_oracle_change':True})
print(json.dumps({'adaptation_sha256':sha(N/'EXECUTION_ADAPTATION.json'),'runner_sha256':sha(runner)}))
