import hashlib,json,shutil,tempfile
from pathlib import Path
N=Path(__file__).resolve().parent;Q=N/'qualification';F=N/'qualification-final';W=next(p for p in N.parents if p.name=='deepeye-implementation-20261014')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
F.mkdir();(F/'tmp').mkdir();matrix=json.loads((Q/'MATRIX.json').read_bytes())
for case in matrix['cases']:
    src=Q/case['spec'];dst=F/case['spec'];dst.parent.mkdir(parents=True)
    for f in ['stdout.txt','stderr.txt','spec.json']:shutil.copyfile(src.parent/f,dst.parent/f);assert sha(src.parent/f)==sha(dst.parent/f)
shutil.copyfile(Q/'MATRIX.json',F/'MATRIX.json')
for tool in ['vlog','vsim']:shutil.copyfile(Q/(tool+'-version.txt'),F/(tool+'-version.txt'))
binding=json.loads((Q/'EXECUTION_BINDING.json').read_bytes());binding['runner_sha256']=sha(Path(binding['runner']));binding['corrected_sources']={k:sha(W/k) for k in binding['corrected_sources']};put(F/'EXECUTION_BINDING.json',binding)
for name in ['run_qualification','entry_qualification']:
    source=N/(name+'.py');text=source.read_text(encoding='utf-8').replace("Q=N/'qualification'","Q=N/'qualification-final'")
    text=text.replace("'entry_qualification.py'","'entry_qualification_final.py'").replace("'run_qualification.py'","'run_qualification_final.py'")
    (N/(name+'_final.py')).write_text(text,encoding='utf-8',newline='\n')
put(N/'FINAL_EXECUTION_BINDING.json',{'binding':binding,'reason':'Narrow mutant label mapping changed runner; requalify final source with immutable same58+10 expectations and targeted alias controls. RTL unchanged, no main baseline replay.','new_scripts':{k:sha(N/k) for k in ['run_qualification_final.py','entry_qualification_final.py']},'old_failed_vendor_summary_sha256':sha(N/'vendor01/summary.json')})
print(json.dumps({'runner_sha256':binding['runner_sha256'],'binding_sha256':sha(N/'FINAL_EXECUTION_BINDING.json')}))
