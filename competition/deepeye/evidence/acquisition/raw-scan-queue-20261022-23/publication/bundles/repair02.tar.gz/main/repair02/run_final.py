import argparse,gzip,importlib.util,json,shutil,sys,tempfile
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;sys.path.insert(0,str(M))
from process23 import W,put,sha,run
p=argparse.ArgumentParser();p.add_argument('kind',choices=['wrap','selftest','saved']);a=p.parse_args()
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
binding=json.loads((N/'FINAL_EXECUTION_BINDING.json').read_bytes())['binding'];runner=Path(binding['runner']);assert sha(runner)==binding['runner_sha256']
d=N/('final-'+a.kind);d.mkdir()
if a.kind in ['wrap','selftest']:
    if a.kind=='wrap':
        args=[sys.executable,'-B','-X','utf8',runner,'--root',W,'--out',N/'vendor-wrap-final','--modelsim','D:/modelsim1/win64','--modelsim-ini',M.parent/'author/config/modelsim.ini','--containment-root',N,'--case','mutant_wrap_depth5']
        why='Only vendor case rejected by main-added payload label mapping; rerun exact corrected final runner end-to-end with actual compiled mutant. RTL/TB unchanged from vendor01.'
    else:
        portable=N/'portable-final';portable.mkdir();target=portable/runner.name;shutil.copyfile(runner,target)
        args=[sys.executable,'-B','-X','utf8',target,'--self-test','--self-test-out',N/'selftest-final'];why='Portable exact final-source selftest after mutant label mapping changed.'
    put(d/'INTENT.json',{'source':binding,'reason':why})
    proc=run(args,d,'execute',600,[{'path':str(runner),'sha256':sha(runner)}]);print(json.dumps({'kind':a.kind,'exit':proc['exit'],'timeout':proc['timed_out'],'stdout':proc['stdout_text'][-3000:],'stderr':proc['stderr_text'][-1000:]}));raise SystemExit(0 if proc['exit']==0 and not proc['timed_out'] else 2)
spec=importlib.util.spec_from_file_location('final_public_runner',runner);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
rows=[]
for cdir in sorted((N/'vendor01/cases').iterdir()):
    report=json.loads((cdir/'case.json').read_bytes());entry=next(x for x in r.CASES if x['name']==report['name']);dest=d/entry['name'];dest.mkdir()
    inv=report['processes']['vsim'];assert inv['exit']==0 and not inv['timed_out'];streams={}
    for stream,meta in inv['streams'].items():
        src=cdir/meta['path'];data=src.read_bytes();data=gzip.decompress(data) if meta['compressed'] else data
        import hashlib
        assert hashlib.sha256(data).hexdigest()==meta['sha256'];(dest/(stream+'.txt')).write_bytes(data);streams[stream]=data.decode('utf-8')
    args={'sim_exit':0,'expected_case':entry['case_arg'],'params':entry['params']}
    if entry['kind']=='guard':mode='guard';args={'sim_exit':0,'compile_exit':0,'family':entry['expected_family']}
    elif entry['kind']=='healthy':mode='healthy'
    elif entry['kind']=='mutant':mode='mutant';args.update(compile_exit=0,required=entry['required_mismatches'])
    elif entry['module']==r.COMPOSITION_TOP:mode='composition'
    else:mode='queue'
    data={'stdout':'stdout.txt','stderr':'stderr.txt','mode':mode,'args':args};put(dest/'spec.json',data)
    put(dest/'RECLASSIFICATION_INTENT.json',{'original_case_sha256':sha(cdir/'case.json'),'original_source':report['inputs'],'original_process_exit':inv['exit'],'new_runner_sha256':sha(runner),'new_vendor_run':False,'expected_exit':0})
    proc=run([sys.executable,'-B','-X','utf8',runner,'--verify-transcript',dest/'spec.json'],dest,'classify',120)
    row={'case':entry['name'],'exit':proc['exit'],'ok':proc['exit']==0 and not proc['timed_out'],'result_sha256':sha(dest/'spec.result.json')};rows.append(row)
# Six whitelist aliases must map to those actual public-port contradictions.
wrap=d/'mutant_wrap_depth5';base=json.loads((wrap/'spec.json').read_bytes());pairs=json.loads((N/'alias-correction/MAPPING_FREEZE.json').read_bytes())['expected_corroborated_tuples']
base['args']['required']=pairs;put(wrap/'six_aliases.json',base);proc=run([sys.executable,'-B','-X','utf8',runner,'--verify-transcript',wrap/'six_aliases.json'],wrap,'six-aliases',120);assert proc['exit']==0
# An independently specified false alias: synthetic trace only contradicts level.
negative=d/'unsubstantiated_payload';negative.mkdir();raw=(N/'selftest01/fixtures/numeric_mutant.stdout').read_text(encoding='utf-8');assert raw.count('field=level expected=0 actual=1')==1
raw=raw.replace('field=level expected=0 actual=1','field=data expected=0 actual=1');(negative/'stdout.txt').write_text(raw,encoding='utf-8',newline='\n');(negative/'stderr.txt').write_bytes(b'')
data={'stdout':'stdout.txt','stderr':'stderr.txt','mode':'mutant','args':{'sim_exit':0,'compile_exit':0,'expected_case':'queue_directed','params':{'DEPTH':1,'SEQ_W':2,'TICK_W':1,'TAG_W':1,'STAT_W':2},'required':[['data',0,1]]}};put(negative/'spec.json',data);put(negative/'EXPECTATION.json',{'expected_exit':1,'reason':'Only level is changed in the coherent captured synthetic ports; data payload stays1, so a claimed out_data0vs1 has no trace witness','stdout_sha256':sha(negative/'stdout.txt'),'post_alias_execution_control':True})
proc2=run([sys.executable,'-B','-X','utf8',runner,'--verify-transcript',negative/'spec.json'],negative,'reject',120);assert proc2['exit']==1
put(d/'RESULT.json',{'runner_sha256':sha(runner),'saved_vendor_cases':rows,'all_pass':all(x['ok'] for x in rows),'six_alias_tuple_control_exit':proc['exit'],'unsubstantiated_payload_exit':proc2['exit'],'new_vendor_runs':0,'original_vendor01_failure_preserved':True});print(json.dumps({'saved_cases':len(rows),'all_pass':all(x['ok'] for x in rows),'alias_positive':proc['exit'],'alias_negative':proc2['exit']}));raise SystemExit(0 if all(x['ok'] for x in rows) else 2)
