"""Fresh hidden ModelSim runs, frozen independent vectors, queue-only guards.

Call only after author terminal/source review. Every run has a fresh label.
"""
import argparse,importlib.util,json,os,shutil,tempfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent.parent))
from process23 import M,W,run,put,sha,classify
TOOLS=Path('D:/modelsim1/win64')
TB=W/'competition/deepeye/tests/rtl/acquisition/main_tb_raw_scan_queue.sv'
COLLECTOR=W/'competition/deepeye/fpga/acquisition/deepeye_sample_scan_capture.sv'
VERIFIER=W/'competition/deepeye/tools/acquisition/main_verify_raw_scan_queue.py'
COLLECTOR_HASH='fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d'
PARAM={'depth':'D','seq':'S','tick':'T','tag':'G','stat':'K','mode':'MODE'}
GUARDPARAM={'DEPTH':'depth','SEQ_W':'seq','TICK_W':'tick','TAG_W':'tag','STAT_W':'stat'}

def main():
    p=argparse.ArgumentParser();p.add_argument('--label',required=True);p.add_argument('--dut',type=Path,required=True)
    p.add_argument('--dut-sha',required=True);p.add_argument('--phase',choices=['baseline','mutant'],default='baseline')
    p.add_argument('--case');p.add_argument('--versions-from',type=Path);args=p.parse_args()
    assert args.label.isalnum() and Path(tempfile.gettempdir()).resolve()==M/'repair02/tmp'
    assert sha(args.dut)==args.dut_sha and sha(COLLECTOR)==COLLECTOR_HASH
    frozen=json.loads((M/'PREDISPATCH_FREEZE.json').read_bytes())
    for row in frozen['files']:
        # Wrapper live streams were excluded at freeze; all actual frozen inputs bind.
        assert sha(Path(row['path']))==row['sha256'],row['path']
    manifest=json.loads((M/'VECTOR_MANIFEST.json').read_bytes())
    out=M/'repair02/runs'/args.label;out.mkdir(parents=True,exist_ok=False)
    put(out/'environment.json',{'cwd':os.getcwd(),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR'],'resolved_temp':tempfile.gettempdir(),'phase':args.phase,'DUT_sha256':args.dut_sha,'freeze_sha256':sha(M/'PREDISPATCH_FREEZE.json')})
    spec=importlib.util.spec_from_file_location('q23_main_verifier',VERIFIER);verify=importlib.util.module_from_spec(spec);spec.loader.exec_module(verify)
    versions={}
    if args.versions_from:
        previous=json.loads(args.versions_from.read_bytes())
        for tool in ['vlog','vsim']:
            assert previous[tool]['classification']['ok'] and sha(TOOLS/(tool+'.exe'))==previous[tool]['executable_sha256']
        versions={'reused_verified_receipt':str(args.versions_from),'receipt_sha256':sha(args.versions_from),'records':previous}
    else:
        vd=out/'v';vd.mkdir()
        for tool in ['vlog','vsim']:
            actual=run([TOOLS/(tool+'.exe'),'-version'],vd,tool,30)
            result=classify('version',actual,tool=tool)
            versions[tool]={'classification':result,'executable_sha256':sha(TOOLS/(tool+'.exe')),'process':actual}
        put(out/'versions.json',versions)
        assert all(versions[t]['classification']['ok'] for t in ['vlog','vsim']), 'Version preflight failed; no RTL run'
    jobs=[]
    if args.phase=='baseline':
        assert args.case is None
        jobs=[{'name':c['name'],'kind':'positive','parameters':c['parameters'],'case':c} for c in manifest['cases']]
        defaults={'depth':4,'seq':32,'tick':64,'tag':32,'stat':32,'mode':0}
        for n,g in enumerate(manifest['parameter_guards']):
            params=dict(defaults);params[GUARDPARAM[g['parameter']]]=g['value']
            jobs.append({'name':f'guard{n:02}','kind':'guard','parameters':params,'own':g['expected_fatal']})
        for n,g in enumerate(manifest['legal_guard_controls']):
            params=dict(defaults);params.update({GUARDPARAM[k]:v for k,v in g.items()})
            jobs.append({'name':f'legal{n:02}','kind':'guard_control','parameters':params})
        jobs.append({'name':'guardpriority','kind':'guard','parameters':dict(defaults,depth=0,seq=1),'own':'deepeye_raw_scan_queue: DEPTH out of range'})
    else:
        assert args.case in ['queue_depth3','queue_depth5']
        case=next(c for c in manifest['cases'] if c['name']==args.case)
        jobs=[{'name':args.case,'kind':'positive','parameters':case['parameters'],'case':case}]
    put(out/'JOBS_INTENT.json',{'jobs':jobs,'version_binding':versions,'DUT':str(args.dut),'DUT_sha256':args.dut_sha,'TB_sha256':sha(TB),'collector_sha256':COLLECTOR_HASH,'runner_sha256':sha(Path(__file__)),'process_helper_sha256':sha(M/'process23.py')})
    results=[]
    for n,job in enumerate(jobs):
        d=out/f'c{n:02}';d.mkdir();snap=d/'s';snap.mkdir()
        for source,name in [(args.dut,'q.sv'),(TB,'t.sv'),(COLLECTOR,'c.sv')]:
            shutil.copyfile(source,snap/name);assert sha(source)==sha(snap/name)
        inputs=[{'path':str(snap/name),'sha256':sha(snap/name)} for name in ['q.sv','t.sv','c.sv']]
        lib=run([TOOLS/'vlib.exe','work'],d,'vlib',30,inputs)
        libok=lib['exit']==0 and not lib['timed_out'] and not lib['stderr_text'].strip() and not any(s in lib['stdout_text'].lower() for s in ['error','warning','fatal'])
        result={'name':job['name'],'kind':job['kind'],'parameters':job['parameters'],'source_snapshots':inputs,'library_ok':libok}
        if not libok:
            result['pass']=False;result['infrastructure_failure']='vlib';results.append(result);put(d/'CLASSIFICATION.json',result);break
        compiled=run([TOOLS/'vlog.exe','-sv','-floatparameters','-work','work',snap/'q.sv',snap/'c.sv',snap/'t.sv'],d,'vlog',60,inputs)
        result['compile']=classify('compile',compiled)
        if not result['compile']['ok']:
            result['pass']=False;result['infrastructure_failure']='vlog';results.append(result);put(d/'CLASSIFICATION.json',result);break
        argv=[TOOLS/'vsim.exe','-c','-lib','work','-wlf',d/'waves.wlf','-do','run -all; quit -f']
        argv += ['-g'+PARAM[k]+'='+str(v) for k,v in job['parameters'].items()]
        argv += ['main_tb_raw_scan_queue']
        if job['kind']=='positive':
            case=job['case'];stim=M/'vectors'/case['stimulus']['path']
            shutil.copyfile(stim,d/'input.stim');assert sha(d/'input.stim')==case['stimulus']['sha256']
            argv += ['+STIM='+str(d/'input.stim'),'+TRACE='+str(d/'ports.txt'),'+CASE='+case['name']]
        else:argv+=['+GUARD']
        simulated=run(argv,d,'vsim',60,inputs)
        result['simulation']=classify(job['kind'],simulated,case=job['name'],edges=job.get('case',{}).get('edges'),own=job.get('own'))
        if job['kind']=='positive' and result['simulation']['ok']:
            try:
                comparison=verify.check_trace(M,job['name'],d/'ports.txt');result['comparison']=comparison
                if args.phase=='mutant':result['pass']=not comparison['pass'] and bool(comparison['first_mismatch']['numeric'])
                else:result['pass']=comparison['pass']
            except Exception as e:result['pass']=False;result['comparison_error']=type(e).__name__+': '+str(e)
        else:result['pass']=result['simulation']['ok'] and job['kind']!='positive'
        put(d/'CLASSIFICATION.json',result);results.append(result)
        print(json.dumps({'case':job['name'],'pass':result['pass'],'kind':job['kind']}),flush=True)
    complete=len(results)==len(jobs)
    final={'phase':args.phase,'DUT_sha256':args.dut_sha,'complete':complete,'planned':len(jobs),'executed':len(results),'all_pass':complete and all(x['pass'] for x in results),'results':results,'planned_positive_edges':sum(j.get('case',{}).get('edges',0) for j in jobs),'verified_complete_trace_edges':sum(x.get('comparison',{}).get('edges',0) for x in results),'partial_failed_trace_note':'Any partial stream from failure is retained separately and is not counted as a complete verified trace'}
    put(out/'RESULT.json',final)
    print(json.dumps({'result':str(out/'RESULT.json'),'sha256':sha(out/'RESULT.json'),'all_pass':final['all_pass'],'executed':len(results)}),flush=True)
    return 0 if final['all_pass'] else 2
if __name__=='__main__':raise SystemExit(main())
