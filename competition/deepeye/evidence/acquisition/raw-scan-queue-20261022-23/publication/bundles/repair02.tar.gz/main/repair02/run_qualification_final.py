"""Independent direct calls, actual transcript CLI, and normal-main process seams."""
import importlib.util,json,shutil,sys,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;Q=N/'qualification-final'
sys.path.insert(0,str(M))
from process23 import sha,put,run,W
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
freeze=json.loads((N/'EXPECTATION_FREEZE.json').read_bytes())
for row in freeze['files']:assert sha(Path(row['path']))==row['sha256']
matrix=json.loads((Q/'MATRIX.json').read_bytes());matrix.update(json.loads((Q/'EXECUTION_BINDING.json').read_bytes()));runner=Path(matrix['runner']);assert sha(runner)==matrix['runner_sha256']
put(Q/'EXECUTION_FREEZE.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'fixture_freeze_sha256':sha(N/'EXPECTATION_FREEZE.json'),'scripts':{str(N/n):sha(N/n) for n in ['run_qualification_final.py','entry_qualification_final.py','emitter.py']},'readonly_process_helper_sha256':sha(M/'process23.py'),'new_main_expectations_are_post_author':True})
spec=importlib.util.spec_from_file_location('qualified_author_runner',runner);r=importlib.util.module_from_spec(spec);spec.loader.exec_module(r)
rows=[]
for case in matrix['cases']:
    p=Q/case['spec'];s=json.loads(p.read_bytes());out=(p.parent/s['stdout']).read_text(encoding='utf-8');err=(p.parent/s['stderr']).read_text(encoding='utf-8');a=s['args'];mode=s['mode']
    if mode in ['queue','healthy']:direct=r.classify_queue_output(a['sim_exit'],out,err,a['expected_case'],a['params'],healthy=mode=='healthy')
    elif mode=='composition':direct=r.classify_composition_output(a['sim_exit'],out,err,a['expected_case'],a['params'])
    elif mode=='guard':direct=r.classify_guard_output(a['compile_exit'],'# Errors: 0, Warnings: 0\n','',a['sim_exit'],out,err,a['family'],r.FATAL_MESSAGES[a['family']])
    else:direct=r.classify_mutant_output(a['compile_exit'],'# Errors: 0, Warnings: 0\n','',a['sim_exit'],out,err,a['expected_case'],a['params'],[tuple(x) for x in a['required']])
    put(p.parent/'direct.json',direct)
    proc=run([sys.executable,'-B','-X','utf8',runner,'--verify-transcript',p],p.parent,'actual-cli',60,[{'path':str(runner),'sha256':sha(runner)},{'path':str(p),'sha256':sha(p)}])
    actual=json.loads((p.parent/'spec.result.json').read_bytes())
    row={'name':case['name'],'expected_ok':case['expected_ok'],'direct_ok':direct['ok'],'actual_cli_ok':actual['ok'],'actual_cli_exit':proc['exit'],'match':direct['ok']==case['expected_ok'] and actual['ok']==case['expected_ok'] and proc['exit']==(0 if case['expected_ok'] else 1),'evidence':str(p.parent.relative_to(Q))}
    rows.append(row);print(json.dumps(row),flush=True)
# Immutable old source snapshots are only material for the synthetic process test.
for rel,source in [(r.RTL_RELATIVE,W/r.RTL_RELATIVE),(r.TB_RELATIVE,W/r.TB_RELATIVE),(r.COLLECTOR_RELATIVE,W/r.COLLECTOR_RELATIVE)]:
    dest=Q/'root'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(source,dest);assert sha(dest)==sha(source)
shutil.copyfile(M.parent/'author/config/modelsim.ini',Q/'modelsim.ini')
entryrows=[]
for cfg in matrix['entry_cases']:
    d=Q/'entries'/cfg['name'];d.mkdir(parents=True)
    proc=run([sys.executable,'-B','-X','utf8',N/'entry_qualification_final.py',cfg['name']],d,'main-process',60,[{'path':str(N/'entry_qualification_final.py'),'sha256':sha(N/'entry_qualification_final.py')},{'path':str(runner),'sha256':sha(runner)}])
    summarypath=d/'run/summary.json';summary=json.loads(summarypath.read_bytes()) if summarypath.exists() else None
    row={'name':cfg['name'],'expected_exit':cfg['expected_exit'],'actual_exit':proc['exit'],'summary_ok':None if summary is None else summary['ok'],'match':not proc['timed_out'] and proc['exit']==cfg['expected_exit'] and summary is not None and summary['ok']==(cfg['expected_exit']==0),'evidence':str(d.relative_to(Q))}
    entryrows.append(row);print(json.dumps(row),flush=True)
result={'runner_sha256':sha(runner),'freeze_sha256':sha(N/'EXPECTATION_FREEZE.json'),'direct_and_cli':rows,'normal_main_entries':entryrows,'pass':all(x['match'] for x in rows+entryrows),'synthetic_process_seam':True,'vendor_runs_in_this_qualification':0,'genuine_base_transcripts_keep_original_source_binding':True}
put(Q/'RESULT.json',result)
raise SystemExit(0 if result['pass'] else 2)
