import argparse,json,shutil,sys,tempfile
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;sys.path.insert(0,str(M))
from process23 import W,put,sha,run
p=argparse.ArgumentParser();p.add_argument('kind',choices=['vendor','selftest']);a=p.parse_args()
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
runner=W/'competition/deepeye/tools/acquisition/run_raw_scan_queue.py';binding=json.loads((N/'qualification/EXECUTION_BINDING.json').read_bytes());assert sha(runner)==binding['runner_sha256']
assert json.loads((N/'qualification/RESULT.json').read_bytes())['pass']
d=N/(a.kind+'-process');d.mkdir()
if a.kind=='vendor':
    selected=['queue_d1','queue_d3','queue_d4_defaults','queue_d5','queue_d8_stat2','comp_d1','comp_d3','comp_d4_defaults','comp_d5','comp_exhaust','guard_depth_0','guard_depth_9','guard_seq_w_1','guard_seq_w_33','guard_tick_w_0','guard_tick_w_65','guard_tag_w_0','guard_tag_w_65','guard_stat_w_1','guard_stat_w_33','guard_priority_depth','guard_healthy','mutant_wrap_depth5','mutant_cancel_depth5']
    out=N/'vendor01';args=[sys.executable,'-B','-X','utf8',runner,'--root',W,'--out',out,'--modelsim','D:/modelsim1/win64','--modelsim-ini',M.parent/'author/config/modelsim.ini','--containment-root',N]
    for name in selected:args+=['--case',name]
    why='Selected new-source captures: five queue depths cover bubble/nonpower/defaults/saturation; five composition cases cover windows/exhaustion; all ten guards+priority+healthy bind fallback fix; two compiled mutants bind trace corroboration to corrected source. Historical2/6/7 not replayed.'
else:
    portable=N/'portable';portable.mkdir();target=portable/runner.name;shutil.copyfile(runner,target);assert sha(target)==sha(runner)
    out=N/'selftest01';args=[sys.executable,'-B','-X','utf8',target,'--self-test','--self-test-out',out];selected=['portable_public_selftest'];why='Changed coherent fixture and actual CLI/process selftest, executed from standalone exact-byte public runner copy without private helper imports.'
put(d/'VALIDATION_INTENT.json',{'selected':selected,'rationale':why,'runner_sha256':sha(runner),'source_binding':binding,'kind':a.kind})
result=run(args,d,'execute',900,[{'path':str(runner),'sha256':sha(runner)}]);print(json.dumps({'kind':a.kind,'exit':result['exit'],'timeout':result['timed_out'],'stdout':result['stdout_text'][-5000:],'stderr':result['stderr_text'][-2000:]}));raise SystemExit(0 if result['exit']==0 and not result['timed_out'] else 2)
