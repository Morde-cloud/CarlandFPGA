import ast,difflib,gzip,hashlib,json,os,shutil,subprocess,tempfile
from datetime import datetime,timezone
from pathlib import Path
N=Path(__file__).resolve().parent;M=N.parent;A=M.parent/'author';R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';O=R/'.local/deployment/node-b/evidence/raw-scan-queue-20261022-23';P=O/'repair02'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
    with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
def info(p):return {'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)}
assert Path(tempfile.gettempdir()).resolve()==N/'tmp'
consumed=json.loads((P/'CONSUMED.json').read_bytes());takeover=json.loads((P/'MAIN_TAKEOVER.json').read_bytes());binding=json.loads((N/'FINAL_EXECUTION_BINDING.json').read_bytes())['binding'];sources=binding['corrected_sources']
for rel,h in sources.items():assert sha(W/rel)==h
assert sources['competition/deepeye/fpga/acquisition/deepeye_raw_scan_queue.sv']=='630e14803d82b3379517d91626de4ad7e7d3c509ad14363b3164031a5f633ee4'
assert sources['competition/deepeye/tests/rtl/acquisition/tb_raw_scan_queue.sv']=='e38944f5340cd4f17c9f6a2481ed4150cf82d3902031dec3ac7f6db3790f0ad0'
for name in ['deepeye_raw_scan_queue.sv','tb_raw_scan_queue.sv']:
    path=next(W/k for k in sources if Path(k).name==name);assert path.read_bytes()==(M/'repair01/expected'/name).read_bytes()
resolution={Path(x['canonical']).resolve():Path(x['snapshot']) for x in takeover['canonical_paths']}
def old_check(path,h):
    path=Path(path).resolve();resolved=resolution.get(path,path);assert sha(resolved)==h,str(path);return resolved
for x in takeover['canonical_paths']:old_check(x['canonical'],x['sha256'])
author=json.loads((A/'FINAL_FILE_HASHES.json').read_bytes());assert len(author['files'])==1686
for rel,h in author['files'].items():old_check(W/rel,h)
counts={}
for manifest,count in [(M/'LOCAL_REVIEW_MANIFEST.json',1020),(M/'repair01/LOCAL_REVIEW_MANIFEST.json',743)]:
    data=json.loads(manifest.read_bytes());assert len(data['artifacts'])==count
    for row in data['artifacts']:old_check(row['path'],row['sha256'])
    counts[str(manifest)]=count
for name in ['FINAL_RECEIPT.json','repair01/FINAL_RECEIPT.json']:
    expected={'FINAL_RECEIPT.json':'954838ee55f22fdc3b923b83af8fd55454cb64b5af33e70ab102674b3fe4a2ab','repair01/FINAL_RECEIPT.json':'0c2a0ac81d87eb342cd1c721984424b97d453906dc0cbac558cd976a4b3009d1'}[name];assert sha(O/name)==expected
for row in json.loads((O/'FREEZE_CHECKS.json').read_bytes())['old_audit_files']:old_check(row['path'],row['sha256'])
assert sha(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
for row in json.loads((M/'PREDISPATCH_FREEZE.json').read_bytes())['files']:assert sha(Path(row['path']))==row['sha256']
for row in json.loads((N/'EXPECTATION_FREEZE.json').read_bytes())['files']:assert sha(Path(row['path']))==row['sha256']
runner=Path(binding['runner']);before=(N/'snapshots/run_raw_scan_queue.py').read_text(encoding='utf-8');after=runner.read_text(encoding='utf-8')
def functions(text):return {x.name:ast.get_source_segment(text,x) for x in ast.parse(text).body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
bfunc,afunc=functions(before),functions(after)
unchanged=['_normal_lines','_strict_diagnostics','_structured_rows','_parse_stats','parse_queue_stats','parse_comp_stats','_mismatch_rows','_params_match','_sat_identity','_compile_ok','classify_guard_output','_run_hidden','_pending_invocation','_persist_invocation','_invoke','_version_check','select_cases','_snapshot_inputs','_case_env','run_case','aggregate_results','_validate_containment','_parse_args','main','_verify_transcript']
for name in unchanged:assert bfunc[name]==afunc[name],name
source_snapshots=[]
(N/'final-source').mkdir()
for rel,h in sources.items():
    path=W/rel;target=N/'final-source'/path.name;shutil.copyfile(path,target);assert sha(target)==h
    patch=N/'final-source'/(path.name+'.diff');patch.write_text(''.join(difflib.unified_diff((N/'snapshots'/path.name).read_text(encoding='utf-8').splitlines(True),path.read_text(encoding='utf-8').splitlines(True),fromfile='old/'+rel,tofile='repair02/'+rel)),encoding='utf-8',newline='\n');source_snapshots.append({'canonical':rel,'new':info(target),'diff':info(patch),'old_snapshot':info(N/'snapshots'/path.name)})
base=json.loads((N/'runs/baseline02/RESULT.json').read_bytes());assert base['all_pass'] and base['executed']==30
cov=json.loads((N/'runs/baseline02/ACTUAL_COVERAGE.json').read_bytes());assert cov['coverage_checks_passed'] and cov['actual_complete_positive_edges']==87836
qual=json.loads((N/'qualification-final/RESULT.json').read_bytes());assert qual['pass'] and len(qual['direct_and_cli'])==58 and len(qual['normal_main_entries'])==10 and qual['runner_sha256']==sha(runner)
first=json.loads((N/'vendor01/summary.json').read_bytes());assert not first['ok'] and first['failed']==['mutant_wrap_depth5']
saved=json.loads((N/'final-saved/RESULT.json').read_bytes());assert saved['all_pass'] and len(saved['saved_vendor_cases'])==24 and saved['six_alias_tuple_control_exit']==0 and saved['unsubstantiated_payload_exit']==1 and saved['runner_sha256']==sha(runner)
wrap=json.loads((N/'vendor-wrap-final/summary.json').read_bytes());assert wrap['ok'] and wrap['selected']==['mutant_wrap_depth5']
selftest=json.loads((N/'selftest-final/self_test_summary.json').read_bytes());assert selftest['ok'] and sha(N/'portable-final'/runner.name)==sha(runner)
# Verify each stored raw vendor/synthetic process stream, including compressed
# expanded byte hashes. These checks do not re-execute those processes.
stream_records=0
for meta in N.rglob('*.invocation.json'):
    d=json.loads(meta.read_bytes())
    for key,row in d['streams'].items():
        path=meta.parent/row['path'];raw=path.read_bytes()
        if row.get('compressed'):
            assert hashlib.sha256(raw).hexdigest()==row['compressed_sha256'];raw=gzip.decompress(raw)
        assert len(raw)==row['bytes'] and hashlib.sha256(raw).hexdigest()==row['sha256'],str(path)
        lines=0 if not raw else raw.count(b'\n')+(0 if raw.endswith(b'\n') else 1)
        assert lines==row['line_count'];stream_records+=1
process_records=0
for meta in N.rglob('*.result.json'):
    d=json.loads(meta.read_bytes())
    if 'stdout_path' in d and 'stdout_sha256' in d:
        for key in ['stdout','stderr']:assert sha(Path(d[key+'_path']))==d[key+'_sha256']
        process_records+=1
gitexe=shutil.which('git');gd=N/'final-git';gd.mkdir()
def git(label,args):
    argv=[gitexe,'-c','core.longpaths=true','-C',str(W),*args];put(gd/(label+'.intent.json'),{'argv':argv,'cwd':str(N),'TMP':os.environ['TMP'],'TEMP':os.environ['TEMP'],'TMPDIR':os.environ['TMPDIR'],'PYTHONDONTWRITEBYTECODE':'1','git_sha256':sha(Path(gitexe)),'at_utc':datetime.now(timezone.utc).isoformat()})
    r=subprocess.run(argv,cwd=N,stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False,timeout=30,creationflags=getattr(subprocess,'CREATE_NO_WINDOW',0));(gd/(label+'.stdout.bin')).write_bytes(r.stdout);(gd/(label+'.stderr.bin')).write_bytes(r.stderr);put(gd/(label+'.result.json'),{'exit':r.returncode,'stdout_sha256':sha(gd/(label+'.stdout.bin')),'stderr_sha256':sha(gd/(label+'.stderr.bin'))});assert r.returncode==0;return r.stdout
head=git('head',['rev-parse','HEAD']).decode().strip();assert head=='94571d2cd9a68bd030c878c406f19a1be6ec53d7';assert not git('staged',['diff','--cached','--name-only']) and not git('unmerged',['ls-files','--unmerged']);git('status',['status','--porcelain=v1','--untracked-files=all'])
decision={k:consumed[k] for k in ['task_id','task_version','parent_work','operation_id','instruction','work_id','actual_thread','actual_turn','contract']}
decision.update(at_utc=datetime.now(timezone.utc).isoformat(),status='REPAIR02_READY_FOR_REVIEW',publication_authorized=False,coordinator_acceptance='pending',main_authored_recovery=True,source_hashes=sources,source_snapshots=source_snapshots,unchanged_public_functions=unchanged,unchanged_main_oracle=True,baseline={'cases':30,'positive_edges':87836,'result':info(N/'runs/baseline02/RESULT.json'),'coverage':info(N/'runs/baseline02/ACTUAL_COVERAGE.json')},qualification={'direct_cli_cases':58,'normal_main_entries':10,'result':info(N/'qualification-final/RESULT.json'),'synthetic_vendor_seams':True},vendor={'initial_actual_cases':24,'initial_qualified':23,'initial_failed':['mutant_wrap_depth5'],'failed_summary':info(N/'vendor01/summary.json'),'final_saved_reclassification':info(N/'final-saved/RESULT.json'),'actual_followup_wrap_cases':1,'actual_followup_wrap':info(N/'vendor-wrap-final/summary.json')},standalone_selftest=info(N/'selftest-final/self_test_summary.json'),schema_freeze=info(N/'TRACE_SCHEMA.json'),expectation_freeze=info(N/'EXPECTATION_FREEZE.json'),alias_freeze=info(N/'alias-correction/MAPPING_FREEZE.json'),takeover=info(P/'MAIN_TAKEOVER.json'),old_author_manifest_verified=1686,old_main_manifests_verified=counts,historical_source_resolution=[{'old_canonical':str(k),'unchanged_old_snapshot':str(v),'sha256':sha(v)} for k,v in resolution.items()],raw_streams_verified=stream_records,process_receipts_verified=process_records,review=info(N/'REVIEW.md'),baseline_head=head,new_source_commit=None,request_hash=None,published_handoff_manifest=None,new_child=False,board='A-only',not_run=['all29','B02','B03','G05','B06','R03','full_product_simulation','synthesis','implementation','timing','CDC_RDC','board','system'])
put(N/'REVIEW_DECISION.json',decision)
artifacts=[]
for root in [N,P]:
    for path in sorted(root.rglob('*')):
        if not path.is_file():continue
        parts=path.relative_to(root).parts
        if any(x in ['tmp','work','cache','__pycache__'] for x in parts) or path.suffix.lower()=='.wlf':continue
        if path.name.startswith('seal-review.') and path.suffix=='.txt':continue
        artifacts.append(info(path))
for path in [A/'FINAL_FILE_HASHES.json',M/'LOCAL_REVIEW_MANIFEST.json',M/'repair01/LOCAL_REVIEW_MANIFEST.json',O/'FINAL_RECEIPT.json',O/'repair01/FINAL_RECEIPT.json']+[W/k for k in sources]:artifacts.append(info(path))
put(N/'LOCAL_REVIEW_MANIFEST.json',{'at_utc':datetime.now(timezone.utc).isoformat(),'kind':'Local repair02 candidate for review; not published handoff','operation_id':decision['operation_id'],'artifacts':artifacts,'excluded':'Derived work/cache/tmp/__pycache__/WLF; live seal stdout; substantive raw ports and subprocess streams retained','historical_resolution':decision['historical_source_resolution'],'decision_sha256':sha(N/'REVIEW_DECISION.json')})
receipt={k:decision[k] for k in ['task_id','task_version','parent_work','operation_id','instruction','work_id','actual_thread','actual_turn','contract','status','publication_authorized','coordinator_acceptance','source_hashes','baseline_head','new_source_commit','request_hash','published_handoff_manifest','not_run']}
receipt.update(at_utc=datetime.now(timezone.utc).isoformat(),decision=info(N/'REVIEW_DECISION.json'),review=info(N/'REVIEW.md'),local_manifest=info(N/'LOCAL_REVIEW_MANIFEST.json'),artifacts=len(artifacts),schema_freeze=decision['schema_freeze'],expectation_freeze=decision['expectation_freeze'],takeover=decision['takeover'],validation={'main_baseline_cases':30,'positive_edges':87836,'direct_cli_cases':58,'normal_main_entries':10,'fresh_vendor_initial_cases':24,'initial_failed':1,'fresh_vendor_followup_wrap':1,'final_saved_reclassified':24,'portable_selftest':True},callback='One supported App return to existing coordinator only; no publication/peer/desktop completion announcement')
put(P/'FINAL_RECEIPT.json',receipt);print(json.dumps({'receipt':info(P/'FINAL_RECEIPT.json'),'manifest':info(N/'LOCAL_REVIEW_MANIFEST.json'),'decision':info(N/'REVIEW_DECISION.json'),'artifacts':len(artifacts),'streams_verified':stream_records,'process_receipts_verified':process_records}))
