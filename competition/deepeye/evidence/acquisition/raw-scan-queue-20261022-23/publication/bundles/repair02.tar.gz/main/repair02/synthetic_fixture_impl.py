def _synthetic_queue_fixture(*, mutant=False) -> str:
    """Main-authored coherent synthetic history, not ModelSim/RTL evidence.

    Constructed separately from the trace validator. No validator call or
    imported expectation model supplies its records. Depth1, tiny payloads.
    """
    schedule = [(1, 0, 0, 0), (0, 0, 1, 0)]
    schedule += [(0, 0, 0, 0)] * 4096
    schedule += [(0, 0, 0, 1), (1, 0, 0, 0), (0, 0, 1, 0)]
    schedule += [(0, 0, 1, 1)] * 2008
    schedule += [(0, 0, 0, 1), (0, 1, 0, 0)]
    occupied = accepted = retired = aborted = 0
    lines = []
    for cycle, (rst, cancel, offered, ready) in enumerate(schedule):
        for side in ("pre", "post"):
            if side == "post":
                if rst:
                    occupied = accepted = retired = aborted = 0
                elif cancel:
                    aborted += occupied
                    occupied = 0
                elif occupied:
                    if ready:
                        occupied = 0
                        retired += 1
                elif offered:
                    occupied = 1
                    accepted += 1
            level = 1 if mutant and cycle == len(schedule) - 1 and side == "post" else occupied
            words = [f"side={side}", "case=queue_directed", f"cycle={cycle + (side == 'post')}",
                     f"rst={rst}", f"cancel={cancel}", f"in_valid={offered}",
                     f"in_ready={int(not (rst or cancel) and not occupied)}"]
            for prefix in ("in", "out"):
                if prefix == "out":
                    words += [f"out_valid={int(not (rst or cancel) and occupied)}", f"out_ready={ready}"]
                words += [prefix + "_" + key + "=1" for key in ("data", "ticks", "quality", "first_seq", "last_seq", "tag")]
            words += [f"level={level}", f"stat_accepted={min(accepted, 3)}", f"stat_retired={min(retired, 3)}", f"stat_aborted={min(aborted, 3)}", f"ref_level={occupied}", f"ref_accepted={accepted}", f"ref_retired={retired}", f"ref_aborted={aborted}"]
            lines.append("# RAW_SCAN_TRACE " + " ".join(words))
    if mutant:
        lines.append("# RAW_SCAN_MISMATCH field=level expected=0 actual=1")
    lines.append(f"# RAW_SCAN_STATS case=queue_directed depth=1 seq_w=2 tick_w=1 tag_w=1 stat_w=2 checks=1 errors={int(mutant)} level={int(mutant)} accepted={min(accepted,3)} retired={min(retired,3)} aborted={min(aborted,3)} true_accepted={accepted} true_retired={retired} true_aborted={aborted} cycles={len(schedule)} resets=2 cancels=1 stalls=4096 wrap_writes=1004 wrap_reads=1004")
    if not mutant:
        lines.append("# RAW_SCAN_PASS")
    lines.append("# Errors: 0, Warnings: 0")
    return "\n".join(lines) + "\n"


def _valid_queue_transcript() -> str:
    return _synthetic_queue_fixture()


