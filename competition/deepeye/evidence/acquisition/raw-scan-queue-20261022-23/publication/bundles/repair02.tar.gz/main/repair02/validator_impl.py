# Main-authored repair02. This code is copied into the self-contained public
# runner; it imports neither the frozen independent oracle nor private files.
_Q_TRACE_FIELDS = "side case cycle rst cancel in_valid in_ready in_data in_ticks in_quality in_first_seq in_last_seq in_tag out_valid out_ready out_data out_ticks out_quality out_first_seq out_last_seq out_tag level stat_accepted stat_retired stat_aborted ref_level ref_accepted ref_retired ref_aborted".split()
_C_TRACE_FIELDS = "side case cycle rst stop rearm rearm_tag sample_strobe sample_channel sample_data sample_tick sample_quality consumer_ready c_out_valid c_out_data c_out_ticks c_out_quality c_out_first_seq c_out_last_seq c_out_tag c_armed c_partial_len c_next_seq c_exhausted c_order_event c_overrun_event c_exhaust_event c_events c_scans c_retired c_discarded c_order_errors c_overruns q_in_ready q_out_valid q_out_ready q_out_data q_out_ticks q_out_quality q_out_first_seq q_out_last_seq q_out_tag q_level q_accepted q_retired q_aborted ref_partial ref_slot ref_q_level ref_q_accepted ref_q_retired ref_q_aborted".split()
_RECORD_FIELDS = ("data", "ticks", "quality", "first_seq", "last_seq", "tag")
_C_COUNT_FIELDS = ("events", "scans", "retired", "discarded", "order_errors", "overruns")


def _trace_schema(params: dict[str, int], composition: bool):
    limits = {"DEPTH": (1, 8), "SEQ_W": (2, 32), "TICK_W": (1, 64),
              "TAG_W": (1, 64), "STAT_W": (2, 32)}
    if set(params) != set(limits) or any(
        type(params[k]) is not int or not lo <= params[k] <= hi
        for k, (lo, hi) in limits.items()
    ):
        raise ValueError("invalid trace parameter identity")
    schema = {k: (10, None) for k in (_C_TRACE_FIELDS if composition else _Q_TRACE_FIELDS)}
    for k in ("side", "case"):
        schema[k] = (0, None)
    controls = ("rst stop rearm sample_strobe consumer_ready c_out_valid c_armed c_exhausted c_order_event c_overrun_event c_exhaust_event q_in_ready q_out_valid q_out_ready ref_slot" if composition else "rst cancel in_valid in_ready out_valid out_ready").split()
    for k in controls:
        schema[k] = (2, 1)
    payload = {"data": 64, "ticks": 4 * params["TICK_W"], "quality": 32,
               "first_seq": params["SEQ_W"], "last_seq": params["SEQ_W"],
               "tag": params["TAG_W"]}
    for prefix in (("c_out_", "q_out_") if composition else ("in_", "out_")):
        for k, width in payload.items():
            schema[prefix + k] = (16, width)
    lw = max(1, params["DEPTH"].bit_length())
    if composition:
        schema.update(rearm_tag=(16, params["TAG_W"]), sample_data=(16, 16),
                      sample_tick=(16, params["TICK_W"]), sample_quality=(16, 8),
                      sample_channel=(10, 2), c_partial_len=(10, 3),
                      c_next_seq=(10, params["SEQ_W"]), q_level=(10, lw))
        for k in _C_COUNT_FIELDS:
            schema["c_" + k] = (10, params["STAT_W"])
        for k in ("accepted", "retired", "aborted"):
            schema["q_" + k] = (10, params["STAT_W"])
    else:
        schema["level"] = (10, lw)
        for k in ("accepted", "retired", "aborted"):
            schema["stat_" + k] = (10, params["STAT_W"])
    return schema


def _parse_trace_row(line: str, marker: str, schema: dict, case: str):
    # Unknown spellings are retained, never converted to zero. Whether a value
    # must be known is decided by the semantic bootstrap/validity policy.
    body = line[len(marker) + 1:]
    pairs = body.split()
    if " ".join(pairs) != body or len(pairs) != len(schema):
        raise ValueError("malformed trace field count/spacing")
    row = {}
    for token in pairs:
        match = re.fullmatch(r"([A-Za-z_][A-Za-z0-9_]*)=([^\s=]+)", token, re.ASCII)
        if not match:
            raise ValueError("malformed trace token")
        key, word = match.groups()
        if key not in schema or key in row:
            raise ValueError("unknown/duplicate trace field " + key)
        base, width = schema[key]
        if base == 0:
            value = word
        elif re.fullmatch(r"[xXzZ]+" if base != 16 else r"[0-9a-fA-FxXzZ]+", word, re.ASCII) and re.search("[xXzZ]", word):
            if width is not None and len(word) > ((width + 3) // 4 if base == 16 else width):
                raise ValueError("oversized unknown trace word " + key)
            value = word.lower()
        else:
            pattern = {2: r"[01]+", 10: r"[0-9]+", 16: r"[0-9a-fA-F]+"}[base]
            if not re.fullmatch(pattern, word, re.ASCII):
                raise ValueError("invalid numeric trace field " + key)
            if width is not None and base in (2, 16) and len(word) > (width if base == 2 else (width + 3) // 4):
                raise ValueError("oversized trace encoding " + key)
            value = int(word, base)
            if width is not None and value >= 1 << width:
                raise ValueError("out-of-width trace field " + key)
        row[key] = value
    if set(row) != set(schema) or row["case"] != case:
        raise ValueError("trace field/case identity mismatch")
    return row


def _known(row: dict, keys):
    for key in keys:
        if type(row[key]) is not int:
            raise ValueError("unknown driven field " + key)


def _new_collector(armed=0, tag=0):
    return {"armed": armed, "tag": tag, "next_seq": 0, "exhausted": 0,
            "partial": [], "slot": None, "counts": dict.fromkeys(_C_COUNT_FIELDS, 0),
            "order_event": 0, "overrun_event": 0, "exhaust_event": 0}


def _advance_collector(c: dict, row: dict, retire: bool, params: dict):
    if row["rst"] or row["stop"] or row["rearm"]:
        return _new_collector(int(not row["rst"] and not row["stop"] and row["rearm"]), row["rearm_tag"] if not row["rst"] and not row["stop"] and row["rearm"] else 0)
    # Retire the old slot independently of a possible new completed scan.
    old_slot = c["slot"]
    if retire:
        c["slot"] = None
        c["counts"]["retired"] += 1
    for key in ("order_event", "overrun_event", "exhaust_event"):
        c[key] = 0
    if not (c["armed"] and row["sample_strobe"]):
        return c
    _known(row, ("sample_data", "sample_tick", "sample_quality", "sample_channel"))
    counts = c["counts"]
    counts["events"] += 1
    ordinal = c["next_seq"]
    event = (row["sample_data"], row["sample_tick"], row["sample_quality"], ordinal)
    channel = row["sample_channel"]
    if channel == len(c["partial"]):
        c["partial"].append(event)
    else:
        c["order_event"] = 1
        counts["order_errors"] += 1
        counts["discarded"] += len(c["partial"]) + (0 if channel == 0 else 1)
        c["partial"] = [event] if channel == 0 else []
    if len(c["partial"]) == 4:
        counts["scans"] += 1
        record = tuple(sum(e[lane] << (i * width) for i, e in enumerate(c["partial"])) for lane, width in ((0, 16), (1, params["TICK_W"]), (2, 8)))
        record += (c["partial"][0][3], ordinal, c["tag"])
        if old_slot is not None and not retire:
            counts["overruns"] += 1
            counts["discarded"] += 4
            c["overrun_event"] = 1
        else:
            c["slot"] = record
        c["partial"] = []
    if ordinal == (1 << params["SEQ_W"]) - 1:
        c["exhaust_event"] = 1
        c["armed"] = 0
        c["exhausted"] = 1
        counts["discarded"] += len(c["partial"])
        c["partial"] = []
    else:
        c["next_seq"] += 1
    return c


def _trace_history(rows: dict, marker: str, stats: dict, params: dict, *, mutant=False):
    result = {"reasons": [], "differences": [], "difference_count": 0,
              "numeric_counterexamples": set(), "metrics": {}, "source": "parsed input/control history; ref_* ignored"}
    reasons = result["reasons"]
    composition = marker == "RAW_SCAN_COMP_TRACE"
    try:
        schema = _trace_schema(params, composition)
        trace = rows[marker]
        if type(stats["cycles"]) is not int or stats["cycles"] <= 0 or len(trace) != 2 * stats["cycles"]:
            raise ValueError("trace row multiplicity/cycle mismatch")
        inputs = (("rst", "stop", "rearm", "rearm_tag", "sample_strobe", "sample_channel", "sample_data", "sample_tick", "sample_quality", "consumer_ready") if composition else ("rst", "cancel", "in_valid", "out_ready") + tuple("in_" + k for k in _RECORD_FIELDS))
        controls = ("rst", "stop", "rearm", "sample_strobe", "sample_channel", "consumer_ready") if composition else ("rst", "cancel", "in_valid", "out_ready")
        q = []
        counts = dict.fromkeys(("accepted", "retired", "aborted"), 0)
        c = _new_collector()
        initialized = False
        sat = (1 << params["STAT_W"]) - 1
        resets = cancels = 0
        hold = hold_best = 0
        segment = segment_best = (0, 0, 0)  # length, admissions, retirements

        def compare(row, key, expected, cycle, side):
            actual = row[key]
            if actual == expected:
                return
            result["difference_count"] += 1
            if len(result["differences"]) < 32:
                result["differences"].append({"cycle": cycle, "side": side, "field": key, "expected": expected, "actual": actual})
            if type(actual) is int:
                result["numeric_counterexamples"].add((key, expected, actual))

        def observe(row, cycle, side):
            abort = bool(row["rst"] or (row["stop"] or row["rearm"] if composition else row["cancel"]))
            if not initialized:
                if abort:
                    for k in (("q_in_ready", "q_out_valid", "c_out_valid") if composition else ("in_ready", "out_valid")):
                        compare(row, k, 0, cycle, side)
                return
            qp = "q_" if composition else ""
            compare(row, "q_in_ready" if composition else "in_ready", int(not abort and len(q) < params["DEPTH"]), cycle, side)
            compare(row, qp + "out_valid", int(not abort and bool(q)), cycle, side)
            compare(row, qp + "level", len(q), cycle, side)
            for key in counts:
                compare(row, ("q_" if composition else "stat_") + key, min(counts[key], sat), cycle, side)
            if q and not abort:
                for key, value in zip(_RECORD_FIELDS, q[0]):
                    compare(row, qp + "out_" + key, value, cycle, side)
            if composition:
                compare(row, "q_out_ready", row["consumer_ready"], cycle, side)
                compare(row, "c_out_valid", int(not abort and c["slot"] is not None), cycle, side)
                for key in ("armed", "next_seq", "exhausted", "order_event", "overrun_event", "exhaust_event"):
                    compare(row, "c_" + key, c[key], cycle, side)
                compare(row, "c_partial_len", len(c["partial"]), cycle, side)
                for key in _C_COUNT_FIELDS:
                    compare(row, "c_" + key, min(c["counts"][key], sat), cycle, side)
                if c["slot"] is not None and not abort:
                    for key, value in zip(_RECORD_FIELDS, c["slot"]):
                        compare(row, "c_out_" + key, value, cycle, side)

        def final_stat(key, expected):
            if stats[key] != expected:
                reasons.append(f"history stat {key}: expected {expected!r}, actual {stats[key]!r}")

        for index in range(stats["cycles"]):
            pre, post = [_parse_trace_row(trace[2 * index + offset], marker, schema, stats["case"]) for offset in (0, 1)]
            if (pre["side"], pre["cycle"], post["side"], post["cycle"]) != ("pre", index, "post", index + 1):
                raise ValueError("trace phase/cycle ordering mismatch")
            if any(pre[k] != post[k] for k in inputs):
                raise ValueError("driven input changed within edge pair")
            _known(pre, controls)
            if composition and pre["rearm"] and not (pre["rst"] or pre["stop"]):
                _known(pre, ("rearm_tag",))
            abort = bool(pre["rst"] or (pre["stop"] or pre["rearm"] if composition else pre["cancel"]))
            if not composition and pre["in_valid"] and not abort:
                _known(pre, tuple("in_" + k for k in _RECORD_FIELDS))
            observe(pre, index, "pre")
            resets += pre["rst"]
            if not composition:
                cancels += pre["cancel"]
            if pre["rst"]:
                q = []
                counts = dict.fromkeys(counts, 0)
                c = _new_collector()
                initialized = True
                hold = 0
                segment = (0, 0, 0)
            elif initialized:
                if abort:
                    counts["aborted"] += len(q)
                    q = []
                    hold = 0
                    segment = (0, 0, 0)
                else:
                    oldlevel = len(q)
                    incoming = c["slot"] if composition else tuple(pre["in_" + k] for k in _RECORD_FIELDS)
                    offer = incoming is not None if composition else bool(pre["in_valid"])
                    push = offer and oldlevel < params["DEPTH"]
                    pop = oldlevel > 0 and bool(pre["consumer_ready"] if composition else pre["out_ready"])
                    if pop:
                        q.pop(0)
                        counts["retired"] += 1
                    if push:
                        q.append(incoming)
                        counts["accepted"] += 1
                    if not composition:
                        eligible = not pre["in_valid"] and not pre["out_ready"] and oldlevel > 0
                        hold = hold + 1 if eligible else 0
                        hold_best = max(hold_best, hold)
                        if pre["in_valid"] and pre["out_ready"]:
                            segment = (segment[0] + 1, segment[1] + int(push), segment[2] + int(pop))
                            if segment[0] > segment_best[0]:
                                segment_best = segment
                        else:
                            segment = (0, 0, 0)
                if composition:
                    # The queue transfer was decided from the old slot and old
                    # occupancy. Abort clears its window before any sample.
                    c = _advance_collector(c, pre, False if abort else push, params)
            observe(post, index + 1, "post")
        if not initialized:
            raise ValueError("trace has no applied reset anchor")
        if not composition:
            for key in counts:
                final_stat("true_" + key, counts[key])
                final_stat(key, post["stat_" + key] if mutant else min(counts[key], sat))
            final_stat("level", post["level"] if mutant else len(q))
            metrics = {"resets": resets, "cancels": cancels, "stalls": hold_best,
                       "wrap_writes": segment_best[1] // params["DEPTH"],
                       "wrap_reads": segment_best[2] // params["DEPTH"]}
            for key, value in metrics.items():
                final_stat(key, value)
            result["metrics"] = dict(metrics, selected_transfer_segment=segment_best)
            if stats["case"] != "guard_healthy" and (hold_best < 4096 or min(metrics["wrap_writes"], metrics["wrap_reads"]) < 1000):
                reasons.append("derived coverage below directed-suite minimum")
        else:
            for key in counts:
                final_stat("q_true_" + key, counts[key])
                final_stat("q_" + key, min(counts[key], sat))
            final_stat("q_level", len(q))
            for key in _C_COUNT_FIELDS:
                final_stat("c_true_" + key, c["counts"][key])
                final_stat("c_" + key, min(c["counts"][key], sat))
            for key in ("armed", "exhausted"):
                final_stat("c_" + key, c[key])
            final_stat("c_partial_len", len(c["partial"]))
            final_stat("c_occupied", int(c["slot"] is not None))
        if result["difference_count"] and not mutant:
            reasons.append(f"public history mismatch: {result['difference_count']} observations")
    except (ValueError, KeyError, TypeError, IndexError) as exc:
        reasons.append("invalid trace/history: " + str(exc))
    return result


def _history_report(history):
    # Keep an auditable bounded example list; full raw traces remain in receipts.
    report = dict(history)
    values = sorted(report.pop("numeric_counterexamples"))
    report["numeric_counterexample_count"] = len(values)
    report["numeric_counterexamples_sha256"] = hashlib.sha256(json.dumps(values, separators=(",", ":")).encode()).hexdigest()
    report["numeric_counterexample_samples"] = values[:32]
    return report
