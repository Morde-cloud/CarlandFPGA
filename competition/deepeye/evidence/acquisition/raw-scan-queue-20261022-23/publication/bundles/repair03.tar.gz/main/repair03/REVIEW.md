# Repair03 local parser qualification

Status: REPAIR03_READY_FOR_REVIEW. Main-authored correction, independent coordinator acceptance pending. No publication.

The runner now rejects known set bits above a hexadecimal field's width even when another nibble is X/Z. It retains the existing symbolic spelling/lowercase normalization and legality of unknown top padding. Exactly six lines were added within `_parse_trace_row`; the remaining module AST and normalized source are identical. Documentation only appends this boundary. RTL, author TB, collector, protected codec and six cancelled-audit files are unchanged.

Frozen before the edit: 45,412 per-nibble bit-position properties covering every supported ordinal2..32 and tag/tick1..64 width, both upper/lower X/Z, symbolic preservation, all-known overflow and full64-bit values. The old source falsely accepts23,504; the new source matches all45,412. There are no new false rejects. Five exact coordinator fixtures pass direct and real CLI expectations; both2x/2z corruptions reject and genuine/1x/x1 controls pass.

The existing58 frozen inputs also pass direct and actual CLI classification, including active-unknown rejection. Three actual normal-main composition processes use unchanged main/run_case/aggregation with a frozen synthetic vendor-process seam: genuine exits0, collector corruption exits1, queue corruption exits1. Fifteen actual Python emitter subprocesses (30 raw streams) preserve their intended vendor argv separately. No vendor executable ran. These are parser/process qualifications of saved transcripts, not new simulation or an RTL failure finding.

Rehashed all7,216 selected old evidence files without mutation. Checked66 CLI/main process receipts and their raw streams, all frozen new inputs, and exact six-line code diff. Prior30-case baseline, repair01 failures, repair02 alias false negative and all historical receipts remain intact. No old08–22 suite or ModelSim replay occurred.

Runner SHA256: 9a06a7a368313dc96b6941fdaa8dfc4bcda27ed426bf5e75e00e2a1072b39996
Document SHA256: 57f81585986e785277a4b5ecceebc6720fe5dfac341b68f368e9d731506b3ee9
Source diff SHA256: 68325a31265361ec8f8e8da2840d38b9bbea8c5e923ef4f81576eb4fe1f8b9a3
Expectation freeze SHA256: 045706bdd5a757ca10af0c6302503c800a2b0e3181e165ee4bb90618491686de
Prior product HEAD: 94571d2cd9a68bd030c878c406f19a1be6ec53d7; no new commit/request hash/PR feedback.

H01–H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 canonical SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 and design1011259415a0916054eb580687612580bc1e5f09 unchanged. All29/B02/B03/G05/B06/R03/full-product simulation/synthesis/implementation/timing/CDC_RDC/board/system remain not_run. Physical board A-only. No ABI, source/clock, freshness, DMA/PS, ENABLE or motion authority is granted.
