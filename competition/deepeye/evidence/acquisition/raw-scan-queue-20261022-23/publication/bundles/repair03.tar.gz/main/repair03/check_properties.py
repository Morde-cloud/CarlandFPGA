"""Evaluate frozen width cases against the provided exact source."""
from common import *
import re
path=Path(sys.argv[1]); label=sys.argv[2]; r=load_runner(path)
base=json.loads((N/'PROPERTY_BASE.json').read_bytes()); props=json.loads((N/'PROPERTY_CASES.json').read_bytes())['cases']; rows=[]
for i,c in enumerate(props):
    params=dict(base['params']); params[c['param']]=c['width']
    line=re.sub(r'(?<!\S)'+re.escape(c['field'])+r'=\S+',c['field']+'='+c['word'],base['line'])
    try:
        actual=r._parse_trace_row(line,base['marker'],r._trace_schema(params,True),base['case']); ok=True; error=None; value=actual[c['field']]
    except ValueError as e: ok=False; error=str(e); value=None
    preserved=not ok or (value==c['word'].lower() and type(value) is str if c['symbolic'] else type(value) is int and value==int(c['word'],16))
    rows.append(dict(index=i,actual_ok=ok,match=ok==c['expected_ok'] and preserved,symbolic_preserved=preserved,error=error))
result=dict(source=str(path),source_sha256=sha(path),properties_sha256=sha(N/'PROPERTY_CASES.json'),total=len(rows),matched=sum(c['match'] for c in rows),false_accepts=sum(c['actual_ok'] and not props[c['index']]['expected_ok'] for c in rows),false_rejects=sum(not c['actual_ok'] and props[c['index']]['expected_ok'] for c in rows),rows=rows)
save(N/(label+'.json'),result); print(json.dumps({k:v for k,v in result.items() if k!='rows'}))
raise SystemExit(0 if result['matched']==result['total'] else 2)
