"""Owned repair03 evidence helpers; not product imports or a hardware oracle."""
import hashlib, importlib.util, json, sys
from pathlib import Path
from datetime import datetime, timezone
N=Path(__file__).resolve().parent; M=N.parent; N2=M/'repair02'
R=Path('D:/pynq/CarlandFPGA'); W=R/'.local/worktrees/deepeye-implementation-20261014'
O=R/'.local/deployment/node-b/evidence/raw-scan-queue-20261022-23'; P=O/'repair03'
C=R/'.local/deployment/node-b/evidence/main-continuation-20261019-v1/raw-scan-queue-20261022-23/repair02-review'
Q=N/'qualification'; RUNNER=W/'competition/deepeye/tools/acquisition/run_raw_scan_queue.py'
DOC=W/'competition/deepeye/fpga/acquisition/raw_scan_queue_candidate.md'
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def stamp(): return datetime.now(timezone.utc).isoformat()
def save(p,obj):
    p=Path(p); assert p.resolve().is_relative_to(N) or p.resolve().is_relative_to(P)
    p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x',encoding='utf-8',newline='\n') as f: json.dump(obj,f,ensure_ascii=False,indent=2); f.write('\n')
def copy(src,dst):
    dst=Path(dst); assert dst.resolve().is_relative_to(N)
    dst.parent.mkdir(parents=True,exist_ok=True)
    with dst.open('xb') as f: f.write(Path(src).read_bytes())
    assert sha(src)==sha(dst)
def load_runner(path):
    s=importlib.util.spec_from_file_location('repair03_candidate',path); r=importlib.util.module_from_spec(s); s.loader.exec_module(r); return r
def classify(r,p):
    s=json.loads(p.read_bytes()); a=s['args']; mode=s['mode']
    out=(p.parent/s['stdout']).read_text(encoding='utf-8'); err=(p.parent/s['stderr']).read_text(encoding='utf-8')
    if mode in ('queue','healthy'): return r.classify_queue_output(a['sim_exit'],out,err,a['expected_case'],a['params'],healthy=mode=='healthy')
    if mode=='composition': return r.classify_composition_output(a['sim_exit'],out,err,a['expected_case'],a['params'])
    if mode=='guard': return r.classify_guard_output(a['compile_exit'],'# Errors: 0, Warnings: 0\n','',a['sim_exit'],out,err,a['family'],r.FATAL_MESSAGES[a['family']])
    return r.classify_mutant_output(a['compile_exit'],'# Errors: 0, Warnings: 0\n','',a['sim_exit'],out,err,a['expected_case'],a['params'],[tuple(x) for x in a['required']])
