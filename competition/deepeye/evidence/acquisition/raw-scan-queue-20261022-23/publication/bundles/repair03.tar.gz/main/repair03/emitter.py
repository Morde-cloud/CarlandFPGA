"""Synthetic vendor-seam process, never a vendor result."""
import sys,time
from pathlib import Path
sys.stdout.buffer.write(Path(sys.argv[1]).read_bytes());sys.stdout.buffer.flush()
if sys.argv[2]=='timeout':time.sleep(5)
raise SystemExit(9 if sys.argv[2]=='nonzero' else 0)
