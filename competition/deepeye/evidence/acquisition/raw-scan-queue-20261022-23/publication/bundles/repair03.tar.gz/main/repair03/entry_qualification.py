"""Unchanged product main/run_case/aggregation; real Python emitter process seam."""
from common import *
import tempfile
matrix=json.loads((Q/'MATRIX.json').read_bytes()); binding=json.loads((Q/'EXECUTION_BINDING.json').read_bytes())
cfg=next(x for x in matrix['entry_cases'] if x['name']==sys.argv[1]); r=load_runner(RUNNER)
assert sha(RUNNER)==binding['runner_sha256']; assert Path(tempfile.gettempdir()).resolve().is_relative_to(N)
actual=r._run_hidden; serial=0
def vendor_seam(argv,cwd,timeout,env):
    global serial
    serial+=1; name=Path(argv[0]).stem
    if '-version' in argv: data=(Q/(name+'-version.txt')).read_bytes()
    elif name=='vlib': data=b''
    elif name=='vlog': data=b'# Errors: 0, Warnings: 0\n'
    else:
        assert name=='vsim'; data=(Q/'fixtures'/cfg['stream_case']/'stdout.txt').read_bytes()
    p=cwd/f'synthetic-emission-{serial:02}.bin'
    with p.open('xb') as f: f.write(data)
    executed=[sys.executable,'-B','-X','utf8',str(N/'emitter.py'),str(p),'normal']
    receipt=actual(executed,cwd,10,env)
    receipt.update(synthetic_vendor_seam=True,vendor_intended_argv=argv,vendor_intended_timeout=timeout,actual_emitter_sha256=sha(N/'emitter.py'),actual_timeout_seconds=10)
    return receipt
r._run_hidden=vendor_seam
raise SystemExit(r.main(['--root',str(Q/'root'),'--out',str(Q/'entries'/cfg['name']/'run'),'--modelsim','D:/modelsim1/win64','--modelsim-ini',str(Q/'modelsim.ini'),'--containment-root',str(N),'--case',cfg['case']]))
