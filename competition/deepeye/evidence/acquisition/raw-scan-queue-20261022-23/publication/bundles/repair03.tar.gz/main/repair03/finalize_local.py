"""Seal completed local evidence; current finalizer/callback logs are separate."""
from common import *
decision=json.loads((N/'REVIEW_DECISION.json').read_bytes())
assert decision['status']=='REPAIR03_READY_FOR_REVIEW' and decision['source_sha256']==sha(RUNNER)
assert json.loads((P/'seal-review.process.json').read_text(encoding='utf-8-sig'))['exit']==0
files=[]
for root in (N,P):
    for p in sorted(root.rglob('*')):
        if not p.is_file() or any(x in ('tmp','work','cache','__pycache__') for x in p.relative_to(root).parts):continue
        if p.name in ('LOCAL_REVIEW_MANIFEST.json','FINAL_RECEIPT.json','CALLBACK_INTENT.json','CALLBACK_RESULT.json','finalize-local.stdout.txt','finalize-local.stderr.txt','finalize-local.process.json'):continue
        files.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
manifest=dict(at_utc=stamp(),status='local_unpublished_pending_independent_review',files=files,count=len(files),exclusions=['derived tmp/work/cache/__pycache__','self-referential manifest/final receipt','current finalizer stdout/stderr/process and later App callback receipts are separately retained'],source_sha256=sha(RUNNER),doc_sha256=sha(DOC),source_diff_sha256=sha(N/'final-source/source.diff'),expectation_freeze_sha256=sha(N/'EXPECTATION_FREEZE.json'),operation_id=decision['operation_id'],work_id=decision['work_id'])
save(N/'LOCAL_REVIEW_MANIFEST.json',manifest)
for f in files:assert sha(f['path'])==f['sha256']
receipt=dict(at_utc=stamp(),status=decision['status'],task_id=decision['task_id'],task_version=1,operation_id=decision['operation_id'],work_id=decision['work_id'],self=decision['self'],main_role='existing B sole product main; direct narrow repair; no additional executor',requirements_sha256=decision['requirements_sha256'],design=decision['design'],prior_head=decision['git']['head'],new_commit=None,public_request_hash=None,source_sha256=sha(RUNNER),doc_sha256=sha(DOC),diff_path=str(N/'final-source/source.diff'),diff_sha256=sha(N/'final-source/source.diff'),freeze_sha256=sha(N/'EXPECTATION_FREEZE.json'),decision_sha256=sha(N/'REVIEW_DECISION.json'),manifest_path=str(N/'LOCAL_REVIEW_MANIFEST.json'),manifest_sha256=sha(N/'LOCAL_REVIEW_MANIFEST.json'),manifest_files=len(files),report_path=str(N/'REVIEW.md'),bounded_results={'width_properties':45412,'old_false_accepts_preserved':23504,'new_false_accepts':0,'new_false_rejects':0,'original_cases_direct_and_real_cli':58,'coordinator_cases_direct_and_real_cli':5,'normal_main_composition_exits':[0,1,1],'real_python_emitter_invocations':15,'new_vendor_runs':0,'historical_files_unchanged':7216},not_run=decision['not_run'],coordinator='01a154de-abd8-7590-b9a3-2819249458e3',next='one local App return; independent coordinator review required; no publication or next increment',unknown_creation_side_effects=False,publication_performed=False)
save(P/'FINAL_RECEIPT.json',receipt)
assert json.loads((P/'FINAL_RECEIPT.json').read_bytes())['manifest_sha256']==sha(N/'LOCAL_REVIEW_MANIFEST.json')
print(json.dumps(dict(status=receipt['status'],receipt_path=str(P/'FINAL_RECEIPT.json'),receipt_sha256=sha(P/'FINAL_RECEIPT.json'),manifest_path=str(N/'LOCAL_REVIEW_MANIFEST.json'),manifest_sha256=sha(N/'LOCAL_REVIEW_MANIFEST.json'),manifest_files=len(files),source_sha256=sha(RUNNER),doc_sha256=sha(DOC),diff_sha256=sha(N/'final-source/source.diff'),freeze_sha256=sha(N/'EXPECTATION_FREEZE.json'))))
