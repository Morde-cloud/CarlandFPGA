"""Freeze expectations before canonical repair, preserving exact old inputs."""
from common import *
import re
assert sha(RUNNER)=='52f0cb0430ae43ce04ef1247fce63c0a44a27ed5a745dffedd2f3d1134056057'
assert sha(DOC)=='392edfdab0798fa8b7004acfb803d5326050f9e0246e97f6dd59d715b1405806'
pins={'REPAIR02_CONSUMED.json':'0ef7bcfb57e2337201a15062b5f5e60cb74b8bb7fcdc5f030802c7dfbc3c66fd','REPAIR02_REVIEW_DECISION.json':'9ba59f8d9f0c64fcf58c504ebd726a8d11e9950d0fe64dd07988a3083b5d7a29','REPAIR03_SCOPE.md':'8591704f0559770ebfb176ca11520651c0db0d49e53228b7b594f74baed4c952','padding-probe/EXPECTATIONS.json':'a7d6042212cfe101c019f72b28a515ec4f92fb77de18ebcd8dd7ca5416ecac4a','padding-probe/RESULT.json':'754e3b21177371858f8179feb85135fa6e742ea3ef79a5ec8358ef8a6cc9256f'}
for rel,h in pins.items(): assert sha(C/rel)==h
contract=json.loads((O/'inputs/immutable_scope.json').read_bytes())
contract_hash=hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
assert contract_hash=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
binding=json.loads((N2/'qualification-final/EXECUTION_BINDING.json').read_bytes())
protected={str(W/rel):h for rel,h in binding['corrected_sources'].items()}
protected[str(W/'competition/deepeye/fpga/acquisition/deepeye_sample_scan_capture.sv')]='fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d'
protected[str(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')]='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
old_audit=json.loads((O/'FREEZE_CHECKS.json').read_bytes())['old_audit_files']
for item in old_audit:
    protected[item['path']]=item['sha256']
for p,h in protected.items(): assert sha(p)==h, p
copy(RUNNER,N/'snapshots/run_raw_scan_queue.py'); copy(DOC,N/'snapshots/raw_scan_queue_candidate.md')
cases=[]
old_matrix=json.loads((N2/'qualification-final/MATRIX.json').read_bytes())
for c in old_matrix['cases']:
    orig=N2/'qualification-final'/c['spec']; dst=Q/'fixtures'/c['name']
    spec=json.loads(orig.read_bytes())
    for name in ('spec.json',spec['stdout'],spec['stderr']): copy(orig.parent/name,dst/name)
    cases.append(dict(name=c['name'],expected_ok=c['expected_ok'],spec=str((dst/'spec.json').relative_to(Q)),origin=str(orig),group='frozen58',reason=c['reason']))
assert len(cases)==58
exp=json.loads((C/'padding-probe/EXPECTATIONS.json').read_bytes())
for c in exp['cases']:
    orig=C/'padding-probe'/c['name']; dst=Q/'fixtures'/('padding_'+c['name'])
    for name in ('spec.json','stdout.txt','stderr.txt'): copy(orig/name,dst/name)
    assert sha(dst/'stdout.txt')==c['stdout_sha256'] and sha(dst/'spec.json')==c['spec_sha256']
    cases.append(dict(name='padding_'+c['name'],expected_ok=c['expected_ok'],spec=str((dst/'spec.json').relative_to(Q)),origin=str(orig/'spec.json'),group='coordinator5',reason=exp['reason']))
entries=[dict(name='composition_'+c['name'],stream_case='padding_'+c['name'],expected_exit=0 if c['expected_ok'] else 1,case='comp_d1') for c in exp['cases'][:3]]
save(Q/'MATRIX.json',dict(at_utc=stamp(),cases=cases,entry_cases=entries,classification='changed-runner parser qualification; no new simulation'))
for name in ('vlog-version.txt','vsim-version.txt'): copy(N2/'qualification-final'/name,Q/name)
copy(N2/'emitter.py',N/'emitter.py')
copy(M.parent/'author/config/modelsim.ini',Q/'modelsim.ini')
r=load_runner(RUNNER)
for rel in (r.RTL_RELATIVE,r.TB_RELATIVE,r.COLLECTOR_RELATIVE): copy(W/rel,Q/'root'/rel)
# Expectations are derived by inspecting each known hexadecimal nibble's bits,
# independent of the product's numeric minimum/mask implementation.
def allowed(word,width):
    if len(word)>(width+3)//4: return False
    for pos,d in enumerate(reversed(word)):
        if d in 'xXzZ': continue
        bits=format(int(d,16),'04b')[::-1]
        if any(bit=='1' and pos*4+j>=width for j,bit in enumerate(bits)): return False
    return True
props=[]
fields=[('c_out_first_seq','SEQ_W',2,32),('q_out_last_seq','SEQ_W',2,32),('c_out_tag','TAG_W',1,64),('q_out_tag','TAG_W',1,64),('sample_tick','TICK_W',1,64)]
for field,param,lo,hi in fields:
    for width in range(lo,hi+1):
        digits=(width+3)//4
        words={'0',format((1<<width)-1,'x'),format(1<<width,'x')}
        words.update({'x','X','z','Z'})
        for u in 'xXzZ':
            words.update({u+'f'*(digits-1),u+'0'*(digits-1),u*digits,u*(digits+1)})
            if digits>1:
                for d in '0123456789abcdefABCDEF':
                    words.add(d+'0'*(digits-2)+u)
                    words.add(d+u+'f'*(digits-2))
        for word in sorted(words): props.append(dict(field=field,param=param,width=width,word=word,expected_ok=allowed(word,width),symbolic=bool(re.search('[xXzZ]',word))))
# Explicit complete 64-bit payload controls, alongside tag/tick at64 above.
for field in ('c_out_data','q_out_data'):
    for word in ('ffffffffffffffff','FFFFFFFFFFFFFFFF','10000000000000000','Xfffffffffffffff','f00000000000000Z'):
        props.append(dict(field=field,param='TAG_W',width=64,word=word,expected_ok=allowed(word,64),symbolic=bool(re.search('[xXzZ]',word))))
save(N/'PROPERTY_CASES.json',dict(reference='per-known-nibble bit positions, never unknown-to-zero expected-value conversion',cases=props))
base=next(s[2:] for s in (C/'padding-probe/genuine_control/stdout.txt').read_text(encoding='utf-8').splitlines() if s.startswith('# RAW_SCAN_COMP_TRACE side=post') and ' cycle=1 ' in s)
save(N/'PROPERTY_BASE.json',dict(line=base,marker='RAW_SCAN_COMP_TRACE',case='comp_basic',params=json.loads((C/'padding-probe/genuine_control/spec.json').read_bytes())['args']['params']))
# Snapshot the old evidence trees' bytes; no old execution or output rewrite.
history=[]
for root in (M.parent/'author',M,O,C):
    for p in sorted(root.rglob('*')):
        if not p.is_file() or p.is_relative_to(N) or p.is_relative_to(P): continue
        if any(x in ('tmp','work','__pycache__') for x in p.relative_to(root).parts): continue
        history.append(dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p)))
history=list({x['path']:x for x in history}.values())
save(N/'HISTORICAL_INPUTS.json',history)
files=[dict(path=str(p),sha256=sha(p),bytes=p.stat().st_size) for p in sorted(N.rglob('*')) if p.is_file() and 'tmp' not in p.relative_to(N).parts]
save(N/'EXPECTATION_FREEZE.json',dict(at_utc=stamp(),pre_edit_runner_sha256=sha(RUNNER),requirements_sha256=contract_hash,contract_h01_h15_unchanged=True,properties=len(props),coordinator_cases=5,frozen_cases=58,normal_main_entries=entries,files=files,protected=protected,coordinator_pins=pins,historical_files=len(history),not_simulation=True,mutation_scope='known-bit width check only; doc semantics',main_work='B-RAW-SCAN-QUEUE-UNKNOWN-WIDTH-RECOVERY-20261022-23-v1'))
print(json.dumps(dict(freeze_sha256=sha(N/'EXPECTATION_FREEZE.json'),property_cases=len(props),historical_files=len(history),frozen_cases=len(cases))))
