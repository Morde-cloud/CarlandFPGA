"""Changed-runner reclassification of frozen captures, not new RTL execution."""
from common import *
sys.path.insert(0,str(M)); from process23 import run
freeze=json.loads((N/'EXPECTATION_FREEZE.json').read_bytes())
for row in freeze['files']: assert sha(row['path'])==row['sha256'],row['path']
save(Q/'EXECUTION_BINDING.json',dict(at_utc=stamp(),runner_sha256=sha(RUNNER),freeze_sha256=sha(N/'EXPECTATION_FREEZE.json'),scripts={str(N/n):sha(N/n) for n in ('common.py','qualify.py','entry_qualification.py','emitter.py')},history_source_binding='Original captures stay bound to original execution sources; these are new parser outcomes only'))
r=load_runner(RUNNER); matrix=json.loads((Q/'MATRIX.json').read_bytes()); rows=[]
for c in matrix['cases']:
    p=Q/c['spec']; direct=classify(r,p); save(p.parent/'direct.json',direct)
    proc=run([sys.executable,'-B','-X','utf8',RUNNER,'--verify-transcript',p],p.parent,'actual-cli',60,[dict(path=str(RUNNER),sha256=sha(RUNNER)),dict(path=str(p),sha256=sha(p))])
    actual=json.loads((p.parent/'spec.result.json').read_bytes())
    row=dict(name=c['name'],group=c['group'],expected_ok=c['expected_ok'],direct_ok=direct['ok'],actual_cli_ok=actual['ok'],actual_exit=proc['exit'],match=direct['ok']==c['expected_ok'] and actual['ok']==c['expected_ok'] and proc['exit']==(0 if c['expected_ok'] else 1) and not proc['timed_out'])
    rows.append(row)
entries=[]
for c in matrix['entry_cases']:
    d=Q/'entries'/c['name']; d.mkdir(parents=True)
    proc=run([sys.executable,'-B','-X','utf8',N/'entry_qualification.py',c['name']],d,'main-process',60,[dict(path=str(RUNNER),sha256=sha(RUNNER)),dict(path=str(N/'entry_qualification.py'),sha256=sha(N/'entry_qualification.py'))])
    path=d/'run/summary.json'; summary=json.loads(path.read_bytes()) if path.exists() else None
    entries.append(dict(name=c['name'],expected_exit=c['expected_exit'],actual_exit=proc['exit'],summary_ok=summary and summary['ok'],match=proc['exit']==c['expected_exit'] and not proc['timed_out'] and summary is not None and summary['ok']==(c['expected_exit']==0)))
result=dict(runner_sha256=sha(RUNNER),direct_and_cli=rows,normal_main_entries=entries,pass_all=all(x['match'] for x in rows+entries),actual_vendor_runs=0,synthetic_vendor_seam=True)
save(Q/'RESULT.json',result)
print(json.dumps(dict(pass_all=result['pass_all'],cases=len(rows),matched=sum(x['match'] for x in rows),entries=entries)))
raise SystemExit(0 if result['pass_all'] else 2)
