"""Main byte/provenance review for the narrow local parser repair."""
from common import *
import ast, collections, difflib, gzip, shutil
sys.path.insert(0,str(M)); from process23 import run
freeze=json.loads((N/'EXPECTATION_FREEZE.json').read_bytes())
for row in freeze['files']: assert sha(row['path'])==row['sha256'],row['path']
history=json.loads((N/'HISTORICAL_INPUTS.json').read_bytes())
for row in history: assert sha(row['path'])==row['sha256'],row['path']
for p,h in freeze['protected'].items():
    if Path(p) not in (RUNNER,DOC): assert sha(p)==h,p
old=(N/'snapshots/run_raw_scan_queue.py').read_text(encoding='utf-8'); new=RUNNER.read_text(encoding='utf-8')
oldt=ast.parse(old); newt=ast.parse(new)
oldfuncs={x.name:ast.dump(x,include_attributes=False) for x in oldt.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
newfuncs={x.name:ast.dump(x,include_attributes=False) for x in newt.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
changed=[k for k in oldfuncs if oldfuncs[k]!=newfuncs.get(k)]
assert changed==['_parse_trace_row'] and oldfuncs.keys()==newfuncs.keys()
for t in (oldt,newt): t.body=[x for x in t.body if not isinstance(x,ast.FunctionDef) or x.name!='_parse_trace_row']
assert ast.dump(oldt,include_attributes=False)==ast.dump(newt,include_attributes=False)
insertion='''            if base == 16 and width is not None:
                # The minimum value checks known padding bits only; keep X/Z
                # symbolic below so inactive/bootstrap semantics are unchanged.
                known_bits = int(re.sub(r"[xXzZ]", "0", word), 16)
                if known_bits >= 1 << width:
                    raise ValueError("out-of-width known trace bits " + key)
'''
assert new.count(insertion)==1 and new.replace(insertion,'')==old
old_doc=(N/'snapshots/raw_scan_queue_candidate.md').read_text(encoding='utf-8'); new_doc=DOC.read_text(encoding='utf-8'); assert new_doc.startswith(old_doc)
for src in (RUNNER,DOC): copy(src,N/'final-source'/src.name)
diff=''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='repair02/run_raw_scan_queue.py',tofile='repair03/run_raw_scan_queue.py'))
diff+=''.join(difflib.unified_diff(old_doc.splitlines(True),new_doc.splitlines(True),fromfile='repair02/raw_scan_queue_candidate.md',tofile='repair03/raw_scan_queue_candidate.md'))
with (N/'final-source/source.diff').open('x',encoding='utf-8',newline='\n') as f:f.write(diff)
red=json.loads((N/'PROPERTY_RED.json').read_bytes()); green=json.loads((N/'PROPERTY_GREEN.json').read_bytes()); props=json.loads((N/'PROPERTY_CASES.json').read_bytes())['cases']
assert red['false_accepts']==23504 and red['false_rejects']==0 and green['matched']==green['total']==len(props)==45412
assert green['source_sha256']==sha(RUNNER) and red['source_sha256']==sha(N/'snapshots/run_raw_scan_queue.py')
coverage={}
for field in sorted({x['field'] for x in props}):
    items=[x for x in props if x['field']==field]; coverage[field]=dict(cases=len(items),widths=sorted({x['width'] for x in items}),expected_valid=sum(x['expected_ok'] for x in items),expected_invalid=sum(not x['expected_ok'] for x in items),symbolic=sum(x['symbolic'] for x in items),uppercase_unknown=sum('X' in x['word'] or 'Z' in x['word'] for x in items),lowercase_unknown=sum('x' in x['word'] or 'z' in x['word'] for x in items))
result=json.loads((Q/'RESULT.json').read_bytes()); assert result['pass_all'] and result['runner_sha256']==sha(RUNNER)
rows=result['direct_and_cli']; assert len(rows)==63 and sum(x['group']=='frozen58' for x in rows)==58
assert [x['actual_exit'] for x in result['normal_main_entries']]==[0,1,1]
assert any('unknown' in x['name'] and x['expected_ok'] is False for x in rows)
processes=[]; invocations=[]; streams=0
for p in sorted(N.rglob('*.result.json')):
    r=json.loads(p.read_bytes())
    if not isinstance(r,dict) or 'stdout_path' not in r: continue
    for k in ('stdout','stderr'): assert sha(r[k+'_path'])==r[k+'_sha256']
    assert Path(r['cwd']).is_relative_to(N) and r['timed_out'] is False
    processes.append(dict(path=str(p),sha256=sha(p),exit=r['exit']))
assert len(processes)==66
for p in sorted(Q.rglob('*.invocation.json')):
    r=json.loads(p.read_bytes())
    assert r['synthetic_vendor_seam'] is True and Path(r['argv'][0]).name=='python.exe'
    assert r['actual_emitter_sha256']==sha(N/'emitter.py') and Path(r['cwd']).is_relative_to(N)
    assert r['exit']==0 and r['timed_out'] is False and r['exception_type'] is None
    assert Path(r['vendor_intended_argv'][0]).stem in ('vlog','vsim','vlib')
    for k,s in r['streams'].items():
        data=(p.parent/s['path']).read_bytes()
        if s['compressed']:
            assert hashlib.sha256(data).hexdigest()==s['compressed_sha256']
            data=gzip.decompress(data)
        assert hashlib.sha256(data).hexdigest()==s['sha256'] and len(data)==s['bytes']
        assert len(data.splitlines())==s['line_count']; streams+=1
    invocations.append(dict(path=str(p),sha256=sha(p),intended=r['vendor_intended_argv'],actual=r['argv']))
assert len(invocations)==15
# Read-only Git checks, retained as actual processes; no staging or publication.
git=shutil.which('git'); gitrows={}
for key,args in [('head',['rev-parse','HEAD']),('branch',['branch','--show-current']),('staged',['diff','--cached','--name-only']),('unmerged',['diff','--name-only','--diff-filter=U'])]:
    r=run([git,'-C',W,*args],N,'git-'+key,30); assert r['exit']==0; gitrows[key]=r['stdout_text'].strip()
assert gitrows['head']=='94571d2cd9a68bd030c878c406f19a1be6ec53d7'
assert gitrows['branch']=='codex/b/deepeye-implementation-20261014' and not gitrows['staged'] and not gitrows['unmerged']
decision=dict(at_utc=stamp(),status='REPAIR03_READY_FOR_REVIEW',task_id='DEEPEYE-IMPLEMENTATION-20261014',task_version=1,work_id='B-RAW-SCAN-QUEUE-UNKNOWN-WIDTH-RECOVERY-20261022-23-v1',operation_id='B-DEEPEYE-RAW-SCAN-QUEUE-20261022-23',self=json.loads((P/'CONSUMED.json').read_bytes())['self'],source_sha256=sha(RUNNER),doc_sha256=sha(DOC),diff_sha256=sha(N/'final-source/source.diff'),expectation_freeze_sha256=sha(N/'EXPECTATION_FREEZE.json'),historical_preserved=len(history),unchanged_readonly_canonical={p:h for p,h in freeze['protected'].items() if Path(p) not in (RUNNER,DOC)},only_changed_function=changed,property_summary=dict(total=45412,old_false_accepts=23504,new_false_accepts=0,new_false_rejects=0,coverage=coverage),frozen58_direct_cli_pass=True,coordinator5_direct_cli_pass=True,normal_main_entries=result['normal_main_entries'],process_receipts=processes,synthetic_vendor_invocations=invocations,expanded_streams_verified=streams,actual_vendor_runs=0,prior_rtl_baseline_rerun=False,git=gitrows,contract='DEEPEYE-HUMAN-LOCK-20261014/revision1',requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',design='1011259415a0916054eb580687612580bc1e5f09',not_run=['all29','B02','B03','G05','B06','R03','full_product_simulation','synthesis','implementation','timing','CDC_RDC','board','system'],public_request=None,new_commit=None,publication='none; local only; independent coordinator acceptance pending')
save(N/'REVIEW_DECISION.json',decision)
report=f'''# Repair03 local parser qualification

Status: REPAIR03_READY_FOR_REVIEW. Main-authored correction, independent coordinator acceptance pending. No publication.

The runner now rejects known set bits above a hexadecimal field's width even when another nibble is X/Z. It retains the existing symbolic spelling/lowercase normalization and legality of unknown top padding. Exactly six lines were added within `_parse_trace_row`; the remaining module AST and normalized source are identical. Documentation only appends this boundary. RTL, author TB, collector, protected codec and six cancelled-audit files are unchanged.

Frozen before the edit: 45,412 per-nibble bit-position properties covering every supported ordinal2..32 and tag/tick1..64 width, both upper/lower X/Z, symbolic preservation, all-known overflow and full64-bit values. The old source falsely accepts23,504; the new source matches all45,412. There are no new false rejects. Five exact coordinator fixtures pass direct and real CLI expectations; both2x/2z corruptions reject and genuine/1x/x1 controls pass.

The existing58 frozen inputs also pass direct and actual CLI classification, including active-unknown rejection. Three actual normal-main composition processes use unchanged main/run_case/aggregation with a frozen synthetic vendor-process seam: genuine exits0, collector corruption exits1, queue corruption exits1. Fifteen actual Python emitter subprocesses (30 raw streams) preserve their intended vendor argv separately. No vendor executable ran. These are parser/process qualifications of saved transcripts, not new simulation or an RTL failure finding.

Rehashed all7,216 selected old evidence files without mutation. Checked66 CLI/main process receipts and their raw streams, all frozen new inputs, and exact six-line code diff. Prior30-case baseline, repair01 failures, repair02 alias false negative and all historical receipts remain intact. No old08–22 suite or ModelSim replay occurred.

Runner SHA256: {sha(RUNNER)}
Document SHA256: {sha(DOC)}
Source diff SHA256: {sha(N/'final-source/source.diff')}
Expectation freeze SHA256: {sha(N/'EXPECTATION_FREEZE.json')}
Prior product HEAD: {gitrows['head']}; no new commit/request hash/PR feedback.

H01–H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 canonical SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 and design1011259415a0916054eb580687612580bc1e5f09 unchanged. All29/B02/B03/G05/B06/R03/full-product simulation/synthesis/implementation/timing/CDC_RDC/board/system remain not_run. Physical board A-only. No ABI, source/clock, freshness, DMA/PS, ENABLE or motion authority is granted.
'''
with (N/'REVIEW.md').open('x',encoding='utf-8',newline='\n') as f:f.write(report)
print(json.dumps(dict(status=decision['status'],source_sha256=sha(RUNNER),decision_sha256=sha(N/'REVIEW_DECISION.json'),historical_files=len(history),invocations=len(invocations),processes=len(processes))))
