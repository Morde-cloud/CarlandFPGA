# op22 tool-version preflight repair - author report

Task: `DEEPEYE-IMPLEMENTATION-20261014/v1`
Work: `B-SAMPLE-SCAN-TOOLCHECK-REPAIR-20261022-22-v1`
Product operation: `B-DEEPEYE-SAMPLE-SCAN-TOOLCHECK-20261022-22`
Parent work: `B-LOCAL-SAMPLE-SCAN-TOOLCHECK-REPAIR-20261022-v1`
Product director: `01a13b55-095b-7461-8dd5-5476a130bd82`
Author: one DeepSeek V4.1 Flash/max execution child. This is author evidence, not acceptance.

## Baseline and result

- Worktree `D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014`, head `cd007dc8190b7c2d911d2be6c1136aabab3518e5`.
- Baseline runner `competition/deepeye/tools/acquisition/run_sample_scan_capture.py`: SHA256 `99748d791432cd0090e92b1e383670200fc3ead59ad3a6795af72f876e6d6b66`, 36049 bytes.
- Preserved original bytes: `author/original/run_sample_scan_capture.py`, same SHA256 and byte count, byte-identical copy.
- Repaired runner: SHA256 `a47dcfb493316f23578d4b10e8d832e3bc48512377e4df07c54f27ec11081547`, 39579 bytes, 959 lines.
- New portable test: `competition/deepeye/tests/acquisition/test_sample_scan_toolcheck.py`, SHA256 `47e3b5031a080e6fd6fc6d31d3390940166394c4a5b3a3cc9ac348f9518b87bc`, 35282 bytes, 725 lines.

## Inputs read and verified

- Frozen repair scope: `dd9ae9019bb6cf4fe3aae93cb71eb784aa4205abd897aa06fcbb40c62ab4994b`, 8167 bytes.
- Continue decision: `3e230dee6cf41432a2268c6340894e61d9809af616fa6d9ba3f274a190e9109c`, 4547 bytes.
- Actual CONSUMED: `c6ffbc639ab6f19e3d41fdb4a03181648b6d9b1a27a0e46a1622a841d4966c2f`, 7896 bytes.
- Contract `DEEPEYE-HUMAN-LOCK-20261014/revision1`, pin `f5989cd5defce561f9ba98e6b18fc2682945f0a2`, canonical requirements SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` (recomputed from the pinned requirements array with ensure_ascii=False, sort_keys=True, separators=(',',':'), UTF-8), design `1011259415a0916054eb580687612580bc1e5f09`. H01-H15 all read and preserved.
- Main freeze `b22bb0c893b05dd790cf80b3e4121e6e01a21e27e056d90bd374403c31859232`; literal matrix `59db090efab27904092056ec913cef6f83ae052f658d3f16af7ba7585937b11c` (136 cases, 12 positive, 124 negative); entry oracle `17d5da9931fded0d4f877f8b75d98affcddfca685f9e524350b1390b63eeea56`.

## Defect and repair

`OP21-TOOLCHECK-ERROR01`: the old `_tool_version` accepted any version query whose combined text contained `10.7` and exited 0. An explicit Error line or a wrong banner therefore passed, and a raised OSError escaped the preflight.

The repair is confined to `_tool_version` plus two narrow helpers:

- Exactly one complete banner across stdout and stderr:
  - vlog: `Model Technology ModelSim SE-64 vlog 10.7 Compiler 2017.12 Dec  7 2017`
  - vsim: `Model Technology ModelSim SE-64 vsim 10.7 Simulator 2017.12 Dec  7 2017`
  - CRLF/LF, horizontal whitespace between tokens, trimmed leading/trailing whitespace, and one optional `# ` prefix are accepted; the raw bytes are unchanged.
- Optional single exact `Errors: 0, Warnings: 0` on either stream; no summary is required for a healthy query.
- Explicit Error/Fatal/Warning (any case), malformed/nonzero/duplicate/conflicting summaries, wrong/missing/duplicate/conflicting banners, any extra unrecognized text, nonzero exit, timeout, or raised OSError/FileNotFoundError/TimeoutExpired fail closed.
- Raw stdout/stderr bytes, exit, timed_out, exception type/message and per-tool reasons are persisted. Both version queries still run for diagnostics. `main` returns 2 and starts zero case compile/simulation work.

No compile/simulation/guard/mutant/selection/aggregate function or RTL/testbench was changed.

## Verification (actual commands and results; logs under `author/logs`)

- `python -B -X utf8 -m unittest competition.deepeye.tests.acquisition.test_sample_scan_toolcheck -v` -> exit 0, `Ran 29 tests`, `OK`.
  Log: `test-run-06-module.stderr.txt`, SHA256 `5f9ba332c51b1fcd881f437664fa0a129baaacec43a2ca2c2fb8c98d170c4728`.
- `python -B -X utf8 -m unittest discover -s competition/deepeye/tests/acquisition -p "test_sample_scan_toolcheck.py" -v` -> exit 0, `Ran 29 tests`, `OK`.
  Log: `test-run-05.stderr.txt`, SHA256 `f36cc4b821506e09e13d016898a6b78c50a55bf5ba5a04c04c9146b5e42da315`.
- Direct file invocation -> exit 0, `Ran 29 tests`, `OK`.
  Log: `test-run-04.stderr.txt`, SHA256 `d8287b11e972c90ae674e123bf3ce243afcb36cb74c21c3599520794ef411f6d`.
- Author cross-check of the repaired validator against the main-frozen 136-case matrix: 12 positive, 124 negative, 0 mismatches.
  Result: `literal-matrix-check-final.json`, SHA256 `04d9ed5b5b977a86a2353bcef9af17302fb69ce450406e42361fe55f8ee33aba`.
- Function/AST fingerprint compare against the preserved op21 original: changed function `_tool_version` only; added `_version_failure_reasons` and `_version_output_bytes`; no top-level changes; all 27 other existing functions have identical source and AST hashes; `_parse_args`, `main`, `run_case` moved line numbers only.
  Result: `function-diff-final.json`, SHA256 `9ea49c44291736e569c84d44d527513ed61e9e0c8a6828680c8ac0541bb72191`.
- Synthetic red/green: op21 accepted `diagnostic_exit0` and `wrong_banner_exit0` with empty reasons, and let OSError escape; op22 rejected all three, preserved the reasons/exception evidence, and still queried vsim.
  Result: `red-green-01.json`, SHA256 `eee6ae0c806847fae5bc7e77f3774840dab57997752c9252266bbd50f4305a17`.
- `--list-cases` -> exit 0, 27 cases; `list-cases.stdout.txt`.
- No real `vlog`/`vsim` command was run. Every vendor invocation in these tests is an explicit synthetic `_run_hidden` seam. No old RTL suite, compile, simulation, synthesis, implementation, timing, CDC/RDC or board run.
- No new bytecode cache was produced by these runs. A pre-existing `competition/deepeye/tools/control3d/__pycache__` entry dated 2026-10-20 is unrelated and untouched.

## Read-only pins verified

- RTL `deepeye_sample_scan_capture.sv`: `fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d`.
- Author TB `tb_sample_scan_capture.sv`: `bf240773bc9a7e15683194e0d7418b1bf07f4e1b6f54267264223e161e47f393`.
- Main TB `main_tb_sample_scan_capture.sv`: `45dfbdf1bab5b3788cad418ec259ea35028f41146013080620cdbc5c10f4936e`.
- Main verifier `main_verify_sample_scan_capture.py`: `f4b4290398df1f4d9a8f2327020fee7fe30f5f7d17e17df9a2338dfdbe7f8d40`.
- Protected codec input `handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json`: `6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8`.

## Attempts retained

- `test-run-01.stderr.txt` preserves the first 26-test run, which failed one self-referential source check (it searched its own text for a process-spawning literal). Exit 1. Fixed in patch `007_fix_self_referential_process_check.patch` by using AST inspection.
- `test-run-02`, `-03`, `-04`, `-05`, `-06` are subsequent passing runs (26 then 29 tests).
- Early red/green helper attempts failed on helper path/out setup; patches `008` and `009` and the final `red-green-01.json` are retained.
- All patch files, staging source and helper scripts are under `author/logs` and `author/tools`. Edits were applied through the project apply_patch entrypoint; owned helpers staged/chunked large patches because Windows PowerShell 5.1 and the 32K process limit mangle large arguments. No unowned helper or root scratch file was created.

## Boundaries and not_run

- No commit, stage, publish, peer/group send, worker/native/App launch, service, credential, config, SQL, queue or board operation.
- Git index remained empty. Only the owned runner, the new test path and this author directory were written.
- `all29`, `B02`, `G05`, `B06`, `R03`, `full_product`, `synthesis`, `implementation`, `timing`, `CDC_RDC`, `board` and `system` remain **not_run**. The physical board remains A-only.
- This report records author work and evidence only. The product main independently decides acceptance.