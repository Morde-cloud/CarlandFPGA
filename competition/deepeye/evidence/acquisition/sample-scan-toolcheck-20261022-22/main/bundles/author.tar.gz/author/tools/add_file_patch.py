#!/usr/bin/env python3
'''Build and apply an add-file patch from a staged UTF-8 source file.'''

import pathlib
import subprocess
import sys


def main(argv: list[str]) -> int:
    if len(argv) != 5:
        print('usage: add_file_patch.py <codex.exe> <source-file> <target-rel-path> <patch-out>',
              file=sys.stderr)
        return 2
    codex, source_name, target, patch_name = argv[1:]
    text = pathlib.Path(source_name).read_text(encoding='utf-8-sig')
    body = '\n'.join('+' + line for line in text.splitlines())
    patch = '*** Begin Patch\n*** Add File: ' + target + '\n' + body + '\n*** End Patch'
    pathlib.Path(patch_name).write_text(patch, encoding='utf-8', newline='\n')
    completed = subprocess.run([codex, '--codex-run-as-apply-patch', patch])
    return completed.returncode


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
