#!/usr/bin/env python3
'''Apply a staged file through chunked apply_patch add/update hunks.'''

import pathlib
import subprocess
import sys


def _add_patch(target: str, lines: list[str]) -> str:
    body = '\n'.join('+' + line for line in lines)
    return '*** Begin Patch\n*** Add File: ' + target + '\n' + body + '\n*** End Patch'


def _append_patch(target: str, context: list[str], lines: list[str]) -> str:
    hunk = '@@\n'
    hunk += '\n'.join(' ' + line for line in context) + '\n'
    hunk += '\n'.join('+' + line for line in lines)
    return '*** Begin Patch\n*** Update File: ' + target + '\n' + hunk + '\n*** End Patch'


def _chunks(lines: list[str], budget: int):
    chunk: list[str] = []
    size = 0
    for line in lines:
        cost = len(line) + 2
        if chunk and size + cost > budget:
            yield chunk
            chunk = []
            size = 0
        chunk.append(line)
        size += cost
    if chunk:
        yield chunk


def main(argv: list[str]) -> int:
    if len(argv) != 6:
        print('usage: apply_file_chunked.py <codex.exe> <source-file> <target-rel-path> <patch-dir> <budget>',
              file=sys.stderr)
        return 2
    codex, source_name, target, patch_dir_name, budget_name = argv[1:]
    lines = pathlib.Path(source_name).read_text(encoding='utf-8-sig').splitlines()
    patch_dir = pathlib.Path(patch_dir_name)
    patch_dir.mkdir(parents=True, exist_ok=True)
    target_path = pathlib.Path(target)
    if target_path.exists():
        print('target already exists: ' + target, file=sys.stderr)
        return 2
    budget = int(budget_name)
    for index, chunk in enumerate(_chunks(lines, budget), 1):
        if index == 1:
            patch = _add_patch(target, chunk)
        else:
            current = target_path.read_text(encoding='utf-8').splitlines()
            context = current[-3:]
            patch = _append_patch(target, context, chunk)
        patch_path = patch_dir / f'{index:03d}.patch'
        patch_path.write_text(patch, encoding='utf-8', newline='\n')
        print(f'chunk {index}: lines={len(chunk)} patch_bytes={len(patch)}')
        completed = subprocess.run([codex, '--codex-run-as-apply-patch', patch])
        if completed.returncode != 0:
            print(f'chunk {index} failed with {completed.returncode}', file=sys.stderr)
            return completed.returncode
    actual = target_path.read_text(encoding='utf-8').splitlines()
    if actual != lines:
        print('final content mismatch', file=sys.stderr)
        return 1
    print(f'verified lines={len(actual)}')
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
