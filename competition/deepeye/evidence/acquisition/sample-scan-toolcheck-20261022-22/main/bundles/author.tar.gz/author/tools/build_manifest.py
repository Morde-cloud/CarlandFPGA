#!/usr/bin/env python3
'''Build the op22 author manifest from actual files and captured logs.'''

from __future__ import annotations

import datetime
import hashlib
import json
import pathlib
import subprocess
import sys


def info(path: pathlib.Path, root: pathlib.Path) -> dict:
    raw = path.read_bytes()
    try:
        display = str(path.relative_to(root)).replace('\\', '/')
    except ValueError:
        display = str(path)
    return {
        'path': display,
        'sha256': hashlib.sha256(raw).hexdigest(),
        'bytes': len(raw),
    }


def text_info(path: pathlib.Path, root: pathlib.Path) -> dict:
    payload = info(path, root)
    payload['lines'] = len(path.read_text(encoding='utf-8').splitlines())
    return payload


def _decode_log(raw: bytes) -> tuple[str, str]:
    if raw.startswith(b'\xff\xfe') or raw.startswith(b'\xfe\xff'):
        return raw.decode('utf-16'), 'utf-16'
    if raw.startswith(b'\xef\xbb\xbf'):
        return raw.decode('utf-8-sig'), 'utf-8-sig'
    return raw.decode('utf-8', errors='replace'), 'utf-8'


def command_record(name: str, command: str, exit_code: int,
                   stdout_path: pathlib.Path, stderr_path: pathlib.Path,
                   root: pathlib.Path) -> dict:
    summary_lines = []
    stderr_encoding = None
    if stderr_path.is_file():
        stderr_text, stderr_encoding = _decode_log(stderr_path.read_bytes())
        for line in stderr_text.splitlines():
            stripped = line.strip()
            if stripped.startswith('Ran ') or stripped == 'OK' or stripped.startswith('FAILED'):
                summary_lines.append(stripped)
    stdout_lines = 0
    if stdout_path.is_file():
        stdout_text, _ = _decode_log(stdout_path.read_bytes())
        stdout_lines = len(stdout_text.splitlines())
    return {
        'name': name,
        'command': command,
        'exit_code': exit_code,
        'summary': '; '.join(summary_lines[-2:]),
        'stdout_lines': stdout_lines,
        'stderr_encoding': stderr_encoding,
        'stdout': info(stdout_path, root) if stdout_path.is_file() else None,
        'stderr': info(stderr_path, root) if stderr_path.is_file() else None,
    }


def main() -> int:
    author = pathlib.Path(__file__).resolve().parents[1]
    root = pathlib.Path(__file__).resolve().parents[7]
    logs = author / 'logs'
    manifest_path = author / 'MANIFEST.json'

    def path(rel: str) -> pathlib.Path:
        return root / rel

    inputs = {
        'scope': info(pathlib.Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/main-continuation-20261019-v1/sample-scan-capture-20261022-21/NEXT_REPAIR_SCOPE_20261022_22.md'), root),
        'decision': info(pathlib.Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/main-continuation-20261019-v1/sample-scan-capture-20261022-21/REPAIR_CONTINUE_DECISION.json'), root),
        'consumed': info(pathlib.Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/sample-scan-toolcheck-20261022-22/CONSUMED.json'), root),
        'main_freeze': info(path('competition/deepeye/evidence/acquisition/sample-scan-toolcheck-20261022-22/main/FREEZE.json'), root),
        'literal_matrix': info(path('competition/deepeye/evidence/acquisition/sample-scan-toolcheck-20261022-22/main/LITERAL_MATRIX.json'), root),
        'entry_oracle': info(path('competition/deepeye/evidence/acquisition/sample-scan-toolcheck-20261022-22/main/ENTRY_ORACLE.json'), root),
    }
    inputs['literal_matrix'].update({'cases': 136, 'positive': 12, 'negative': 124})
    inputs['contract'] = {
        'id': 'DEEPEYE-HUMAN-LOCK-20261014',
        'revision': 1,
        'pin': 'f5989cd5defce561f9ba98e6b18fc2682945f0a2',
        'requirements_sha256': 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
        'design': '1011259415a0916054eb580687612580bc1e5f09',
        'ids': ['H01', 'H02', 'H03', 'H04', 'H05', 'H06', 'H07', 'H08',
                'H09', 'H10', 'H11', 'H12', 'H13', 'H14', 'H15'],
    }

    runner = path('competition/deepeye/tools/acquisition/run_sample_scan_capture.py')
    test = path('competition/deepeye/tests/acquisition/test_sample_scan_toolcheck.py')
    original = author / 'original' / 'run_sample_scan_capture.py'
    report = author / 'AUTHOR_REPORT.md'
    function_diff = json.loads((logs / 'function-diff-final.json').read_text(encoding='utf-8'))
    matrix_result_path = logs / 'literal-matrix-check-final.json'
    matrix_result = json.loads(matrix_result_path.read_text(encoding='utf-8'))
    red_green_path = logs / 'red-green-01.json'
    red_green = json.loads(red_green_path.read_text(encoding='utf-8'))
    rg_old = red_green['results']['op21']
    rg_new = red_green['results']['op22']
    red_green_facts = {
        'synthetic_only': red_green.get('synthetic_only'),
        'op21_diagnostic_exit0_accepted': rg_old['diagnostic_exit0'].get('reasons') == [],
        'op21_wrong_banner_exit0_accepted': rg_old['wrong_banner_exit0'].get('reasons') == [],
        'op21_oserror_escaped': rg_old['exception_oserror'].get('raised') == 'OSError',
        'op22_diagnostic_exit0_rejected': bool(rg_new['diagnostic_exit0'].get('reasons')),
        'op22_wrong_banner_exit0_rejected': bool(rg_new['wrong_banner_exit0'].get('reasons')),
        'op22_oserror_caught_and_rejected': (
            rg_new['exception_oserror'].get('raised') is None
            and bool(rg_new['exception_oserror'].get('reasons'))
        ),
    }

    commands = [
        command_record(
            'module_unittest',
            'python -B -X utf8 -m unittest competition.deepeye.tests.acquisition.test_sample_scan_toolcheck -v',
            0, logs / 'test-run-06-module.stdout.txt', logs / 'test-run-06-module.stderr.txt', root),
        command_record(
            'discovery_unittest',
            'python -B -X utf8 -m unittest discover -s competition/deepeye/tests/acquisition -p test_sample_scan_toolcheck.py -v',
            0, logs / 'test-run-05.stdout.txt', logs / 'test-run-05.stderr.txt', root),
        command_record(
            'direct_unittest',
            'python -B -X utf8 competition/deepeye/tests/acquisition/test_sample_scan_toolcheck.py -v',
            0, logs / 'test-run-04.stdout.txt', logs / 'test-run-04.stderr.txt', root),
        command_record(
            'list_cases',
            'python -B -X utf8 competition/deepeye/tools/acquisition/run_sample_scan_capture.py --list-cases',
            0, logs / 'list-cases.stdout.txt', logs / 'list-cases.stderr.txt', root),
    ]
    attempts = [
        command_record(
            'first_test_run_failed_self_referential_check',
            'python -B -X utf8 competition/deepeye/tests/acquisition/test_sample_scan_toolcheck.py -v',
            1, logs / 'test-run-01.stdout.txt', logs / 'test-run-01.stderr.txt', root),
        command_record(
            'second_test_run_26_ok',
            'python -B -X utf8 competition/deepeye/tests/acquisition/test_sample_scan_toolcheck.py -v',
            0, logs / 'test-run-02.stdout.txt', logs / 'test-run-02.stderr.txt', root),
        command_record(
            'discovery_26_ok',
            'python -B -X utf8 -m unittest discover -s competition/deepeye/tests/acquisition -p test_sample_scan_toolcheck.py -v',
            0, logs / 'test-run-03.stdout.txt', logs / 'test-run-03.stderr.txt', root),
    ]

    read_only = {
        'rtl': info(path('competition/deepeye/fpga/acquisition/deepeye_sample_scan_capture.sv'), root),
        'author_tb': info(path('competition/deepeye/tests/rtl/acquisition/tb_sample_scan_capture.sv'), root),
        'main_tb': info(path('competition/deepeye/tests/rtl/acquisition/main_tb_sample_scan_capture.sv'), root),
        'main_verifier': info(path('competition/deepeye/tools/acquisition/main_verify_sample_scan_capture.py'), root),
        'protected_codec_input': info(path('handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json'), root),
    }

    status = subprocess.run(
        ['git', 'status', '--porcelain', '--',
         'competition/deepeye/tools/acquisition/run_sample_scan_capture.py',
         'competition/deepeye/tests/acquisition',
         'competition/deepeye/evidence/acquisition/sample-scan-toolcheck-20261022-22/author'],
        cwd=root, capture_output=True, text=True,
    )
    staged = subprocess.run(
        ['git', 'diff', '--cached', '--name-only'],
        cwd=root, capture_output=True, text=True,
    )

    evidence_files = []
    for item in sorted(author.rglob('*')):
        if not item.is_file():
            continue
        if item.name in {'MANIFEST.json', 'MANIFEST.sha256'}:
            continue
        evidence_files.append(info(item, root))

    manifest = {
        'schema': 'deepeye-sample-scan-toolcheck-author-manifest/v1',
        'at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'task_id': 'DEEPEYE-IMPLEMENTATION-20261014',
        'task_version': 1,
        'work_id': 'B-SAMPLE-SCAN-TOOLCHECK-REPAIR-20261022-22-v1',
        'parent_work': 'B-LOCAL-SAMPLE-SCAN-TOOLCHECK-REPAIR-20261022-v1',
        'product_operation': 'B-DEEPEYE-SAMPLE-SCAN-TOOLCHECK-20261022-22',
        'product_director_thread': '01a13b55-095b-7461-8dd5-5476a130bd82',
        'author_model': 'DeepSeek V4.1 Flash/max, single author',
        'worktree': {
            'path': str(root),
            'head': subprocess.run(['git', 'rev-parse', 'HEAD'], cwd=root,
                                   capture_output=True, text=True, check=True).stdout.strip(),
            'index_empty': staged.stdout.strip() == '',
            'owned_status': [line for line in status.stdout.splitlines() if line.strip()],
        },
        'inputs': inputs,
        'changes': {
            'runner': {
                'path': str(runner.relative_to(root)).replace('\\', '/'),
                'before': info(original, root) | {'note': 'preserved op21 bytes'},
                'after': text_info(runner, root),
                'changed_functions': function_diff['changed_functions'],
                'added_functions': function_diff['added_functions'],
                'moved_functions': function_diff['moved_functions'],
                'missing_functions': function_diff['missing_functions'],
                'changed_top_level_indices': function_diff['changed_top_level_indices'],
                'added_top_level': function_diff['added_top_level'],
                'removed_top_level': function_diff['removed_top_level'],
                'protected_functions_verified': 27,
                'top_level_unchanged': (
                    not function_diff['changed_top_level_indices']
                    and not function_diff['added_top_level']
                    and not function_diff['removed_top_level']
                ),
            },
            'test': text_info(test, root) | {'tests': 29},
            'author_report': info(report, root),
        },
        'verification': {
            'commands': commands,
            'attempts': attempts,
            'matrix_cross_check': {
                'matrix': inputs['literal_matrix'],
                'result': info(matrix_result_path, root),
                'cases': matrix_result['cases'],
                'positive': matrix_result['positive'],
                'negative': matrix_result['negative'],
                'mismatches': len(matrix_result['mismatches']),
            },
            'function_diff': {
                'path': str((logs / 'function-diff-final.json').relative_to(root)).replace('\\', '/'),
                'sha256': info(logs / 'function-diff-final.json', root)['sha256'],
                'changed_functions': function_diff['changed_functions'],
                'added_functions': function_diff['added_functions'],
                'moved_functions': function_diff['moved_functions'],
                'top_level_unchanged': (
                    not function_diff['changed_top_level_indices']
                    and not function_diff['added_top_level']
                    and not function_diff['removed_top_level']
                ),
            },
            'red_green': info(red_green_path, root) | red_green_facts,
            'read_only': read_only,
            'real_vendor_commands_run': False,
            'rtl_suite_run': False,
            'new_pycache_created': False,
            'pre_existing_unrelated_pycache': 'competition/deepeye/tools/control3d/__pycache__ (2026-10-20)',
        },
        'not_run': ['all29', 'B02', 'G05', 'B06', 'R03', 'full_product', 'synthesis',
                    'implementation', 'timing', 'CDC_RDC', 'board', 'system'],
        'board': 'A-only',
        'boundaries': [
            'no commit, stage, publish, peer/group send, worker/native/App launch',
            'no service, credential, config, SQL, queue or board operation',
            'only the owned runner, new test path and author evidence directory were written',
            'author evidence only; product main independently decides acceptance',
        ],
        'author_evidence_files': evidence_files,
    }
    manifest_path.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
        encoding='utf-8', newline='\n',
    )
    digest = hashlib.sha256(manifest_path.read_bytes()).hexdigest()
    (author / 'MANIFEST.sha256').write_text(digest + '  MANIFEST.json\n',
                                            encoding='utf-8', newline='\n')
    print(json.dumps({
        'manifest': str(manifest_path),
        'manifest_sha256': digest,
        'runner_sha256': manifest['changes']['runner']['after']['sha256'],
        'test_sha256': manifest['changes']['test']['sha256'],
        'evidence_files': len(evidence_files),
        'matrix_mismatches': len(matrix_result['mismatches']),
        'tests': 29,
    }, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
