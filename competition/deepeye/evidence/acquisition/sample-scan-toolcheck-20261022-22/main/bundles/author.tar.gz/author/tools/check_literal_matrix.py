#!/usr/bin/env python3
'''Cross-check the repaired validator against the frozen literal matrix.'''

from __future__ import annotations

import importlib.util
import json
import pathlib
import sys


def _load_runner(source: pathlib.Path):
    spec = importlib.util.spec_from_file_location('op22_runner_under_check', source)
    if spec is None or spec.loader is None:
        raise RuntimeError('cannot load runner')
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main(argv: list[str]) -> int:
    if len(argv) != 4:
        print('usage: check_literal_matrix.py <runner.py> <matrix.json> <result.json>',
              file=sys.stderr)
        return 2
    runner = _load_runner(pathlib.Path(argv[1]))
    matrix = json.loads(pathlib.Path(argv[2]).read_text(encoding='utf-8'))
    rows = []
    mismatches = []
    for case in matrix['cases']:
        invocation = {
            'stdout_text': case['stdout'],
            'stderr_text': case['stderr'],
            'exit': case['exit'],
            'timed_out': case['timed_out'],
        }
        if case['exception']:
            invocation['exception_type'] = case['exception']
            invocation['exception_message'] = 'synthetic matrix exception'
        reasons = runner._version_failure_reasons(case['tool'], invocation)
        observed_ok = not reasons
        row = {
            'id': case['id'],
            'expected_ok': case['expected_ok'],
            'observed_ok': observed_ok,
            'reasons': reasons,
        }
        rows.append(row)
        if observed_ok != case['expected_ok']:
            mismatches.append(row)
    result = {
        'matrix_sha256': matrix.get('matrix_sha256'),
        'cases': len(rows),
        'positive': sum(1 for row in rows if row['expected_ok']),
        'negative': sum(1 for row in rows if not row['expected_ok']),
        'mismatches': mismatches,
        'rows': rows,
    }
    pathlib.Path(argv[3]).write_text(
        json.dumps(result, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
        encoding='utf-8',
        newline='\n',
    )
    print(json.dumps({
        'cases': result['cases'],
        'positive': result['positive'],
        'negative': result['negative'],
        'mismatch_count': len(mismatches),
    }, indent=2, sort_keys=True))
    return 0 if not mismatches else 1


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
