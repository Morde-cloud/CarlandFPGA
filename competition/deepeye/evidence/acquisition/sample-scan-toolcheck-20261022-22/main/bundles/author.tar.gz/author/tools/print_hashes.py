import json
p='competition/deepeye/evidence/acquisition/sample-scan-toolcheck-20261022-22/author/original/FUNCTION_BASELINE.json'
d=json.load(open(p,encoding='utf-8'))['source']['functions']
for name in sorted(d):
    print(f"    '{name}': ('{d[name]['source_sha256']}', '{d[name]['ast_sha256']}'),")