import json,hashlib
p='competition/deepeye/evidence/acquisition/sample-scan-toolcheck-20261022-22/author/original/FUNCTION_BASELINE.json'
d=json.load(open(p,encoding='utf-8'))['source']
print('TOP_LEVEL_SHA256='+hashlib.sha256(json.dumps(d['top_level'],sort_keys=True,separators=(',',':')).encode()).hexdigest())
print('TOP_LEVEL_ENTRIES='+str(len(d['top_level'])))
print('TOP_LEVEL='+json.dumps(d['top_level'],sort_keys=True))