#!/usr/bin/env python3
'''Synthetic red/green comparison of the op21 and repaired runners.

This never starts ModelSim. _run_hidden is replaced by an explicit seam that
returns the same synthetic bytes to both sources.
'''

from __future__ import annotations

import importlib.util
import json
import pathlib
import tempfile
from unittest import mock


VLOG = 'Model Technology ModelSim SE-64 vlog 10.7 Compiler 2017.12 Dec  7 2017\r\n'
VSIM = 'Model Technology ModelSim SE-64 vsim 10.7 Simulator 2017.12 Dec  7 2017\r\n'


def load(path: str, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def make_hidden(fixture: str):
    def hidden(argv, cwd, timeout):
        tool = pathlib.Path(argv[0]).stem
        if fixture == 'diagnostic_exit0':
            if tool == 'vlog':
                return {
                    'argv': argv, 'cwd': str(cwd), 'exit': 0, 'timed_out': False,
                    'elapsed_seconds': 0.001,
                    'stdout_bytes': (VLOG + '** Error: license failed\n').encode(),
                    'stderr_bytes': b'',
                }
            return {
                'argv': argv, 'cwd': str(cwd), 'exit': 0, 'timed_out': False,
                'elapsed_seconds': 0.001,
                'stdout_bytes': VSIM.encode(), 'stderr_bytes': b'',
            }
        if fixture == 'wrong_banner_exit0':
            if tool == 'vlog':
                return {
                    'argv': argv, 'cwd': str(cwd), 'exit': 0, 'timed_out': False,
                    'elapsed_seconds': 0.001,
                    'stdout_bytes': b'ModelSim SE-64 10.7 / 2017.12\n',
                    'stderr_bytes': b'',
                }
            return {
                'argv': argv, 'cwd': str(cwd), 'exit': 0, 'timed_out': False,
                'elapsed_seconds': 0.001,
                'stdout_bytes': VSIM.encode(), 'stderr_bytes': b'',
            }
        if fixture == 'exception_oserror':
            if tool == 'vlog':
                raise OSError('synthetic spawn failure')
            return {
                'argv': argv, 'cwd': str(cwd), 'exit': 0, 'timed_out': False,
                'elapsed_seconds': 0.001,
                'stdout_bytes': VSIM.encode(), 'stderr_bytes': b'',
            }
        raise AssertionError('unknown fixture')
    return hidden


def run_one(module, fixture: str):
    with tempfile.TemporaryDirectory() as temp:
        base = pathlib.Path(temp)
        modelsim = base / 'modelsim'
        modelsim.mkdir()
        (modelsim / 'vlog.exe').write_bytes(b'')
        (modelsim / 'vsim.exe').write_bytes(b'')
        out = base / 'out'
        out.mkdir()
        with mock.patch.object(module, '_run_hidden', side_effect=make_hidden(fixture)):
            try:
                versions, reasons = module._tool_version(modelsim, out)
            except Exception as exc:
                return {
                    'fixture': fixture,
                    'raised': type(exc).__name__,
                    'message': str(exc),
                }
        return {
            'fixture': fixture,
            'raised': None,
            'reasons': reasons,
            'ok': {tool: versions[tool].get('ok') for tool in ('vlog', 'vsim')},
        }


def main():
    author = pathlib.Path(__file__).resolve().parents[1]
    worktree = pathlib.Path(__file__).resolve().parents[7]
    old_path = author / 'original' / 'run_sample_scan_capture.py'
    new_path = (worktree / 'competition' / 'deepeye' / 'tools' / 'acquisition'
                / 'run_sample_scan_capture.py')
    old = load(str(old_path), 'runner_op21')
    new = load(str(new_path), 'runner_op22')
    fixtures = ['diagnostic_exit0', 'wrong_banner_exit0', 'exception_oserror']
    payload = {
        'synthetic_only': True,
        'old_source': str(old_path),
        'new_source': str(new_path),
        'results': {
            'op21': {fixture: run_one(old, fixture) for fixture in fixtures},
            'op22': {fixture: run_one(new, fixture) for fixture in fixtures},
        },
    }
    out = author / 'logs' / 'red-green-01.json'
    out.write_text(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
                   encoding='utf-8', newline='\n')
    print(json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


if __name__ == '__main__':
    main()
