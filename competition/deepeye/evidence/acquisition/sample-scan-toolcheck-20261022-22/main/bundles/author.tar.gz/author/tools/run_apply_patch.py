#!/usr/bin/env python3
'''Apply a UTF-8 patch file through the Codex apply_patch entrypoint.'''

import pathlib
import subprocess
import sys


def main(argv: list[str]) -> int:
    if len(argv) != 3:
        print('usage: run_apply_patch.py <codex.exe> <patch-file>', file=sys.stderr)
        return 2
    patch = pathlib.Path(argv[2]).read_text(encoding='utf-8-sig')
    completed = subprocess.run([argv[1], '--codex-run-as-apply-patch', patch])
    return completed.returncode


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
