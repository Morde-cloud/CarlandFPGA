#!/usr/bin/env python3
'''Record or compare function-level source/AST fingerprints for the runner.'''

from __future__ import annotations

import ast
import hashlib
import json
import pathlib
import sys


def _sha(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def _inventory(path: pathlib.Path) -> dict:
    raw = path.read_bytes()
    text = raw.decode('utf-8')
    tree = ast.parse(text)
    functions: dict[str, dict] = {}
    top_level: list[dict[str, str]] = []
    for node in tree.body:
        segment = ast.get_source_segment(text, node)
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            functions[node.name] = {
                'lineno': node.lineno,
                'end_lineno': node.end_lineno,
                'source_sha256': _sha(segment or ''),
                'ast_sha256': _sha(ast.dump(node, include_attributes=False)),
            }
        else:
            top_level.append({
                'kind': type(node).__name__,
                'source_sha256': _sha(segment or ''),
            })
    return {
        'path': str(path),
        'sha256': hashlib.sha256(raw).hexdigest(),
        'bytes': len(raw),
        'functions': functions,
        'top_level': top_level,
    }


def main(argv: list[str]) -> int:
    if len(argv) < 2 or argv[1] not in {'snapshot', 'compare'}:
        print('usage: snapshot_source.py snapshot <input> <output>', file=sys.stderr)
        print('       snapshot_source.py compare <baseline.json> <current-source> <output>',
              file=sys.stderr)
        return 2
    mode = argv[1]
    if mode == 'snapshot':
        if len(argv) != 4:
            print('usage: snapshot_source.py snapshot <input> <output>', file=sys.stderr)
            return 2
        input_name = pathlib.Path(argv[2])
        output_name = pathlib.Path(argv[3])
        current = _inventory(input_name)
        payload = {'mode': 'snapshot', 'source': current}
        output_name.write_text(
            json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
            encoding='utf-8',
            newline='\n',
        )
        print(json.dumps({'functions': len(current['functions']), 'sha256': current['sha256']}))
        return 0

    if len(argv) != 5:
        print('usage: snapshot_source.py compare <baseline.json> <current-source> <output>',
              file=sys.stderr)
        return 2
    baseline_name = pathlib.Path(argv[2])
    current_name = pathlib.Path(argv[3])
    output_name = pathlib.Path(argv[4])
    baseline = json.loads(baseline_name.read_text(encoding='utf-8'))['source']
    current = _inventory(current_name)
    old_functions = baseline['functions']
    new_functions = current['functions']
    def fingerprint(entry: dict) -> tuple[str, str]:
        return entry['source_sha256'], entry['ast_sha256']

    changed = sorted(name for name in old_functions if name in new_functions
                     and fingerprint(old_functions[name]) != fingerprint(new_functions[name]))
    moved = sorted(name for name in old_functions if name in new_functions
                   and fingerprint(old_functions[name]) == fingerprint(new_functions[name])
                   and (old_functions[name]['lineno'], old_functions[name]['end_lineno'])
                   != (new_functions[name]['lineno'], new_functions[name]['end_lineno']))
    missing = sorted(set(old_functions) - set(new_functions))
    added = sorted(set(new_functions) - set(old_functions))
    old_top = baseline['top_level']
    new_top = current['top_level']
    top_changed = [index for index, (old, new) in enumerate(zip(old_top, new_top))
                   if old != new]
    top_removed = old_top[len(new_top):]
    top_added = new_top[len(old_top):]
    payload = {
        'mode': 'compare',
        'baseline_sha256': baseline['sha256'],
        'current_sha256': current['sha256'],
        'changed_functions': changed,
        'moved_functions': moved,
        'missing_functions': missing,
        'added_functions': added,
        'changed_top_level_indices': top_changed,
        'removed_top_level': top_removed,
        'added_top_level': top_added,
    }
    output_name.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True) + '\n',
        encoding='utf-8',
        newline='\n',
    )
    print(json.dumps(payload, indent=2, sort_keys=True))
    return 0


if __name__ == '__main__':
    raise SystemExit(main(sys.argv))
