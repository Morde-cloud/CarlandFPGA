# Single OOC46 diagnostic

Read FINAL_RESULT.json for the collected result and exact hashes. RESULT.json
is the preserved initial driver failure; it has not been overwritten.

One Vivado2026.1 OOC completed in the original tracked Windows job. cmd and
Vivado exited0, all12 process exits were captured, and active processes ended0.
Two findstr.exe helpers exited1. The initial driver required zero for every
helper and stopped classification before exporting; its exit1 and raw evidence
remain intact. A separate Python-only collector copied the existing DCP and
four reports and checked byte identity. No vendor command was replayed.

Actual synthesis: LUT97, FF451, DSP0, BRAM0, latches0. Diagnostic WNS+7.172ns
uses only a10ns clk created after synthesis. The two console warnings, one
ZPS7-1 DRC warning,452 inputs lacking delay and189 outputs lacking delay remain
unwaived. Clock-source/skew estimation and OOC DRC coverage gaps remain.

The exact source and pinned Tcl are unchanged. Tcl retains its original33
comments/B06 marker names; run metadata identifies actual operation46. Main
owns independent DCP review and acceptance. No timing closure, formal-card,
implementation, motion authority or board result is claimed. All29 formal
cards including B01/B03/B06/R03 remain not_run. Physical board work is A only.

H01-H15 contract requirements SHA256:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design:1011259415a0916054eb580687612580bc1e5f09.
