"""Collect the single completed OOC. No process creation, no vendor replay."""
from pathlib import Path
import hashlib
import json
import re
import shutil
import os
import sys
import datetime

A=Path(__file__).resolve().parent
S=Path("D:/pynq/CarlandFPGA/.local/b46")
P=A.parents[3]
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding="utf-8"))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def record(p):return dict(path=str(p),bytes=Path(p).stat().st_size,sha256=sha(p))
assert not (A/"FINAL_RESULT.json").exists()
failed=load(A/"RESULT.json")
assert failed["status"]=="failed_preserved" and failed["vendor_launches"]==1 and failed["synthesis_complete"]
process=load(A/"PROCESS.json")
assert process["exit_code"]==0 and process["job_accounting"]["ActiveProcesses"]==0
assert process["job_accounting"]["TotalProcesses"]==len(process["members"])==12
assert not process["timed_out"] and process["active_pids_at_end"]==[]
engine=[m for m in process["members"] if Path(m["image"]).name.lower()=="vivado.exe"]
assert len(engine)==1 and engine[0]["exit_code"]==0
assert all("exit_code" in m for m in process["members"])
nonzero=[m for m in process["members"] if m["exit_code"]!=0]
assert len(nonzero)==2 and all(Path(m["image"]).name.lower()=="findstr.exe" and m["exit_code"]==1 for m in nonzero)
stdout=(A/"logs/vivado.stdout.bin").read_bytes().decode("utf-8",errors="replace")
stderr=(A/"logs/vivado.stderr.bin").read_bytes().decode("utf-8",errors="replace")
markers=[line for line in stdout.splitlines() if line.startswith("B06_OOC_")]
expected=["BEGIN","USER_DATA","VERSION","PART","THREADS","SOURCE_READ","SOURCE_COUNT","SYNTH_BEGIN","SYNTH_DONE",
          "DESIGN","CLOCK","REPORT","REPORT","REPORT","REPORT","CHECKPOINT","END"]
assert [v.split("|")[0].removeprefix("B06_OOC_") for v in markers]==expected
assert "B06_OOC_VERSION|value=2026.1" in markers
assert "B06_OOC_PART|requested=xc7z020clg400-1|matched=1" in markers
assert "B06_OOC_THREADS|requested=2|actual=2" in markers
assert "B06_OOC_SOURCE_COUNT|count=1" in markers
assert "B06_OOC_CLOCK|name=clk|port=clk|period_ns=10.000|status=created" in markers
assert markers[-1]=="B06_OOC_END|run_id=b46|top=deepeye_scan_lane_stream|status=artifact_complete"
assert not re.search(r"^(ERROR:|FATAL:|B06_OOC_TCL_ERROR\|)",stdout+"\n"+stderr,re.M)
assert not any("B06_OOC_" in line for line in stderr.splitlines())
outputs={}
(A/"reports").mkdir()
for rel in ("reports/utilization.rpt","reports/timing_summary.rpt","reports/check_timing.rpt","reports/drc.rpt","ooc.dcp"):
    source=S/rel;target=A/rel
    assert source.is_file() and source.stat().st_size>0 and not target.exists()
    shutil.copyfile(source,target)
    assert sha(source)==sha(target)
    outputs[rel]=dict(original=record(source),export=record(target))
util=(A/"reports/utilization.rpt").read_text(encoding="utf-8")
usage={}
for name in ("Slice LUTs","Slice Registers","DSPs","Block RAM Tile","Register as Latch"):
    match=re.search(r"^\|\s*"+re.escape(name)+r"\*?\s*\|\s*([0-9,.]+)\s*\|",util,re.M)
    assert match is not None,name
    usage[name]=float(match[1].replace(",","")) if "." in match[1] else int(match[1].replace(",",""))
timing=(A/"reports/timing_summary.rpt").read_text(encoding="utf-8")
start=timing.index("WNS(ns)")
wns=re.search(r"^\s*(-?[0-9]+\.[0-9]+)\s+",timing[start:],re.M)
assert wns
checks=(A/"reports/check_timing.rpt").read_text(encoding="utf-8")
check_counts={name:int(count) for name,count in re.findall(r"^\d+\. checking ([a-z_]+) \((\d+)\)$",checks,re.M)}
assert check_counts["no_input_delay"]==452 and check_counts["no_output_delay"]==189
drc=(A/"reports/drc.rpt").read_text(encoding="utf-8")
drc_rules=[dict(rule=m[0],severity=m[1],description=m[2].strip(),checks=int(m[3])) for m in
           re.findall(r"^\|\s*([A-Z0-9_-]+)\s*\|\s*(Warning|Error|Critical Warning)\s*\|\s*([^|]+)\|\s*(\d+)\s*\|",drc,re.M)]
assert drc_rules==[dict(rule="ZPS7-1",severity="Warning",description="PS7 block required",checks=1)]
warnings=[line for line in (stdout+"\n"+stderr).splitlines() if line.startswith("WARNING:")]
critical=[line for line in (stdout+"\n"+stderr).splitlines() if line.startswith("CRITICAL WARNING:")]
diagnostics=dict(wns_ns=float(wns[1]),utilization=usage,warnings=warnings,critical_warnings=critical,
                 console_warning_count=len(warnings),check_timing=check_counts,drc_rules=drc_rules,
                 drc_violation_count=1,markers=markers,
                 limitations=["Diagnostic10ns clock only after synth; no input/output delays.",
                              "HD.CLK_SRC unset: OOC clock delay/skew not estimated.",
                              "OOC connectivity DRC coverage incomplete; ZPS7-1 warning retained without waiver.",
                              "No placement/routing, timing closure, implementation or board acceptance."],
                 original_tcl_mapping="Pinned operation33 Tcl/comments/B06 marker names reused byte-identically for operation46.")
save(A/"DIAGNOSTICS.json",diagnostics)
old=load(A/"ORIGINAL_EVIDENCE_BEFORE.json")
assert all(sha(p)==h for p,h in old.items())
for ref in failed["input_pins"]:assert sha(ref["path"])==ref["sha256"]
assert sha(A/"snapshot/deepeye_scan_lane_stream.sv")=="b3c9d2024d9325191538cf08fec9a652ff8ff0ae316ec9af96078f85cf5be3cc"
assert sha(A/"snapshot/ooc_qualification.tcl")=="54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9"
binding=load(Path("D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/scan-lane-ooc-20261024-46/binding-private.json"))
assert binding["job_id"]==failed["job_id"] and binding["native_agent_id"]==failed["agent_id"]
result={
 "task":failed["task"],"work":failed["work"],"operation":failed["operation"],"job_id":failed["job_id"],
 "agent_id":failed["agent_id"],"turn_id":failed["turn_id"],"parent_id":failed["parent_id"],
 "status":"single_ooc_diagnostic_artifacts_collected","synthesis_complete":True,"report_export_complete":True,
 "vendor_launches":1,"vendor_replay":False,"source_edits":0,"parent_acceptance":"pending independent DCP review",
 "source_sha256":"b3c9d2024d9325191538cf08fec9a652ff8ff0ae316ec9af96078f85cf5be3cc",
 "contract":failed["contract"],"all_29_formal_cards":"not_run","B01":"not_run","B03":"not_run","B06":"not_run","R03":"not_run",
 "board":"not_run; A only","motion_grant":False,"timing_closure":"not_claimed","input_pins":failed["input_pins"],
 "actual_process":process,"outputs":outputs,"diagnostics":diagnostics,
 "driver_failure_preserved":dict(path=str(A/"RESULT.json"),sha256=sha(A/"RESULT.json"),exit_code=1,
   reason="Initial driver required zero for every helper process; two actual findstr.exe exits1 caused classification to stop before exports. Original cmd/Vivado exits0, all12 actual child exits retained, active0. This collection does not suppress those exits or rewrite that failure.",
   nonzero_helpers=nonzero),
 "original44_44r1_evidence_files_unchanged":len(old),
 "evidence_collection":dict(script=record(Path(__file__)),python=sys.executable,pid=os.getpid(),argv=sys.argv,
                           cwd=os.getcwd(),new_process_or_vendor_launch=False,ended_utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),
 "raw_logs":{p.name:record(p) for p in sorted((A/"logs").glob("*")) if p.is_file()},
 "spec":failed["spec"],"main_acceptance_receipt":failed["main_acceptance_receipt"],
 "busy_gate":record(A/"BUSY_GATE.json"),"artifact_manifest":str(A/"ARTIFACT_MANIFEST.json")
}
save(A/"FINAL_RESULT.json",result)
print(json.dumps(dict(status=result["status"],result=str(A/"FINAL_RESULT.json"),result_sha256=sha(A/"FINAL_RESULT.json"),
                      dcp_sha256=sha(A/"ooc.dcp"),diagnostics=diagnostics,original_evidence_unchanged=len(old)),ensure_ascii=True))
