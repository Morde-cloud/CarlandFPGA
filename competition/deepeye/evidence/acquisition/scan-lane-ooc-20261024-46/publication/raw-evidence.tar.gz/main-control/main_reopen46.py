from pathlib import Path
import ast,datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/acquisition/scan-lane-ooc-20261024-46';A=E/'author';O=E/'main/reopen-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
t=get(D/'native-terminal.json')[0];assert t['terminal'] and t['status']=='completed' and not t['stale'];tr=json.loads(t['result']['text']);assert sha(Path(tr['result']))==tr['result_sha256'];assert sha(A/'ARTIFACT_MANIFEST.json')==tr['artifact_manifest_sha256']
O.mkdir(parents=True,exist_ok=False);verified={}
for v in get(A/'ARTIFACT_MANIFEST.json')['files']:
 p=A/v['path'];assert sha(p)==v['sha256'] and p.stat().st_size==v['bytes'];verified[v['path']]=v
process=get(A/'PROCESS.json');assert process['exit_code']==0 and not process['timed_out'] and process['job_accounting']['ActiveProcesses']==0 and len(process['members'])==process['job_accounting']['TotalProcesses']==12
nonzero=[m for m in process['members'] if m['exit_code']!=0];assert len(nonzero)==2 and all(Path(m['image']).name.lower()=='findstr.exe' and m['exit_code']==1 for m in nonzero)
vivado=[m for m in process['members'] if Path(m['image']).name.lower()=='vivado.exe'];assert len(vivado)==1 and vivado[0]['exit_code']==0
a=get(A/'FINAL_RESULT.json');assert a['vendor_launches']==1 and not a['vendor_replay'] and a['synthesis_complete'] and a['report_export_complete']
for v in a['input_pins']:assert sha(Path(v['path']))==v['sha256']
helper=R/'.local/deployment/node-b/evidence/b06-ooc-20261024-33/main_audit_and_reopen.py';nodes=[n for n in ast.parse(helper.read_text()).body if isinstance(n,ast.FunctionDef) and n.name in ('table','timing')];assert len(nodes)==2;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'));(O/'source_report_helper.py').write_bytes(helper.read_bytes())
dcp=A/'ooc.dcp';assert sha(dcp)==tr['dcp_sha256']=='eeb32fb10b50ec3633da1bd9bdc6c1d862f68df56ba9b22b012fc304f7cf4591';resource=table(A/'reports/utilization.rpt');times=timing(A/'reports/timing_summary.rpt');assert resource=={'Slice LUTs':97,'Slice Registers':451,'Block RAM Tile':0,'DSPs':0} and times['WNS']=='7.172'
q=lambda p:'{'+p.as_posix()+'}';script=O/'reopen.tcl';script.write_text('\n'.join(['set_param general.maxThreads 2','puts "MAIN46_REOPEN_BEGIN"','open_checkpoint '+q(dcp),'puts "MAIN46_DESIGN|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"','foreach c [get_clocks] {puts "MAIN46_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}','report_utilization -file '+q(O/'utilization.rpt'),'report_timing_summary -file '+q(O/'timing_summary.rpt'),'report_timing -delay_type max -max_paths 10 -path_type full_clock_expanded -input_pins -file '+q(O/'critical_paths.rpt'),'close_design','puts "MAIN46_REOPEN_END"','exit 0'])+'\n')
env=os.environ.copy()
for n in ('work','tmp','cache'):(O/n).mkdir()
for k in ('TEMP','TMP','TMPDIR'):env[k]=str(O/'tmp')
env['XILINX_LOCAL_USER_DATA']=str(O/'cache');tool=Path('D:/pynq/AMD2026/2026.1/Vivado/bin/vivado.bat');assert sha(tool)=='a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b'
argv=[r'C:\Windows\System32\cmd.exe','/d','/c',str(tool),'-mode','batch','-nojournal','-nolog','-notrace','-source',str(script)];put(O/'INTENT.json',{'argv':argv,'cwd':str(O/'work'),'script_sha256':sha(script),'dcp_sha256':sha(dcp),'scope':'Exact DCP read/report only; no synthesis or implementation'});start=time.monotonic();p=subprocess.Popen(argv,cwd=O/'work',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(O/'STARTED.json',{'pid':p.pid});timed=False
try:b,e=p.communicate(timeout=240)
except subprocess.TimeoutExpired:timed=True;p.kill();b,e=p.communicate()
(O/'stdout.bin').write_bytes(b);(O/'stderr.bin').write_bytes(e);put(O/'PROCESS.json',{'pid':p.pid,'exit_code':p.returncode,'timed_out':timed,'elapsed':time.monotonic()-start,'stdout_sha256':sha(O/'stdout.bin'),'stderr_sha256':sha(O/'stderr.bin')});assert p.returncode==0 and not timed;raw=b.decode();assert not re.search(r'^\s*(ERROR:|CRITICAL WARNING:)',raw,re.M)
assert [l for l in raw.splitlines() if l.startswith('MAIN46_')]==['MAIN46_REOPEN_BEGIN','MAIN46_DESIGN|part=xc7z020clg400-1|ports=642|clocks=1','MAIN46_CLOCK|name=clk|period=10.000','MAIN46_REOPEN_END']
assert table(O/'utilization.rpt')==resource and timing(O/'timing_summary.rpt')==times and sha(dcp)==tr['dcp_sha256']
diag=get(A/'DIAGNOSTICS.json');assert diag['console_warning_count']==2 and diag['drc_violation_count']==1 and diag['check_timing']['no_input_delay']==452 and diag['check_timing']['no_output_delay']==189
r={'status':'OOC_ARTIFACTS_VERIFIED_DIAGNOSTIC_TIMING_MET','operation_id':'B-DEEPEYE-SCAN-LANE-OOC-20261024-46','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','source_sha256':tr['source_sha256'],'dcp_sha256':sha(dcp),'resources':resource,'timing':times,'actual_syntheses':1,'actual_main_dcp_reopens':1,'main_process_exit':0,'verified_author_artifacts':len(verified),'original_nonzero_helpers':nonzero,'author_driver_failure':'Initial driverexit1 aftertwofindstr.exe exits1. Preserved original process/log/result. Separate no-process collector exported existing artifacts, no vendor replay.','scope':'One10ns post-synth diagnostic, +7.172ns not timingclosure;2consolewarnings/1ZPS7-1DRC/452inputand189outputdelaygaps andHD.CLK_SRCunset retained. No route/implementation/CDC_RDC/board/system/ABIgrant; all29/B01/B03/B06/R03/fullproductnot_run. A-onlyboard.'};put(O/'RESULT.json',r);put(O/'VERIFIED_AUTHOR_FILES.json',verified);print(json.dumps(r))
