"""Final author record for the fresh parser-only repair lease."""
import hashlib
import json
import os
from pathlib import Path
import sys
import datetime

A=Path(__file__).resolve().parent
P=A.parents[3]
OLD=A.parent/"author"
PRIVATE=Path("D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/scan-lane-qualifier-repair-20261024-44r1")
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
check=load(A/"check-02/RESULT.json")
assert check["status"]=="pass" and check["false_accepts"]==check["false_rejects"]==0
assert check["correction_cycles_used"]==1
assert os.environ["CODEX_THREAD_ID"]=="01a16a34-b419-7942-9a7b-2b033142446b"
binding=load(PRIVATE/"binding-reconciled-private.json")
allowed={"job_id","task_id","task_version","work_id","route","status","native_agent_id",
         "execution_allowed","terminal","stale","ownership"}
binding_fields=[]
def select(obj,path=""):
    if isinstance(obj,dict):
        for key,value in obj.items():
            if key in allowed:
                binding_fields.append(dict(field=path+"/"+key,value=value))
            elif isinstance(value,(dict,list)):
                select(value,path+"/"+key)
    elif isinstance(obj,list):
        for i,value in enumerate(obj):select(value,path+"/"+str(i))
select(binding)
assert any(x["field"].endswith("/job_id") and x["value"]=="child-ea186decdf6143b79bfcd2600f987977" for x in binding_fields)
assert any(x["field"].endswith("/native_agent_id") and x["value"]=="01a16a34-b419-7942-9a7b-2b033142446b" for x in binding_fields)
save(A/"BINDING_PUBLIC_FIELDS.json",binding_fields)
before=load(A/"original_before.json")
now={p.relative_to(OLD).as_posix():sha(p) for p in sorted(OLD.rglob("*")) if p.is_file()}
assert now=={rel:v["sha256"] for rel,v in before["original_author_inventory"].items()}
for ref in before["protected"]:assert sha(ref["path"])==ref["sha256"]
runner=P/"tools/acquisition/run_scan_lane_stream.py"
assert sha(runner)==check["runner_sha256"]
assert sha(OLD/"RESULT.json")=="78708daeca40df013d6b347760e3348fc82a711e23089e0144a0fd8fbf54e8a4"
assert load(OLD/"RESULT.json")["status"]=="failed_parser_qualification_preserved"
spec=PRIVATE/"MAIN_SPEC.md"
(A/"MAIN_SPEC.snapshot.md").write_bytes(spec.read_bytes())
processes=[load(p) for p in sorted((A/"processes").glob("*.json")) if not p.name.endswith(".started.json")]
assert len(processes)==4
assert sorted(p["exit_code"] for p in processes)==[0,0,0,1]
result={
 "task":"DEEPEYE-IMPLEMENTATION-20261014/v1","work":"B-SCAN-LANE-QUALIFIER-REPAIR-20261024-44r1-v1","operation":"B-DEEPEYE-SCAN-LANE-STREAM-20261024-44",
 "job_id":"child-ea186decdf6143b79bfcd2600f987977","actual_agent_id":"01a16a34-b419-7942-9a7b-2b033142446b","actual_turn_id":"01a16d4c-d69e-74b3-8a22-150c6629acfa","parent_id":"01a13b55-095b-7461-8dd5-5476a130bd82",
 "status":"pass_saved_log_qualifier_repair_only","parent_acceptance":"pending independent main review; does not promote original44 failure",
 "ownership":["tools/acquisition/run_scan_lane_stream.py","evidence/acquisition/scan-lane-stream-20261024-44/author-qualifier-repair1/"],
 "spec":dict(path=str(spec),sha256=sha(spec)),"lease_validation":"actual CLI native_validate execution_allowed=true and canonical agent recorded in PREFLIGHT.json",
 "contract":{"id":"DEEPEYE-HUMAN-LOCK-20261014/revision1","commit":"f5989cd5defce561f9ba98e6b18fc2682945f0a2","requirements_sha256":"c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804","ids":[f"H{i:02d}" for i in range(1,16)],"verified":"pinned full requirements read and canonical hash matched, PREFLIGHT.json","frozen_design":"1011259415a0916054eb580687612580bc1e5f09"},
 "all_29_formal_cards":"not_run","physical_board_authority":"A only",
 "scope_limitations":"ModelSim10.7 saved-log grammar repair, not log authentication or new RTL/capture proof. Zero vendor launches; no RTL/TB/notes/old-author/main-evidence edits.",
 "runner":{"path":str(runner),"before_sha256":sha(A/"original_runner.py"),"after_sha256":sha(runner),"changed_ast_nodes":check["changed_ast_nodes"],"diff":str(A/"check-02/runner.diff"),"snapshot":str(A/"check-02/repaired_runner.py")},
 "repair":"Global literal occurrence count and exact-position check for $finish, Time:, Iteration:, Instance:, End time:, Elapsed time:, Errors:, Warnings:, Start time:. Existing exact terminal grammar, SL_/control/error checks and public trace reconciliation retained.",
 "qualification":check,
 "frozen_expected":dict(path=str(A/"EXPECTED_CLASSIFICATION_v2.json"),sha256=sha(A/"EXPECTED_CLASSIFICATION_v2.json"),freeze_sha256=sha(A/"FREEZE_v2.json")),
 "original_failure":dict(job_id="child-b9a99bec1d9b42359a9ac31150dc7817",status="failed",result=str(OLD/"RESULT.json"),result_sha256=sha(OLD/"RESULT.json"),unchanged_original_artifacts=230,manifest_unchanged=True,total_files_including_manifest=231),
 "read_only_inputs":before["protected"],
 "preserved_failed_attempt":{"path":str(A/"check-01/RESULT.json"),"exit_code":1,"reason":"Four independently frozen negative fixtures were byte-identical to valid LF logs: relocating the already-last footer to the end was a no-op. All six original false accepts were rejected by the first parser fix.",
 "allowed_correction":"One bounded correction changed only those mutation bytes and matching qualify case generator; v1 matrix, raw logs, code and failed process retained. Expected reject classification unchanged; v2 frozen before second parser invocation.","proof":str(A/"FIXTURE_CORRECTION.json")},
 "actual_python_processes":processes,"python":dict(executable=sys.executable,version=sys.version,sha256=sha(sys.executable)),
 "commands_and_raw_logs":str(A/"processes"),"preflight":str(A/"PREFLIGHT.json"),"artifact_manifest":str(A/"ARTIFACT_MANIFEST.json"),
 "finalized_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
 "completion_route":"supported project_cli native_complete with private UTF8 args; separate fresh terminal result"
}
save(A/"RESULT.json",result)
print(json.dumps(dict(status=result["status"],result=str(A/"RESULT.json"),result_sha256=sha(A/"RESULT.json"),
                      runner_sha256=sha(runner),expected_sha256=sha(A/"EXPECTED_CLASSIFICATION_v2.json"),
                      negatives=check["rejected"],positives=check["accepted"],original_files_preserved=len(now))))
