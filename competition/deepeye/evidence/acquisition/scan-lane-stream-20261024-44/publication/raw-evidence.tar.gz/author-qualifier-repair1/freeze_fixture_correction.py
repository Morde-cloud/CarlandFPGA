"""Preserve v1; correct four independently proven no-op negative mutations."""
from pathlib import Path
import hashlib
import json

A=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_text(encoding="utf-8"))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
old=load(A/"FREEZE.json")
assert sha(A/"EXPECTED_CLASSIFICATION.json")==old["expected_matrix_sha256"]
matrix=load(A/"EXPECTED_CLASSIFICATION.json")
observed=load(A/"check-01/RESULT.json")
assert len(observed["mismatches"])==4
mismatch_names={c["name"] for c in observed["mismatches"]}
assert mismatch_names=={f"m{m}_{label}_relocated_to_end" for m in (0,1) for label in ("errors","warnings")}
fixdir=A/"frozen-correction"
fixdir.mkdir()
proof=[]
for c in matrix["cases"]:
    if c["name"] in mismatch_names:
        baseline=next(x for x in matrix["cases"] if x["name"]==f"m{c['mode']}_positive_lf")
        assert c["log"]["sha256"]==baseline["log"]["sha256"]
        assert Path(c["log"]["path"]).read_bytes()==Path(baseline["log"]["path"]).read_bytes()
        lines=Path(c["log"]["path"]).read_bytes().decode("utf-8").removesuffix("\n").split("\n")
        assert lines[-1]=="# Errors: 0, Warnings: 0"
        data=("\n".join([lines[-1]]+lines[:-1])+"\n").encode("utf-8")
        assert data!=Path(c["log"]["path"]).read_bytes()
        path=fixdir/(c["name"].replace("_relocated_to_end","_relocated")+".log")
        path.write_bytes(data)
        proof.append(dict(original_name=c["name"],original_log=c["log"],byte_identical_positive=baseline["log"],
                          correction="Move final footer to the beginning instead; negative classification unchanged.",
                          corrected_log=dict(path=str(path),sha256=sha(path))))
        c["log"]=dict(path=str(path),sha256=sha(path),bytes=len(data))
    if c["group"]=="target_provenance" and c["name"].endswith("_relocated_to_end"):
        c["name"]=c["name"].removesuffix("_to_end")
matrix["correction"]="One permitted correction: four last-line relocations were no-op fixtures. Original v1 frozen files and failed check preserved. New v2 classification fixed before repaired parser invocation."
save(A/"EXPECTED_CLASSIFICATION_v2.json",matrix)
save(A/"FIXTURE_CORRECTION.json",dict(prior_freeze_sha256=sha(A/"FREEZE.json"),cases=proof,parser_terminal_stats_changed=False))
freeze=dict(expected_matrix_sha256=sha(A/"EXPECTED_CLASSIFICATION_v2.json"),original_runner_sha256=old["original_runner_sha256"],
            prior_expected_matrix_sha256=old["expected_matrix_sha256"],correction_sha256=sha(A/"FIXTURE_CORRECTION.json"),
            case_count=len(matrix["cases"]),expected_accepts=matrix["expected_accepts"],expected_rejects=matrix["expected_rejects"],
            counts=matrix["counts"],correction_cycles_used=1,correction_cycles_limit=1)
save(A/"FREEZE_v2.json",freeze)
print(json.dumps(freeze))
