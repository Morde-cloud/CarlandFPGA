"""Freeze independent saved-file classification before invoking the fixed parser."""
import hashlib
import json
from pathlib import Path
import re
import sys
from collections import Counter

sys.dont_write_bytecode = True
A = Path(__file__).resolve().parent
P = A.parents[3]
OLD = A.parent / "author"
RUNNER = P / "tools/acquisition/run_scan_lane_stream.py"


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def save(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")


def load(p):
    return json.loads(p.read_text(encoding="utf-8"))


def file_ref(p):
    return dict(path=str(p), sha256=sha(p), bytes=p.stat().st_size)


assert sha(RUNNER) == "f3c3c21238dfc331f1bb6398d386efc488bf08b38eddbd2c8fe480aa208b4db1"
assert not (A/"original_runner.py").exists(), "do not replay fixture freeze"
(A/"original_runner.py").write_bytes(RUNNER.read_bytes())
old_manifest = load(OLD/"ARTIFACT_MANIFEST.json")
assert sha(OLD/"ARTIFACT_MANIFEST.json") == "12b0cc2f3879fe1b73d227d2d51c03df324985ba725b75b5a75e283497a7a1ea"
assert len(old_manifest["files"]) == 230
for entry in old_manifest["files"]:
    path = OLD/entry["path"]
    assert path.is_relative_to(OLD) and sha(path) == entry["sha256"] and path.stat().st_size == entry["bytes"], str(path)
inventory = {p.relative_to(OLD).as_posix():file_ref(p) for p in sorted(OLD.rglob("*")) if p.is_file()}
assert len(inventory) == 231  # original 230 files, plus their self-excluded manifest
protected = {
    P/"fpga/acquisition/deepeye_scan_lane_stream.sv":"b3c9d2024d9325191538cf08fec9a652ff8ff0ae316ec9af96078f85cf5be3cc",
    P/"tests/rtl/acquisition/tb_scan_lane_stream.sv":"0105ec93b9e78395615c98737459ac260ba8dfdc3f74a30f2572fe1504261828",
    P/"fpga/acquisition/scan_lane_stream_candidate.md":"a280054f3e85f266ce71dae5982a344c58fb0ad8b608889b30b81bf271abad77",
    P.parents[1]/"handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json":"6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8",
}
source39 = load(OLD/"attempt-03/RESULT.json")["sources"]
for rel, v in source39.items():
    if rel.startswith("fpga/acquisition/") and "scan_lane_stream" not in rel:
        protected[P/rel] = v["sha256"]
for path, wanted in protected.items():
    assert sha(path) == wanted, str(path)
save(A/"original_before.json", dict(original_author_inventory=inventory, fixed_manifest_entries=230,
                                   protected=[dict(path=str(p),sha256=h) for p,h in protected.items()],
                                   original_runner=file_ref(RUNNER)))

outdir = A/"frozen"
outdir.mkdir()
cases, modes = [], {}
old_result = load(OLD/"attempt-03/RESULT.json")
finish = old_result["finish_provenance"]


def add(name, group, mode, expect, raw, trace, metadata=None, data=None, recipe=None):
    if data is not None:
        raw = outdir/(name+".log")
        raw.write_bytes(data)
    case = dict(name=name,group=group,mode=mode,expect_accept=expect,
                log=file_ref(raw),trace=file_ref(trace),tb_path=metadata or finish["path"],
                finish_line=finish["line"])
    if recipe is not None:
        case["trace_recipe"] = recipe
    cases.append(case)


for mode, folder_name in ((0,"standalone"),(1,"integration39")):
    folder = OLD/"attempt-03"/folder_name
    fixture = load(folder/"fixture.json")
    assert fixture["mode"] == mode
    # Independently check exact saved stimulus bytes against the frozen fixture.
    table = [f"{len(fixture['records'])} {len(fixture['stream'])} {len(fixture['rows'])}"]
    table += [" ".join([r["packed"],*r["lanes"]]) for r in fixture["records"]]
    table += [str(r) for r in fixture["stream"]]
    table += [f"{s} {c:x} {r} {p:032x}" for s,c,r,p in fixture["rows"]]
    assert (folder/"stimulus.txt").read_text(encoding="ascii").splitlines() == table
    expected_stats = next(m["stats"] for m in old_result["modes"] if m["mode"]==mode)
    modes[str(mode)] = dict(fixture=file_ref(folder/"fixture.json"),stimulus=file_ref(folder/"stimulus.txt"),
                            expected_stats=expected_stats)
    baseline = folder/"modelsim.log"
    trace = folder/"public.trace"
    text = baseline.read_bytes().decode("utf-8")
    lines = text.replace("\r\n","\n").removesuffix("\n").split("\n")
    at = next(i for i,l in enumerate(lines) if l.startswith("# SL_SUMMARY "))
    assert len(lines)==at+6
    start_index = next(i for i,l in enumerate(lines) if l.startswith("# Start time: "))
    unicode_path = str(Path(finish["path"]).parent/"语法正例"/Path(finish["path"]).name).replace("\\","/")
    for positive, path, metadata in (
        ("actual",baseline,None),
        ("crlf",folder/"qualifier/positive-crlf.log",None),
        ("unicode_grammar",folder/"qualifier/positive-unicode-grammar-only.log",unicode_path),
    ):
        add(f"m{mode}_original_positive_{positive}","original_positive",mode,True,path,trace,metadata)
    q = load(folder/"qualifier/qualification.json")
    assert len(q["negatives"])==37
    for n in q["negatives"]:
        if "raw" in n:
            assert sha(n["raw"])==n["sha256"]
            add(f"m{mode}_original_negative_{n['name']}","original_negative",mode,False,Path(n["raw"]),trace)
        else:
            assert sha(n["trace_base"])==n["trace_sha256"]==sha(trace)
            add(f"m{mode}_original_negative_{n['name']}","original_negative",mode,False,baseline,trace,recipe=n["recipe"])
    # Each reserved literal's expected line is taken from actual bytes, not parser helpers.
    tokens = [
        ("finish","$finish",at+2),("time","Time:",at+3),("iteration","Iteration:",at+3),
        ("instance","Instance:",at+3),("end","End time:",at+4),("elapsed","Elapsed time:",at+4),
        ("errors","Errors:",at+5),("warnings","Warnings:",at+5),("start","Start time:",start_index),
    ]
    for label, token, index in tokens:
        original = lines[index]
        badline = original.replace(token,token+"CONFLICT",1)
        variants = {
            "prepend_same":[original]+lines,
            "prepend_conflict":[badline]+lines,
            "interleave_same":lines[:at]+[original]+lines[at:],
            "interleave_conflict":lines[:at]+[badline]+lines[at:],
            "append_same":lines+[original],
            "append_conflict":lines+[badline],
            "substring_early":["untrusted<"+token+">fragment"]+lines,
            "leading_altered":lines[:index]+["prefix "+original]+lines[index+1:],
            "trailing_altered":lines[:index]+[original+" suffix"]+lines[index+1:],
            "inline_duplicate":lines[:index]+[original+" "+token]+lines[index+1:],
            "nul":lines[:index]+[original+"\x00"]+lines[index+1:],
            "bare_cr":lines[:index]+[original+"\rfragment"]+lines[index+1:],
        }
        without = lines[:index]+lines[index+1:]
        variants["relocated_to_end"] = without+[original]
        for variant, altered in variants.items():
            add(f"m{mode}_{label}_{variant}","target_provenance",mode,False,None,trace,
                data=("\n".join(altered)+"\n").encode("utf-8"))
    for n in range(6):
        add(f"m{mode}_truncated_terminal_{n}","target_incomplete",mode,False,None,trace,
            data=("\n".join(lines[:at+n])+"\n").encode("utf-8"))
    for name, data in (
        ("empty",b""),("truncated_summary",("\n".join(lines[:at])+"\n# SL_SUMMARY mode=").encode()),
        ("prefixed_whole_terminal",("\n".join(lines[at:]+lines)+"\n").encode()),
        ("unknown_sl_substring",("noiseSL_unknown\n"+text).encode()),
        ("conflicting_stats_footer",("\n".join(lines[:at]+["# Errors: 99, Warnings: 99"]+lines[at:])+"\n").encode()),
        ("start_substring",("noiseStart time:invalid\n"+text).encode()),
    ):
        add(f"m{mode}_{name}","target_incomplete",mode,False,None,trace,data=data)
    lf = "\n".join(lines)+"\n"
    add(f"m{mode}_positive_lf","additional_positive",mode,True,None,trace,data=lf.encode("utf-8"))
    uni = lf.replace(finish["path"],unicode_path)
    assert uni!=lf
    add(f"m{mode}_positive_unicode_lf","additional_positive",mode,True,None,trace,
        metadata=unicode_path,data=uni.encode("utf-8"))
    add(f"m{mode}_positive_unicode_crlf","additional_positive",mode,True,None,trace,
        metadata=unicode_path,data=uni.replace("\n","\r\n").encode("utf-8"))
    # Metadata mismatches must remain negative even with syntactically valid UTF8.
    add(f"m{mode}_negative_unicode_metadata","target_metadata",mode,False,None,trace,data=uni.encode("utf-8"))
    add(f"m{mode}_negative_finish_line_metadata","target_metadata",mode,False,baseline,trace)
    cases[-1]["finish_line"] += 1

audit = load(OLD/"post-run-provenance-audit/RESULT.json")
assert audit["false_accepts"]==6
for case in audit["cases"]:
    assert not case["rejected"]
    add("old_six_"+case["name"],"original_six",0,False,Path(case["raw"]),OLD/"attempt-03/standalone/public.trace")

assert len({c["name"] for c in cases})==len(cases)
counts=Counter(c["group"] for c in cases)
assert counts["original_positive"]==6 and counts["original_negative"]==74 and counts["original_six"]==6
matrix=dict(freeze_policy="Expected classifications fixed before repaired parser import/execution. All raw logs preserved; old trace negatives retain exact immutable recipes.",
            modes=modes,cases=cases,counts=dict(counts),expected_accepts=sum(c["expect_accept"] for c in cases),
            expected_rejects=sum(not c["expect_accept"] for c in cases),
            portability="UTF8 path/metadata saved-log grammar and LF/CRLF only; no vendor filesystem or authentication claim.")
save(A/"EXPECTED_CLASSIFICATION.json",matrix)
freeze={"expected_matrix_sha256":sha(A/"EXPECTED_CLASSIFICATION.json"),
        "original_runner_sha256":sha(A/"original_runner.py"),
        "fixture_builder_sha256":sha(Path(__file__)),"case_count":len(cases),
        "expected_accepts":matrix["expected_accepts"],"expected_rejects":matrix["expected_rejects"],
        "counts":dict(counts)}
save(A/"FREEZE.json",freeze)
print(json.dumps(freeze))
