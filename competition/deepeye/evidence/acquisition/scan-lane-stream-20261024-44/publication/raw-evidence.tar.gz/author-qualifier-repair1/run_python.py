"""Capture actual Python-only processes; fresh receipt name required."""
from pathlib import Path
import subprocess
import sys
import datetime
import hashlib
import json
import os

A=Path(__file__).resolve().parent
name, target, *arguments = sys.argv[1:]
assert Path(target).resolve().is_relative_to(A) and name.isascii() and name.replace("-","").isalnum()
logs=A/"processes"
logs.mkdir(exist_ok=True)
meta=logs/(name+".json")
assert not meta.exists(), "do not replay a completed process"
argv=[sys.executable,target,*arguments]
env=os.environ.copy()
env["PYTHONDONTWRITEBYTECODE"]="1"
record=dict(argv=argv,cwd=str(A.parents[3]),started_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
with (logs/(name+".stdout.log")).open("wb") as out,(logs/(name+".stderr.log")).open("wb") as err:
    p=subprocess.Popen(argv,cwd=A.parents[3],env=env,stdout=out,stderr=err,shell=False)
    record["pid"]=p.pid
    (logs/(name+".started.json")).write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
    record["exit_code"]=p.wait(timeout=120)
record["ended_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
for key in ("stdout","stderr"):
    path=logs/(name+"."+key+".log")
    record[key]=dict(path=str(path),sha256=hashlib.sha256(path.read_bytes()).hexdigest())
meta.write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
print(json.dumps(record))
print((logs/(name+".stdout.log")).read_bytes().decode("utf-8",errors="replace"))
print((logs/(name+".stderr.log")).read_bytes().decode("utf-8",errors="replace"))
sys.exit(record["exit_code"])
