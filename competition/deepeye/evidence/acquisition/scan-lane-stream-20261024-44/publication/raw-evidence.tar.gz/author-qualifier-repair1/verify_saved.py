"""Python-only replay of the independently frozen expected classification."""
import ast
from collections import Counter
import difflib
import hashlib
import json
from pathlib import Path
import runpy
import sys
import traceback

sys.dont_write_bytecode = True
A = Path(__file__).resolve().parent
P = A.parents[3]
OLD = A.parent/"author"
RUNNER = P/"tools/acquisition/run_scan_lane_stream.py"
OUT = A/"check-02"


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def load(p):
    return json.loads(Path(p).read_text(encoding="utf-8"))


def save(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2)+"\n", encoding="utf-8", newline="\n")


assert not OUT.exists(), "preserve attempts; do not replay this verifier"
OUT.mkdir()
result = dict(status="running", scope="saved-file parser repair only",
              correction_cycles_used=1, correction_cycles_limit=1, vendor_launches=0)
try:
    freeze = load(A/"FREEZE_v2.json")
    assert sha(A/"EXPECTED_CLASSIFICATION_v2.json")==freeze["expected_matrix_sha256"]
    matrix = load(A/"EXPECTED_CLASSIFICATION_v2.json")
    assert sha(A/"original_runner.py")==freeze["original_runner_sha256"]
    original = (A/"original_runner.py").read_text(encoding="utf-8")
    repaired = RUNNER.read_text(encoding="utf-8")
    original_ast, repaired_ast = ast.parse(original), ast.parse(repaired)
    assert len(original_ast.body)==len(repaired_ast.body)
    changed_nodes = []
    for before, after in zip(original_ast.body,repaired_ast.body):
        if ast.dump(before,include_attributes=False)!=ast.dump(after,include_attributes=False):
            assert isinstance(before,ast.FunctionDef) and isinstance(after,ast.FunctionDef) and before.name==after.name
            changed_nodes.append(before.name)
    assert changed_nodes==["terminal_stats","qualify"], changed_nodes
    (OUT/"runner.diff").write_text("".join(difflib.unified_diff(original.splitlines(True),repaired.splitlines(True),
                                                        fromfile="original_runner.py",tofile="run_scan_lane_stream.py")),
                                 encoding="utf-8",newline="\n")
    (OUT/"repaired_runner.py").write_bytes(RUNNER.read_bytes())
    result.update(expected_matrix_sha256=freeze["expected_matrix_sha256"],runner_sha256=sha(RUNNER),
                  original_runner_sha256=sha(A/"original_runner.py"),changed_ast_nodes=changed_nodes)
    input_hashes = {}
    for case in matrix["cases"]:
        for ref in (case["log"],case["trace"]):
            input_hashes[ref["path"]]=ref["sha256"]
    for m in matrix["modes"].values():
        for key in ("fixture","stimulus"):
            input_hashes[m[key]["path"]]=m[key]["sha256"]
    for path,wanted in input_hashes.items():
        assert sha(path)==wanted,path
    module = runpy.run_path(str(RUNNER))
    # Even an accidental call through the runner cannot start a vendor process.
    def forbidden_process(*args, **kwargs):
        result["vendor_launch_attempts"] = result.get("vendor_launch_attempts",0)+1
        raise AssertionError("process creation is forbidden in saved-file verification")
    module["subprocess"].Popen = forbidden_process
    fixtures = {int(k):load(v["fixture"]["path"]) for k,v in matrix["modes"].items()}
    trace_cache = {}
    for c in matrix["cases"]:
        path = c["trace"]["path"]
        if path not in trace_cache:
            trace_cache[path] = Path(path).read_bytes().decode("ascii").splitlines(keepends=True)
    classifications = []
    for case in matrix["cases"]:
        traces = trace_cache[case["trace"]["path"]]
        if "trace_recipe" in case:
            # Match the immutable original recipe's text-mode newline handling.
            traces = [line.replace("\r\n","\n") for line in traces]
            recipe = case["trace_recipe"]
            if "remove_index" in recipe:
                del traces[recipe["remove_index"]]
            elif "insert_index" in recipe:
                traces.insert(recipe["insert_index"],recipe["value"])
            elif "append" in recipe:
                traces.append(recipe["append"])
            else:
                traces[recipe["index"]]=recipe["replacement"]
        text = Path(case["log"]["path"]).read_bytes().decode("utf-8")
        outcome = dict(name=case["name"],group=case["group"],mode=case["mode"],expected_accept=case["expect_accept"])
        try:
            actual = module["check_saved"](text,iter(traces),fixtures[case["mode"]],case["tb_path"],case["finish_line"])
        except ValueError as error:
            outcome.update(actual_accept=False,error=str(error))
        else:
            outcome.update(actual_accept=True,stats=actual["stats"])
            assert actual["stats"]==matrix["modes"][str(case["mode"])]["expected_stats"], "positive counter reconciliation"
        outcome["matches_expected"] = outcome["actual_accept"]==outcome["expected_accept"]
        classifications.append(outcome)
    save(OUT/"classifications.json",classifications)
    failures = [c for c in classifications if not c["matches_expected"]]
    result.update(frozen_cases=len(classifications),accepted=sum(c["actual_accept"] for c in classifications),
                  rejected=sum(not c["actual_accept"] for c in classifications),mismatches=failures,
                  group_counts=dict(Counter(c["group"] for c in classifications)))
    assert not failures, "frozen classification mismatch"
    # Exercise the runner's targeted qualify cases too. Every generated log or
    # trace recipe must match a fixture whose expected classification was frozen.
    qualifiers = []
    for mode, folder_name in ((0,"standalone"),(1,"integration39")):
        folder = OLD/"attempt-03"/folder_name
        tb = next(c["tb_path"] for c in matrix["cases"] if c["mode"]==mode and c["group"]=="original_positive")
        finish_line = next(c["finish_line"] for c in matrix["cases"] if c["mode"]==mode)
        qfolder = OUT/("qualify-mode-"+str(mode))
        summary = module["qualify"](qfolder,(folder/"modelsim.log").read_bytes().decode("utf-8"),
                                    folder/"public.trace",fixtures[mode],tb,finish_line)
        assert summary==dict(negative_count=154,false_accepts=0,positive_count=3),summary
        expected = {}
        for c in matrix["cases"]:
            if c["mode"]!=mode:
                continue
            if c["group"]=="original_negative":
                expected[c["name"].removeprefix(f"m{mode}_original_negative_")]=c
            elif c["group"]=="target_provenance":
                expected[c["name"].removeprefix(f"m{mode}_")]=c
        observed = load(qfolder/"qualification.json")["negatives"]
        assert len(expected)==len(observed)==154
        for negative in observed:
            c = expected.pop(negative["name"])
            assert negative["rejected"]
            if "raw" in negative:
                assert sha(negative["raw"])==c["log"]["sha256"],negative["name"]
            else:
                assert negative["recipe"]==c["trace_recipe"],negative["name"]
        assert not expected
        qualifiers.append(dict(mode=mode,**summary,raw_inputs_match_frozen=True))
    result["built_in_qualify_replay"] = qualifiers
    before = load(A/"original_before.json")
    current_inventory = {p.relative_to(OLD).as_posix():sha(p) for p in sorted(OLD.rglob("*")) if p.is_file()}
    wanted_inventory = {rel:entry["sha256"] for rel,entry in before["original_author_inventory"].items()}
    assert current_inventory==wanted_inventory,"original author evidence changed"
    for entry in before["protected"]:
        assert sha(entry["path"])==entry["sha256"],entry["path"]
    for path,wanted in input_hashes.items():
        assert sha(path)==wanted,path
    save(OUT/"original_after.json",dict(original_author_inventory=current_inventory,
                                      protected=before["protected"],fixed_manifest_entries=230,
                                      actual_files_including_manifest=231,all_unchanged=True))
    assert sha(RUNNER)==result["runner_sha256"]
    assert not result.get("vendor_launch_attempts")
    result.update(status="pass",original_230_plus_manifest_unchanged=True,protected_inputs_unchanged=True,
                  false_accepts=0,false_rejects=0,portability=matrix["portability"])
except Exception as error:
    result.update(status="failed_preserved",error=type(error).__name__+": "+str(error),traceback=traceback.format_exc())
    save(OUT/"RESULT.json",result)
    raise
save(OUT/"RESULT.json",result)
print(json.dumps(result,ensure_ascii=True))
