# B scan-record lane serializer candidate44

Task DEEPEYE-IMPLEMENTATION-20261014/version1; work B-SCAN-LANE-STREAM-20261024-44-v1; operation B-DEEPEYE-SCAN-LANE-STREAM-20261024-44. Main01a13b55-095b-7461-8dd5-5476a130bd82 owns this design, decisions and independent acceptance. Original worker42 has actually completed and its lease is terminal; this is a new bounded assignment in the same Arendt context, not replay or a second director.

First read all H01-H15 at f5989cd5defce561f9ba98e6b18fc2682945f0a2, DEEPEYE-HUMAN-LOCK-20261014/revision1, and recompute requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 (canonical UTF8 ensure_ascii=False/sort_keys/separators). Frozen design1011259415a0916054eb580687612580bc1e5f09. Full3D/UI/solidcollision/freecamera/layout/equalblue-redfullpassage/hiddentruth/causalobservations/online3DPC-AI/bothcontrolchains remain mandatory. All29formalnot_run; A only physicalboard.

Why this next owned task: accepted39 closes capture-to-queue; raw-record-to-channel/block remains missing. Main selects a bounded, reversible field-preserving lane primitive now. It does not decide cadence, acquisition index, quality encoding, grouping, TRACE admission or any A-owned public ABI. The frame/command/global source identity gates remain open.

Read-only exact input commit PR30head782ee8883bccd7aadb0343e3da670644d61843f2/source05e70705176f67a92b157c9af985bc1e110a040e; all beneath D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye:
- fpga/acquisition/deepeye_buffered_scan_capture.sv c8a540db8122b8f5520582a0f1fa9be0c43cb54a62f03c7c4edc893906f28411
- fpga/acquisition/deepeye_sample_scan_capture.sv fc8064a11ac40b6ee59418994825f0fc550ee867954bd1f1ccd2c9464e52028d
- fpga/acquisition/deepeye_raw_scan_queue.sv 630e14803d82b3379517d91626de4ad7e7d3c509ad14363b3164031a5f633ee4
- fpga/acquisition/buffered_scan_capture_candidate.md c36d01bb248250ff83642dc44e6d236ebaf11e623bc0e2348f41fe8e3f0c8fdd

Implement new fixed-width top deepeye_scan_lane_stream; no parameters. Inputs clk,rst,cancel,in_valid; output in_ready. Input record fields in_data[63:0],in_ticks[255:0],in_quality[31:0],in_first_seq[31:0],in_last_seq[31:0],in_tag[31:0]. Outputs out_valid, input out_ready, out_channel[1:0],out_data[15:0],out_tick[63:0],out_quality[7:0],out_first_seq[31:0],out_last_seq[31:0],out_tag[31:0],out_last. One private whole-record holding slot and2bit lane counter only. No statistics, extra queues, arithmetic on source metadata or error/policy semantics.

Main-selected exact synchronous behavior:
1. Lane order0,1,2,3. For accepted record R, channelj outputs data bits16j+:16, tick bits64j+:64, quality bits8j+:8; first_seq,last_seq,tag copied unchanged on every lane. out_last only lane3 when out_valid. First/last are opaque record bounds, not inferred per-channel acquisition index. Do NOT generate first_seq+j, infer sourceclock, interpret tag as session/epoch, or reinterpret quality mask.
2. full is1 iff holding a record. out_valid=full&&!rst&&!cancel. in_ready=(!full || (out_valid && out_ready && lane==3))&&!rst&&!cancel. A transfer requires both valid and ready, pre-edge. No combinational payload fall-through. A record accepted on an idle edge becomes lane0valid after that edge, never same-edge consumed.
3. If final lane transfers and a new record also transfers, atomically replace entire record, lane=0,full=1. Otherwise final lane clears full. Earlier lane transfer increments lane and rejects any simultaneous in_valid while in_ready=0. No duplicate/lost/reordered lane. Stalled outputs remain stable irrespective of changing unaccepted input fields.
4. rst or cancel masks both handshake endpoints immediately and synchronously discards any unretired lanes on the edge, resets full/lane. No delayed lane or stale tag can reappear. These controls only own serializer state; capture stop/rearm and upstream queue_cancel remain independent external controls. Invalid payload values need not be cleared/zeroed. After release next valid record restarts at lane0.

Exclusive NEW writable paths under product root:
- fpga/acquisition/deepeye_scan_lane_stream.sv
- fpga/acquisition/scan_lane_stream_candidate.md
- tests/rtl/acquisition/tb_scan_lane_stream.sv
- tools/acquisition/run_scan_lane_stream.py
- evidence/acquisition/scan-lane-stream-20261024-44/author/
No edits to39/42/43/core/ABI/source protocols or main-owned evidence. Ordinary execution Flash/max priority; two actual HTTP402 failures retained, no billingretry. Native fallback is needed for local ModelSim/files/process evidence; no delegation of main design/acceptance.

Bounded actual validation: one author runner with standalone serializer public-port scoreboard and a small actual39->44 integration test using unchanged3input RTL modules. Check every accepted record against four emitted lanes and opaque bounds; prove stalls, input changes while blocked, final-lane same-edge replacement, full/empty, reset/cancel at each lane/stall/reload, alternating tags and maximum-width field values. Cover all lane values and both control types; fixed directed vectors plus seeded finite mix. Integration reuses39 capture behavior explicitly and only checks boundary transport/field preservation; do not claim new capture proof. Use independently computed transaction-list expected records, not a mirroredRTL model. Keep cycle-pre/post public raw traces, exact source/input/tool hashes, command argv/PID/cwd/exits and terminal markers. Qualifier must anchor unique completion/statistics and reject conflicting/missing/duplicate/footer/control-byte saved-log negatives. Pin actual TB finish provenance and avoid39's known false accepts. Valid Unicode local paths/CRLF accepted where tool actually supports them; no broad portability claim.

At most two bounded functional fix cycles, retaining first evidence; stop/report concrete fault when outside this limit, no unknown-outcome retry. No force/internal state writes. No synthesis/OOC/implementation/UART/TRACE/frame/control/board run in44. Main will write a distinct public transaction oracle and inspect exact diff/bytes/raw exits before acceptance. Source39 already published,42 separately mainreviewed local and not used here;43 separate OOC may run in parallel, no file overlap. Protect original codec input SHA6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8.

No Gitcommit/publication/peer/group/service/credentials/queues/installation or physical board action. Selfvalidate new lease with canonicalthread01a16a34-b419-7942-9a7b-2b033142446b before executing; completion through native_complete plus actual final report. Report real blockers with [需桌面回合]/[需本人操作] only to main. No speculative replacement tasks or second main. Full task cards remainnot_run.
