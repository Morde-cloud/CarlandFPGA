import sys,runpy,json
from pathlib import Path
sys.dont_write_bytecode=True
a=Path("D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/scan-lane-stream-20261024-44/author")
root=a.parents[3]
m=runpy.run_path(str(root/"tools/acquisition/run_scan_lane_stream.py"))
f=a/"attempt-03/standalone"
fixture=json.loads((f/"fixture.json").read_text(encoding="utf-8"))
result=json.loads((a/"attempt-03/RESULT.json").read_text(encoding="utf-8"))
tb=result["finish_provenance"]["path"]; fin=result["finish_provenance"]["line"]
text=(f/"modelsim.log").read_bytes().decode("utf-8")
lines=m["clean_lines"](text); at=next(i for i,v in enumerate(lines) if v.startswith("# SL_SUMMARY"))
cases={
"prefixed_duplicate_finish":lines[:at]+[lines[at+2]]+lines[at:],
"prefixed_conflicting_finish":lines[:at]+[lines[at+2].replace("tb_scan_lane_stream.sv","wrong.sv")]+lines[at:],
"prefixed_duplicate_footer":lines[:at]+[lines[-1]]+lines[at:],
"prefixed_conflicting_footer":lines[:at]+["# Errors: 9, Warnings: 4"]+lines[at:],
"prefixed_duplicate_time":lines[:at]+[lines[at+3]]+lines[at:],
"prefixed_conflicting_end":lines[:at]+["# End time: 00:00:00 on Oct 24,2026, Elapsed time: 0:00:00"]+lines[at:]
}
out=[]
d=a/"post-run-provenance-audit";d.mkdir()
for name,bad in cases.items():
 raw="\n".join(bad)+"\n"; p=d/(name+".log");p.write_bytes(raw.encode("utf-8"))
 try:
  with (f/"public.trace").open(encoding="ascii",newline="") as trace:m["check_saved"](raw,trace,fixture,tb,fin)
  out.append({"name":name,"rejected":False,"raw":str(p)})
 except ValueError as e:out.append({"name":name,"rejected":True,"error":str(e),"raw":str(p)})
r={"diagnostic":"additional finish-provenance uniqueness audit, no vendor execution or production edits","cases":out,"false_accepts":sum(not c["rejected"] for c in out)}
(d/"RESULT.json").write_text(json.dumps(r,indent=2)+"\n",encoding="utf-8")
print(json.dumps(r))

