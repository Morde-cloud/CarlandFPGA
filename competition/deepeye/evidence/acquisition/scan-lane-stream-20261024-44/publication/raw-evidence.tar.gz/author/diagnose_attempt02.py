import sys,runpy,json
from pathlib import Path
sys.dont_write_bytecode=True
root=Path("D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/scan-lane-stream-20261024-44/author").parents[3]
m=runpy.run_path(str(root/"tools/acquisition/run_scan_lane_stream.py"))
f=Path("D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/scan-lane-stream-20261024-44/author")/"attempt-02/standalone"
fixture=json.loads((f/"fixture.json").read_text(encoding="utf-8"))
with (f/"public.trace").open(encoding="ascii",newline="") as trace:
 r=m["check_trace"](trace,fixture)
out={"kind":"diagnostic trace-only check; warning-bearing attempt02 is NOT qualified","stats":r[0],"coverage":r[1]}
(Path("D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/scan-lane-stream-20261024-44/author")/"attempt-02/trace-only-diagnostic.json").write_text(json.dumps(out,indent=2)+"\n",encoding="utf-8")
print(json.dumps(out))

