from pathlib import Path
import hashlib,json,datetime,sys,os
A=Path("D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/scan-lane-stream-20261024-44/author")
P=A.parents[3]
W=P.parents[1]
def sh(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,obj):p.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def load(p):return json.loads(p.read_text(encoding="utf-8"))
attempt=load(A/"attempt-03/RESULT.json")
audit=load(A/"post-run-provenance-audit/RESULT.json")
history=load(A/"ATTEMPT_HISTORY.json")
pins=attempt["sources"]
finalsources={}
for rel,entry in pins.items():
 actual=sh(P/rel)
 if rel!="fpga/acquisition/scan_lane_stream_candidate.md":assert actual==entry["sha256"],rel
 finalsources[rel]={"path":str(P/rel),"sha256":actual,"attempt03_sha256":entry["sha256"],"post_run_change":rel=="fpga/acquisition/scan_lane_stream_candidate.md"}
protected=attempt["protected_input"]
assert sh(Path(protected["path"]))==protected["before_sha256"]==protected["after_sha256"]
for k,v in attempt["tool_hashes"].items():assert sh(v["path"])==v["sha256"],k
spec=Path("D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/scan-lane-stream-20261024-44/MAIN_SPEC.md")
(A/"MAIN_SPEC.snapshot.md").write_bytes(spec.read_bytes())
processes=[]
for folder in (A/"attempt-02/processes",A/"attempt-03/processes"):
 for p in sorted(folder.glob("*.json")):
  if not p.name.endswith(".running.json"):processes.append({"metadata":str(p),"sha256":sh(p),**load(p)})
r={
 "task":"DEEPEYE-IMPLEMENTATION-20261014/version1","work":"B-SCAN-LANE-STREAM-20261024-44-v1","operation":"B-DEEPEYE-SCAN-LANE-STREAM-20261024-44",
 "job_id":"child-b9a99bec1d9b42359a9ac31150dc7817","agent_id":"01a16a34-b419-7942-9a7b-2b033142446b","turn_id":"01a16d1f-5f58-7622-8d04-ac1943a28c6d","parent_id":"01a13b55-095b-7461-8dd5-5476a130bd82",
 "status":"failed_parser_qualification_preserved","functional_simulation":"pass","acceptance":"not_ready; parent owns independent review",
 "blocker":{"kind":"author software parser","desktop_assistance_required":False,"human_only_action_required":False,
 "description":"6 saved-log false accepts: prefix duplicate/conflicting finish, footer counters, time or end before the valid terminal block. Native simulation data reconcile, but parser provenance uniqueness is incomplete.",
 "repair_cycles_used":2,"repair_cycles_limit":2,"further_repairs_or_vendor_runs":"none; stopped at bound","evidence":str(A/"post-run-provenance-audit/RESULT.json")},
 "scope":{"spec":str(spec),"spec_sha256":sh(spec),"owned_paths":["fpga/acquisition/deepeye_scan_lane_stream.sv","fpga/acquisition/scan_lane_stream_candidate.md","tests/rtl/acquisition/tb_scan_lane_stream.sv","tools/acquisition/run_scan_lane_stream.py","evidence/acquisition/scan-lane-stream-20261024-44/author/"]},
 "contract":{"id":"DEEPEYE-HUMAN-LOCK-20261014/revision1","commit":"f5989cd5defce561f9ba98e6b18fc2682945f0a2","requirements_sha256":"c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804","requirements":[f"H{i:02d}" for i in range(1,16)],"verification":"full pinned read and canonical requirements hash in PREFLIGHT.json","frozen_design":"1011259415a0916054eb580687612580bc1e5f09"},
 "all_29_formal_cards":"not_run","synthesis_OOC_implementation_board":"not_run","board_authority":"A only",
 "source39":{"published_head":"782ee8883bccd7aadb0343e3da670644d61843f2","source":"05e70705176f67a92b157c9af985bc1e110a040e","coverage_reuse":"Published39 reused unchanged. Small integration checks boundary transport/field preservation only; no new capture proof."},
 "final_sources":finalsources,"protected_input":protected,"tool_hashes":attempt["tool_hashes"],"python":attempt["python"],
 "finish_provenance":attempt["finish_provenance"],"modes":attempt["modes"],
 "planned_qualification":{"negatives_rejected":sum(m["qualification"]["negative_count"] for m in attempt["modes"]),"false_accepts_in_planned_set":0,"limitation":"Additional audit supersedes this narrower result: six false accepts. CRLF positive tested; Unicode saved-log grammar positive only, no vendor Unicode filesystem claim."},
 "additional_provenance_audit":audit,
 "attempts":[{"path":str(A/"attempt-01/RESULT.json"),"status":"failed preflight; no ModelSim; runner protected path wrong; preserved", "runner_pid":"not captured; initial exec_command chunk88af94 exit1 recorded in ATTEMPT_HISTORY.json"},
 {"path":str(A/"attempt-02/RESULT.json"),"status":"failed qualification; standalone ModelSim exit0 with15 warnings; preserved","runner_process":load(A/"runner-attempt-02.process.json")},
 {"path":str(A/"attempt-03/RESULT.json"),"status":"narrow runner pass superseded by six audit false accepts","runner_process":load(A/"runner-attempt-03.process.json")}],
 "raw_vendor_processes":processes,"attempt_history":str(A/"ATTEMPT_HISTORY.json"),
 "final_git_receipt":str(A/"FINAL_GIT_RECEIPT.json"),"preflight":str(A/"PREFLIGHT.json"),"artifact_manifest":str(A/"ARTIFACT_MANIFEST.json"),
 "finalized_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"finalizer_process":{"pid":os.getpid(),"cwd":os.getcwd(),"argv":sys.argv}
}
save(A/"RESULT.json",r)
files=[p for p in A.rglob("*") if p.is_file() and p.name!="ARTIFACT_MANIFEST.json"]
manifest={"root":str(A),"files":[{"path":p.relative_to(A).as_posix(),"bytes":p.stat().st_size,"sha256":sh(p)} for p in sorted(files)]}
save(A/"ARTIFACT_MANIFEST.json",manifest)
print(json.dumps({"status":r["status"],"result":str(A/"RESULT.json"),"result_sha256":sh(A/"RESULT.json"),"manifest_sha256":sh(A/"ARTIFACT_MANIFEST.json"),"artifact_files":len(files),"bytes":sum(p.stat().st_size for p in files),"final_source_hashes":{k:v["sha256"] for k,v in finalsources.items()}},ensure_ascii=False))

