from pathlib import Path
import subprocess,json,sys,datetime
author=Path("D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/scan-lane-stream-20261024-44/author")
cwd=author.parents[3]
argv=[sys.executable,str(cwd/"tools/acquisition/run_scan_lane_stream.py"),"--out",str(author/"attempt-03")]
record={"argv":argv,"cwd":str(cwd),"started_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"kind":"actual author runner process","bounded_repair_cycle":2}
with (author/"runner-attempt-03.stdout.log").open("wb") as o,(author/"runner-attempt-03.stderr.log").open("wb") as e:
 p=subprocess.Popen(argv,cwd=cwd,stdout=o,stderr=e,shell=False);record["pid"]=p.pid
 (author/"runner-attempt-03.running.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
 record["exit_code"]=p.wait(timeout=240)
record["ended_utc"]=datetime.datetime.now(datetime.timezone.utc).isoformat()
(author/"runner-attempt-03.process.json").write_text(json.dumps(record,indent=2)+"\n",encoding="utf-8")
print(json.dumps(record))
print((author/"runner-attempt-03.stdout.log").read_text(encoding="utf-8"))
print((author/"runner-attempt-03.stderr.log").read_text(encoding="utf-8"))
sys.exit(record["exit_code"])

