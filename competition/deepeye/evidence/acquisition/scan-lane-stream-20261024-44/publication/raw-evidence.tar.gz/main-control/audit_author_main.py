from pathlib import Path
import datetime,hashlib,json,runpy,sys
sys.dont_write_bytecode=True
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/acquisition/scan-lane-stream-20261024-44';A=E/'author';O=E/'main/author-audit-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
O.mkdir(exist_ok=False)
files=read(A/'ARTIFACT_MANIFEST.json')['files']
for v in files:
 p=A/v['path'];assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256'],p
r=read(A/'RESULT.json');pins={}
for n,v in r['final_sources'].items():
 p=P/n;assert sha(p)==v['sha256'];pins[n]=sha(p)
 (O/p.name).write_bytes(p.read_bytes())
runner=P/'tools/acquisition/run_scan_lane_stream.py';assert sha(runner)=='f3c3c21238dfc331f1bb6398d386efc488bf08b38eddbd2c8fe480aa208b4db1'
m=runpy.run_path(str(runner));f=A/'attempt-03/standalone';fixture=read(f/'fixture.json');prov=r['finish_provenance'];rows=[]
for p in sorted((A/'post-run-provenance-audit').glob('*.log')):
 try:
  with (f/'public.trace').open(encoding='ascii',newline='') as trace:m['check_saved'](p.read_bytes().decode('utf-8'),trace,fixture,prov['path'],prov['line'])
  accepted=True;error=None
 except ValueError as ex:accepted=False;error=str(ex)
 rows.append({'path':str(p),'sha256':sha(p),'accepted':accepted,'error':error})
assert len(rows)==6 and all(x['accepted'] for x in rows)
for d in ('standalone','integration39'):
 f=A/'attempt-03'/d;fixture=read(f/'fixture.json')
 with (f/'public.trace').open(encoding='ascii',newline='') as trace:m['check_saved']((f/'modelsim.log').read_bytes().decode('utf-8'),trace,fixture,prov['path'],prov['line'])
commands=[]
for p in sorted(A.glob('attempt-*/processes/*.json')):
 v=read(p)
 if 'exit_code' not in v:continue
 for stream in ('stdout','stderr'):
  item=v[stream];assert sha(Path(item['path']))==item['sha256']
 commands.append({'receipt':str(p),'sha256':sha(p),'exit_code':v['exit_code'],'pid':v['pid'],'argv':v['argv']})
assert sha(P.parent/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
out={'status':'REJECT_QUALIFIER_SIX_FALSE_ACCEPTS_REPRODUCED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_artifacts_verified':len(files),'pins':pins,'saved_log_reproductions':rows,'commands':commands,'source_rtl_independent_execution':'not_yet_run','scope':'Author original actual terminal failed; immutable failures retained. Fresh explicit qualifier-only assignment required; do not rerun original vendor commands.'}
put(O/'RESULT.json',out);print(json.dumps({'status':out['status'],'artifacts':len(files),'commands':len(commands),'false_accepts':len(rows)}))
