from pathlib import Path
import datetime,hashlib,json,random
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;O=P/'evidence/acquisition/scan-lane-stream-20261024-44/main/preinspection-01';O.mkdir(parents=True,exist_ok=False)
SOURCE='''from collections import deque
INPUTS=[('rst',1),('cancel',1),('in_valid',1),('out_ready',1),('in_data',64),('in_ticks',256),('in_quality',32),('in_first_seq',32),('in_last_seq',32),('in_tag',32)]
OUTPUTS=[('in_ready',1),('out_valid',1),('out_channel',2),('out_data',16),('out_tick',64),('out_quality',8),('out_first_seq',32),('out_last_seq',32),('out_tag',32),('out_last',1)]
def pack(values,layout):
 total=0;shift=0
 for name,width in layout:
  n=values.get(name,0);assert 0<=n<(1<<width);total|=n<<shift;shift+=width
 return total
class Model:
 def __init__(self):self.pending=deque();self.accepted=0;self.emitted=0;self.discarded=0;self.replacements=0
 def view(self,x):
  active=not(x['rst'] or x['cancel']);valid=active and bool(self.pending)
  z={'in_ready':int(active and (not self.pending or (len(self.pending)==1 and x['out_ready']))),'out_valid':int(valid),'out_last':int(valid and len(self.pending)==1)}
  if valid:z.update(self.pending[0])
  return z
 def step(self,x):
  pre=self.view(x)
  if x['rst'] or x['cancel']:self.discarded+=len(self.pending);self.pending.clear()
  else:
   replacing=bool(len(self.pending)==1 and pre['out_valid'] and x['out_ready'] and pre['in_ready'] and x['in_valid'])
   if pre['out_valid'] and x['out_ready']:self.pending.popleft();self.emitted+=1
   if pre['in_ready'] and x['in_valid']:
    assert not self.pending;self.accepted+=1;self.replacements+=int(replacing)
    for channel in range(4):self.pending.append(dict(out_channel=channel,out_data=(x['in_data']>>(16*channel))&65535,out_tick=(x['in_ticks']>>(64*channel))&((1<<64)-1),out_quality=(x['in_quality']>>(8*channel))&255,out_first_seq=x['in_first_seq'],out_last_seq=x['in_last_seq'],out_tag=x['in_tag']))
  assert 0<=len(self.pending)<=4 and self.accepted*4==self.emitted+self.discarded+len(self.pending)
  return pre,self.view(x)
'''
(O/'main_reference.py').write_text(SOURCE,encoding='utf-8',newline='\n');ns={};exec(compile(SOURCE,'main_reference.py','exec'),ns);Model=ns['Model'];model=Model();rng=random.Random(2026102444);vectors=[]
def step(label,**kw):
 x={name:0 for name,_ in ns['INPUTS']};x.update(in_data=rng.getrandbits(64),in_ticks=rng.getrandbits(256),in_quality=rng.getrandbits(32),in_first_seq=rng.getrandbits(32),in_last_seq=rng.getrandbits(32),in_tag=rng.getrandbits(32));x.update(kw);pre,post=model.step(x);vectors.append(dict(label=label,inputs=x,pre=pre,post=post))
step('initial_reset',rst=1)
for phase in range(5):
 for bits in range(16):
  step('matrix_clear',rst=1)
  if phase<4:
   step('matrix_accept',in_valid=1)
   for j in range(phase):step('matrix_advance',out_ready=1)
   for j in range(2):step('matrix_stall',in_valid=1,out_ready=0)
  step('matrix_%d_%d'%(phase,bits),rst=(bits>>3)&1,cancel=(bits>>2)&1,in_valid=(bits>>1)&1,out_ready=bits&1)
for i in range(128):step('continuous_reload_%d'%i,in_valid=1,out_ready=1,in_data=(1<<64)-1 if i%2 else 0,in_ticks=(1<<256)-1 if i%2 else 0,in_quality=(1<<32)-1 if i%2 else 0,in_first_seq=(1<<32)-1-i,in_last_seq=i,in_tag=0xa5000000+i)
for i in range(6000):step('seeded_%d'%i,rst=int(rng.randrange(173)==0),cancel=int(rng.randrange(67)==0),in_valid=int(rng.randrange(4)!=0),out_ready=int(rng.randrange(4)!=0))
step('final_abort',cancel=1)
step('fresh_final',in_valid=1,in_data=0x777788889999aaaa,in_ticks=0x111122223333444455556666777788889999aaaabbbbccccddddeeeeffff0000,in_quality=0x12345678,in_first_seq=0xffffffff,in_last_seq=0,in_tag=0x00ff00ff)
for i in range(6):step('final_drain',out_ready=1)
for row in vectors:
 for phase in ('pre','post'):
  row[phase+'_packed']=format(ns['pack'](row[phase],ns['OUTPUTS']),'x')
  row[phase+'_mask']=format(ns['pack']({name:(1<<width)-1 for name,width in ns['OUTPUTS'] if name in ('in_ready','out_valid','out_last') or row[phase]['out_valid']},ns['OUTPUTS']),'x')
 row['input_packed']=format(ns['pack'](row['inputs'],ns['INPUTS']),'x')
(O/'vectors.json').write_text(json.dumps({'inputs':ns['INPUTS'],'outputs':ns['OUTPUTS'],'vectors':vectors,'totals':dict(accepted=model.accepted,emitted=model.emitted,discarded=model.discarded,replacements=model.replacements)},indent=2),encoding='utf-8')
with (O/'vectors.txt').open('x',encoding='ascii') as f:
 for v in vectors:f.write(' '.join(v[k] for k in ('input_packed','pre_packed','pre_mask','post_packed','post_mask'))+'\n')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
out={'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-SCAN-LANE-MAIN-REFERENCE-20261024-44-v1','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author44_source_read':False,'spec_sha256':sha(D/'MAIN_SPEC.md'),'reference_sha256':sha(O/'main_reference.py'),'vectors_json_sha256':sha(O/'vectors.json'),'vectors_txt_sha256':sha(O/'vectors.txt'),'cycles':len(vectors),'directed_control_matrix_cases':80,'totals':dict(accepted=model.accepted,emitted=model.emitted,discarded=model.discarded,replacements=model.replacements),'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','scope':'Independent deque of expected lane transactions, whole-record bounds opaque; record conservation checked. Written from main spec before reading44source. No vendor/product execution or adoption.'}
(O/'FREEZE.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
