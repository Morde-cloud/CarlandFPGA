from pathlib import Path
import datetime,hashlib,json,re
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/acquisition/scan-lane-stream-20261024-44';O=E/'main/qualifier-preinspection-01';O.mkdir(exist_ok=False);cases=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=json.loads((E/'author/RESULT.json').read_bytes())['finish_provenance']
for mode in ('standalone','integration39'):
 d=E/'author/attempt-03'/mode;raw=(d/'modelsim.log').read_bytes().decode('utf-8').replace('\r\n','\n');lines=raw.splitlines();at=next(i for i,v in enumerate(lines) if v.startswith('# SL_SUMMARY'))
 prefix=lines[:at];terminal=lines[at:];assert len(terminal)==6
 def add(name,txt,accept=False,path=None,trace=None):
  fn=f'{mode}-{name}.log';(O/fn).write_bytes(txt.encode('utf-8'));tpath=d/'public.trace'
  if trace is not None:tpath=O/(mode+'-'+name+'.trace');tpath.write_text(trace,encoding='ascii')
  cases.append({'name':mode+'-'+name,'log':str(O/fn),'log_sha256':sha(O/fn),'fixture':str(d/'fixture.json'),'fixture_sha256':sha(d/'fixture.json'),'trace':str(tpath),'trace_sha256':sha(tpath),'tb_path':path or source['path'],'finish_line':source['line'],'accept':accept})
 add('positive-lf',raw,True);add('positive-crlf',raw.replace('\n','\r\n'),True)
 unicode_path='D:/主复核/四通道/tb_scan_lane_stream.sv';add('positive-unicode-pair',raw.replace(source['path'],unicode_path),True,unicode_path)
 for label,line in zip(('summary','done','finish','time','end','counters'),terminal):
  for placement in ('prefix','suffix'):
   for variant,v in (('duplicate',line),('substring','NOT_'+line)):
    altered=prefix+[v]+terminal if placement=='prefix' else lines+[v];add(label+'-'+placement+'-'+variant,'\n'.join(altered)+'\n')
 for label,tok in [('only-time','# Time: 1 ns'),('only-iteration','# Iteration: 99'),('only-instance','# Instance: /different'),('only-elapsed','# Elapsed time: 0:00:00'),('only-errors','# Errors: 0'),('only-warnings','# Warnings: 0'),('finish-substring','# NOT_$finish_but_present'),('zero-width-finish','# $finish\u200b')]:add(label,'\n'.join(prefix+[tok]+terminal)+'\n')
 start=next(x for x in prefix if x.startswith('# Start time:'));add('duplicate-start','\n'.join(prefix+[start]+terminal)+'\n');add('substring-start','\n'.join(prefix+['NOT_'+start]+terminal)+'\n')
 add('nul-before-terminal','\n'.join(prefix)+'\x00\n'+'\n'.join(terminal)+'\n');add('bare-cr',raw.replace('\n','\r',1));add('truncate-footer','\n'.join(lines[:-1])+'\n');add('nonzero-final',raw.replace('# Errors: 0, Warnings: 0','# Errors: 1, Warnings: 0'))
 add('wrong-source',raw.replace(source['path'],'D:/wrong/tb.sv'));add('wrong-finish-line',raw.replace(f'({source["line"]})',f'({source["line"]+1})'))
 trace=(d/'public.trace').read_text();tlines=trace.splitlines();index=next(i for i,l in enumerate(tlines) if l.split()[5]=='1');z=tlines[index].split();z[8]=format(int(z[8],16)^(1<<41),'047x');z[9]=z[8];tlines[index]=' '.join(z);add('changed-valid-lane',raw,trace='\n'.join(tlines)+'\n')
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'before_repaired_runner_inspection':True,'cases':cases,'expected_positive':sum(c['accept'] for c in cases),'expected_negative':sum(not c['accept'] for c in cases),'scope':'Main original transcript/port mutations, no repaired runner import and no new vendor execution. Unicode positive is saved grammar only, not a vendor path run.'}
with (O/'FREEZE.json').open('x',encoding='utf-8') as f:json.dump(r,f,indent=2,ensure_ascii=False)
(O/'freeze_qualifier_probes.py').write_bytes(Path(__file__).read_bytes());print(json.dumps({'positive':r['expected_positive'],'negative':r['expected_negative']}))
