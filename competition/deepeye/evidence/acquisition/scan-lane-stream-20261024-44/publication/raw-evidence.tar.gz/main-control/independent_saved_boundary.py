from pathlib import Path
import hashlib,json,runpy
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/acquisition/scan-lane-stream-20261024-44';F=E/'main/preinspection-01';O=E/'main/saved-boundary-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
assert sha(F/'main_reference.py')=='56d145f2e37402bb6cd0340a04cb98fd9f52c23ec59613cbb5d17b91e70624c9'
mod=runpy.run_path(str(F/'main_reference.py'));results=[]
def take(word,layout):
 r={};s=0
 for n,w in layout:r[n]=(word>>s)&((1<<w)-1);s+=w
 return r
for mode in ('standalone','integration39'):
 path=E/'author/attempt-03'/mode/'public.trace';lines=path.read_text().splitlines();assert len(lines)%2==0;model=mod['Model']();checks=0
 for c in range(len(lines)//2):
  pair=[line.split() for line in lines[2*c:2*c+2]]
  for z,phase in zip(pair,('PRE','POST')):assert len(z)==13 and z[:2]==[str(c+1),phase]
  pre,post=pair;rst,can,iv,ready=map(int,pre[3]);masked=int(pre[6],16)
  if iv:assert int(pre[7],16)==masked
  else:assert masked==0
  values=take(masked,[('in_data',64),('in_ticks',256),('in_quality',32),('in_first_seq',32),('in_last_seq',32),('in_tag',32)])
  wanted=model.step(dict(rst=rst,cancel=can,in_valid=iv,out_ready=ready,**values))
  for z,w in zip(pair,wanted):
   assert (int(z[3][0]),int(z[3][1]),int(z[3][3]))==(rst,can,ready)
   assert [int(z[i]) for i in (4,5,12)]==[w[k] for k in ('in_ready','out_valid','out_last')];checks+=3
   word=int(z[8],16)
   if w['out_valid']:
    assert int(z[9],16)==word;observed=take(word,[('out_last',1),('out_tag',32),('out_last_seq',32),('out_first_seq',32),('out_quality',8),('out_tick',64),('out_data',16),('out_channel',2)])
    assert all(observed[k]==w[k] for k in observed),(c,z,observed,w);checks+=8
   else:assert word==0
 assert not model.pending and model.accepted*4==model.emitted+model.discarded
 results.append({'mode':mode,'trace_sha256':sha(path),'cycles':len(lines)//2,'field_checks':checks,'accepted':model.accepted,'emitted':model.emitted,'discarded':model.discarded,'replacements':model.replacements})
r={'status':'PASS_MAIN_FROZEN_REFERENCE_ON_ACTUAL_AUTHOR_TRACES','results':results,'new_vendor_runs':0,'scope':'Reused actual author44 standalone and exact39→44 integration trace. Main preinspection model receives actual input record fields, never author expected-lane fixtures. Independent transport preservation/conservation only; unchanged39 capture proof remains its original scope.'}
with (O/'RESULT.json').open('x',encoding='utf-8') as f:json.dump(r,f,indent=2)
print(json.dumps(r))
