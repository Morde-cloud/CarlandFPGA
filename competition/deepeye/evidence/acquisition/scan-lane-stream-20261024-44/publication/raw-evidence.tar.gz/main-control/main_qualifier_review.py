from pathlib import Path
import ast,datetime,hashlib,json,runpy
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/acquisition/scan-lane-stream-20261024-44';A=E/'author-qualifier-repair1';D=Path(__file__).parent;O=E/'main/qualifier-review-01'
def get(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False)
term=get(D.parent/'scan-lane-qualifier-repair-20261024-44r1/native-terminal.json')[0];assert term['status']=='completed' and term['terminal'] and not term['stale'];report=json.loads(term['result']['text']);assert sha(Path(report['result']))==report['result_sha256']
assert sha(A/'ARTIFACT_MANIFEST.json')==report['artifact_manifest_sha256'];runner=P/'tools/acquisition/run_scan_lane_stream.py';pin='8233ef936eae50c35eb09f8bc88e7376bce4e4ae42eb6bc1b95edf67e0f1548d';assert sha(runner)==pin
O.mkdir(exist_ok=False);summary={'status':'RUNNING'}
try:
 verified={}
 for root in (E/'author',A):
  files=get(root/'ARTIFACT_MANIFEST.json')['files']
  for v in files:
   p=root/v['path'];assert sha(p)==v['sha256'] and p.stat().st_size==v['bytes'],p
  verified[root.name]=len(files)
 old=ast.parse((A/'original_runner.py').read_text());new=ast.parse(runner.read_text());assert len(old.body)==len(new.body)
 changed=[]
 for x,y in zip(old.body,new.body):
  if ast.dump(x)!=ast.dump(y):assert isinstance(x,ast.FunctionDef) and isinstance(y,ast.FunctionDef) and x.name==y.name;changed.append(x.name)
 assert changed==['terminal_stats','qualify']
 inputs={};matrix=get(A/'EXPECTED_CLASSIFICATION_v2.json');assert sha(A/'EXPECTED_CLASSIFICATION_v2.json')==report['expected_classification_sha256']
 for c in matrix['cases']:
  for k in ('log','trace'):inputs[c[k]['path']]=c[k]['sha256']
 for m in matrix['modes'].values():
  for k in ('fixture','stimulus'):inputs[m[k]['path']]=m[k]['sha256']
 for p,h in inputs.items():assert sha(Path(p))==h
 module=runpy.run_path(str(runner));fixtures={int(k):get(Path(v['fixture']['path'])) for k,v in matrix['modes'].items()};cache={};results=[]
 for c in matrix['cases']:
  path=c['trace']['path']
  if path not in cache:cache[path]=Path(path).read_bytes().decode('ascii').splitlines(keepends=True)
  rows=list(cache[path])
  if 'trace_recipe' in c:
   rows=[x.replace('\r\n','\n') for x in rows];recipe=c['trace_recipe']
   if 'remove_index' in recipe:rows.pop(recipe['remove_index'])
   elif 'insert_index' in recipe:rows.insert(recipe['insert_index'],recipe['value'])
   elif 'append' in recipe:rows.append(recipe['append'])
   else:rows[recipe['index']]=recipe['replacement']
  try:actual=module['check_saved'](Path(c['log']['path']).read_bytes().decode('utf-8'),iter(rows),fixtures[c['mode']],c['tb_path'],c['finish_line']);accept=True;error=None
  except ValueError as ex:accept=False;error=str(ex)
  if accept:assert actual['stats']==matrix['modes'][str(c['mode'])]['expected_stats']
  results.append({'name':c['name'],'expected':c['expect_accept'],'actual':accept,'error':error})
 put(O/'author_cases.json',results);assert all(x['expected']==x['actual'] for x in results)
 maincases=get(E/'main/qualifier-preinspection-01/FREEZE.json')['cases'];independent=[]
 for c in maincases:
  for k in ('log','trace','fixture'):assert sha(Path(c[k]))==c[k+'_sha256']
  try:
   with Path(c['trace']).open(encoding='ascii',newline='') as stream:module['check_saved'](Path(c['log']).read_bytes().decode('utf-8'),stream,get(Path(c['fixture'])),c['tb_path'],c['finish_line'])
   accept=True;error=None
  except ValueError as ex:accept=False;error=str(ex)
  independent.append({'name':c['name'],'expected':c['accept'],'actual':accept,'error':error})
 put(O/'main_cases.json',independent);assert all(x['expected']==x['actual'] for x in independent)
 before=get(E/'main/author-audit-02/RESULT.json')['pins']
 for n,h in before.items():assert sha(P/n)==(pin if n=='tools/acquisition/run_scan_lane_stream.py' else h),n
 assert sha(P.parents[1]/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
 for p in (E/'main/positive-reconcile-01/RESULT.json',E/'main/compiled-mutants-01/RESULT.json',E/'main/saved-boundary-01/RESULT.json'):assert get(p)['status'].startswith('PASS')
 receipts=[]
 for p in sorted((A/'processes').glob('*.json')):
  v=get(p)
  if 'exit_code' not in v:continue
  receipts.append({'path':str(p),'sha256':sha(p),'exit_code':v['exit_code']})
 correction=get(A/'FIXTURE_CORRECTION.json');assert len(correction['cases'])==4
 for c in correction['cases']:
  assert sha(Path(c['original_log']['path']))==sha(Path(c['byte_identical_positive']['path']))
  assert sha(Path(c['corrected_log']['path']))==c['corrected_log']['sha256']!=c['original_log']['sha256']
 summary.update(status='PASS_BOUNDED_LANE_STREAM_AND_REPAIRED_QUALIFIER',requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',main_thread='01a13b55-095b-7461-8dd5-5476a130bd82',runner_sha256=pin,changed_functions=changed,verified_artifact_counts=verified,author_cases=len(results),author_accepted=sum(x['actual'] for x in results),main_cases=len(independent),main_accepted=sum(x['actual'] for x in independent),input_hashes=len(inputs),python_receipts=receipts,new_vendor_runs=0,original44_native_status='failed, unchanged',repair_native_status='completed/stalefalse',original_failures='Original six false accepts and author failure retained. Initialrepair4no-op-negative fixtures byte-identical to good logs; retained then corrected before second verification. Main CRLF and path errors retained; no vendor replay.',scope='Only local same-clock scan record to four opaque lanes and exact ModelSim10.7 saved-log grammar. No arbitrary log authentication, Unicode vendor-path claim, ABI/timing/CDC_RDC/board/formal acceptance. All29formalnot_run; A-onlyboard.',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
except Exception as ex:summary.update(status='FAILED',error=repr(ex));raise
finally:
 (O/'main_qualifier_review.py').write_bytes(Path(__file__).read_bytes());put(O/'RESULT.json',summary);print(json.dumps(summary))
