from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/acquisition/scan-lane-stream-20261024-44/main';F=E/'preinspection-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def command(out,name,argv,bound):
 argv=list(map(str,argv));put(out/(name+'.intent.json'),{'argv':argv,'cwd':str(out),'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});t=time.monotonic();p=subprocess.Popen(argv,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(out/(name+'.started.json'),{'pid':p.pid});timed=False
 try:stdout,stderr=p.communicate(timeout=bound)
 except subprocess.TimeoutExpired:timed=True;p.kill();stdout,stderr=p.communicate()
 (out/(name+'.stdout.bin')).write_bytes(stdout);(out/(name+'.stderr.bin')).write_bytes(stderr);put(out/(name+'.command.json'),{'pid':p.pid,'exit_code':p.returncode,'timeout':timed,'elapsed_s':time.monotonic()-t,'stdout_sha256':sha(out/(name+'.stdout.bin')),'stderr_sha256':sha(out/(name+'.stderr.bin'))});assert p.returncode==0 and not timed
 return (stdout+stderr).decode('utf-8',errors='strict')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--name',required=True);ap.add_argument('--expected-rtl-sha',required=True);ap.add_argument('--mutant',type=Path);args=ap.parse_args();assert re.fullmatch('[a-zA-Z0-9_-]+',args.name)
 term=get(D/'native-terminal.json')[0];assert term['terminal'] and term['status']=='completed' and not term['stale']
 source=P/'fpga/acquisition/deepeye_scan_lane_stream.sv';assert sha(source)==args.expected_rtl_sha
 freeze=get(F/'FREEZE.json');tb=F/'main_tb_scan_lane_stream.sv';assert sha(tb)==get(F/'TB_FREEZE.json')['tb_sha256'];assert sha(F/'vectors.txt')==freeze['vectors_txt_sha256'] and sha(F/'vectors.json')==freeze['vectors_json_sha256'] and sha(F/'main_reference.py')==freeze['reference_sha256']
 out=E/args.name;out.mkdir(exist_ok=False);snap=out/'inputs';snap.mkdir();rtl=args.mutant or source
 for n,p in [('deepeye_scan_lane_stream.sv',rtl),(tb.name,tb)]+[(n,F/n) for n in ('main_reference.py','vectors.json','vectors.txt','FREEZE.json','TB_FREEZE.json')]: (snap/n).write_bytes(p.read_bytes())
 (snap/Path(__file__).name).write_bytes(Path(__file__).read_bytes());result={'status':'RUNNING','mutant':args.mutant is not None,'rtl_sha256':sha(rtl),'tb_sha256':sha(tb),'commands':0};tool=Path('D:/modelsim1/win64')
 try:
  for name,argv,bound in [('version',[tool/'vsim.exe','-version'],30),('vlib',[tool/'vlib.exe','lib'],30),('vlog',[tool/'vlog.exe','-sv','-work','lib',snap/'deepeye_scan_lane_stream.sv',snap/tb.name],60),('vsim',[tool/'vsim.exe','-c','-work','lib','-l',out/'transcript.txt','-wlf',out/'sim.wlf','-do','run -all; quit -f','main_scan_lane','+VECTORS='+str(snap/'vectors.txt'),'+TRACE='+str(out/'trace.txt')],120)]:
   raw=command(out,name,argv,bound);result['commands']+=1
   if name=='vlog':assert not re.search(r'^#?\s*\*\* (Error|Warning)',raw,re.M)
  if args.mutant:
   failures=re.findall(r'^# MAIN44_FAIL cycle=(\d+) phase=([PQ])$',raw,re.M);assert len(failures)==1 and 'MAIN44_DONE' not in raw
   assert re.findall(r'^# Errors: (\d+), Warnings: (\d+)$',raw,re.M)==[('1','0')];result.update(status='EXPECTED_COMPILED_REJECTION',cycle=int(failures[0][0]),phase=failures[0][1])
  else:
   done=re.findall(r'^# MAIN44_DONE cycles=(\d+) checks=(\d+)$',raw,re.M);assert done==[(str(freeze['cycles']),str(2*freeze['cycles']))]
   assert re.findall(r'^# Errors: (\d+), Warnings: (\d+)$',raw,re.M)==[('0','0')]
   vectors=get(F/'vectors.json')['vectors'];rows=(out/'trace.txt').read_text().splitlines();assert len(rows)==2*len(vectors);portchecks=0
   for i,row in enumerate(rows):
    z=row.split();v=vectors[i//2];phase='pre' if i%2==0 else 'post';assert z[:3]==['T',str(i//2),'P' if i%2==0 else 'Q'];assert int(z[3],16)==int(v['input_packed'],16);bits=z[4].lower();assert len(bits)==189 and set(bits)<=set('01xz')
    mask=int(v[phase+'_mask'],16);unknown=int(''.join('1' if c in 'xz' else '0' for c in bits),2);observed=int(bits.replace('x','0').replace('z','0'),2);assert not(unknown&mask) and (observed&mask)==(int(v[phase+'_packed'],16)&mask),(i,row)
    portchecks+=10 if v[phase]['out_valid'] else 3
   result.update(status='PASS',cycles=len(vectors),trace_rows=len(rows),public_field_checks=portchecks,totals=get(F/'vectors.json')['totals'],directed_control_matrix_cases=80)
  result['trace_sha256']=sha(out/'trace.txt');assert sha(source)==args.expected_rtl_sha
 except Exception as ex:result.update(status='FAILED',error=repr(ex));raise
 finally:put(out/'RESULT.json',result);print(json.dumps(result))
if __name__=='__main__':main()
