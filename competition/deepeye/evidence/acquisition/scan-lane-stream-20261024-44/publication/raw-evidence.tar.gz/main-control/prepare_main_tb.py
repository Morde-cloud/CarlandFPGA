from pathlib import Path
import hashlib,json
D=Path(__file__).parent;F=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/acquisition/scan-lane-stream-20261024-44/main/preinspection-01');v=json.loads((F/'vectors.json').read_bytes());nin=sum(w for n,w in v['inputs']);nout=sum(w for n,w in v['outputs']);assert(nin,nout)==(452,189)
ports=['.clk(clk)'];offset=0
for n,w in v['inputs']:ports.append('.'+n+'(drive['+str(offset+w-1)+':'+str(offset)+'])');offset+=w
offset=0
for n,w in v['outputs']:ports.append('.'+n+'(observed['+str(offset+w-1)+':'+str(offset)+'])');offset+=w
s='''`timescale 1ns/1ps
// Main-owned44public pre/post driver, frozen without reading author44code.
module main_scan_lane;
 reg clk=0;always #5 clk=~clk;
 reg [451:0] drive=452'd1;
 wire [188:0] observed;
 reg [451:0] next_input;
 reg [188:0] pre_value,pre_mask,post_value,post_mask;
 integer fd,logfd,rc,cycles=0,checks=0;
 string vectors_path,trace_path;
 deepeye_scan_lane_stream dut(PORTS);
 initial begin
  if(!$value$plusargs("VECTORS=%s",vectors_path)||!$value$plusargs("TRACE=%s",trace_path))$fatal(1,"MAIN44_PATH");
  fd=$fopen(vectors_path,"r");logfd=$fopen(trace_path,"w");if(!fd||!logfd)$fatal(1,"MAIN44_OPEN");
  while(!$feof(fd))begin
   rc=$fscanf(fd,"%h %h %h %h %h",next_input,pre_value,pre_mask,post_value,post_mask);
   if(rc==0||rc==-1)break;if(rc!=5)$fatal(1,"MAIN44_VECTOR");
   @(negedge clk);drive=next_input;#1;
   $fdisplay(logfd,"T %0d P %h %b",cycles,drive,observed);
   if((observed&pre_mask)!==(pre_value&pre_mask))begin $display("MAIN44_FAIL cycle=%0d phase=P",cycles);$fatal(1,"MAIN44_NUMERIC_FAILURE");end
   checks=checks+1;
   @(posedge clk);#1;
   $fdisplay(logfd,"T %0d Q %h %b",cycles,drive,observed);
   if((observed&post_mask)!==(post_value&post_mask))begin $display("MAIN44_FAIL cycle=%0d phase=Q",cycles);$fatal(1,"MAIN44_NUMERIC_FAILURE");end
   checks=checks+1;cycles=cycles+1;
  end
  $display("MAIN44_DONE cycles=%0d checks=%0d",cycles,checks);
  $fclose(fd);$fclose(logfd);$finish;
 end
endmodule
'''.replace('PORTS',',\n  '.join(ports))
p=F/'main_tb_scan_lane_stream.sv'
with p.open('x',encoding='utf-8',newline='\n') as f:f.write(s)
out={'tb_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'spec_sha256':hashlib.sha256((D/'MAIN_SPEC.md').read_bytes()).hexdigest(),'input_bits':nin,'output_bits':nout,'cycles':len(v['vectors']),'author44_source_read':False,'design_note':'Inputs applied on negedge then #1 precheck; posedge then #1 postcheck. Only valid payload bits compared; opaque record fields never interpreted.'}
(F/'TB_FREEZE.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps(out))
