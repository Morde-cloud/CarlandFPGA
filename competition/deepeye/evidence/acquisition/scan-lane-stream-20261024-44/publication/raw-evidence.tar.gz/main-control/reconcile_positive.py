from pathlib import Path
import hashlib,json,re
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/acquisition/scan-lane-stream-20261024-44/main';O=E/'positive-01';F=E/'preinspection-01';D=E/'positive-reconcile-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
D.mkdir(exist_ok=False);freeze=get(F/'FREEZE.json');vectors=get(F/'vectors.json')['vectors']
for name in ('version','vlib','vlog','vsim'):
 c=get(O/(name+'.command.json'));assert c['exit_code']==0 and not c['timeout']
 for s in ('stdout','stderr'):assert sha(O/(name+'.'+s+'.bin'))==c[s+'_sha256']
raw=(O/'vsim.stdout.bin').read_bytes();assert b'\r\n' in raw and b'\x00' not in raw;txt=raw.decode('utf-8').replace('\r\n','\n');assert '\r' not in txt
assert re.findall(r'^# MAIN44_DONE cycles=(\d+) checks=(\d+)$',txt,re.M)==[('6585','13170')]
assert re.findall(r'^# Errors: (\d+), Warnings: (\d+)$',txt,re.M)==[('0','0')]
assert len(re.findall(r'\$finish',txt))==1 and 'MAIN44_FAIL' not in txt and not re.search(r'\*\* (Error|Fatal|Warning)',txt)
rows=(O/'trace.txt').read_text().splitlines();assert len(rows)==2*len(vectors);checks=0
for i,row in enumerate(rows):
 z=row.split();v=vectors[i//2];phase='pre' if i%2==0 else 'post';assert z[:3]==['T',str(i//2),'P' if i%2==0 else 'Q'];assert int(z[3],16)==int(v['input_packed'],16)
 bits=z[4].lower();assert len(bits)==189 and set(bits)<=set('01xz');mask=int(v[phase+'_mask'],16);unknown=int(''.join('1' if c in 'xz' else '0' for c in bits),2);value=int(bits.replace('x','0').replace('z','0'),2)
 assert not(unknown&mask) and value&mask==int(v[phase+'_packed'],16)&mask,(i,row)
 checks+=10 if v[phase]['out_valid'] else 3
assert sha(P/'fpga/acquisition/deepeye_scan_lane_stream.sv')=='b3c9d2024d9325191538cf08fec9a652ff8ff0ae316ec9af96078f85cf5be3cc'
r={'status':'PASS_ACTUAL_POSITIVE_RECONCILED','original_runner_failure':'Regex used $ on unnormalized CRLF. Original actual four commands exited0, RTL/TB remained fixed; no rerun. Original FAILED result retained.','trace_rows':len(rows),'cycles':len(vectors),'public_field_checks':checks,'totals':get(F/'vectors.json')['totals'],'trace_sha256':sha(O/'trace.txt'),'stdout_sha256':sha(O/'vsim.stdout.bin'),'original_result_sha256':sha(O/'RESULT.json'),'commands':4,'new_vendor_runs':0}
with (D/'RESULT.json').open('x',encoding='utf-8') as f:json.dump(r,f,indent=2)
print(json.dumps(r))
