from pathlib import Path
import hashlib,json,subprocess,sys,datetime
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/acquisition/scan-lane-stream-20261024-44/main';O=E/'compiled-mutants-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
source=P/'fpga/acquisition/deepeye_scan_lane_stream.sv';expected='b3c9d2024d9325191538cf08fec9a652ff8ff0ae316ec9af96078f85cf5be3cc';assert sha(source)==expected
runner=(D/'main_run2.py').read_text();old="return (stdout+stderr).decode('utf-8',errors='strict')";assert runner.count(old)==1;runner=runner.replace(old,"return (stdout+stderr).decode('utf-8',errors='strict').replace('\\r\\n','\\n')")
with (D/'main_run3.py').open('x',encoding='utf-8') as f:f.write(runner)
raw=source.read_text();specs=[('rotated-tick','ticks_q[64*lane+:64]','ticks_q[64*(lane^2\'d1)+:64]'),('invent-sequence','out_first_seq=first_q;','out_first_seq=first_q+lane;'),('lose-final-reload',"in_valid&&in_ready)begin","in_valid&&in_ready&&!(out_valid&&out_ready&&(lane==2'd3)))begin"),('ignore-cancel','if(rst||cancel)begin','if(rst)begin')]
plans=[]
for name,a,b in specs:
 assert raw.count(a)==1;(O/(name+'.sv')).write_text(raw.replace(a,b),encoding='utf-8');plans.append({'name':name,'file':str(O/(name+'.sv')),'sha256':sha(O/(name+'.sv')),'expected':'reject at public port; actual compiled mutant only'})
with (O/'FREEZE.json').open('x',encoding='utf-8') as f:json.dump({'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_sha256':expected,'runner_sha256':sha(D/'main_run3.py'),'plans':plans},f,indent=2)
results=[]
for p in plans:
 argv=[sys.executable,'-B','-X','utf8',str(D/'main_run3.py'),'--name','mutant-'+p['name'],'--expected-rtl-sha',expected,'--mutant',p['file']]
 with (O/(p['name']+'.intent.json')).open('x',encoding='utf-8') as f:json.dump({'argv':argv,'cwd':str(R)},f)
 process=subprocess.Popen(argv,cwd=R,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);stdout,stderr=process.communicate(timeout=240)
 (O/(p['name']+'.stdout.bin')).write_bytes(stdout);(O/(p['name']+'.stderr.bin')).write_bytes(stderr)
 receipt={'pid':process.pid,'exit_code':process.returncode,'stdout_sha256':sha(O/(p['name']+'.stdout.bin')),'stderr_sha256':sha(O/(p['name']+'.stderr.bin'))}
 with (O/(p['name']+'.receipt.json')).open('x',encoding='utf-8') as f:json.dump(receipt,f)
 assert process.returncode==0,stdout+stderr
 result=json.loads((E/('mutant-'+p['name'])/'RESULT.json').read_bytes());assert result['status']=='EXPECTED_COMPILED_REJECTION';results.append({'name':p['name'],**result})
assert sha(source)==expected
with (O/'RESULT.json').open('x',encoding='utf-8') as f:json.dump({'status':'PASS_FOUR_COMPILED_MUTANTS_REJECTED','results':results,'actual_vendor_commands':16},f,indent=2)
print(json.dumps({'status':'PASS_FOUR_COMPILED_MUTANTS_REJECTED','results':[{k:r[k] for k in ('name','cycle','phase')} for r in results],'actual_vendor_commands':16}))
