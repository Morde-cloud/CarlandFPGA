from collections import deque
INPUTS=[('rst',1),('cancel',1),('in_valid',1),('out_ready',1),('in_data',64),('in_ticks',256),('in_quality',32),('in_first_seq',32),('in_last_seq',32),('in_tag',32)]
OUTPUTS=[('in_ready',1),('out_valid',1),('out_channel',2),('out_data',16),('out_tick',64),('out_quality',8),('out_first_seq',32),('out_last_seq',32),('out_tag',32),('out_last',1)]
def pack(values,layout):
 total=0;shift=0
 for name,width in layout:
  n=values.get(name,0);assert 0<=n<(1<<width);total|=n<<shift;shift+=width
 return total
class Model:
 def __init__(self):self.pending=deque();self.accepted=0;self.emitted=0;self.discarded=0;self.replacements=0
 def view(self,x):
  active=not(x['rst'] or x['cancel']);valid=active and bool(self.pending)
  z={'in_ready':int(active and (not self.pending or (len(self.pending)==1 and x['out_ready']))),'out_valid':int(valid),'out_last':int(valid and len(self.pending)==1)}
  if valid:z.update(self.pending[0])
  return z
 def step(self,x):
  pre=self.view(x)
  if x['rst'] or x['cancel']:self.discarded+=len(self.pending);self.pending.clear()
  else:
   replacing=bool(len(self.pending)==1 and pre['out_valid'] and x['out_ready'] and pre['in_ready'] and x['in_valid'])
   if pre['out_valid'] and x['out_ready']:self.pending.popleft();self.emitted+=1
   if pre['in_ready'] and x['in_valid']:
    assert not self.pending;self.accepted+=1;self.replacements+=int(replacing)
    for channel in range(4):self.pending.append(dict(out_channel=channel,out_data=(x['in_data']>>(16*channel))&65535,out_tick=(x['in_ticks']>>(64*channel))&((1<<64)-1),out_quality=(x['in_quality']>>(8*channel))&255,out_first_seq=x['in_first_seq'],out_last_seq=x['in_last_seq'],out_tag=x['in_tag']))
  assert 0<=len(self.pending)<=4 and self.accepted*4==self.emitted+self.discarded+len(self.pending)
  return pre,self.view(x)
