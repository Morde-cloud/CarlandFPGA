`timescale 1ns/1ps
// Main-owned44public pre/post driver, frozen without reading author44code.
module main_scan_lane;
 reg clk=0;always #5 clk=~clk;
 reg [451:0] drive=452'd1;
 wire [188:0] observed;
 reg [451:0] next_input;
 reg [188:0] pre_value,pre_mask,post_value,post_mask;
 integer fd,logfd,rc,cycles=0,checks=0;
 string vectors_path,trace_path;
 deepeye_scan_lane_stream dut(.clk(clk),
  .rst(drive[0:0]),
  .cancel(drive[1:1]),
  .in_valid(drive[2:2]),
  .out_ready(drive[3:3]),
  .in_data(drive[67:4]),
  .in_ticks(drive[323:68]),
  .in_quality(drive[355:324]),
  .in_first_seq(drive[387:356]),
  .in_last_seq(drive[419:388]),
  .in_tag(drive[451:420]),
  .in_ready(observed[0:0]),
  .out_valid(observed[1:1]),
  .out_channel(observed[3:2]),
  .out_data(observed[19:4]),
  .out_tick(observed[83:20]),
  .out_quality(observed[91:84]),
  .out_first_seq(observed[123:92]),
  .out_last_seq(observed[155:124]),
  .out_tag(observed[187:156]),
  .out_last(observed[188:188]));
 initial begin
  if(!$value$plusargs("VECTORS=%s",vectors_path)||!$value$plusargs("TRACE=%s",trace_path))$fatal(1,"MAIN44_PATH");
  fd=$fopen(vectors_path,"r");logfd=$fopen(trace_path,"w");if(!fd||!logfd)$fatal(1,"MAIN44_OPEN");
  while(!$feof(fd))begin
   rc=$fscanf(fd,"%h %h %h %h %h",next_input,pre_value,pre_mask,post_value,post_mask);
   if(rc==0||rc==-1)break;if(rc!=5)$fatal(1,"MAIN44_VECTOR");
   @(negedge clk);drive=next_input;#1;
   $fdisplay(logfd,"T %0d P %h %b",cycles,drive,observed);
   if((observed&pre_mask)!==(pre_value&pre_mask))begin $display("MAIN44_FAIL cycle=%0d phase=P",cycles);$fatal(1,"MAIN44_NUMERIC_FAILURE");end
   checks=checks+1;
   @(posedge clk);#1;
   $fdisplay(logfd,"T %0d Q %h %b",cycles,drive,observed);
   if((observed&post_mask)!==(post_value&post_mask))begin $display("MAIN44_FAIL cycle=%0d phase=Q",cycles);$fatal(1,"MAIN44_NUMERIC_FAILURE");end
   checks=checks+1;cycles=cycles+1;
  end
  $display("MAIN44_DONE cycles=%0d checks=%0d",cycles,checks);
  $fclose(fd);$fclose(logfd);$finish;
 end
endmodule
