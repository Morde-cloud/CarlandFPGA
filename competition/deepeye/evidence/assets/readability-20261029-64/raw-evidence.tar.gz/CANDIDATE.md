# G01 material readability candidate (B execution record)

- Task: `DEEPEYE-IMPLEMENTATION-20261014/v1`, work `B-ASSET-READABILITY-20261029-64-v1`.
- Owner: B successor main `01a18824-4172-74e2-a13f-f3e3d1e3ed99`.
- Contract: `DEEPEYE-HUMAN-LOCK-20261014/revision1`, source `f5989cd5defce561f9ba98e6b18fc2682945f0a2`, requirements SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` (match=True).
- Requirement ids: `H01, H02, H03, H04, H05, H06, H07, H08, H09, H10, H11, H12, H13, H14, H15`.
- Frozen design commit: `1011259415a0916054eb580687612580bc1e5f09`. Exact product worktree HEAD: `056844e02e49f5047edb2151a838947dd8cdf409`.
- Candidate: `candidate-r1` (round 1), attempt `evidence/candidate-r1/attempt-1`.
- Status: `candidate_ready_pending_main_visual_review`. Adoption is **pending the main's personal visual review**; this file does not claim G01, game-grade, system or board acceptance.

## Scope and material changes

Only the existing numeric color/metallic/roughness values inside `_material_pdc_blade`, `_material_pdc_stud`, `_material_void`, and `_material_casing` were eligible. This candidate changed blade, stud, and void. Casing was kept byte-identical because it is already visible; no necessity to change it was found. No emission, unshaded/shading mode, texture, transparency, blend, cull, geometry, collision, transform, name, metadata, or other function changes are present.

| file | function | old color / metallic / roughness | new color / metallic / roughness | changed |
|---|---|---|---|---|
| `world/drill_geometry.gd` | `_material_pdc_blade` | [0.07, 0.07, 0.08] / 0.35 / 0.14 | [0.22, 0.24, 0.29] / 0.35 / 0.34 | True |
| `world/drill_geometry.gd` | `_material_pdc_stud` | [0.12, 0.12, 0.14] / 0.6 / 0.06 | [0.55, 0.5, 0.42] / 0.45 / 0.28 | True |
| `world/obstacle_geometry.gd` | `_material_void` | [0.05, 0.05, 0.07] / 0.05 / 0.95 | [0.14, 0.155, 0.19] / 0.0 / 0.9 | True |
| `world/obstacle_geometry.gd` | `_material_casing` | [0.62, 0.64, 0.68] / 0.95 / 0.18 | [0.62, 0.64, 0.68] / 0.95 / 0.18 | False |

Scope check: `pass`; changed files: `['world/drill_geometry.gd', 'world/obstacle_geometry.gd']`; outside-function bytes identical; normalized function bodies identical; forbidden-token hits: none.

## Source hashes and diff

- Hash table: `source/HASH_TABLE.md`; machine-readable hashes: `source/SOURCE_HASHES.json`.
- Candidate source manifest: `source/candidates/round-1/SOURCE_HASHES.json` SHA256 `9f55853c0c43c25bb97df3a6478e62458380092301bf2430fcce97e9a900d405`; scope check: `source/candidates/round-1/SCOPE_CHECK.json` SHA256 `bab359343e8a2bf5f8a5fd97ae89ab9783ca875a7e469b87f5268d6c7174953f`; diff hash record: `source/candidates/round-1/DIFF_HASH.json` SHA256 `074dcac5e937ea2d51922fb93b3f2b637bd011c08390a3c72e8cd269c80bd0c7`.
- Baseline source files are exact `056844e02e49f5047edb2151a838947dd8cdf409` bytes (verified against `git show` and the worktree).
- Godot executable: `D:\pynq\CarlandFPGA\.local\tools\godot\4.7.2-stable\Godot_v4.7.2-stable_win64.exe` SHA256 `ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424` (match=True); no global install or configuration change.
- Source diff: `CANDIDATE_SOURCE_DIFF.patch`.

```diff
# Baseline exact HEAD 056844e02e49f5047edb2151a838947dd8cdf409 vs candidate round 1
# Only numeric color/metallic/roughness values in the four named material functions change.
# Casing remains byte-identical to the baseline value.

--- baseline/world/drill_geometry.gd
+++ candidate-round-1/world/drill_geometry.gd
@@ -191,10 +191,10 @@
     return _standard_material(Color(0.55, 0.46, 0.36), 0.90, 0.35)
 
 static func _material_matrix() -> StandardMaterial3D:
     return _standard_material(Color(0.52, 0.53, 0.55), 0.85, 0.42)
 
 static func _material_pdc_blade() -> StandardMaterial3D:
-    return _standard_material(Color(0.07, 0.07, 0.08), 0.35, 0.14)
+    return _standard_material(Color(0.22, 0.24, 0.29), 0.35, 0.34)
 
 static func _material_pdc_stud() -> StandardMaterial3D:
-    return _standard_material(Color(0.12, 0.12, 0.14), 0.60, 0.06)
+    return _standard_material(Color(0.55, 0.5, 0.42), 0.45, 0.28)
--- baseline/world/obstacle_geometry.gd
+++ candidate-round-1/world/obstacle_geometry.gd
@@ -256,10 +256,10 @@
     return _opaque_material(Color(0.42, 0.38, 0.33), 0.0, 0.92)
 
 static func _material_fault() -> StandardMaterial3D:
     return _opaque_material(Color(0.55, 0.42, 0.30), 0.0, 0.78)
 
 static func _material_void() -> StandardMaterial3D:
-    return _opaque_material(Color(0.05, 0.05, 0.07), 0.05, 0.95)
+    return _opaque_material(Color(0.14, 0.155, 0.19), 0.0, 0.9)
 
 static func _material_casing() -> StandardMaterial3D:
     return _opaque_material(Color(0.62, 0.64, 0.68), 0.95, 0.18)
```

## Actual commands and logs

### import
- argv: `["D:\\pynq\\CarlandFPGA\\.local\\tools\\godot\\4.7.2-stable\\Godot_v4.7.2-stable_win64.exe", "--path", "D:\\pynq\\CarlandFPGA\\.local\\deployment\\node-b\\main-handoff-20261029\\successor-01\\successor-work\\asset-readability\\work\\candidate-round-1-project", "--headless", "--editor", "--import", "--quit"]`
- PID: `888`; start `2026-10-29T15:03:02.103024+00:00`; end `2026-10-29T15:03:05.380137+00:00`; duration `3.277 s`; timeout `60 s`; timed_out `False`; exit `0`.
- stdout: `evidence/candidate-r1/attempt-1/logs/import.stdout.txt` SHA256 `e081e80e80e8916799257e8957c778dd9d2a51ef155519b304ff8d287d78d196`; stderr: `evidence/candidate-r1/attempt-1/logs/import.stderr.txt` SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

### tests
- argv: `["D:\\pynq\\CarlandFPGA\\.local\\tools\\godot\\4.7.2-stable\\Godot_v4.7.2-stable_win64.exe", "--path", "D:\\pynq\\CarlandFPGA\\.local\\deployment\\node-b\\main-handoff-20261029\\successor-01\\successor-work\\asset-readability\\work\\candidate-round-1-project", "--headless", "--script", "res://tests/test_asset_contract.gd"]`
- PID: `19632`; start `2026-10-29T15:03:05.583656+00:00`; end `2026-10-29T15:03:06.067397+00:00`; duration `0.484 s`; timeout `60 s`; timed_out `False`; exit `0`.
- stdout: `evidence/candidate-r1/attempt-1/logs/tests.stdout.txt` SHA256 `db972c99d154d241a0d49dd1b586512866b16205b244cd54d48aa002a8a577cc`; stderr: `evidence/candidate-r1/attempt-1/logs/tests.stderr.txt` SHA256 `f214b82fd6fa9f9b69d2a3b2cde48773590918c14e425fefef5d3219a43607bf`.

### export
- argv: `["D:\\pynq\\CarlandFPGA\\.local\\tools\\godot\\4.7.2-stable\\Godot_v4.7.2-stable_win64.exe", "--path", "D:\\pynq\\CarlandFPGA\\.local\\deployment\\node-b\\main-handoff-20261029\\successor-01\\successor-work\\asset-readability\\work\\candidate-round-1-project", "--headless", "--script", "res://export_asset_meshes.gd"]`
- PID: `53440`; start `2026-10-29T15:03:06.206530+00:00`; end `2026-10-29T15:03:06.601210+00:00`; duration `0.395 s`; timeout `60 s`; timed_out `False`; exit `0`.
- stdout: `evidence/candidate-r1/attempt-1/logs/export.stdout.txt` SHA256 `6e21defb34a6e75a3fc34f65dc7a75c4849d36e2e1324c24527b373542302330`; stderr: `evidence/candidate-r1/attempt-1/logs/export.stderr.txt` SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

### render
- argv: `["D:\\pynq\\CarlandFPGA\\.local\\tools\\godot\\4.7.2-stable\\Godot_v4.7.2-stable_win64.exe", "--path", "D:\\pynq\\CarlandFPGA\\.local\\deployment\\node-b\\main-handoff-20261029\\successor-01\\successor-work\\asset-readability\\work\\candidate-round-1-project", "--rendering-method", "gl_compatibility", "--rendering-driver", "opengl3", "--position", "-3200,120", "--resolution", "1280x720", "--script", "res://render/render_capture.gd"]`
- PID: `20972`; start `2026-10-29T15:03:07.507475+00:00`; end `2026-10-29T15:03:09.908704+00:00`; duration `2.401 s`; timeout `60 s`; timed_out `False`; exit `0`.
- stdout: `evidence/candidate-r1/attempt-1/logs/render.stdout.txt` SHA256 `060409283c4d3639a787277a85e356ddad537fe7642333b9e69f919360d889c4`; stderr: `evidence/candidate-r1/attempt-1/logs/render.stderr.txt` SHA256 `e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855`.

## Engine tests and geometry equality

- `tests/test_asset_contract.gd`: checks `622`, failures `0` (expected 622/0). The intentional unsupported-kind negative test remains in stderr; it is not a product failure.
- Export: asset_count `7` (expected 7).
- Mesh review: assets `7`, meshes `45`, findings `[]`, status `passed`.
- Geometry equality: `exact_geometry_and_shape_match`; assets exactly equal `True`; full export file equal `True`; old fixed-review equality `True`.
- Reference export SHA256 `7720cf598e74c8af7f2b32de421b3289ebfaddf3b5aa96c31af64bee80dcfc97`; candidate export SHA256 `7720cf598e74c8af7f2b32de421b3289ebfaddf3b5aa96c31af64bee80dcfc97`.
- Candidate mesh/shape counts: `45` meshes, `18` disabled shapes (reference `45`/`18`).

## Actual GPU render

- Harness status `ok`; shot count `11`.
- GPU: `NVIDIA GeForce RTX 4060 Laptop GPU` / `NVIDIA`; API `3.3.0 NVIDIA 566.26`; method `gl_compatibility`; driver `opengl3`.
- Window: requested `(-3200,120)` / `1280x720`; actual position `[-3200, 120]`, size `[1280, 720]`.
- PNG technical verification: `True`; images changed from the old render: `10/11`.

| image | dimensions | bytes | sha256 | technical pass | changed from reference |
|---|---:|---:|---|---|---|
| `evidence/candidate-r1/attempt-1/renders/png/01_drill_actual_scale_oblique.png` | 1280x720 | 42196 | `9cecb26c41677597db9e37b6dcf3a302e94c51f542419f5e837aa92156dd39a7` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/02_drill_head_detail_6blades_18studs.png` | 1280x720 | 40067 | `e382ae5e30a0836bf5fe865202ec0392894b4e0011b08f1df3ee1c3274efbaac` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/03_obstacle_kind_gallery_5kinds.png` | 1280x720 | 45998 | `86990e95c070558e6219227d0a8901a20380d009ec2925df94b75ecf33a039d9` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/04_world_overview_30obstacles_drill_frame.png` | 1280x720 | 57226 | `a05fca70a0c9454e467956d8e13b39519ddd8a7896def77aca9ade053978f0fd` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/05_world_alt_angle_hollow_edge_cube.png` | 1280x720 | 55946 | `7d1e1254a90d12afe5ebca5cd4a621c84ed6ef6779c62c98a648eae1e6292782` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/06_drill_axis_minus_x.png` | 1280x720 | 36026 | `f3ceb6cc4a2fde7f0bc6f822079facf8e7dd9fc0a405e82bcf31496273e04db2` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/06_drill_axis_minus_y.png` | 1280x720 | 35733 | `3b546006c667721905a83ead5422760901f554699a9f3da9a28cbd972f23e5f1` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/06_drill_axis_minus_z.png` | 1280x720 | 19557 | `2c7d3337fac1db3b0809c7fe9d26a347ab8750ff5c0f37d006e1af4822f70448` | True | False |
| `evidence/candidate-r1/attempt-1/renders/png/06_drill_axis_plus_x.png` | 1280x720 | 35180 | `72b4969e867cd650ab5373bab90540c1a3ebdbfb0ea9bd4bc5522a53062e1a7b` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/06_drill_axis_plus_y.png` | 1280x720 | 40843 | `fe7a32f4d3be8258af20b9f71fb3151e7e39c3b99c6dedf2a1f0f9194ef23b82` | True | True |
| `evidence/candidate-r1/attempt-1/renders/png/06_drill_axis_plus_z.png` | 1280x720 | 29910 | `69d1f8207fac730a423321f0591e2af5dc0fbaff0a9f8712b6000f91bbf7b226` | True | True |

## Preserved failures

All attempt directories are retained. Failed or superseded attempts are not deleted or rewritten.

- No candidate Godot command failed or timed out in this work's own runs.
- Tooling corrections are retained in `NOTES.md`: (1) baseline `evidence/baseline/attempt-1/run.json` contains an `expected_shape_count=43` metadata typo; the seven exported assets actually have 18 disabled shapes, and baseline `attempt-2` was run fresh with the corrected count; (2) the original malformed source-diff formatting is retained as `source/candidates/round-1/SOURCE_DIFF.preformatted.patch` while the line-safe `SOURCE_DIFF.patch` has identical content. Neither correction changes candidate source, tests, geometry, or renders.


## Limits and non-claims

- Root G01: `not_run`. System: `not_run`. Board: `not_run`.
- This record does not claim game-grade visual acceptance, runtime gameplay, continuous collision, truth isolation, FPS/performance, blue/red gate integration, free-camera/editor acceptance, PC-AI integration, either control path, or any A physical-board result.
- The execution child's visual observation is not acceptance. The main must personally inspect the new PNGs and decide whether to adopt the candidate.
- Execution-child observation: Execution-child inspection of the 11 actual GPU PNGs: head-detail shows six distinct blue-grey blade groups with 18 warm cutter studs; void is a visible dark blue-grey solid; casing remains visible and byte-identical. This is not acceptance; main must inspect personally.
