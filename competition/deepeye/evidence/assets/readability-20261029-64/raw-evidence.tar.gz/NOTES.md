# Execution notes and preserved tooling corrections

- Work: `DEEPEYE-IMPLEMENTATION-20261014/v1` / `B-ASSET-READABILITY-20261029-64-v1`.
- Exact product source: `056844e02e49f5047edb2151a838947dd8cdf409`.
- Contract: `DEEPEYE-HUMAN-LOCK-20261014/revision1`, source `f5989cd5defce561f9ba98e6b18fc2682945f0a2`, requirements SHA256 `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804` (recomputed and matched from the fixed `requirements` array).
- This work wrote only under the owned directory. The product worktree and old evidence were read-only inputs; the old `independent_review.py` was not executed. The old evidence was copied byte-identically into `reference/main-review-20261016/` for comparison.

## Preserved corrections (not hidden or rewritten)

1. **Baseline metadata typo.** `evidence/baseline/attempt-1/run.json` recorded `expected_shape_count=43` by mistakenly using the old 30-instance probe's disabled-shape count. The seven exported assets actually contain 18 disabled shapes; the old `geometry/exported_meshes.json` also has 18. The baseline engine test, export, and geometry equality in attempt-1 were already exact (622 checks/0 failures; export SHA256 `7720cf598e74c8af7f2b32de421b3289ebfaddf3b5aa96c31af64bee80dcfc97`; 45 meshes). The runner was corrected to derive expected mesh/shape counts from the reference export, and baseline `attempt-2` was run fresh. `attempt-1` is retained unchanged.
2. **Source-diff formatting.** The first generated `source/candidates/round-1/SOURCE_DIFF.patch` had missing newlines between header lines because the header strings were joined without terminators. The diff content and the scope check were correct. The original malformed file is preserved as `source/candidates/round-1/SOURCE_DIFF.preformatted.patch` (SHA256 `65543d57e27b023b045df8d6d37f6c83acd508915214f6e92547ee61d74438cb`). The line-safe diff is `SOURCE_DIFF.patch` (SHA256 `991c4c7f94fb77a93020d14509ebbac1fc61845f689aae2ff0392a744b5ee9b0`).

## Candidate-r1 command outcome

- `candidate-r1/attempt-1`: import, tests, export, and render all exited 0; no timeout occurred; no process was killed. The four PIDs and exact argv/tool hash/stdout/stderr hashes are in `evidence/candidate-r1/attempt-1/run.json` and `commands` therein.
- No physical board, network publication, service/credential, SQL/queue, or model-dispatch action occurred.

## Limits

- Root G01, system, and board remain `not_run`.
- The execution child's visual read is not acceptance. The main must personally inspect the 11 new PNGs before adopting the candidate.
