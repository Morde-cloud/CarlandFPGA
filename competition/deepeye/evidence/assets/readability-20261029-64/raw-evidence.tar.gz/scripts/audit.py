from __future__ import annotations

import hashlib
import json
import pathlib
import subprocess
from datetime import datetime, timezone

OWNED = pathlib.Path(__file__).resolve().parents[1]
REPO = pathlib.Path(r"D:\pynq\CarlandFPGA")
PRODUCT = REPO / ".local" / "worktrees" / "deepeye-implementation-20261014"
EXACT_HEAD = "056844e02e49f5047edb2151a838947dd8cdf409"


def sha(path: pathlib.Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    result = json.loads((OWNED / "RESULT.json").read_text(encoding="utf-8"))
    baseline = json.loads((OWNED / "source" / "SOURCE_HASHES.json").read_text(encoding="utf-8"))
    candidate_path = OWNED / result["candidate_source_manifest_path"]
    candidate = json.loads(candidate_path.read_text(encoding="utf-8"))
    diff_hash = json.loads((OWNED / result["diff_hash_path"]).read_text(encoding="utf-8"))
    checks = {}
    checks["product_head_exact"] = subprocess.check_output(["git", "-C", str(PRODUCT), "rev-parse", "HEAD"]).decode("ascii").strip() == EXACT_HEAD
    checks["contract_match"] = result["contract"]["requirements_match"] is True and result["contract"]["requirements_sha256_computed"] == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
    checks["tool_match"] = result["godot"]["match"] is True and result["godot"]["sha256"] == "ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424"
    checks["tests_622_0"] = result["tests"]["checks"] == 622 and result["tests"]["failures"] == 0
    checks["export_7"] = result["export"]["asset_count"] == 7
    checks["geometry_exact"] = result["geometry"]["status"] == "exact_geometry_and_shape_match" and result["geometry"]["assets_exactly_equal"] is True and result["geometry"]["reference_file_sha256"] == result["geometry"]["candidate_file_sha256"]
    checks["mesh_45_zero_findings"] = result["mesh_review"]["mesh_count"] == 45 and result["mesh_review"]["findings"] == [] and result["mesh_review"]["asset_count"] == 7
    checks["render_11"] = len(result["images"]) == 11 and result["render"]["shot_count"] == 11 and result["render"]["all_technical_checks_pass"] is True
    checks["render_gpu_actual"] = "NVIDIA" in str(result["render"]["video_adapter_vendor"]) and result["render"]["window_position_actual"] == [-3200, 120] and result["render"]["window_size_actual"] == [1280, 720]
    checks["root_flags_not_run"] = result["root_G01"] == "not_run" and result["system"] == "not_run" and result["board"] == "not_run"
    checks["pending_main_review"] = result["status"] == "candidate_ready_pending_main_visual_review" and result["adoption"] == "pending_main_personal_visual_review"
    checks["g01_not_claimed"] = "G01" in result["not_claimed"] and "game_grade" in result["not_claimed"]
    checks["candidate_manifest_hash"] = sha(candidate_path) == result["candidate_source_manifest_sha256"]
    checks["scope_check_hash"] = sha(OWNED / result["scope_check_path"]) == result["scope_check_sha256"]
    checks["material_changes_hash"] = sha(OWNED / result["material_changes_path"]) == result["material_changes_sha256"]
    checks["diff_hash_record"] = sha(OWNED / result["diff_hash_path"]) == result["diff_hash_sha256"]
    checks["source_diff_hash"] = sha(OWNED / result["source_diff_path"]) == diff_hash["source_diff_sha256"]
    checks["baseline_manifest_hashes"] = all(sha(OWNED / "source" / "baseline" / "project" / item["path"]) == item["sha256"] for item in baseline["source_files"])
    checks["candidate_manifest_hashes"] = all(sha(OWNED / "source" / "candidates" / "round-1" / "project" / item["path"]) == item["candidate_sha256"] for item in candidate["files"])
    checks["work_project_matches_candidate"] = all(sha(OWNED / "work" / "candidate-round-1-project" / item["path"]) == item["candidate_sha256"] for item in candidate["files"])
    checks["product_sources_unchanged"] = all(sha(PRODUCT / "competition" / "deepeye" / "simulator" / item["path"]) == item["sha256"] for item in baseline["source_files"])
    checks["images_exist_and_hash"] = all(sha(OWNED / image["path"]) == image["sha256"] for image in result["images"])
    checks["no_godot_process"] = subprocess.check_output(["powershell", "-NoProfile", "-Command", "Get-Process Godot* -ErrorAction SilentlyContinue | Measure-Object | Select-Object -ExpandProperty Count"]).decode("ascii").strip() in ("0", "")
    checks["no_pycache"] = not list(OWNED.rglob("__pycache__"))
    audit = {"checks": checks, "all_pass": all(checks.values()), "result_status": result["status"], "checked_at_utc": datetime.now(timezone.utc).isoformat()}
    (OWNED / "AUDIT.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8", newline="\n")
    print(json.dumps(audit, indent=2))
    return 0 if audit["all_pass"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
