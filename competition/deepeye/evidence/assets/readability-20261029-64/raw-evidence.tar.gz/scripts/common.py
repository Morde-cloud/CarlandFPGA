from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime, timezone

OWNED = pathlib.Path(__file__).resolve().parents[1]
REPO = pathlib.Path(r"D:\pynq\CarlandFPGA")
PRODUCT = REPO / ".local" / "worktrees" / "deepeye-implementation-20261014"
PRODUCT_EVIDENCE = PRODUCT / "competition" / "deepeye" / "evidence" / "assets" / "main-review-20261016"
SIMULATOR = PRODUCT / "competition" / "deepeye" / "simulator"

EXACT_HEAD = "056844e02e49f5047edb2151a838947dd8cdf409"
DESIGN_COMMIT = "1011259415a0916054eb580687612580bc1e5f09"
CONTRACT_COMMIT = "f5989cd5defce561f9ba98e6b18fc2682945f0a2"
REQUIREMENTS_SHA = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"

GODOT = REPO / ".local" / "tools" / "godot" / "4.7.2-stable" / "Godot_v4.7.2-stable_win64.exe"
GODOT_SHA = "ab1824f85bfd8e0e4128182c000c4003a3e042245b2967848d089b2a04b22424"

SOURCE_RELS = [
    "world/asset_library.gd",
    "world/asset_library.gd.uid",
    "world/drill_geometry.gd",
    "world/drill_geometry.gd.uid",
    "world/frame_geometry.gd",
    "world/frame_geometry.gd.uid",
    "world/obstacle_geometry.gd",
    "world/obstacle_geometry.gd.uid",
    "tests/test_asset_contract.gd",
    "tests/test_asset_contract.gd.uid",
    "assets/LICENSES.md",
    "assets/scene_catalog.json",
]

PRODUCT_SOURCE_PREFIX = pathlib.Path("competition/deepeye/simulator")

HARNESS_FILES = {
    "export_asset_meshes.gd": ("competition/deepeye/evidence/assets/main-review-20261016/export_asset_meshes.gd", "tools/export_asset_meshes.gd"),
    "mesh_review.py": ("competition/deepeye/evidence/assets/main-review-20261016/mesh_review.py", "tools/mesh_review.py"),
    "render_capture.gd": ("competition/deepeye/evidence/assets/main-review-20261016/render/render_capture.gd", "tools/render_capture.gd"),
    "project.godot": ("competition/deepeye/evidence/assets/main-review-20261016/render/project.godot", "tools/project.godot"),
    "png_verify.py": ("competition/deepeye/evidence/assets/main-review-20261016/render/png_verify.py", "tools/png_verify.py"),
}

REFERENCE_DIR = OWNED / "reference" / "main-review-20261016"
SOURCE_BASELINE = OWNED / "source" / "baseline"
SOURCE_CANDIDATES = OWNED / "source" / "candidates"
WORK = OWNED / "work"
EVIDENCE = OWNED / "evidence"
TOOLS = OWNED / "tools"
TEMP = OWNED / "temp"
CACHE = OWNED / "cache"

PNG_NAMES = [
    "01_drill_actual_scale_oblique.png",
    "02_drill_head_detail_6blades_18studs.png",
    "03_obstacle_kind_gallery_5kinds.png",
    "04_world_overview_30obstacles_drill_frame.png",
    "05_world_alt_angle_hollow_edge_cube.png",
    "06_drill_axis_minus_x.png",
    "06_drill_axis_minus_y.png",
    "06_drill_axis_minus_z.png",
    "06_drill_axis_plus_x.png",
    "06_drill_axis_plus_y.png",
    "06_drill_axis_plus_z.png",
]

ALLOWED_FUNCTIONS = {
    "world/drill_geometry.gd": ["_material_pdc_blade", "_material_pdc_stud"],
    "world/obstacle_geometry.gd": ["_material_void", "_material_casing"],
}

OLD_MATERIALS = {
    "world/drill_geometry.gd": {
        "_material_pdc_blade": {"color": [0.07, 0.07, 0.08], "metallic": 0.35, "roughness": 0.14},
        "_material_pdc_stud": {"color": [0.12, 0.12, 0.14], "metallic": 0.60, "roughness": 0.06},
    },
    "world/obstacle_geometry.gd": {
        "_material_void": {"color": [0.05, 0.05, 0.07], "metallic": 0.05, "roughness": 0.95},
        "_material_casing": {"color": [0.62, 0.64, 0.68], "metallic": 0.95, "roughness": 0.18},
    },
}

ROUND_SPECS = {
    1: {
        "world/drill_geometry.gd": {
            "_material_pdc_blade": {"color": [0.22, 0.24, 0.29], "metallic": 0.35, "roughness": 0.34},
            "_material_pdc_stud": {"color": [0.55, 0.50, 0.42], "metallic": 0.45, "roughness": 0.28},
        },
        "world/obstacle_geometry.gd": {
            "_material_void": {"color": [0.14, 0.155, 0.19], "metallic": 0.00, "roughness": 0.90},
            "_material_casing": {"color": [0.62, 0.64, 0.68], "metallic": 0.95, "roughness": 0.18},
        },
    },
}

FORBIDDEN_TOKENS = [
    "emission",
    "emission_enabled",
    "emission_energy",
    "EMISSION",
    "unshaded",
    "SHADING_MODE_UNSHADED",
    "shading_mode",
    "albedo_texture",
    "normal_texture",
    "roughness_texture",
    "metallic_texture",
    "transparency",
    "blend_mode",
    "next_pass",
    "cull_mode",
    "vertex_color_use_as_albedo",
    "billboard_mode",
    "grow",
    "depth_draw_mode",
    "no_depth_test",
    "disable_receive_shadows",
    "disable_ambient_light",
]


def now_utc() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: pathlib.Path) -> str:
    return sha256_bytes(path.read_bytes())


def canonical_json_bytes(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")


def canonical_sha(value) -> str:
    return sha256_bytes(canonical_json_bytes(value))


def write_json(path: pathlib.Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n", encoding="utf-8", newline="\n")


def write_text(path: pathlib.Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8", newline="\n")


def git_show(commit: str, rel: str) -> bytes:
    return subprocess.check_output(["git", "-C", str(REPO), "show", f"{commit}:{rel}"])


def git_head(product: pathlib.Path = PRODUCT) -> str:
    return subprocess.check_output(["git", "-C", str(product), "rev-parse", "HEAD"]).decode("ascii").strip()


def verify_godot() -> dict:
    data = GODOT.read_bytes()
    actual = sha256_bytes(data)
    return {"path": str(GODOT), "bytes": len(data), "sha256": actual, "expected": GODOT_SHA, "match": actual == GODOT_SHA}


def extract_function(text: str, name: str) -> str:
    marker = f"static func {name}("
    start = text.index(marker)
    end = text.find("\n\nstatic func ", start + len(marker))
    if end < 0:
        end = len(text)
    return text[start:end]


def function_line_range(text: str, name: str) -> tuple[int, int]:
    lines = text.splitlines()
    marker = f"static func {name}("
    start_line = None
    for index, line in enumerate(lines, 1):
        if line.lstrip().startswith(marker):
            start_line = index
            break
    if start_line is None:
        raise ValueError(f"function not found: {name}")
    end_line = len(lines)
    for index in range(start_line + 1, len(lines) + 1):
        if lines[index - 1].lstrip().startswith("static func "):
            end_line = index - 1
            break
    return start_line, end_line


def normalize_numbers(text: str) -> str:
    return re.sub(r"(?<![A-Za-z_])-?\d+(?:\.\d+)?", "<n>", text)


def strip_allowed_functions(text: str, names: list[str]) -> str:
    for name in names:
        block = extract_function(text, name)
        text = text.replace(block, f"<<{name}>>", 1)
    return text


def fmt_number(value: float) -> str:
    text = format(float(value), ".6g")
    if "." not in text and "e" not in text and "E" not in text:
        text += ".0"
    return text


def material_line(function: str, spec: dict) -> str:
    color = spec["color"]
    color_text = ", ".join(fmt_number(v) for v in color)
    if function == "_material_pdc_blade" or function == "_material_pdc_stud":
        return f"    return _standard_material(Color({color_text}), {fmt_number(spec['metallic'])}, {fmt_number(spec['roughness'])})"
    if function == "_material_void" or function == "_material_casing":
        return f"    return _opaque_material(Color({color_text}), {fmt_number(spec['metallic'])}, {fmt_number(spec['roughness'])})"
    raise ValueError(function)


def old_material_line(function: str, spec: dict) -> str:
    color = spec["color"]
    color_text = ", ".join(format(float(v), ".2f") for v in color)
    if function == "_material_pdc_blade" or function == "_material_pdc_stud":
        return f"    return _standard_material(Color({color_text}), {format(float(spec['metallic']), '.2f')}, {format(float(spec['roughness']), '.2f')})"
    if function == "_material_void" or function == "_material_casing":
        return f"    return _opaque_material(Color({color_text}), {format(float(spec['metallic']), '.2f')}, {format(float(spec['roughness']), '.2f')})"
    raise ValueError(function)


def ensure_dirs() -> None:
    for path in [OWNED, TOOLS, SOURCE_BASELINE, SOURCE_CANDIDATES, WORK, EVIDENCE, TEMP, CACHE, OWNED / "contract"]:
        path.mkdir(parents=True, exist_ok=True)


def copy_project(src: pathlib.Path, dst: pathlib.Path) -> None:
    if dst.exists():
        raise FileExistsError(f"destination already exists: {dst}")
    shutil.copytree(src, dst)


def install_harness(project: pathlib.Path) -> None:
    shutil.copyfile(TOOLS / "export_asset_meshes.gd", project / "export_asset_meshes.gd")
    (project / "render").mkdir(exist_ok=True)
    shutil.copyfile(TOOLS / "render_capture.gd", project / "render" / "render_capture.gd")
    shutil.copyfile(TOOLS / "project.godot", project / "project.godot")


def project_file_hashes(project: pathlib.Path) -> dict[str, str]:
    result = {}
    for path in sorted(project.rglob("*")):
        if path.is_file() and ".godot" not in path.parts and "png" not in path.parts and "results" not in path.parts:
            result[path.relative_to(project).as_posix()] = sha256_file(path)
    return result


def next_attempt_dir(variant: str) -> pathlib.Path:
    base = EVIDENCE / variant
    base.mkdir(parents=True, exist_ok=True)
    existing = [p for p in base.iterdir() if p.is_dir() and p.name.startswith("attempt-")]
    numbers = []
    for path in existing:
        try:
            numbers.append(int(path.name.split("-")[1]))
        except (IndexError, ValueError):
            pass
    number = max(numbers, default=0) + 1
    attempt = base / f"attempt-{number}"
    attempt.mkdir()
    return attempt


def run_command(attempt: pathlib.Path, name: str, argv: list[str], cwd: pathlib.Path, env: dict, timeout: int = 60) -> tuple[dict, bytes, bytes]:
    logs = attempt / "logs"
    logs.mkdir(exist_ok=True)
    tool = verify_godot()
    if not tool["match"]:
        raise RuntimeError(f"Godot hash mismatch: {tool}")
    started = now_utc()
    started_monotonic = time.monotonic()
    creationflags = subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0
    proc = subprocess.Popen(argv, cwd=str(cwd), env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, creationflags=creationflags)
    timed_out = False
    try:
        stdout, stderr = proc.communicate(timeout=timeout)
    except subprocess.TimeoutExpired:
        timed_out = True
        proc.kill()
        stdout, stderr = proc.communicate()
    finished = now_utc()
    duration = time.monotonic() - started_monotonic
    stdout_path = logs / f"{name}.stdout.txt"
    stderr_path = logs / f"{name}.stderr.txt"
    stdout_path.write_bytes(stdout)
    stderr_path.write_bytes(stderr)
    record = {
        "name": name,
        "argv": argv,
        "cwd": str(cwd),
        "tool_sha256": tool["sha256"],
        "tool_expected_sha256": tool["expected"],
        "tool_match": tool["match"],
        "pid": proc.pid,
        "started_utc": started,
        "finished_utc": finished,
        "duration_s": round(duration, 3),
        "timeout_s": timeout,
        "timed_out": timed_out,
        "exit": proc.returncode,
        "stdout_path": str(stdout_path.relative_to(OWNED)).replace("\\", "/"),
        "stderr_path": str(stderr_path.relative_to(OWNED)).replace("\\", "/"),
        "stdout_sha256": sha256_bytes(stdout),
        "stderr_sha256": sha256_bytes(stderr),
        "stdout_bytes": len(stdout),
        "stderr_bytes": len(stderr),
    }
    return record, stdout, stderr


def test_summary(stdout: bytes, stderr: bytes) -> dict:
    text = stdout.decode("utf-8", "replace")
    err = stderr.decode("utf-8", "replace")
    checks = None
    failures = None
    match = re.search(r"RESULT checks=(\d+) failures=(\d+)", text)
    if match:
        checks = int(match.group(1))
        failures = int(match.group(2))
    return {
        "checks": checks,
        "failures": failures,
        "expected_checks": 622,
        "expected_failures": 0,
        "checks_match": checks == 622,
        "failures_match": failures == 0,
        "result_line_present": bool(match),
        "intentional_negative_stderr_present": "unknown obstacle kind" in err or "unknown" in err.lower(),
        "stdout_tail": text[-1200:],
        "stderr_tail": err[-1200:],
    }


def export_summary(stdout: bytes, stderr: bytes) -> dict:
    text = stdout.decode("utf-8", "replace")
    match = re.search(r"EXPORT asset_count=(\d+)", text)
    return {
        "asset_count": int(match.group(1)) if match else None,
        "expected_asset_count": 7,
        "asset_count_match": bool(match and int(match.group(1)) == 7),
        "stdout_tail": text[-800:],
        "stderr_tail": stderr.decode("utf-8", "replace")[-800:],
    }
