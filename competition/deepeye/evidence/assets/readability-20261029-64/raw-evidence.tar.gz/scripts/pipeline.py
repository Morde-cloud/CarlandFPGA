from __future__ import annotations

import argparse
import difflib
import importlib.util
import json
import os
import pathlib
import shutil
import subprocess
import sys
import traceback
from datetime import datetime, timezone

from common import (
    ALLOWED_FUNCTIONS,
    CACHE,
    CONTRACT_COMMIT,
    DESIGN_COMMIT,
    EVIDENCE,
    EXACT_HEAD,
    FORBIDDEN_TOKENS,
    GODOT,
    GODOT_SHA,
    HARNESS_FILES,
    OLD_MATERIALS,
    OWNED,
    PNG_NAMES,
    PRODUCT,
    PRODUCT_EVIDENCE,
    PRODUCT_SOURCE_PREFIX,
    REFERENCE_DIR,
    REQUIREMENTS_SHA,
    ROUND_SPECS,
    SIMULATOR,
    SOURCE_BASELINE,
    SOURCE_CANDIDATES,
    SOURCE_RELS,
    TEMP,
    TOOLS,
    WORK,
    canonical_sha,
    copy_project,
    ensure_dirs,
    export_summary,
    extract_function,
    function_line_range,
    git_head,
    git_show,
    install_harness,
    material_line,
    next_attempt_dir,
    normalize_numbers,
    now_utc,
    old_material_line,
    project_file_hashes,
    run_command,
    sha256_bytes,
    sha256_file,
    strip_allowed_functions,
    test_summary,
    verify_godot,
    write_json,
    write_text,
)


def fail(message: str) -> None:
    raise RuntimeError(message)


def verify_head() -> str:
    head = git_head(PRODUCT)
    if head != EXACT_HEAD:
        fail(f"product worktree HEAD is {head}, expected {EXACT_HEAD}")
    return head


def prepare_sources() -> list[dict]:
    records = []
    for rel in SOURCE_RELS:
        product_rel = (PRODUCT_SOURCE_PREFIX / rel).as_posix()
        blob = git_show(EXACT_HEAD, product_rel)
        worktree = (PRODUCT / product_rel).read_bytes()
        head_sha = sha256_bytes(blob)
        worktree_sha = sha256_bytes(worktree)
        if head_sha != worktree_sha:
            fail(f"worktree differs from exact HEAD: {product_rel}")
        target = SOURCE_BASELINE / "project" / rel
        if target.exists():
            if target.read_bytes() != blob:
                fail(f"existing owned baseline source differs: {target}")
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(blob)
        records.append({
            "path": rel,
            "product_path": product_rel,
            "bytes": len(blob),
            "sha256": head_sha,
            "worktree_sha256": worktree_sha,
            "worktree_matches_head": head_sha == worktree_sha,
        })
    return records


def prepare_harness() -> list[dict]:
    records = []
    for key, (rel, dest) in HARNESS_FILES.items():
        blob = git_show(EXACT_HEAD, rel)
        target = OWNED / dest
        if target.exists():
            if target.read_bytes() != blob:
                fail(f"existing owned harness differs: {target}")
        else:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(blob)
        records.append({
            "name": key,
            "product_path": rel,
            "owned_path": dest,
            "bytes": len(blob),
            "sha256": sha256_bytes(blob),
        })
    return records


def prepare_reference() -> list[dict]:
    if not REFERENCE_DIR.exists():
        shutil.copytree(PRODUCT_EVIDENCE, REFERENCE_DIR)
    records = []
    for source in sorted(PRODUCT_EVIDENCE.rglob("*")):
        if not source.is_file():
            continue
        rel = source.relative_to(PRODUCT_EVIDENCE).as_posix()
        target = REFERENCE_DIR / rel
        if not target.is_file():
            fail(f"reference copy missing: {rel}")
        source_sha = sha256_file(source)
        target_sha = sha256_file(target)
        if source_sha != target_sha:
            fail(f"reference copy differs: {rel}")
        records.append({"path": rel, "bytes": source.stat().st_size, "sha256": source_sha})
    return records


def prepare_contract() -> dict:
    json_rel = "docs/competition/deepeye-2026/immutable_scope.json"
    md_rel = "docs/competition/deepeye-2026/immutable_scope.md"
    json_blob = git_show(CONTRACT_COMMIT, json_rel)
    md_blob = git_show(CONTRACT_COMMIT, md_rel)
    (OWNED / "contract").mkdir(exist_ok=True)
    (OWNED / "contract" / "immutable_scope.json").write_bytes(json_blob)
    (OWNED / "contract" / "immutable_scope.md").write_bytes(md_blob)
    document = json.loads(json_blob.decode("utf-8"))
    computed = canonical_sha(document["requirements"])
    ids = [item["id"] for item in document["requirements"]]
    check = {
        "contract_id": document.get("contract_id"),
        "revision": document.get("revision"),
        "task_id": document.get("task_id"),
        "source_commit": CONTRACT_COMMIT,
        "design_commit": DESIGN_COMMIT,
        "json_sha256": sha256_bytes(json_blob),
        "md_sha256": sha256_bytes(md_blob),
        "requirements_sha256_in_document": document.get("requirements_sha256"),
        "requirements_sha256_expected": REQUIREMENTS_SHA,
        "requirements_sha256_computed": computed,
        "requirements_match": computed == REQUIREMENTS_SHA,
        "requirements_count": len(ids),
        "requirement_ids": ids,
    }
    if computed != REQUIREMENTS_SHA:
        fail(f"requirements hash mismatch: {computed}")
    if ids != [f"H{i:02d}" for i in range(1, 16)]:
        fail(f"unexpected requirement ids: {ids}")
    write_json(OWNED / "contract" / "CONTRACT_CHECK.json", check)
    return check


def write_hash_table(source_records: list[dict], harness_records: list[dict], tool: dict, contract: dict, reference_records: list[dict]) -> None:
    lines = [
        "# Owned source hash table",
        "",
        f"- Exact product worktree HEAD: `{EXACT_HEAD}` (verified).",
        f"- Frozen design commit: `{DESIGN_COMMIT}`.",
        f"- Contract source commit: `{CONTRACT_COMMIT}`.",
        f"- Canonical requirements SHA256: `{contract['requirements_sha256_computed']}` (match={contract['requirements_match']}).",
        f"- Godot executable SHA256: `{tool['sha256']}` (expected `{GODOT_SHA}`, match={tool['match']}).",
        "",
        "## Baseline source files (exact HEAD bytes)",
        "",
        "| path | bytes | sha256 | worktree==HEAD |",
        "|---|---:|---|---|",
    ]
    for item in source_records:
        lines.append(f"| `{item['path']}` | {item['bytes']} | `{item['sha256']}` | {item['worktree_matches_head']} |")
    lines += [
        "",
        "## Reused harness files (exact HEAD bytes, not modified)",
        "",
        "| name | owned path | bytes | sha256 |",
        "|---|---|---:|---|",
    ]
    for item in harness_records:
        lines.append(f"| `{item['name']}` | `{item['owned_path']}` | {item['bytes']} | `{item['sha256']}` |")
    lines += [
        "",
        "## Reference evidence copy",
        "",
        f"- `{REFERENCE_DIR.relative_to(OWNED).as_posix()}` contains {len(reference_records)} byte-identical old evidence files, including the old `source-manifest.json`, `geometry/exported_meshes.json`, `convex-review.json`, `visual-review.json`, and 11 PNGs.",
        f"- Old `geometry/exported_meshes.json` SHA256: `{sha256_file(REFERENCE_DIR / 'geometry' / 'exported_meshes.json')}`.",
        f"- Old `geometry/source-manifest.json` SHA256: `{sha256_file(REFERENCE_DIR / 'geometry' / 'source-manifest.json')}`.",
        f"- Old `visual-review.json` SHA256: `{sha256_file(REFERENCE_DIR / 'visual-review.json')}`.",
        "",
    ]
    write_text(OWNED / "source" / "HASH_TABLE.md", "\n".join(lines))


def verify_project_against_source(variant: str, project: pathlib.Path) -> list[str]:
    if variant == "baseline":
        source_project = SOURCE_BASELINE / "project"
    elif variant.startswith("candidate-r"):
        round_no = int(variant.split("candidate-r", 1)[1])
        source_project = SOURCE_CANDIDATES / f"round-{round_no}" / "project"
    else:
        fail(f"unknown variant: {variant}")
    problems = []
    source_hashes = project_file_hashes(source_project)
    for rel, expected in source_hashes.items():
        target = project / rel
        if not target.is_file():
            problems.append(f"missing {rel}")
        elif sha256_file(target) != expected:
            problems.append(f"hash mismatch {rel}")
    for name, dest in [("export_asset_meshes.gd", "export_asset_meshes.gd"), ("render_capture.gd", "render/render_capture.gd"), ("project.godot", "project.godot")]:
        target = project / dest
        expected = sha256_file(TOOLS / name)
        if not target.is_file() or sha256_file(target) != expected:
            problems.append(f"harness hash mismatch {dest}")
    return problems


def cmd_prepare(args: argparse.Namespace) -> int:
    ensure_dirs()
    head = verify_head()
    tool = verify_godot()
    if not tool["match"]:
        fail(f"Godot hash mismatch: {tool}")
    source_records = prepare_sources()
    harness_records = prepare_harness()
    reference_records = prepare_reference()
    contract = prepare_contract()
    snapshot = {
        "at_utc": now_utc(),
        "exact_head": EXACT_HEAD,
        "head_verified": head == EXACT_HEAD,
        "design_commit": DESIGN_COMMIT,
        "product_worktree": str(PRODUCT),
        "source_files": source_records,
        "harness_files": harness_records,
        "reference_files_count": len(reference_records),
        "godot": tool,
        "contract": contract,
    }
    write_json(OWNED / "source" / "SOURCE_HASHES.json", snapshot)
    write_json(OWNED / "reference" / "REFERENCE_HASHES.json", {"files": reference_records, "count": len(reference_records)})
    write_json(OWNED / "TOOL_HASHES.json", {"godot": tool, "harness": harness_records, "note": "Godot executable and reusable scripts are recorded before any candidate run."})
    write_hash_table(source_records, harness_records, tool, contract, reference_records)
    baseline_work = WORK / "baseline-project"
    if not baseline_work.exists():
        copy_project(SOURCE_BASELINE / "project", baseline_work)
        install_harness(baseline_work)
    problems = verify_project_against_source("baseline", baseline_work)
    if problems:
        fail(f"baseline work project verification failed: {problems}")
    print(f"PREPARE ok head={head} sources={len(source_records)} harness={len(harness_records)} reference={len(reference_records)} baseline_work={baseline_work}")
    return 0


def apply_material_spec(project: pathlib.Path, round_no: int, spec: dict) -> dict:
    changes = []
    for rel, functions in spec.items():
        path = project / rel
        text = path.read_text(encoding="utf-8")
        for function, new_spec in functions.items():
            old_spec = OLD_MATERIALS[rel][function]
            changed = old_spec != new_spec
            if changed:
                old_line = old_material_line(function, old_spec)
                new_line = material_line(function, new_spec)
                count = text.count(old_line)
                if count != 1:
                    fail(f"expected exactly one old material line for {rel}:{function}, found {count}: {old_line!r}")
                text = text.replace(old_line, new_line, 1)
            changes.append({
                "file": rel,
                "function": function,
                "old": old_spec,
                "new": new_spec,
                "changed": changed,
            })
        path.write_text(text, encoding="utf-8", newline="\n")
    return {"round": round_no, "changes": changes}


def changed_opcodes(before: str, after: str) -> list[dict]:
    a = before.splitlines()
    b = after.splitlines()
    matcher = difflib.SequenceMatcher(None, a, b, autojunk=False)
    records = []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            continue
        records.append({
            "tag": tag,
            "before_lines": [i1 + 1, i2],
            "after_lines": [j1 + 1, j2],
            "before": a[i1:i2],
            "after": b[j1:j2],
        })
    return records


def scope_check(baseline_project: pathlib.Path, candidate_project: pathlib.Path) -> dict:
    baseline_hashes = project_file_hashes(baseline_project)
    candidate_hashes = project_file_hashes(candidate_project)
    if set(baseline_hashes) != set(candidate_hashes):
        fail("baseline and candidate project file sets differ")
    changed_files = [rel for rel in sorted(baseline_hashes) if baseline_hashes[rel] != candidate_hashes[rel]]
    allowed_files = set(ALLOWED_FUNCTIONS)
    if not set(changed_files) <= allowed_files:
        fail(f"files outside allowed material scope changed: {sorted(set(changed_files) - allowed_files)}")
    checks = []
    for rel, functions in ALLOWED_FUNCTIONS.items():
        before = (baseline_project / rel).read_text(encoding="utf-8")
        after = (candidate_project / rel).read_text(encoding="utf-8")
        outside_equal = strip_allowed_functions(before, functions) == strip_allowed_functions(after, functions)
        normalized = {}
        for function in functions:
            normalized[function] = normalize_numbers(extract_function(before, function)) == normalize_numbers(extract_function(after, function))
        ranges = [function_line_range(after, function) for function in functions]
        opcodes = changed_opcodes(before, after)
        outside_changed_lines = []
        forbidden_hits = []
        for opcode in opcodes:
            for line_no in range(opcode["after_lines"][0], opcode["after_lines"][1] + 1):
                if not any(start <= line_no <= end for start, end in ranges):
                    outside_changed_lines.append(line_no)
            changed_text = "\n".join(opcode["before"] + opcode["after"])
            for token in FORBIDDEN_TOKENS:
                if token in changed_text:
                    forbidden_hits.append({"line": opcode["after_lines"], "token": token})
        if not outside_equal:
            fail(f"outside material functions changed in {rel}")
        if not all(normalized.values()):
            fail(f"non-numeric material function change in {rel}: {normalized}")
        if outside_changed_lines:
            fail(f"changed lines outside allowed functions in {rel}: {outside_changed_lines}")
        if forbidden_hits:
            fail(f"forbidden material token in {rel}: {forbidden_hits}")
        checks.append({
            "file": rel,
            "allowed_functions": functions,
            "outside_allowed_functions_identical": outside_equal,
            "normalized_function_body_identical": normalized,
            "changed_line_ranges": opcodes,
            "forbidden_token_hits": forbidden_hits,
            "function_line_ranges": {function: list(function_line_range(after, function)) for function in functions},
        })
    return {
        "status": "pass",
        "changed_files": changed_files,
        "allowed_files": sorted(allowed_files),
        "checks": checks,
        "forbidden_tokens": FORBIDDEN_TOKENS,
        "geometry_collision_transform_names_metadata_changed": False,
        "note": "Only numeric color/metallic/roughness values inside the four named material functions changed; casing is unchanged.",
    }


def cmd_candidate(args: argparse.Namespace) -> int:
    ensure_dirs()
    verify_head()
    tool = verify_godot()
    if not tool["match"]:
        fail(f"Godot hash mismatch: {tool}")
    if args.spec:
        spec = json.loads(pathlib.Path(args.spec).read_text(encoding="utf-8"))
    else:
        if args.round not in ROUND_SPECS:
            fail(f"no built-in spec for round {args.round}; pass --spec")
        spec = ROUND_SPECS[args.round]
    if set(spec) != set(ALLOWED_FUNCTIONS):
        fail(f"spec files must be exactly {sorted(ALLOWED_FUNCTIONS)}")
    for rel, functions in ALLOWED_FUNCTIONS.items():
        if set(spec[rel]) != set(functions):
            fail(f"spec functions for {rel} must be exactly {functions}")
    round_root = SOURCE_CANDIDATES / f"round-{args.round}"
    if round_root.exists():
        fail(f"candidate round already exists; refusing to overwrite evidence: {round_root}")
    round_root.mkdir(parents=True)
    candidate_project = round_root / "project"
    copy_project(SOURCE_BASELINE / "project", candidate_project)
    material_changes = apply_material_spec(candidate_project, args.round, spec)
    write_json(round_root / "MATERIAL_CHANGES.json", material_changes)
    scope = scope_check(SOURCE_BASELINE / "project", candidate_project)
    write_json(round_root / "SCOPE_CHECK.json", scope)
    baseline_hashes = project_file_hashes(SOURCE_BASELINE / "project")
    candidate_hashes = project_file_hashes(candidate_project)
    source_manifest = {
        "round": args.round,
        "baseline_exact_head": EXACT_HEAD,
        "baseline_project": str((SOURCE_BASELINE / "project").relative_to(OWNED)).replace("\\", "/"),
        "candidate_project": str(candidate_project.relative_to(OWNED)).replace("\\", "/"),
        "files": [{"path": rel, "baseline_sha256": baseline_hashes[rel], "candidate_sha256": candidate_hashes[rel], "changed": baseline_hashes[rel] != candidate_hashes[rel]} for rel in sorted(baseline_hashes)],
        "changed_files": scope["changed_files"],
        "material_changes": material_changes,
        "scope_check": scope,
    }
    write_json(round_root / "SOURCE_HASHES.json", source_manifest)
    diff_lines = [
        f"# Baseline exact HEAD {EXACT_HEAD} vs candidate round {args.round}",
        "# Only numeric color/metallic/roughness values in the four named material functions change.",
        "# Casing remains byte-identical to the baseline value.",
        "",
    ]
    for rel in scope["changed_files"]:
        before = (SOURCE_BASELINE / "project" / rel).read_text(encoding="utf-8").splitlines()
        after = (candidate_project / rel).read_text(encoding="utf-8").splitlines()
        diff_lines.extend(difflib.unified_diff(before, after, fromfile=f"baseline/{rel}", tofile=f"candidate-round-{args.round}/{rel}", n=6, lineterm=""))
    diff_text = "\n".join(diff_lines).rstrip() + "\n"
    write_text(round_root / "SOURCE_DIFF.patch", diff_text)
    write_text(OWNED / "CANDIDATE_SOURCE_DIFF.patch", diff_text)
    write_json(OWNED / "CANDIDATE_MATERIAL_CHANGES.json", material_changes)
    work_project = WORK / f"candidate-round-{args.round}-project"
    if not work_project.exists():
        copy_project(candidate_project, work_project)
        install_harness(work_project)
    problems = verify_project_against_source(f"candidate-r{args.round}", work_project)
    if problems:
        fail(f"candidate work project verification failed: {problems}")
    summary = {
        "status": "pass",
        "round": args.round,
        "candidate_root": str(round_root.relative_to(OWNED)).replace("\\", "/"),
        "work_project": str(work_project.relative_to(OWNED)).replace("\\", "/"),
        "changed_files": scope["changed_files"],
        "source_diff": str((round_root / "SOURCE_DIFF.patch").relative_to(OWNED)).replace("\\", "/"),
        "materials": material_changes,
        "godot": tool,
    }
    write_json(round_root / "CANDIDATE_PREP.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0


def load_module(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def find_diffs(reference, candidate, path: str = "", limit: int = 20) -> list[dict]:
    out: list[dict] = []
    if len(out) >= limit:
        return out
    if type(reference) is not type(candidate):
        out.append({"path": path, "reference_type": type(reference).__name__, "candidate_type": type(candidate).__name__})
        return out
    if isinstance(reference, dict):
        for key in sorted(set(reference) | set(candidate)):
            if key not in reference or key not in candidate:
                out.append({"path": f"{path}/{key}", "missing": "reference" if key not in reference else "candidate"})
            else:
                out.extend(find_diffs(reference[key], candidate[key], f"{path}/{key}", limit - len(out)))
            if len(out) >= limit:
                break
    elif isinstance(reference, list):
        if len(reference) != len(candidate):
            out.append({"path": path, "reference_len": len(reference), "candidate_len": len(candidate)})
        for index in range(min(len(reference), len(candidate))):
            out.extend(find_diffs(reference[index], candidate[index], f"{path}[{index}]", limit - len(out)))
            if len(out) >= limit:
                break
    elif isinstance(reference, (int, float)) and isinstance(candidate, (int, float)):
        if reference != candidate:
            out.append({"path": path, "reference": reference, "candidate": candidate, "delta": candidate - reference})
    else:
        if reference != candidate:
            out.append({"path": path, "reference": reference, "candidate": candidate})
    return out


def geometry_comparison(project: pathlib.Path, review: dict, attempt: pathlib.Path) -> dict:
    reference_raw = (REFERENCE_DIR / "geometry" / "exported_meshes.json").read_bytes()
    candidate_raw = (project / "exported_meshes.json").read_bytes()
    reference = json.loads(reference_raw)
    candidate = json.loads(candidate_raw)
    fixed_review = json.loads((REFERENCE_DIR / "convex-review.json").read_text(encoding="utf-8"))["fixed"]
    assets_equal = reference.get("assets") == candidate.get("assets")
    full_equal = reference == candidate
    review_equal = review == fixed_review
    mesh_count = sum(len(asset.get("meshes", [])) for asset in candidate.get("assets", []))
    shape_count = sum(len(asset.get("shapes", [])) for asset in candidate.get("assets", []))
    reference_mesh_count = sum(len(asset.get("meshes", [])) for asset in reference.get("assets", []))
    reference_shape_count = sum(len(asset.get("shapes", [])) for asset in reference.get("assets", []))
    result = {
        "reference_path": str((REFERENCE_DIR / "geometry" / "exported_meshes.json").relative_to(OWNED)).replace("\\", "/"),
        "candidate_path": str((attempt / "geometry" / "exported_meshes.json").relative_to(OWNED)).replace("\\", "/"),
        "reference_file_sha256": sha256_bytes(reference_raw),
        "candidate_file_sha256": sha256_bytes(candidate_raw),
        "reference_assets_canonical_sha256": canonical_sha(reference.get("assets")),
        "candidate_assets_canonical_sha256": canonical_sha(candidate.get("assets")),
        "full_file_equal": full_equal,
        "assets_exactly_equal": assets_equal,
        "assets_diff": [] if assets_equal else find_diffs(reference.get("assets"), candidate.get("assets")),
        "review_equals_old_fixed_review": review_equal,
        "review_asset_count": review.get("asset_count"),
        "review_mesh_count": review.get("mesh_count"),
        "review_findings": review.get("findings"),
        "review_status": review.get("status"),
        "candidate_mesh_count": mesh_count,
        "candidate_shape_count": shape_count,
        "reference_mesh_count": reference_mesh_count,
        "reference_shape_count": reference_shape_count,
        "expected_mesh_count": reference_mesh_count,
        "expected_shape_count": reference_shape_count,
        "mesh_count_ok": mesh_count == reference_mesh_count,
        "shape_count_ok": shape_count == reference_shape_count,
        "findings_empty": review.get("findings") == [],
        "status": "exact_geometry_and_shape_match" if (assets_equal and review_equal and mesh_count == reference_mesh_count and shape_count == reference_shape_count and review.get("findings") == []) else "mismatch",
    }
    return result


def verify_pngs(project: pathlib.Path, attempt: pathlib.Path) -> tuple[dict, list[dict]]:
    png_module = load_module("owned_png_verify", TOOLS / "png_verify.py")
    source_png = project / "png"
    dest_png = attempt / "renders" / "png"
    dest_png.mkdir(parents=True, exist_ok=True)
    entries = []
    for name in PNG_NAMES:
        source = source_png / name
        if not source.is_file():
            entries.append({"name": name, "exists": False, "pass": False, "error": "missing"})
            continue
        shutil.copyfile(source, dest_png / name)
        info = png_module.analyse(str(dest_png / name))
        info["name"] = name
        info["exists"] = True
        reference_png = REFERENCE_DIR / "render" / "png" / name
        reference_sha = sha256_file(reference_png) if reference_png.is_file() else None
        info["reference_path"] = str(reference_png.relative_to(OWNED)).replace("\\", "/") if reference_png.is_file() else None
        info["reference_sha256"] = reference_sha
        info["sha_matches_reference"] = reference_sha == info["sha256"]
        info["path"] = str((dest_png / name).relative_to(OWNED)).replace("\\", "/")
        entries.append(info)
    all_pass = all(entry.get("exists") and entry.get("pass") and entry.get("width") == 1280 and entry.get("height") == 720 for entry in entries)
    changed = sum(1 for entry in entries if entry.get("exists") and not entry.get("sha_matches_reference"))
    result = {
        "images": entries,
        "expected_count": 11,
        "actual_count": len([entry for entry in entries if entry.get("exists")]),
        "all_technical_checks_pass": all_pass,
        "changed_from_reference_count": changed,
        "note": "Technical checks only: PNG decode, 1280x720, nonblank, orientation bars. Main visual review remains required.",
    }
    return result, entries


def archive_stale(project: pathlib.Path, attempt: pathlib.Path, names: list[str], label: str) -> list[str]:
    archived = []
    destination = attempt / label
    for name in names:
        source = project / name
        if not source.exists():
            continue
        destination.mkdir(parents=True, exist_ok=True)
        target = destination / name
        if target.exists():
            index = 1
            while (destination / f"{name}.{index}").exists():
                index += 1
            target = destination / f"{name}.{index}"
        shutil.move(str(source), str(target))
        archived.append(str(target.relative_to(OWNED)).replace("\\", "/"))
    return archived


def cmd_run(args: argparse.Namespace) -> int:
    ensure_dirs()
    tool = verify_godot()
    if not tool["match"]:
        fail(f"Godot hash mismatch: {tool}")
    variant = args.variant
    if variant == "baseline":
        project = WORK / "baseline-project"
    elif variant.startswith("candidate-r"):
        project = WORK / f"candidate-round-{variant.split('candidate-r', 1)[1]}-project"
    else:
        fail(f"unknown variant: {variant}")
    if not project.is_dir():
        fail(f"work project does not exist: {project}")
    problems = verify_project_against_source(variant, project)
    if problems:
        fail(f"work project does not match prepared source: {problems}")
    attempt = next_attempt_dir(variant)
    info = {
        "variant": variant,
        "attempt": str(attempt.relative_to(OWNED)).replace("\\", "/"),
        "work_project": str(project.relative_to(OWNED)).replace("\\", "/"),
        "started_utc": now_utc(),
        "tool": tool,
        "commands": [],
        "not_claimed": ["G01", "game_grade", "system", "board", "runtime_gameplay", "continuous_collision"],
        "root_G01": "not_run",
        "system": "not_run",
        "board": "not_run",
    }
    attempt_temp = TEMP / variant / attempt.name
    appdata = attempt_temp / "appdata"
    localappdata = attempt_temp / "localappdata"
    cache_dir = CACHE / variant / attempt.name
    for path in [attempt_temp, appdata, localappdata, cache_dir]:
        path.mkdir(parents=True, exist_ok=True)
    env = os.environ.copy()
    env_overrides = {"TEMP": str(attempt_temp), "TMP": str(attempt_temp), "APPDATA": str(appdata), "LOCALAPPDATA": str(localappdata)}
    env.update(env_overrides)
    info["env_overrides"] = env_overrides
    info["env_overrides_note"] = "Only the Godot subprocess receives these owned TEMP/APPDATA/LOCALAPPDATA values; the parent environment is not modified."

    def finish(status: str, error: str | None = None) -> int:
        info["status"] = status
        if error:
            info["error"] = error
        info["finished_utc"] = now_utc()
        write_json(attempt / "run.json", info)
        print(json.dumps({"variant": variant, "attempt": info["attempt"], "status": status, "error": error, "commands": len(info["commands"])}, ensure_ascii=False))
        return 0 if status == "ok" else 1

    try:
        import_record, import_out, import_err = run_command(
            attempt,
            "import",
            [str(GODOT), "--path", str(project), "--headless", "--editor", "--import", "--quit"],
            project,
            env,
        )
        info["commands"].append(import_record)
        if import_record["exit"] != 0 or import_record["timed_out"]:
            return finish("failed:import", f"exit={import_record['exit']} timed_out={import_record['timed_out']} stderr={import_err.decode('utf-8', 'replace')[-800:]}")

        test_record, test_out, test_err = run_command(
            attempt,
            "tests",
            [str(GODOT), "--path", str(project), "--headless", "--script", "res://tests/test_asset_contract.gd"],
            project,
            env,
        )
        info["commands"].append(test_record)
        info["tests"] = test_summary(test_out, test_err)
        if test_record["exit"] != 0 or test_record["timed_out"]:
            return finish("failed:tests_exit", f"exit={test_record['exit']} timed_out={test_record['timed_out']}")
        if not (info["tests"]["checks_match"] and info["tests"]["failures_match"]):
            return finish("failed:tests_result", f"checks={info['tests']['checks']} failures={info['tests']['failures']}")

        archive_stale(project, attempt, ["exported_meshes.json"], "stale-before-export")
        export_record, export_out, export_err = run_command(
            attempt,
            "export",
            [str(GODOT), "--path", str(project), "--headless", "--script", "res://export_asset_meshes.gd"],
            project,
            env,
        )
        info["commands"].append(export_record)
        info["export"] = export_summary(export_out, export_err)
        if export_record["exit"] != 0 or export_record["timed_out"]:
            return finish("failed:export_exit", f"exit={export_record['exit']} timed_out={export_record['timed_out']}")
        if not info["export"]["asset_count_match"]:
            return finish("failed:export_assets", f"asset_count={info['export']['asset_count']}")
        exported = project / "exported_meshes.json"
        if not exported.is_file():
            return finish("failed:export_missing", "exported_meshes.json missing")
        geometry_dir = attempt / "geometry"
        geometry_dir.mkdir(exist_ok=True)
        shutil.copyfile(exported, geometry_dir / "exported_meshes.json")
        mesh_module = load_module("owned_mesh_review", TOOLS / "mesh_review.py")
        review = mesh_module.review(json.loads(exported.read_bytes()))
        write_json(geometry_dir / "mesh_review.json", review)
        geometry = geometry_comparison(project, review, attempt)
        write_json(geometry_dir / "geometry_equality.json", geometry)
        info["geometry"] = geometry
        info["mesh_review"] = {
            "asset_count": review.get("asset_count"),
            "mesh_count": review.get("mesh_count"),
            "findings": review.get("findings"),
            "status": review.get("status"),
            "review_equals_old_fixed_review": geometry["review_equals_old_fixed_review"],
            "report_path": str((geometry_dir / "mesh_review.json").relative_to(OWNED)).replace("\\", "/"),
        }
        if geometry["status"] != "exact_geometry_and_shape_match":
            return finish("failed:geometry", f"geometry status={geometry['status']} mesh_count={geometry['candidate_mesh_count']} findings={geometry['review_findings']}")

        if args.render:
            archived = archive_stale(project, attempt, ["png", "results"], "stale-before-render")
            info["archived_before_render"] = archived
            render_record, render_out, render_err = run_command(
                attempt,
                "render",
                [
                    str(GODOT),
                    "--path",
                    str(project),
                    "--rendering-method",
                    "gl_compatibility",
                    "--rendering-driver",
                    "opengl3",
                    "--position",
                    "-3200,120",
                    "--resolution",
                    "1280x720",
                    "--script",
                    "res://render/render_capture.gd",
                ],
                project,
                env,
            )
            info["commands"].append(render_record)
            if render_record["exit"] != 0 or render_record["timed_out"]:
                return finish("failed:render", f"exit={render_record['exit']} timed_out={render_record['timed_out']} stderr={render_err.decode('utf-8', 'replace')[-1200:]}")
            render_report_path = project / "results" / "render_report.json"
            if not render_report_path.is_file():
                return finish("failed:render_report_missing", "results/render_report.json missing")
            render_report = json.loads(render_report_path.read_text(encoding="utf-8"))
            renders_dir = attempt / "renders"
            renders_dir.mkdir(exist_ok=True)
            shutil.copyfile(render_report_path, renders_dir / "render_report.json")
            measurements = project / "results" / "render_measurements.json"
            if measurements.is_file():
                shutil.copyfile(measurements, renders_dir / "render_measurements.json")
            png_verification, entries = verify_pngs(project, attempt)
            write_json(renders_dir / "png_verification.json", png_verification)
            info["render"] = {
                "report_path": str((renders_dir / "render_report.json").relative_to(OWNED)).replace("\\", "/"),
                "measurements_path": str((renders_dir / "render_measurements.json").relative_to(OWNED)).replace("\\", "/") if measurements.is_file() else None,
                "harness_status": render_report.get("status"),
                "shot_count": len(render_report.get("shots", [])),
                "video_adapter_name": render_report.get("video_adapter_name"),
                "video_adapter_vendor": render_report.get("video_adapter_vendor"),
                "video_adapter_api_version": render_report.get("video_adapter_api_version"),
                "active_rendering_method": render_report.get("active_rendering_method"),
                "active_rendering_driver": render_report.get("active_rendering_driver"),
                "window_position_actual": render_report.get("window_position_actual"),
                "window_size_actual": render_report.get("window_size_actual"),
                "requested_window_position": [-3200, 120],
                "requested_resolution": [1280, 720],
                "png_verification_path": str((renders_dir / "png_verification.json").relative_to(OWNED)).replace("\\", "/"),
                "images": entries,
                "all_technical_checks_pass": png_verification["all_technical_checks_pass"],
                "changed_from_reference_count": png_verification["changed_from_reference_count"],
            }
            if render_report.get("status") != "ok" or len(render_report.get("shots", [])) != 11:
                return finish("failed:render_report", f"harness_status={render_report.get('status')} shots={len(render_report.get('shots', []))}")
            if not png_verification["all_technical_checks_pass"]:
                return finish("failed:png_verification", "one or more PNGs missing or technically invalid")
        return finish("ok")
    except Exception as exc:  # noqa: BLE001 - evidence must record failures
        info["exception"] = {"type": type(exc).__name__, "message": str(exc), "traceback": traceback.format_exc()}
        return finish("exception", str(exc))


def latest_attempts(variant: str) -> list[dict]:
    base = EVIDENCE / variant
    if not base.exists():
        return []
    records = []
    for path in sorted(base.iterdir(), key=lambda p: p.name):
        if not path.is_dir() or not path.name.startswith("attempt-"):
            continue
        run_path = path / "run.json"
        if run_path.is_file():
            data = json.loads(run_path.read_text(encoding="utf-8"))
        else:
            data = {"status": "incomplete"}
        records.append({"path": str(path.relative_to(OWNED)).replace("\\", "/"), "status": data.get("status"), "run": data})
    return records


def cmd_status(args: argparse.Namespace) -> int:
    for variant in ["baseline", "candidate-r1", "candidate-r2"]:
        attempts = latest_attempts(variant)
        if attempts:
            print(variant)
            for item in attempts:
                print(f"  {item['path']} status={item['status']}")
    return 0


def markdown_material_table(changes: dict) -> str:
    lines = ["| file | function | old color / metallic / roughness | new color / metallic / roughness | changed |", "|---|---|---|---|---|"]
    for item in changes["changes"]:
        old = f"{item['old']['color']} / {item['old']['metallic']} / {item['old']['roughness']}"
        new = f"{item['new']['color']} / {item['new']['metallic']} / {item['new']['roughness']}"
        lines.append(f"| `{item['file']}` | `{item['function']}` | {old} | {new} | {item['changed']} |")
    return "\n".join(lines)


def cmd_finalize(args: argparse.Namespace) -> int:
    variant = args.variant
    attempts = latest_attempts(variant)
    if not attempts:
        fail(f"no attempts for {variant}")
    successful = [item for item in attempts if item["status"] == "ok"]
    chosen = successful[-1] if successful else attempts[-1]
    run = chosen["run"]
    attempt_path = OWNED / chosen["path"]
    round_no = int(variant.split("candidate-r", 1)[1]) if variant.startswith("candidate-r") else None
    candidate_root = SOURCE_CANDIDATES / f"round-{round_no}" if round_no is not None else None
    material_changes = json.loads((candidate_root / "MATERIAL_CHANGES.json").read_text(encoding="utf-8")) if candidate_root else None
    scope = json.loads((candidate_root / "SCOPE_CHECK.json").read_text(encoding="utf-8")) if candidate_root else None
    source_hashes = json.loads((OWNED / "source" / "SOURCE_HASHES.json").read_text(encoding="utf-8"))
    contract = json.loads((OWNED / "contract" / "CONTRACT_CHECK.json").read_text(encoding="utf-8"))
    diff_path = OWNED / "CANDIDATE_SOURCE_DIFF.patch"
    diff_text = diff_path.read_text(encoding="utf-8") if diff_path.is_file() else ""
    candidate_manifest_path = candidate_root / "SOURCE_HASHES.json" if candidate_root else None
    scope_path = candidate_root / "SCOPE_CHECK.json" if candidate_root else None
    material_path = candidate_root / "MATERIAL_CHANGES.json" if candidate_root else None
    diff_hash_path = candidate_root / "DIFF_HASH.json" if candidate_root else None
    failed_attempts = [{"path": item["path"], "status": item["status"], "error": item["run"].get("error"), "exception": item["run"].get("exception")} for item in attempts if item["status"] != "ok"]
    images = run.get("render", {}).get("images", []) if isinstance(run.get("render"), dict) else []
    success = run.get("status") == "ok"
    result = {
        "task_id": "DEEPEYE-IMPLEMENTATION-20261014",
        "task_version": 1,
        "work_id": "B-ASSET-READABILITY-20261029-64-v1",
        "owner": "B successor main 01a18824-4172-74e2-a13f-f3e3d1e3ed99",
        "execution_child": "DeepSeek V4.1 Flash/max",
        "owned_root": str(OWNED),
        "contract": contract,
        "design_commit": DESIGN_COMMIT,
        "exact_source_head": EXACT_HEAD,
        "variant": variant,
        "attempt": chosen["path"],
        "candidate_round": round_no,
        "material_changes": material_changes,
        "scope_check": scope,
        "source_hashes": source_hashes,
        "candidate_source_manifest_path": str(candidate_manifest_path.relative_to(OWNED)).replace("\\", "/") if candidate_manifest_path and candidate_manifest_path.is_file() else None,
        "candidate_source_manifest_sha256": sha256_file(candidate_manifest_path) if candidate_manifest_path and candidate_manifest_path.is_file() else None,
        "scope_check_path": str(scope_path.relative_to(OWNED)).replace("\\", "/") if scope_path and scope_path.is_file() else None,
        "scope_check_sha256": sha256_file(scope_path) if scope_path and scope_path.is_file() else None,
        "material_changes_path": str(material_path.relative_to(OWNED)).replace("\\", "/") if material_path and material_path.is_file() else None,
        "material_changes_sha256": sha256_file(material_path) if material_path and material_path.is_file() else None,
        "diff_hash_path": str(diff_hash_path.relative_to(OWNED)).replace("\\", "/") if diff_hash_path and diff_hash_path.is_file() else None,
        "diff_hash_sha256": sha256_file(diff_hash_path) if diff_hash_path and diff_hash_path.is_file() else None,
        "source_diff_path": str(diff_path.relative_to(OWNED)).replace("\\", "/") if diff_path.is_file() else None,
        "source_diff": diff_text,
        "godot": run.get("tool"),
        "commands": run.get("commands", []),
        "tests": run.get("tests"),
        "export": run.get("export"),
        "geometry": run.get("geometry"),
        "mesh_review": run.get("mesh_review"),
        "render": run.get("render"),
        "images": images,
        "preserved_failed_attempts": failed_attempts,
        "tooling_notes_path": "NOTES.md",
        "tooling_corrections_preserved": [
            "Baseline evidence/baseline/attempt-1/run.json retained with an expected_shape_count=43 metadata typo; the seven exported assets actually have 18 disabled shapes. Baseline attempt-2 was run fresh with the corrected count and passed 622/0 with the same exact export SHA256.",
            "The original source-diff formatting file is retained as source/candidates/round-1/SOURCE_DIFF.preformatted.patch; the line-safe SOURCE_DIFF.patch has identical content and passed scope checks.",
        ],
        "all_attempts": [{"path": item["path"], "status": item["status"]} for item in attempts],
        "execution_child_observation": args.observation,
        "adoption": "pending_main_personal_visual_review",
        "status": "candidate_ready_pending_main_visual_review" if success else "failed",
        "root_G01": "not_run",
        "system": "not_run",
        "board": "not_run",
        "not_claimed": ["G01", "game_grade", "system", "board", "runtime_gameplay", "continuous_collision", "truth_isolation", "FPS_performance"],
    }
    write_json(OWNED / "RESULT.json", result)

    lines = [
        "# G01 material readability candidate (B execution record)",
        "",
        f"- Task: `DEEPEYE-IMPLEMENTATION-20261014/v1`, work `B-ASSET-READABILITY-20261029-64-v1`.",
        f"- Owner: B successor main `01a18824-4172-74e2-a13f-f3e3d1e3ed99`.",
        f"- Contract: `DEEPEYE-HUMAN-LOCK-20261014/revision1`, source `{CONTRACT_COMMIT}`, requirements SHA256 `{contract['requirements_sha256_computed']}` (match={contract['requirements_match']}).",
        f"- Requirement ids: `{', '.join(contract['requirement_ids'])}`.",
        f"- Frozen design commit: `{DESIGN_COMMIT}`. Exact product worktree HEAD: `{EXACT_HEAD}`.",
        f"- Candidate: `{variant}` (round {round_no}), attempt `{chosen['path']}`.",
        f"- Status: `{result['status']}`. Adoption is **pending the main's personal visual review**; this file does not claim G01, game-grade, system or board acceptance.",
        "",
        "## Scope and material changes",
        "",
        "Only the existing numeric color/metallic/roughness values inside `_material_pdc_blade`, `_material_pdc_stud`, `_material_void`, and `_material_casing` were eligible. This candidate changed blade, stud, and void. Casing was kept byte-identical because it is already visible; no necessity to change it was found. No emission, unshaded/shading mode, texture, transparency, blend, cull, geometry, collision, transform, name, metadata, or other function changes are present.",
        "",
        markdown_material_table(material_changes),
        "",
        f"Scope check: `{scope['status']}`; changed files: `{scope['changed_files']}`; outside-function bytes identical; normalized function bodies identical; forbidden-token hits: none.",
        "",
        "## Source hashes and diff",
        "",
        f"- Hash table: `source/HASH_TABLE.md`; machine-readable hashes: `source/SOURCE_HASHES.json`.",
        f"- Candidate source manifest: `{result.get('candidate_source_manifest_path')}` SHA256 `{result.get('candidate_source_manifest_sha256')}`; scope check: `{result.get('scope_check_path')}` SHA256 `{result.get('scope_check_sha256')}`; diff hash record: `{result.get('diff_hash_path')}` SHA256 `{result.get('diff_hash_sha256')}`.",
        f"- Baseline source files are exact `{EXACT_HEAD}` bytes (verified against `git show` and the worktree).",
        f"- Godot executable: `{run['tool']['path']}` SHA256 `{run['tool']['sha256']}` (match={run['tool']['match']}); no global install or configuration change.",
        f"- Source diff: `{result['source_diff_path']}`.",
        "",
        "```diff",
        diff_text.rstrip(),
        "```",
        "",
        "## Actual commands and logs",
        "",
    ]
    for command in run.get("commands", []):
        lines += [
            f"### {command['name']}",
            f"- argv: `{json.dumps(command['argv'], ensure_ascii=False)}`",
            f"- PID: `{command['pid']}`; start `{command['started_utc']}`; end `{command['finished_utc']}`; duration `{command['duration_s']} s`; timeout `{command['timeout_s']} s`; timed_out `{command['timed_out']}`; exit `{command['exit']}`.",
            f"- stdout: `{command['stdout_path']}` SHA256 `{command['stdout_sha256']}`; stderr: `{command['stderr_path']}` SHA256 `{command['stderr_sha256']}`.",
            "",
        ]
    lines += [
        "## Engine tests and geometry equality",
        "",
        f"- `tests/test_asset_contract.gd`: checks `{run.get('tests', {}).get('checks')}`, failures `{run.get('tests', {}).get('failures')}` (expected 622/0). The intentional unsupported-kind negative test remains in stderr; it is not a product failure.",
        f"- Export: asset_count `{run.get('export', {}).get('asset_count')}` (expected 7).",
        f"- Mesh review: assets `{run.get('mesh_review', {}).get('asset_count')}`, meshes `{run.get('mesh_review', {}).get('mesh_count')}`, findings `{run.get('mesh_review', {}).get('findings')}`, status `{run.get('mesh_review', {}).get('status')}`.",
        f"- Geometry equality: `{run.get('geometry', {}).get('status')}`; assets exactly equal `{run.get('geometry', {}).get('assets_exactly_equal')}`; full export file equal `{run.get('geometry', {}).get('full_file_equal')}`; old fixed-review equality `{run.get('geometry', {}).get('review_equals_old_fixed_review')}`.",
        f"- Reference export SHA256 `{run.get('geometry', {}).get('reference_file_sha256')}`; candidate export SHA256 `{run.get('geometry', {}).get('candidate_file_sha256')}`.",
        f"- Candidate mesh/shape counts: `{run.get('geometry', {}).get('candidate_mesh_count')}` meshes, `{run.get('geometry', {}).get('candidate_shape_count')}` disabled shapes (reference `{run.get('geometry', {}).get('reference_mesh_count')}`/`{run.get('geometry', {}).get('reference_shape_count')}`).",
        "",
        "## Actual GPU render",
        "",
        f"- Harness status `{run.get('render', {}).get('harness_status')}`; shot count `{run.get('render', {}).get('shot_count')}`.",
        f"- GPU: `{run.get('render', {}).get('video_adapter_name')}` / `{run.get('render', {}).get('video_adapter_vendor')}`; API `{run.get('render', {}).get('video_adapter_api_version')}`; method `{run.get('render', {}).get('active_rendering_method')}`; driver `{run.get('render', {}).get('active_rendering_driver')}`.",
        f"- Window: requested `(-3200,120)` / `1280x720`; actual position `{run.get('render', {}).get('window_position_actual')}`, size `{run.get('render', {}).get('window_size_actual')}`.",
        f"- PNG technical verification: `{run.get('render', {}).get('all_technical_checks_pass')}`; images changed from the old render: `{run.get('render', {}).get('changed_from_reference_count')}/11`.",
        "",
        "| image | dimensions | bytes | sha256 | technical pass | changed from reference |",
        "|---|---:|---:|---|---|---|",
    ]
    for image in images:
        lines.append(f"| `{image.get('path')}` | {image.get('width')}x{image.get('height')} | {image.get('file_size')} | `{image.get('sha256')}` | {image.get('pass')} | {not image.get('sha_matches_reference')} |")
    lines += [
        "",
        "## Preserved failures",
        "",
        "All attempt directories are retained. Failed or superseded attempts are not deleted or rewritten.",
        "",
    ]
    if failed_attempts:
        for item in failed_attempts:
            lines.append(f"- `{item['path']}` status `{item['status']}` error `{item.get('error')}`.")
    else:
        lines.append("- No candidate Godot command failed or timed out in this work's own runs.")
    lines += [
        "- Tooling corrections are retained in `NOTES.md`: (1) baseline `evidence/baseline/attempt-1/run.json` contains an `expected_shape_count=43` metadata typo; the seven exported assets actually have 18 disabled shapes, and baseline `attempt-2` was run fresh with the corrected count; (2) the original malformed source-diff formatting is retained as `source/candidates/round-1/SOURCE_DIFF.preformatted.patch` while the line-safe `SOURCE_DIFF.patch` has identical content. Neither correction changes candidate source, tests, geometry, or renders.",
        "",
    ]
    lines += [
        "",
        "## Limits and non-claims",
        "",
        "- Root G01: `not_run`. System: `not_run`. Board: `not_run`.",
        "- This record does not claim game-grade visual acceptance, runtime gameplay, continuous collision, truth isolation, FPS/performance, blue/red gate integration, free-camera/editor acceptance, PC-AI integration, either control path, or any A physical-board result.",
        "- The execution child's visual observation is not acceptance. The main must personally inspect the new PNGs and decide whether to adopt the candidate.",
        f"- Execution-child observation: {args.observation}",
        "",
    ]
    write_text(OWNED / "CANDIDATE.md", "\n".join(lines))
    print(json.dumps({"result": str((OWNED / 'RESULT.json').relative_to(OWNED)), "candidate": str((OWNED / 'CANDIDATE.md').relative_to(OWNED)), "status": result["status"], "variant": variant, "attempt": chosen["path"]}, ensure_ascii=False))
    return 0 if success else 1


def main() -> int:
    parser = argparse.ArgumentParser(description="Owned isolated G01 material readability pipeline")
    sub = parser.add_subparsers(dest="command", required=True)
    p_prepare = sub.add_parser("prepare")
    p_prepare.set_defaults(func=cmd_prepare)
    p_candidate = sub.add_parser("candidate")
    p_candidate.add_argument("--round", type=int, required=True)
    p_candidate.add_argument("--spec", default=None, help="Optional JSON material spec; defaults to a built-in round spec")
    p_candidate.set_defaults(func=cmd_candidate)
    p_run = sub.add_parser("run")
    p_run.add_argument("--variant", required=True, choices=["baseline", "candidate-r1", "candidate-r2"])
    p_run.add_argument("--render", action="store_true")
    p_run.set_defaults(func=cmd_run)
    p_finalize = sub.add_parser("finalize")
    p_finalize.add_argument("--variant", required=True, choices=["candidate-r1", "candidate-r2"])
    p_finalize.add_argument("--observation", default="Not recorded.")
    p_finalize.set_defaults(func=cmd_finalize)
    p_status = sub.add_parser("status")
    p_status.set_defaults(func=cmd_status)
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    sys.exit(main())
