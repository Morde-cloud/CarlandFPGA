#!/usr/bin/env python3
"""Offline negative fixtures for the B06 OOC marker classifier.

These tests fabricate bounded in-memory marker streams. They are not Vivado
runs and do not claim any synthesis artifact or acceptance.
"""

from __future__ import annotations

import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path


HERE = Path(__file__).resolve().parent
REPOSITORY = next(
    parent for parent in (HERE, *HERE.parents)
    if (parent / "competition/deepeye/tools/build/run_ooc_qualification.py").is_file()
)
RUNNER_PATH = REPOSITORY / "competition/deepeye/tools/build/run_ooc_qualification.py"
SPEC = importlib.util.spec_from_file_location("b06_ooc_runner", RUNNER_PATH)
if SPEC is None or SPEC.loader is None:
    raise RuntimeError(f"cannot load runner from {RUNNER_PATH}")
RUNNER = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = RUNNER
SPEC.loader.exec_module(RUNNER)


class MarkerClassifierTests(unittest.TestCase):
    def setUp(self) -> None:
        self.pin = RUNNER.PINS[0]
        self.attempt = HERE / "synthetic_attempt"
        self.run_id = f"01_{self.pin.module}"
        self.cache = self.attempt / "runs" / self.run_id / "cache"
        self.lines = self.valid_lines()

    def valid_lines(self, pin: object | None = None, attempt: Path | None = None) -> list[str]:
        selected_pin = self.pin if pin is None else pin
        selected_attempt = self.attempt if attempt is None else attempt
        run_id = f"01_{selected_pin.module}"
        run_dir = selected_attempt / "runs" / run_id
        cache = selected_attempt / "runs" / run_id / "cache"
        lines = [
            f"B06_OOC_BEGIN|run_id={run_id}|top={selected_pin.module}|clock_mode={selected_pin.clock_mode}",
            f"B06_OOC_USER_DATA|mode=owned_cache|path={cache.resolve()}",
            "B06_OOC_VERSION|value=2026.1",
            f"B06_OOC_PART|requested={RUNNER.PART}|matched=1",
            "B06_OOC_THREADS|requested=2|actual=2",
        ]
        for index, pin in enumerate(RUNNER.PINS, start=1):
            relative = Path(pin.git_path).relative_to("competition/deepeye")
            source = (selected_attempt / "source_snapshot" / relative).resolve()
            lines.append(f"B06_OOC_SOURCE_READ|index={index}|path={source}")
        lines.extend([
            f"B06_OOC_SOURCE_COUNT|count={len(RUNNER.PINS)}",
            f"B06_OOC_SYNTH_BEGIN|top={selected_pin.module}|mode=out_of_context|part={RUNNER.PART}",
            f"B06_OOC_SYNTH_DONE|top={selected_pin.module}|status=complete",
            f"B06_OOC_DESIGN|part={RUNNER.PART}|port_count=8",
        ])
        if selected_pin.clock_mode == "none":
            lines.append("B06_OOC_CLOCK_POLICY|mode=none|reason=combinational_no_clock|constrained=0")
        else:
            for port in selected_pin.clock_mode.removeprefix("clock:").split(","):
                lines.append(f"B06_OOC_CLOCK|name={port}|port={port}|period_ns=10.000|status=created")
        lines.extend([
            f"B06_OOC_REPORT|kind=utilization|status=written|path={run_dir / 'reports/utilization.rpt'}",
            f"B06_OOC_REPORT|kind=timing_summary|status=written|diagnostic_only=1|path={run_dir / 'reports/timing_summary.rpt'}",
            f"B06_OOC_REPORT|kind=check_timing|status=written|diagnostic_only=1|path={run_dir / 'reports/check_timing.rpt'}",
            f"B06_OOC_REPORT|kind=drc|status=written|violation_count=2|path={run_dir / 'reports/drc.rpt'}",
            f"B06_OOC_CHECKPOINT|status=written|path={run_dir / 'ooc.dcp'}",
            f"B06_OOC_END|run_id={run_id}|top={selected_pin.module}|status=artifact_complete",
        ])
        return lines

    def validate(
        self,
        lines: list[str],
        pin: object | None = None,
        attempt: Path | None = None,
    ) -> tuple[list[str], dict[str, object]]:
        selected_pin = self.pin if pin is None else pin
        selected_attempt = self.attempt if attempt is None else attempt
        run_id = f"01_{selected_pin.module}"
        cache = selected_attempt / "runs" / run_id / "cache"
        return RUNNER.validate_marker_stream(
            lines,
            run_id=run_id,
            pin=selected_pin,
            attempt=selected_attempt,
            cache_path=cache,
        )

    def test_valid_protocol_is_artifact_complete_but_drc_is_not_clean(self) -> None:
        failures, summary = self.validate(self.lines)
        self.assertEqual(failures, [])
        self.assertEqual(summary["drc_violation_count"], 2)
        self.assertFalse(summary["drc_violation_count"] == 0)
        self.assertEqual(summary["end_status"], "artifact_complete")

    def test_findings_are_retained_without_claiming_acceptance(self) -> None:
        findings = RUNNER.engineering_findings(
            artifact_complete=True,
            drc_violation_count=3,
            warning_count=4,
            critical_warning_count=1,
            latch_related_line_count=2,
            multidriver_related_line_count=1,
        )
        self.assertTrue(findings["artifact_complete"])
        self.assertFalse(findings["clean_drc"])
        self.assertEqual(findings["drc_violation_count"], 3)
        self.assertEqual(findings["warning_count"], 4)
        self.assertEqual(findings["critical_warning_count"], 1)
        self.assertEqual(findings["timing_acceptance"], "not_assessed_diagnostic_only")
        self.assertEqual(findings["product_acceptance"], "not_claimed")

    def test_classifier_integration_requires_files_and_retains_findings(self) -> None:
        with tempfile.TemporaryDirectory(prefix="unit-attempt-", dir=HERE) as temporary:
            attempt = Path(temporary)
            run_id = f"01_{self.pin.module}"
            run_dir = attempt / "runs" / run_id
            (run_dir / "cache").mkdir(parents=True)
            (run_dir / "reports").mkdir()
            for pin in RUNNER.PINS:
                relative = Path(pin.git_path).relative_to("competition/deepeye")
                source = attempt / "source_snapshot" / relative
                source.parent.mkdir(parents=True, exist_ok=True)
                source.write_bytes(b"// synthetic source snapshot\n")
            for report_name in ("utilization.rpt", "timing_summary.rpt", "check_timing.rpt", "drc.rpt"):
                (run_dir / "reports" / report_name).write_bytes(b"synthetic report\n")
            (run_dir / "ooc.dcp").write_bytes(b"synthetic checkpoint\n")
            process_record = {
                "run_id": run_id,
                "timed_out": False,
                "exit_code": 0,
                "pid": 1,
                "duration_seconds": 0.0,
            }
            (run_dir / "PROCESS.json").write_bytes(b"{}\n")
            stdout = ("\n".join(self.valid_lines(attempt=attempt)) + "\nCRITICAL WARNING: synthetic finding\n").encode("utf-8")
            run_result = RUNNER.classify_run(self.pin, 1, attempt, process_record, stdout, b"")
            self.assertEqual(run_result["status"], "artifact_complete")
            self.assertFalse(run_result["engineering_findings"]["clean_drc"])
            self.assertEqual(run_result["engineering_findings"]["drc_violation_count"], 2)
            self.assertEqual(run_result["engineering_findings"]["critical_warning_count"], 1)
            self.assertEqual(run_result["engineering_acceptance"], "not_claimed")
            self.assertTrue((run_dir / "RUN.json").is_file())
            self.assertTrue((run_dir / "DIAGNOSTICS.json").is_file())
            (run_dir / "ooc.dcp").unlink()
            missing_result = RUNNER.classify_run(self.pin, 1, attempt, process_record, stdout, b"")
            self.assertEqual(missing_result["status"], "failed")
            self.assertIn("missing_required_outputs:checkpoint", missing_result["failures"])

    def test_combinational_none_clock_policy_is_required(self) -> None:
        pin = next(item for item in RUNNER.PINS if item.clock_mode == "none")
        failures, summary = self.validate(self.valid_lines(pin), pin)
        self.assertEqual(failures, [])
        self.assertEqual(summary["clock_ports"], [])

    def test_dual_clock_policy_requires_exact_ports_and_periods(self) -> None:
        pin = next(item for item in RUNNER.PINS if item.clock_mode == "clock:src_clk,dst_clk")
        lines = self.valid_lines(pin)
        failures, summary = self.validate(lines, pin)
        self.assertEqual(failures, [])
        self.assertEqual([row["port"] for row in summary["clock_ports"]], ["src_clk", "dst_clk"])
        clock_index = next(index for index, line in enumerate(lines) if "name=dst_clk|" in line)
        lines[clock_index] = lines[clock_index].replace("period_ns=10.000", "period_ns=12.000")
        failures, _summary = self.validate(lines, pin)
        self.assertIn("clock_identity_mismatch:port=dst_clk", failures)

    def test_reordered_markers_are_rejected(self) -> None:
        self.lines[2], self.lines[3] = self.lines[3], self.lines[2]
        failures, _summary = self.validate(self.lines)
        self.assertTrue(any(item.startswith("marker_sequence_mismatch:") for item in failures))

    def test_duplicate_exact_row_is_rejected(self) -> None:
        self.lines.insert(3, self.lines[2])
        failures, _summary = self.validate(self.lines)
        self.assertTrue(any(item.startswith("duplicate_exact_marker_row:") for item in failures))
        self.assertTrue(any(item.startswith("marker_sequence_mismatch:") for item in failures))

    def test_conflicting_duplicate_marker_is_rejected(self) -> None:
        self.lines.insert(4, "B06_OOC_PART|requested=xc7a35tcsg324-1|matched=1")
        failures, _summary = self.validate(self.lines)
        self.assertTrue(any(item.startswith("marker_sequence_mismatch:") for item in failures))

    def test_unanchored_or_embedded_marker_text_is_rejected(self) -> None:
        self.lines.append("WARNING: embedded B06_OOC_END|run_id=fake|top=fake|status=artifact_complete")
        failures, _summary = self.validate(self.lines)
        self.assertTrue(any(item.startswith("unanchored_marker_text:") for item in failures))

    def test_duplicate_field_is_rejected(self) -> None:
        self.lines[2] = "B06_OOC_VERSION|value=2026.1|value=2026.1"
        failures, _summary = self.validate(self.lines)
        self.assertTrue(any("duplicate marker field" in item for item in failures))

    def test_wrong_source_index_is_rejected(self) -> None:
        first_source = next(index for index, line in enumerate(self.lines) if line.startswith("B06_OOC_SOURCE_READ|"))
        self.lines[first_source] = self.lines[first_source].replace("index=1|", "index=2|", 1)
        failures, _summary = self.validate(self.lines)
        self.assertIn("source_read_identity_mismatch:index=1", failures)

    def test_wrong_source_path_is_rejected(self) -> None:
        first_source = next(index for index, line in enumerate(self.lines) if line.startswith("B06_OOC_SOURCE_READ|"))
        self.lines[first_source] = self.lines[first_source].rsplit("|path=", 1)[0] + "|path=C:/wrong/source.sv"
        failures, _summary = self.validate(self.lines)
        self.assertIn("source_read_identity_mismatch:index=1", failures)

    def test_wrong_top_and_version_are_rejected(self) -> None:
        self.lines[0] = self.lines[0].replace(f"top={self.pin.module}", "top=wrong_top", 1)
        self.lines[2] = "B06_OOC_VERSION|value=2025.2"
        failures, _summary = self.validate(self.lines)
        self.assertIn("begin_identity_mismatch", failures)
        self.assertIn("tool_version_mismatch", failures)

    def test_wrong_clock_period_is_rejected(self) -> None:
        clock = next(index for index, line in enumerate(self.lines) if line.startswith("B06_OOC_CLOCK|"))
        self.lines[clock] = self.lines[clock].replace("period_ns=10.000", "period_ns=8.000")
        failures, _summary = self.validate(self.lines)
        self.assertIn("clock_identity_mismatch:port=clk", failures)

    def test_wrong_report_and_checkpoint_paths_are_rejected(self) -> None:
        drc = next(index for index, line in enumerate(self.lines) if "|kind=drc|" in line)
        checkpoint = next(index for index, line in enumerate(self.lines) if line.startswith("B06_OOC_CHECKPOINT|"))
        self.lines[drc] = self.lines[drc].rsplit("|path=", 1)[0] + "|path=C:/wrong/drc.rpt"
        self.lines[checkpoint] = self.lines[checkpoint].rsplit("|path=", 1)[0] + "|path=C:/wrong/ooc.dcp"
        failures, _summary = self.validate(self.lines)
        self.assertIn("report_path_mismatch:drc", failures)
        self.assertIn("checkpoint_identity_mismatch", failures)

    def test_tcl_uses_positional_checkpoint_and_owned_cache(self) -> None:
        tcl = (REPOSITORY / "competition/deepeye/fpga/build_qualification/ooc_qualification.tcl").read_text(encoding="utf-8")
        self.assertIn("write_checkpoint $checkpoint", tcl)
        self.assertNotIn("write_checkpoint -file", tcl)
        self.assertIn("mode=owned_cache|path=$observed_cache", tcl)


if __name__ == "__main__":
    unittest.main(verbosity=2)


