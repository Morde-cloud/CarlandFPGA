from pathlib import Path
import hashlib,json
D=Path(__file__).parent;P=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye');E=P/'evidence/build/ooc-20261024-33';out=E/'main/repair5'
p=E/'author/repair2/offline_classifier_tests.py';old=p.read_bytes();s=old.decode();s=s.replace('item.clock_mode == "clock:src_clk,dst_clk"','item.clock_mode == "dual_clock"');s=s.replace('for port in selected_pin.clock_mode.removeprefix("clock:").split(","):', 'for port in (["src_clk", "dst_clk"] if selected_pin.clock_mode == "dual_clock" else ["clk"]):')
(out/'offline_classifier_tests.py').write_text(s,encoding='utf-8',newline='\n')
note={'original_tests_sha256':hashlib.sha256(old).hexdigest(),'adaptation':'Copy historical16tests, update only dualclock token lookup and two-port positivefixture. Original15passed/1StopIteration retained; not a vendor failure. First main recovery driver stopped at oldtest gate before launching Vivado. New independent marker mutations additionally test exact2clock ordering.'}
(out/'OFFLINE_ADAPTATION.json').write_text(json.dumps(note,indent=2)+'\n')
s=(D/'main_mailbox_recovery.py').read_text();s=s.replace("review/'old-unit.exit.txt'","review/'adapted-unit.exit.txt'");s=s.replace("E/'author/repair2/offline_classifier_tests.py'","review/'offline_classifier_tests.py'")
a="lines=case.valid_lines(pin=pin);i=next(i for i,s in enumerate(lines) if s.startswith('B06_OOC_CLOCK|'))\nassert 'port=dual_clock|' in lines[i]\nlines[i:i+1]=['B06_OOC_CLOCK|name='+c+'|port='+c+'|period_ns=10.000|status=created' for c in ('src_clk','dst_clk')]"
assert a in s;s=s.replace(a,"lines=case.valid_lines(pin=pin);assert sum(x.startswith('B06_OOC_CLOCK|') for x in lines)==2")
(D/'main_mailbox_recovery2.py').write_text(s,encoding='utf-8',newline='\n')
