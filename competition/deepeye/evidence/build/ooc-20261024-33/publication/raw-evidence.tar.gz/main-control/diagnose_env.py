from pathlib import Path
import datetime,hashlib,json,os,subprocess,time
R=Path('D:/pynq/CarlandFPGA');D=R/'.local/deployment/node-b/evidence/b06-ooc-20261024-33';out=D/'main-env-diagnosis';out.mkdir(exist_ok=False)
# Actual resident terminal receipt is required; a completed artifact is not it.
w=json.loads((D/'wait.stdout.json').read_bytes())
def find(x):
 if isinstance(x,dict):
  if x.get('job_id')=='child-36cedc99065e4c5492a583b5162f2961' and x.get('terminal') is True:return x
  for v in x.values():
   q=find(v)
   if q:return q
 if isinstance(x,list):
  for v in x:
   q=find(v)
   if q:return q
 return None
assert find(w),'actual job terminal not observed'
ps=subprocess.run(['powershell','-NoProfile','-Command',"@(Get-Process -Name vivado -ErrorAction SilentlyContinue).Count"],capture_output=True);assert ps.returncode==0 and ps.stdout.strip()==b'0','another Vivado process exists'
(out/'resource-fence.stdout').write_bytes(ps.stdout);(out/'resource-fence.stderr').write_bytes(ps.stderr)
script=R/'.local/deployment/node-b/evidence/b06-toolchain-discovery-20261024-32/main/parts_probe.tcl';assert hashlib.sha256(script.read_bytes()).hexdigest()=='2247b4eaf7156909cae801fb00f342b684a4dd98e89864f7f75ee18425df3b37'
tool=Path('D:/pynq/AMD2026/2026.1/Vivado/bin/vivado.bat');assert hashlib.sha256(tool.read_bytes()).hexdigest()=='a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b'
records=[]
for name in ('inherited','empty_owned_cache'):
 cwd=out/name;cwd.mkdir();(cwd/'temp').mkdir();(cwd/'cache').mkdir();env=dict(os.environ,TEMP=str(cwd/'temp'),TMP=str(cwd/'temp'),TMPDIR=str(cwd/'temp'))
 if name=='empty_owned_cache':env['XILINX_LOCAL_USER_DATA']=str(cwd/'cache')
 argv=[r'C:\Windows\System32\cmd.exe','/d','/c',str(tool),'-mode','batch','-nojournal','-nolog','-notrace','-source',str(script)]
 rec={'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'argv':argv,'cwd':str(cwd),'mode':name,'inherited_cache_key_present':'XILINX_LOCAL_USER_DATA' in os.environ,'scope':'read-only catalog; no license content or configuration changes'}
 (cwd/'INTENT.json').write_text(json.dumps(rec,indent=2)+'\n');t=time.time()
 try:p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=60,creationflags=0x08000000);code,stdout,stderr=p.returncode,p.stdout,p.stderr;timed=False
 except subprocess.TimeoutExpired as e:code,stdout,stderr=None,e.stdout or b'',e.stderr or b'';timed=True
 (cwd/'stdout.bin').write_bytes(stdout);(cwd/'stderr.bin').write_bytes(stderr)
 rec.update(exit=code,timeout=timed,elapsed=time.time()-t,stdout_sha256=hashlib.sha256(stdout).hexdigest(),stderr_sha256=hashlib.sha256(stderr).hexdigest(),catalog_pass=b'B32_CATALOG_PASS' in stdout,license_error=b'valid license was not found' in stderr)
 (cwd/'RESULT.json').write_text(json.dumps(rec,indent=2)+'\n');records.append(rec);print(json.dumps(rec),flush=True)
 if timed:break
(out/'RESULT.json').write_text(json.dumps({'records':records,'different_cache_outcome':len(records)==2 and records[0]['exit']==0 and records[0]['catalog_pass'] and records[1]['exit']==42 and records[1]['license_error'],'no_license_credentials_read_or_copied':True},indent=2)+'\n')
