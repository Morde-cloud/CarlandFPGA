puts "B33_MAIN_HELP_BEGIN"
foreach command {write_checkpoint report_drc check_timing synth_design report_timing_summary create_project} {
    puts "B33_COMMAND $command"
    puts [help $command]
}
puts "B33_MAIN_HELP_END"
exit 0
