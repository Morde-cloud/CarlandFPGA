from pathlib import Path
import argparse,datetime,hashlib,importlib.util,json,os,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/build/ooc-20261024-33';review=E/'main/repair5'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def loadmodule(name,p):
 spec=importlib.util.spec_from_file_location(name,p);m=importlib.util.module_from_spec(spec);sys.modules[name]=m;spec.loader.exec_module(m);return m
edit=json.loads((review/'EDIT.json').read_bytes())
for n,h in edit['after'].items():assert sha(P/n)==h,n
assert (review/'adapted-unit.exit.txt').read_text(encoding='utf-8-sig').strip()=='0'
m=loadmodule('old_classifier_tests',review/'offline_classifier_tests.py');runner=m.RUNNER
case=m.MarkerClassifierTests();case.setUp();pin=runner.PINS[-1];assert pin.module=='deepeye_snapshot_mailbox' and pin.clock_mode=='dual_clock'
lines=case.valid_lines(pin=pin);assert sum(x.startswith('B06_OOC_CLOCK|') for x in lines)==2
assert not case.validate(lines,pin=pin)[0]
probes=[]
for i,line in enumerate(lines):
 for kind,mut in [('deleted',lines[:i]+lines[i+1:]),('duplicate',lines[:i]+[line]+lines[i:]),('prefixed',lines[:i]+['NOT_'+line]+lines[i+1:]),('suffix',lines[:i]+[line+'|extra']+lines[i+1:])]:
  errors,_=case.validate(mut,pin=pin);assert errors,(i,kind);probes.append({'row':i,'kind':kind,'rejected':True})
put(review/'DUAL_CLOCK_OFFLINE.json',{'valid_accepted':True,'negative_probes':len(probes),'probes':probes,'source':edit['after'],'type':'offline synthetic classifier checks, not vendor run'})
before=json.loads((E/'author/main-execution-01/RESULT.json').read_bytes());assert before['totals']['artifacts_complete']==18 and before['runs'][-1]['synthesis_started'] is False
assert all(x['exit_code']==0 for x in before['runs'][:-1])
thread=os.environ.get('CODEX_THREAD_ID');assert thread=='01a13b55-095b-7461-8dd5-5476a130bd82';turn='not_exposed_by_exec;context_record_01a16933-edc1-7022-8e5f-25b4561a4ea5'
ps=subprocess.run(['powershell','-NoProfile','-Command','@(Get-Process -Name vivado -ErrorAction SilentlyContinue).Count'],capture_output=True);assert ps.returncode==0 and ps.stdout.strip()==b'0'
out=E/'author/main-mailbox-recovery-01'
args=runner.parse_arguments(['--output',str(out),'--author-thread',thread,'--author-turn',turn,'--parent-thread',thread,'--parent-turn',turn,'--timeout-seconds','900'])
out=runner.create_fresh_attempt(W,args.output);result=runner.initial_result(args,W,out)
result['work_id']='B-B06-OOC-MAIN-RECOVERY-20261024-33-r5';result['totals']['planned']=1
result['selection']={'selected_top':pin.module,'original_inventory_count':19,'original_inventory_index':19,'not_reexecuted_completed_tops':[r['top'] for r in before['runs'][:-1]],'prior_result_sha256':sha(E/'author/main-execution-01/RESULT.json'),'combined_acceptance':False}
runner.write_json(out/'RESULT.json',result)
try:
 runner.verify_contract(result,W);result['source']=runner.prepare_source_snapshot(result,W,out);result['tool']=runner.prepare_tool(args.tool_root);result['harness']=runner.prepare_harness(W,out)
 runner.write_json(out/'PREFLIGHT.json',{k:result[k] for k in ['selection','source','tool','harness','contract_verification']})
 process,stdout,stderr=runner.launch_vivado(pin,19,out,Path(result['source']['source_list_path']),result['harness'],result['tool'],900)
 r=runner.classify_run(pin,19,out,process,stdout,stderr);result['runs']=[r]
 result['totals'].update(attempted=1,artifacts_complete=int(r['status']=='artifact_complete'),failed=int(r['status']=='failed'),clean_drc=int(r['engineering_findings']['clean_drc'] is True),warning_bearing=int(r['diagnostics']['warning_count']>0 or r['diagnostics']['critical_warning_count']>0))
 result['overall_status']='artifacts_complete' if r['status']=='artifact_complete' else 'failed'
except Exception as ex:
 result['overall_status']='failed';result['fatal_error']=repr(ex);raise
finally:
 result['completed_at_utc']=runner.utc_now();result['execution']={'executor':'main','selected_top_only':True,'actual_synthesis_attempt':1,'earlier_18_not_reexecuted':True,'engineering_acceptance':'not_claimed'};runner.write_json(out/'RESULT.json',result)
print(json.dumps({'out':str(out),'overall_status':result['overall_status'],'totals':result['totals'],'fatal_error':result['fatal_error']}));raise SystemExit(0 if result['overall_status']=='artifacts_complete' else 1)
