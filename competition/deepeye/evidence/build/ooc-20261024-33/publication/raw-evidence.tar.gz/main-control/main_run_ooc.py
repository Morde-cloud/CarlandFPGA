from pathlib import Path
import datetime,hashlib,importlib.util,json,os,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/build/ooc-20261024-33';review=E/'main/pre-execution-01';review.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
wait=json.loads((D/'repair2-wait2.stdout.json').read_text(encoding='utf-8-sig'))
if isinstance(wait,list):assert len(wait)==1;wait=wait[0]
assert wait['terminal'] and wait['status']=='completed' and not wait['stale']
pins={'tools/build/run_ooc_qualification.py':'d8ac42575b8ad50f39cdd0107a94d8b561d9a1d506e1ef04415c146610186e2f','fpga/build_qualification/ooc_qualification.tcl':'a9e1ea5d493eeaa91ba3f5798cefd3d1296e88d9be5f5cc8b7cd083cf93b3a7e','fpga/build_qualification/README.md':'f9b15c11b5512b4a3b8057029d981646336560d5265253f3f3cd3dad55594be3'}
for name,h in pins.items():assert sha(P/name)==h;(review/Path(name).name).write_bytes((P/name).read_bytes())
tcl=(P/'fpga/build_qualification/ooc_qualification.tcl').read_text();assert 'write_checkpoint $checkpoint' in tcl and 'write_checkpoint -file' not in tcl and 'set_param general.maxThreads 2' in tcl
tests=E/'author/repair2/offline_classifier_tests.py';spec=importlib.util.spec_from_file_location('main_ooc_fixture',tests);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);runner=m.RUNNER
case=m.MarkerClassifierTests();case.setUp();valid=case.valid_lines();args={'run_id':case.run_id,'pin':case.pin,'attempt':case.attempt,'cache_path':case.cache};assert not runner.validate_marker_stream(valid,**args)[0]
probes=[]
for i,line in enumerate(valid):
 for kind,changed in [('deleted',valid[:i]+valid[i+1:]),('duplicated',valid[:i]+[line]+valid[i:]),('prefix',valid[:i]+['NOT_'+line]+valid[i+1:]),('bare_suffix',valid[:i]+[line+'|garbage']+valid[i+1:])]:
  errors,_=runner.validate_marker_stream(changed,**args);assert errors,(i,kind);probes.append({'position':i,'kind':kind,'rejected':True,'errors':errors})
inventory=[]
for pin in runner.PINS:
 b=subprocess.check_output(['git','-C',str(W),'show',runner.SOURCE_COMMIT+':'+pin.git_path]);oid=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();assert oid==pin.blob and len(b)==pin.size
 assert hashlib.sha256(b).hexdigest()==sha(W/pin.git_path);inventory.append({'path':pin.git_path,'oid':oid,'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)})
assert len(inventory)==19
summ=json.loads((E/'author/repair2/PROCESS_SUMMARY.json').read_bytes())
for rec in summ['processes']:
 p=Path(rec['process_path']);assert sha(p)==rec['process_sha256'];detail=json.loads(p.read_bytes());assert rec['exit_code']==0
# Official catalog proved license availability in main, not across child environments.
envdiag=json.loads((D/'main-env-diagnosis/RESULT.json').read_bytes());assert all(x['exit']==0 and x['catalog_pass'] for x in envdiag['records'])
thread=os.environ.get('CODEX_THREAD_ID');assert thread=='01a13b55-095b-7461-8dd5-5476a130bd82';turn='not_exposed_by_exec;context_record_01a16933-edc1-7022-8e5f-25b4561a4ea5'
ps=subprocess.run(['powershell','-NoProfile','-Command',"@(Get-Process -Name vivado -ErrorAction SilentlyContinue).Count"],capture_output=True);assert ps.returncode==0 and ps.stdout.strip()==b'0'
put(review/'RESULT.json',{'accepted_harness_for_first_synthesis_execution':True,'sources':pins,'inventory':inventory,'independent_marker_negatives':len(probes),'probes':probes,'author_terminal_job':wait['job_id'],'actual_main_thread':thread,'turn_visibility':turn,'artifact_completion_not_engineering_acceptance':True,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
output=E/'author/main-execution-01';assert not output.exists()
argv=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(P/'tools/build/run_ooc_qualification.py'),'--output',str(output),'--author-thread',thread,'--author-turn',turn,'--parent-thread',thread,'--parent-turn',turn,'--timeout-seconds','900']
put(review/'EXECUTION_INTENT.json',{'work_id':'B-B06-OOC-MAIN-EXECUTION-20261024-33-r3','argv':argv,'actual_executor':'main tool environment','license_credentials_environment_untouched':True,'scope':'first actual synthesis attempt pertop; oldchildfailedbeforeTcl','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
with (review/'runner.stdout.bin').open('xb') as stdout,(review/'runner.stderr.bin').open('xb') as stderr:
 p=subprocess.Popen(argv,cwd=W,stdout=stdout,stderr=stderr,creationflags=0x08000000);put(review/'PROCESS_STARTED.json',{'pid':p.pid,'argv':argv,'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});code=p.wait()
put(review/'EXECUTION_RESULT.json',{'exit':code,'stdout_sha256':sha(review/'runner.stdout.bin'),'stderr_sha256':sha(review/'runner.stderr.bin'),'finished_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'output':str(output),'synthesis_results_require_main_review':True});print(json.dumps({'exit':code,'output':str(output),'review':str(review)}));raise SystemExit(code)
