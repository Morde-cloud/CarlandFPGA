from pathlib import Path
import datetime,hashlib,json,os,subprocess
D=Path(__file__).parent;out=D/'main-help2';out.mkdir(exist_ok=False);(out/'temp').mkdir();(out/'cache').mkdir();script=D/'main_help2.tcl';(out/script.name).write_bytes(script.read_bytes())
env=dict(os.environ,TEMP=str(out/'temp'),TMP=str(out/'temp'),TMPDIR=str(out/'temp'),XILINX_LOCAL_USER_DATA=str(out/'cache'))
argv=[r'C:\Windows\System32\cmd.exe','/d','/c',r'D:\pynq\AMD2026\2026.1\Vivado\bin\vivado.bat','-mode','batch','-nojournal','-nolog','-notrace','-source',str(script)]
r=subprocess.run(argv,cwd=out,env=env,capture_output=True,timeout=60,creationflags=0x08000000);(out/'stdout.bin').write_bytes(r.stdout);(out/'stderr.bin').write_bytes(r.stderr)
(out/'RESULT.json').write_text(json.dumps({'argv':argv,'exit':r.returncode,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest(),'scope':'installed help returned values; previous help invocation emitted command labels only'},indent=2)+'\n');print('exit',r.returncode);print(r.stdout.decode('utf-8',errors='replace')[:25000])
