set_param general.maxThreads 2
puts "MAIN_DCP_REOPEN_BEGIN|count=4"
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/author/main-execution-01/runs/03_deepeye_block_encoder/ooc.dcp}
puts "MAIN_DCP_DESIGN|top=deepeye_block_encoder|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN_DCP_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_block_encoder/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_block_encoder/timing_summary.rpt}
close_design
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/author/main-execution-01/runs/09_deepeye_block_stream/ooc.dcp}
puts "MAIN_DCP_DESIGN|top=deepeye_block_stream|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN_DCP_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_block_stream/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_block_stream/timing_summary.rpt}
close_design
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/author/main-execution-01/runs/11_deepeye_crc16_byte/ooc.dcp}
puts "MAIN_DCP_DESIGN|top=deepeye_crc16_byte|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN_DCP_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_crc16_byte/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_crc16_byte/timing_summary.rpt}
close_design
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/author/main-mailbox-recovery-01/runs/19_deepeye_snapshot_mailbox/ooc.dcp}
puts "MAIN_DCP_DESIGN|top=deepeye_snapshot_mailbox|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN_DCP_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_snapshot_mailbox/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/deepeye_snapshot_mailbox/timing_summary.rpt}
close_design
puts "MAIN_DCP_REOPEN_END|count=4"
exit 0
