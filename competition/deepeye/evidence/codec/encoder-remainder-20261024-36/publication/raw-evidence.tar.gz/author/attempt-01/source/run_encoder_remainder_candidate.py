#!/usr/bin/env python3
"""Bounded author software/ModelSim evidence for the main-approved identity.

No main oracle is imported. Expected payload bytes reuse the pinned published
golden codec_reference.py, explicitly; the arithmetic sweep is independent.
All generated files, tool libraries and transcripts live inside --output.
An existing --output is refused. No synthesis, board or acceptance evaluation.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import random
import re
import shutil
import subprocess
import sys
import time
import traceback

sys.dont_write_bytecode = True
TASK_ID = 'DEEPEYE-IMPLEMENTATION-20261014'
WORK_ID = 'B-ENCODER-REMAINDER-CANDIDATE-20261024-36-v1'
OPERATION_ID = 'B-DEEPEYE-ENCODER-REMAINDER-20261024-36'
CONTRACT_COMMIT = 'f5989cd5defce561f9ba98e6b18fc2682945f0a2'
CONTRACT_HASH = 'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
ORIGINAL_HASH = '870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5'
GOLDEN_HASH = '2e24e01c7e8cc9a010f9c0f26d94091b33676b7394f0f7344ca5bf938fefbfd5'
CONTRACT = {
    'id': 'DEEPEYE-HUMAN-LOCK-20261014', 'revision': 1,
    'requirements_ids': ['H%02d' % i for i in range(1, 16)],
    'requirements_sha256': CONTRACT_HASH, 'commit': CONTRACT_COMMIT,
    'design_commit': '1011259415a0916054eb580687612580bc1e5f09',
}
E_VALUES = (0, 1, 2, 4, 8)
OWNED = (
    'fpga/codec/deepeye_block_encoder_remainder_candidate.sv',
    'fpga/codec/encoder_remainder_candidate.md',
    'tests/rtl/codec/tb_encoder_remainder_candidate.sv',
    'tools/codec/run_encoder_remainder_candidate.py',
    'evidence/codec/encoder-remainder-20261024-36/author/',
)


def utc():
    return datetime.now(timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            digest.update(chunk)
    return digest.hexdigest()


def save_json(path, obj):
    Path(path).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n', encoding='utf-8')


def arithmetic_sweep():
    """Every reachable n, each E, distinct feasible p endpoints/midpoint."""
    rows = []
    for e in E_VALUES:
        d = 2 * e + 1
        counts = Counter()
        remainders = set()
        min_y, max_y = 1 << 30, -(1 << 30)
        for n in range(e - 65535, e + 65536):
            a = abs(n)
            div_quot, r_abs = divmod(a, d)
            q_original = div_quot if n >= 0 else -(div_quot + int(r_abs != 0))
            r_euclid = d - r_abs if n < 0 and r_abs != 0 else r_abs
            assert q_original == n // d
            assert n == q_original * d + r_euclid
            assert 0 <= r_abs < d and 0 <= r_euclid < d
            assert -(1 << 17) <= n < (1 << 17) and a < (1 << 17)
            assert 0 <= (2*q_original if q_original >= 0 else -2*q_original-1) < (1 << 17)
            remainders.add(r_euclid)
            counts['reachable_n'] += 1
            counts['negative_divisible_n' if n < 0 and r_abs == 0 else
                   'negative_remainder_n' if n < 0 else 'nonnegative_n'] += 1
            lo, hi = max(0, e - n), min(65535, 65535 + e - n)
            assert lo <= hi
            for p in sorted({lo, (lo + hi)//2, hi}):
                x = n + p - e
                assert 0 <= x <= 65535 and 0 <= p <= 65535
                old_y = p + q_original * d
                new_y = x + e - r_euclid
                assert old_y == new_y
                # Check the specified signed 25-bit zero extensions and clamp.
                assert -8 <= new_y <= 65543 and x-e <= new_y <= x+e
                encoded25 = (x + e - r_euclid) & ((1 << 25)-1)
                signed25 = encoded25 - (1 << 25) if encoded25 & (1 << 24) else encoded25
                assert signed25 == old_y
                assert min(65535, max(0, old_y)) == min(65535, max(0, signed25))
                counts['feasible_x_p_cases'] += 1
                if old_y < 0: counts['low_clamp_cases'] += 1
                if old_y > 65535: counts['high_clamp_cases'] += 1
                min_y, max_y = min(min_y, new_y), max(max_y, new_y)
        assert counts['reachable_n'] == 131071
        rows.append({'e': e, 'd': d, 'counts': dict(counts),
                     'remainders_seen': sorted(remainders), 'preclamp_min': min_y,
                     'preclamp_max': max_y, 'n_range': [e-65535, e+65535]})
    return {'status': 'passed', 'method': 'all reachable n; distinct feasible p lo/mid/hi; actual x=n+p-E',
            'total_reachable_n': sum(r['counts']['reachable_n'] for r in rows),
            'total_feasible_x_p_cases': sum(r['counts']['feasible_x_p_cases'] for r in rows),
            'all_2_pow_32_x_p_pairs_enumerated': False, 'per_e': rows}


def make_cases(golden):
    rng = random.Random(0x2026102436)
    cases = []
    def add(label, samples, e):
        fixture = golden.encode_block(samples, e)
        golden.decode_block(fixture)
        cases.append({'id': len(cases), 'label': label, 'samples': samples, 'e': e,
                      'fixture': fixture})
    for e in E_VALUES:
        d = 2*e + 1
        for n in (1, 2, 127, 128):
            patterns = {
                'zero': [0]*n,
                'full': [65535]*n,
                'alternating_extrema': [0 if i % 2 == 0 else 65535 for i in range(n)],
                'ascending': [(100 + i*(e+1)) & 65535 for i in range(n)],
                'descending': [(65435 - i*(e+1)) & 65535 for i in range(n)],
                'sign_transitions': [(0,65535,32768,32767,1,65534,2,65533)[i%8] for i in range(n)],
                'random': [rng.randrange(65536) for _ in range(n)],
            }
            for label, samples in patterns.items():
                add('%s_n%d_e%d' % (label,n,e), samples, e)
        # Explicit anchor p=32768 gives n=-d, -(d+1), -1, 0, +1, +d.
        for num in (-2*d, -d-1, -d, -1, 0, 1, d-1, d, d+1):
            add('signed_n%d_e%d' % (num,e), [32768,32768-e+num], e)
        for p in (0,1,65534,65535):
            for x in (0,1,65534,65535):
                add('clamp_p%d_x%d_e%d' % (p,x,e), [p,x,0,65535,1,65534], e)
        for r in range(6):
            n = rng.choice((2,17,31,64,127,128))
            add('fixed_random_%d_e%d' % (r,e), [rng.randrange(65536) for _ in range(n)],e)
    # Exercise long legal unary fields in the unchanged Rice writer.
    for q in (9,15):
        add('unary_q%d' % q, [32768,32768+q]+[32768+q]*126, 0)
    assert {c['fixture']['mode'] for c in cases} == {'raw','rice'}
    return cases


def write_fixtures(path, cases):
    with path.open('w', encoding='ascii', newline='\n') as f:
        f.write('%d\n' % len(cases))
        for c in cases:
            v = c['fixture']; data = bytes.fromhex(v['payload_hex'])
            f.write('%d %d %d %d %d %d %d\n' % (
                c['id'], len(c['samples']), c['e'], int(v['mode']=='raw'),
                v['k'] if v['k'] is not None else 0, v['valid_bit_count'], len(data)))
            f.write(' '.join('%04x' % x for x in c['samples'])+'\n')
            f.write(' '.join('%02x' % x for x in data)+'\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--modelsim-home', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--thread-id', required=True)
    parser.add_argument('--turn-id', required=True)
    args = parser.parse_args()
    p = Path(__file__).resolve().parents[2]
    author = (p / OWNED[4]).resolve()
    out = args.output.resolve()
    if not out.is_relative_to(author) or out == author:
        parser.error('--output must be a new child directory of the owned author directory')
    if out.exists():
        parser.error('refusing pre-existing --output; preserve attempts')
    out.mkdir(parents=True)
    (out / 'logs').mkdir()
    (out / 'source').mkdir()
    records = []
    result = {
        'schema': 1, 'task_id': TASK_ID, 'task_version': 1, 'work_id': WORK_ID,
        'operation_id': OPERATION_ID, 'contract': CONTRACT,
        'thread_id': args.thread_id, 'turn_id': args.turn_id,
        'job_id': 'child-dbcdc099d56046d2808ad94838b0b4e4',
        'quality_main_thread_id': '01a13b55-095b-7461-8dd5-5476a130bd82',
        'at_utc': utc(), 'status': 'running', 'evidence_type': 'author_bounded_only',
        'argv': [sys.executable] + sys.argv, 'cwd': os.getcwd(),
        'ownership': list(OWNED), 'execution_allowed_before_project_work': True,
        'commands': records, 'sources': {}, 'python_version': sys.version,
        'author_software': 'not_run', 'author_modelsim': 'not_run',
        'formal_29': 'not_run', 'B01': 'not_run', 'B03': 'not_run', 'B06': 'not_run',
        'R03': 'not_run', 'synthesis': 'not_run', 'implementation': 'not_run',
        'timing_closure': 'not_run', 'CDC': 'not_run', 'board': 'not_run',
        'system': 'not_run', 'final_acceptance': 'not_run',
        'golden_reuse': 'Published golden/codec/codec_reference.py supplies expected metadata and bytes; disclosed non-independent payload oracle. No main oracle imported.',
        'limitations': ['Miter uses the original core as reference; shared bugs remain possible.',
                        'Arithmetic sweep covers every n and feasible p endpoints/midpoint, not every x,p pair.',
                        'No synthesis, timing, resource, physical-board or product-acceptance claim.'],
    }

    def run(name, cmd, cwd=out, timeout=120):
        record = {'name': name, 'argv': [str(a) for a in cmd], 'cwd': str(cwd),
                  'started_utc': utc(), 'stdout': 'logs/'+name+'.stdout.txt',
                  'stderr': 'logs/'+name+'.stderr.txt', 'exit_code': None}
        records.append(record)
        save_json(out/'RESULT.json',result)
        t0 = time.monotonic()
        with (out/record['stdout']).open('wb') as stdout, (out/record['stderr']).open('wb') as stderr:
            try:
                cp = subprocess.run(record['argv'], cwd=cwd, stdout=stdout, stderr=stderr,
                                    timeout=timeout, shell=False)
                record['exit_code'] = cp.returncode
            except subprocess.TimeoutExpired:
                record['timed_out'] = True
                raise RuntimeError('timeout: '+name)
            finally:
                record['duration_seconds'] = time.monotonic()-t0
                record['finished_utc'] = utc()
                record['stdout_sha256'] = sha(out/record['stdout'])
                record['stderr_sha256'] = sha(out/record['stderr'])
                save_json(out/'RESULT.json',result)
        if record['exit_code'] != 0:
            raise RuntimeError('%s exit %s' % (name,record['exit_code']))
        return (out/record['stdout']).read_bytes().decode('utf-8',errors='replace')

    exit_code = 1
    try:
        result['source_head'] = run('git_head',['git','rev-parse','HEAD'],cwd=p).strip()
        # Read pinned contract from local Git object; no network or editable-document trust.
        contract_text = run('contract_read',['git','show',CONTRACT_COMMIT+':docs/competition/deepeye-2026/immutable_scope.json'],cwd=p)
        contract = json.loads(contract_text)
        digest = hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,
                                sort_keys=True,separators=(',',':')).encode('utf-8')).hexdigest()
        assert digest == CONTRACT_HASH
        assert [r['id'] for r in contract['requirements']] == CONTRACT['requirements_ids']
        result['verified_contract_sha256'] = digest
        source_paths = {
            'original': p/'fpga/codec/deepeye_block_encoder.sv',
            'candidate': p/OWNED[0], 'notes': p/OWNED[1], 'tb': p/OWNED[2],
            'runner': Path(__file__).resolve(),
            'golden': p/'golden/codec/codec_reference.py',
        }
        for name, path in source_paths.items():
            target = out/'source'/path.name
            shutil.copyfile(path,target)
            result['sources'][name] = {'path': str(path), 'sha256': sha(path),
                                        'snapshot': str(target.relative_to(out))}
        assert result['sources']['original']['sha256'] == ORIGINAL_HASH
        assert result['sources']['golden']['sha256'] == GOLDEN_HASH
        print('START arithmetic all reachable n and feasible p endpoints/midpoint',flush=True)
        t0 = time.monotonic()
        math = arithmetic_sweep()
        math['duration_seconds'] = time.monotonic()-t0
        save_json(out/'arithmetic.json',math)
        result['arithmetic'] = math
        result['author_software'] = 'passed'
        print('ARITHMETIC PASS n=%d actual_x_p=%d' % (math['total_reachable_n'],math['total_feasible_x_p_cases']),flush=True)
        spec = importlib.util.spec_from_file_location('published_codec_reference',source_paths['golden'])
        golden = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(golden)
        cases = make_cases(golden)
        save_json(out/'fixtures.json',cases)
        write_fixtures(out/'fixtures.txt',cases)
        result['fixtures'] = {'count': len(cases), 'modes': dict(Counter(c['fixture']['mode'] for c in cases)),
                              'counts': sorted({len(c['samples']) for c in cases}),
                              'e': sorted({c['e'] for c in cases}), 'seed': '0x2026102436',
                              'json_sha256': sha(out/'fixtures.json'), 'text_sha256': sha(out/'fixtures.txt')}
        home = args.modelsim_home.resolve()
        exe = {name: home/(name+'.exe') for name in ('vlib','vmap','vlog','vsim')}
        for name,path in exe.items():
            if not path.is_file(): raise RuntimeError('missing tool '+str(path))
        result['tools'] = {name: {'path':str(path),'sha256':sha(path)} for name,path in exe.items()}
        result['tools']['vlog']['version'] = run('vlog_version',[exe['vlog'],'-version']).strip()
        result['tools']['vsim']['version'] = run('vsim_version',[exe['vsim'],'-version']).strip()
        run('vmap_init',[exe['vmap'],'-c'])
        run('vlib',[exe['vlib'],out/'work'])
        run('vmap_work',[exe['vmap'],'work',out/'work'])
        run('vlog',[exe['vlog'],'-sv','-work','work',out/'source'/source_paths['original'].name,
                    out/'source'/source_paths['candidate'].name,out/'source'/source_paths['tb'].name])
        dofile = out/'run.do'
        dofile.write_text('onerror {quit -f -code 2}\nonbreak {quit -f -code 3}\nrun -all\nquit -f -code 0\n',encoding='ascii')
        print('START ModelSim public-port miter cases=%d' % len(cases),flush=True)
        transcript = run('vsim',[exe['vsim'],'-c','-t','1ns','-l',out/'transcript.txt',
                                '-wlf',out/'simulation.wlf','work.tb_encoder_remainder_candidate',
                                '+INPUT='+(out/'fixtures.txt').as_posix(),
                                '+TRACE='+(out/'public_ports.txt').as_posix(),'-do',dofile],timeout=600)
        if re.search(r'TB_FAIL|\*\* (?:Error|Fatal):',transcript):
            raise RuntimeError('simulation failure marker')
        if transcript.count('TB_DONE encoder_remainder_candidate PASS') != 1:
            raise RuntimeError('missing/excess completion marker')
        passed_ids = re.findall(r'TB_CASE id=(\d+) .* PASS',transcript)
        assert [int(i) for i in passed_ids] == list(range(len(cases)))
        summaries = re.findall(r'TB_SUMMARY (.*)',transcript)
        assert len(summaries) == 1
        summary = {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',summaries[0])}
        assert summary['valid'] == len(cases) and summary['invalid'] == 6
        assert summary['abort'] == 24 and summary['recovery'] == 24
        assert summary['completed'] == len(cases)+6+24
        assert summary['reset'] == 12 and summary['cancel'] == 12
        assert len(re.findall(r'TB_ABORT .* PASS',transcript)) == 24
        assert len(re.findall(r'TB_INVALID .* PASS',transcript)) == 6
        trace = out/'public_ports.txt'
        with trace.open('r',encoding='ascii') as f:
            first_cycle, last_cycle, lines = None,None,0
            for line in f:
                observed_cycle = int(line.split()[0])
                if first_cycle is None: first_cycle = observed_cycle
                if last_cycle is not None: assert observed_cycle == last_cycle+1
                last_cycle = observed_cycle; lines += 1
        assert first_cycle == 4 and last_cycle == summary['cycles']
        assert lines == summary['cycles']-3
        result['simulation'] = summary
        result['public_trace'] = {'path':str(trace),'sha256':sha(trace),'cycles':lines,
                                  'first_cycle':first_cycle,'last_cycle':last_cycle,
                                  'metadata_and_data_masked_when_invalid':True}
        result['author_modelsim'] = 'passed'
        result['status'] = 'author_bounded_pass'
        exit_code = 0
        print('MODELSIM PASS '+json.dumps(summary,sort_keys=True),flush=True)
    except Exception as exc:
        result['status'] = 'failed'
        result['error'] = str(exc)
        result['traceback'] = traceback.format_exc()
        if result['author_software'] == 'not_run': result['author_software'] = 'failed'
        elif result['author_modelsim'] == 'not_run': result['author_modelsim'] = 'failed'
        (out/'failure.txt').write_text(result['traceback'],encoding='utf-8')
        print(result['traceback'],file=sys.stderr,flush=True)
    finally:
        original = p/'fpga/codec/deepeye_block_encoder.sv'
        result['original_sha256_after'] = sha(original)
        if result['original_sha256_after'] != ORIGINAL_HASH:
            result['status'] = 'failed'; result['error'] = 'original core changed'; exit_code = 1
        result['source_drift'] = [name for name, info in result['sources'].items()
                                  if sha(info['path']) != info['sha256']]
        if result['source_drift']:
            result['status'] = 'failed'; result['error'] = 'source drift'; exit_code = 1
        result['finished_utc'] = utc(); result['exit_code'] = exit_code
        save_json(out/'RESULT.json',result)
        artifacts = {str(f.relative_to(out).as_posix()):sha(f) for f in sorted(out.rglob('*'))
                     if f.is_file() and f.name != 'artifact_hashes.json'}
        save_json(out/'artifact_hashes.json',artifacts)
    print('RESULT '+str(out/'RESULT.json'),flush=True)
    return exit_code


if __name__ == '__main__':
    raise SystemExit(main())
