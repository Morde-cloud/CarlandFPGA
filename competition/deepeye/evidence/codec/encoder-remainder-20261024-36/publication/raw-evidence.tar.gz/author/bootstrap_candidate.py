"""Apply only the main-approved remainder identity to a new candidate file."""
from pathlib import Path
import hashlib
import json
import subprocess
from datetime import datetime, timezone

P = Path(__file__).resolve().parents[4]
old = P / 'fpga/codec/deepeye_block_encoder.sv'
new = P / 'fpga/codec/deepeye_block_encoder_remainder_candidate.sv'
raw = old.read_bytes()
expected = '870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5'
assert hashlib.sha256(raw).hexdigest() == expected
text = raw.decode('utf-8')
replacements = [
    ('// Work: B-BLOCK-ENCODER-RTL-20261018-08-v1',
     '// Work: B-ENCODER-REMAINDER-CANDIDATE-20261024-36-v1\n'
     '// Derived from B-BLOCK-ENCODER-RTL-20261018-08-v1; main-approved identity.\n'
     '// Candidate only: no synthesis or timing improvement claim.'),
    ('module deepeye_block_encoder (',
     'module deepeye_block_encoder_remainder_candidate ('),
    ('    logic        cur_last;',
     '    logic        cur_last;\n    logic [15:0] cur_sample;'),
    ('    logic signed [23:0] prod;', '    logic [5:0]  r_euclid;'),
    ("        prod = $signed(q_bits) * $signed({1'b0, d_calc});\n"
     "        y_ext = $signed({9'b0, p_q}) + prod;",
     "        // p + floor((x-p+E)/d)*d = x + E - r_euclid.\n"
     "        r_euclid = (div_neg && (div_rem != 6'd0))\n"
     "                   ? ({1'b0, d_calc} - div_rem) : div_rem;\n"
     "        y_ext = $signed({9'b0, cur_sample})\n"
     "                + $signed({21'b0, cfg_e_q})\n"
     "                - $signed({19'b0, r_euclid});"),
    ("            cur_last        <= 1'b0;",
     "            cur_last        <= 1'b0;\n            cur_sample      <= 16'd0;"),
    ('                            cur_idx  <= load_idx;',
     '                            cur_sample <= s_data;\n'
     '                            cur_idx  <= load_idx;'),
]
newline = '\r\n' if b'\r\n' in raw else '\n'
text = text.replace('\r\n', '\n')
for before, after in replacements:
    assert text.count(before) == 1, before
    text = text.replace(before, after)
with new.open('xb') as handle:
    handle.write(text.replace('\n', newline).encode('utf-8'))
record = {
    'at_utc': datetime.now(timezone.utc).isoformat(),
    'thread_id': '01a16a34-b419-7942-9a7b-2b033142446b',
    'turn_id': '01a16a34-b53d-7cf2-b12a-3b044fc08392',
    'turn_id_source': 'Codex read_thread self, 2026-10-23/24 active turn',
    'job_id': 'child-dbcdc099d56046d2808ad94838b0b4e4',
    'execution_allowed': True,
    'source_head': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=P).decode().strip(),
    'original_sha256': expected,
    'candidate_sha256': hashlib.sha256(new.read_bytes()).hexdigest(),
    'replacement_count': len(replacements),
    'preexisting_owned_paths': False,
    'initial_read_failures': [
        {'command_item': 'exec-9e703ec8-6056-40ad-8fdf-6b5563d0a97e', 'exit_code': 1,
         'cause': 'Installed skill relative paths absent inside W; used installed absolute paths after inspection.'},
        {'command_item': 'exec-e773eefc-9d38-4566-81a8-c03169863165', 'exit_code': 1,
         'cause': 'rg tests/rtl/codec absent (new assigned parent directory); existing TB is tests/codec/rtl.'},
    ],
}
(Path(__file__).parent / 'bootstrap.json').write_text(json.dumps(record, indent=2) + '\n', encoding='utf-8')
print(json.dumps(record, indent=2))
