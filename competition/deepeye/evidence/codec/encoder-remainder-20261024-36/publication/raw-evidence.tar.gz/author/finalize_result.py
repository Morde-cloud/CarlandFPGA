"""Persist the actual attempt result; no new simulation or acceptance work."""
from datetime import datetime, timezone
import difflib
import hashlib
import json
from pathlib import Path
import subprocess
import sys

AUTHOR = Path(__file__).resolve().parent
P = AUTHOR.parents[3]


def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1 << 20), b''):
            h.update(chunk)
    return h.hexdigest()


result = json.loads((AUTHOR/'attempt-01/RESULT.json').read_text(encoding='utf-8'))
assert result['status'] == 'author_bounded_pass' and result['exit_code'] == 0
assert result['source_drift'] == []
assert result['original_sha256_after'] == '870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5'
original = P/'fpga/codec/deepeye_block_encoder.sv'
candidate = P/'fpga/codec/deepeye_block_encoder_remainder_candidate.sv'
diff = ''.join(difflib.unified_diff(original.read_text(encoding='utf-8').splitlines(True),
    candidate.read_text(encoding='utf-8').splitlines(True),
    fromfile='original/deepeye_block_encoder.sv',tofile='new/deepeye_block_encoder_remainder_candidate.sv'))
(AUTHOR/'candidate.diff.txt').write_text(diff,encoding='utf-8')
attempt_hashes = json.loads((AUTHOR/'attempt-01/artifact_hashes.json').read_text())
verified = 0
for name, expected in attempt_hashes.items():
    assert sha(AUTHOR/'attempt-01'/name) == expected, name
    verified += 1
result['attempt_result'] = 'attempt-01/RESULT.json'
result['attempt_result_sha256'] = sha(AUTHOR/result['attempt_result'])
for item in result['sources'].values():
    item['snapshot'] = 'attempt-01/' + item['snapshot']
for record in result['commands']:
    record['stdout'] = 'attempt-01/' + record['stdout']
    record['stderr'] = 'attempt-01/' + record['stderr']
result['attempt_artifact_hashes_verified'] = verified
result['failed_modelsim_or_math_attempts'] = []
result['meaningful_repairs'] = 0
result['initial_read_failures'] = json.loads((AUTHOR/'bootstrap.json').read_text())['initial_read_failures']
result['initial_read_failures_evidence'] = 'self_turn_evidence.json'
result['parent_main_approval'] = {
    'scope_path': 'D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/encoder-remainder-20261024-36/SCOPE.md',
    'scope_sha256': sha(Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/encoder-remainder-20261024-36/SCOPE.md')),
    'startup_message_id': '01a16a35-2c99-74a0-b4a0-2b4c77e10350',
    'native_validation': {'job_id':result['job_id'],'execution_allowed':True,
                          'canonical_agent_id':result['thread_id']},
    'token_persisted': False,
}
result['installed_skill_evidence'] = {}
for rel in ('fpga-multi-node/SKILL.md','fpga-multi-node/skill-role.json',
            'pynq-z2-single-node/SKILL.md','pynq-z2-single-node/skill-role.json'):
    path = Path('D:/pynq/CarlandFPGA/.agents/skills')/rel
    result['installed_skill_evidence'][rel] = {'path':str(path),'sha256':sha(path)}
result['node_id'] = 'B'
result['board_access'] = False
result['source_head_after'] = subprocess.check_output(['git','rev-parse','HEAD'],cwd=P).decode().strip()
result['original_sha256_final'] = sha(original)
assert result['source_head_after'] == result['source_head']
assert result['original_sha256_final'] == result['original_sha256_after']
for name, item in result['sources'].items():
    assert sha(Path(item['path'])) == item['sha256'], name
result['changed_files'] = list(result['ownership'])
result['author_directory_files'] = sorted(p.relative_to(AUTHOR).as_posix()
                                         for p in AUTHOR.rglob('*') if p.is_file())
result['raw_logs'] = {
    'invocation_stdout':'attempt-01.stdout.txt', 'invocation_stderr':'attempt-01.stderr.txt',
    'tool_commands_and_exits':'attempt-01/RESULT.json',
    'tool_stdout_stderr':'attempt-01/logs/', 'transcript':'attempt-01/transcript.txt',
    'public_ports':'attempt-01/public_ports.txt', 'early_read_errors':'self_turn_evidence.json',
    'bootstrap_stdout':'bootstrap.stdout.txt', 'bootstrap_stderr':'bootstrap.stderr.txt',
}
result['entry_commands'] = [
    {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
             'competition/deepeye/evidence/codec/encoder-remainder-20261024-36/author/bootstrap_candidate.py'],
     'exit_code':0,'stdout':'bootstrap.stdout.txt','stderr':'bootstrap.stderr.txt'},
    {'argv':result['argv'],'exit_code':0,'stdout':'attempt-01.stdout.txt','stderr':'attempt-01.stderr.txt'},
    {'argv':[sys.executable,'-B','-X','utf8',str(Path(__file__).resolve())],
     'exit_code':0,'stdout':'finalize.stdout.txt','stderr':'finalize.stderr.txt'},
]
result['handoff_note'] = 'Author bounded evidence only. Quality main independently reviews; no main decision or final acceptance by this worker.'
result['finished_utc'] = datetime.now(timezone.utc).isoformat()
dest = AUTHOR/'RESULT.json'
assert not dest.exists()
dest.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
hashes = {f.relative_to(AUTHOR).as_posix():sha(f) for f in sorted(AUTHOR.rglob('*'))
          if f.is_file() and f.name != 'artifact_hashes.json' and f.name not in ('finalize.stdout.txt','finalize.stderr.txt')}
(AUTHOR/'artifact_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'result':str(dest),'sha256':sha(dest),
                  'attempt_artifacts_verified':verified,'source_head':result['source_head'],
                  'original_sha256':result['original_sha256_final'],
                  'candidate_sha256':sha(candidate)},indent=2))
