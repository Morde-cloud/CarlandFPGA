Work B-ENCODER-REMAINDER-PARSER-REPAIR-20261024-36-r1.
Task DEEPEYE-IMPLEMENTATION-20261014/v1.
Worker 01a16a34-b419-7942-9a7b-2b033142446b.
Only runner + this new directory are owned. Preserve all earlier evidence.
Native self-validation returned execution_allowed=true before scope execution.
Contract DEEPEYE-HUMAN-LOCK-20261014/revision1, H01-H15,
requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804,
pin f5989cd5defce561f9ba98e6b18fc2682945f0a2.
Offline parser repair only: no RTL/TB change, vendor run, Git mutation,
publication or board work. All 29 formal/acceptance cards remain not_run.

The runner now calls check_saved_run(transcript, trace_lines, cases), a pure
offline function. It checks exact whole-line records and pinned TB ordering,
fixture metadata and recorded original sample/metadata/byte values, all trace
columns and counters, and exact simulator completion/time/instance/diagnostics.
No hashes whitelist accepted content. Changed fields, counters and ordering
are rejected using parsed numeric values and complete observed transitions.

Replay: python -B -X utf8 qualify_offline.py 1 (fresh cycle-01 directory only).
cycle-01/RESULT.json records the unchanged positive and 134 negative probes,
including all 14 preserved main red fixtures. Negative transcripts and fixture
files are saved; trace mutations are replayable base-row edit recipes.
Existing output directories are refused. No vendor process is launched.

Limitation: the original trace omits candidate metadata/data, config payload
and s_last. Offline checks cannot independently revalidate those unrecorded
values. Main retains candidate clock/byte review and all final acceptance.
