from pathlib import Path
import hashlib
import json
import shutil
from datetime import datetime, timezone

out = Path(__file__).resolve().parent
p = out.parents[4]
root = out.parent.parent
assert not (out/'baseline.json').exists()
runner = p/'tools/codec/run_encoder_remainder_candidate.py'
assert hashlib.sha256(runner.read_bytes()).hexdigest() == '559fbacc8ec2d25c9ebd71c67bfecdd9ad4b75c265c39181dac0f69b77f7a6e6'
(out/'original').mkdir()
shutil.copyfile(runner,out/'original'/runner.name)
red = root/'main/author-parser-qualification-02'
shutil.copytree(red,out/'initial-red')
protected = [p/'fpga/codec/deepeye_block_encoder.sv',
             p/'fpga/codec/deepeye_block_encoder_remainder_candidate.sv',
             p/'fpga/codec/encoder_remainder_candidate.md',
             p/'tests/rtl/codec/tb_encoder_remainder_candidate.sv',out.parent/'RESULT.json']
protected += [f for f in (out.parent/'attempt-01').rglob('*') if f.is_file()]
protected += [f for f in red.rglob('*') if f.is_file()]
record = {'utc':datetime.now(timezone.utc).isoformat(),
          'thread_id':'01a16a34-b419-7942-9a7b-2b033142446b',
          'turn_id':'01a16a47-b325-7122-9876-fd41bf56efbb',
          'job_id':'child-afb057bcc4014cd38495defd9df87caf',
          'work_id':'B-ENCODER-REMAINDER-PARSER-REPAIR-20261024-36-r1',
          'self_validation_execution_allowed':True,
          'runner_before_sha256':hashlib.sha256(runner.read_bytes()).hexdigest(),
          'protected':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in protected}}
(out/'baseline.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':'snapshotted','protected_files':len(record['protected']),
                  'runner_before_sha256':record['runner_before_sha256']}))
