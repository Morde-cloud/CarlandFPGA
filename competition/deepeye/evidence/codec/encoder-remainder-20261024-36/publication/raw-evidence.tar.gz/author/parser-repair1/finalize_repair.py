from pathlib import Path
import hashlib
import json
import sys
from datetime import datetime, timezone

out = Path(__file__).resolve().parent
p = out.parents[4]
cycle = int(sys.argv[1])
actual = json.loads((out/('cycle-%02d/RESULT.json' % cycle)).read_bytes())
if actual['exit_code'] != 0 or actual['status'] != 'author_offline_parser_qualification_pass':
    raise RuntimeError('qualification not passed')
def sha(f):
    return hashlib.sha256(f.read_bytes()).hexdigest()
baseline = json.loads((out/'baseline.json').read_bytes())
drift = [name for name,digest in baseline['protected'].items() if sha(Path(name)) != digest]
if drift: raise RuntimeError('protected file drift: '+str(drift))
current_runner = p/'tools/codec/run_encoder_remainder_candidate.py'
if sha(current_runner) != actual['sources'][str(current_runner)]:
    raise RuntimeError('runner changed after qualification')
result = dict(actual)
result.update({
    'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,
    'operation_id':'B-DEEPEYE-ENCODER-REMAINDER-PARSER-REPAIR-20261024-36-r1',
    'quality_main_thread_id':'01a13b55-095b-7461-8dd5-5476a130bd82',
    'source_design_commit':'1011259415a0916054eb580687612580bc1e5f09',
    'source_head_at_initial_candidate':'8ca3dd05cac4aea49c0afe53a6d9a12124aa12d2',
    'changed_paths':['competition/deepeye/tools/codec/run_encoder_remainder_candidate.py',
                     'competition/deepeye/evidence/codec/encoder-remainder-20261024-36/author/parser-repair1/'],
    'runner_sha256_before':baseline['runner_before_sha256'],
    'runner_sha256_after':sha(current_runner),
    'python_version':sys.version,
    'scope_sha256':sha(Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/encoder-remainder-20261024-36/PARSER_REPAIR1_SCOPE.md')),
    'protected_files_verified':len(baseline['protected']),
    'protected_drift':drift,
    'edit_qualification_cycles':cycle,
    'self_validation':{'job_id':baseline['job_id'],'canonical_agent_id':baseline['thread_id'],
                       'execution_allowed':True},
    'changed_behavior':'Whole-line ordered unique records; exact fixture fields; all 12 trace columns; handshake/stall/reset/cancel and completion counters derived from complete trace segments; exact simulator finish/time/instance/zero diagnostics.',
    'limitations':actual['positive_parsed']['limitations']+[
        'No RTL, TB, notes, original RESULT, original attempt or main evidence changed.',
        'Offline author parser evidence only. No vendor run, synthesized improvement, independent candidate clock/byte acceptance or final product acceptance.'],
    'initial_red_evidence':'initial-red/RESULT.json',
    'raw_stdout':'cycle-%02d.stdout.txt'%cycle,'raw_stderr':'cycle-%02d.stderr.txt'%cycle,
    'qualification_result':'cycle-%02d/RESULT.json'%cycle,
    'commands':[
        {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
                 'competition/deepeye/evidence/codec/encoder-remainder-20261024-36/author/parser-repair1/bootstrap_repair.py'],
         'exit_code':0,'stdout':'bootstrap.stdout.txt','stderr':'bootstrap.stderr.txt'},
        {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
                 'competition/deepeye/evidence/codec/encoder-remainder-20261024-36/author/parser-repair1/qualify_offline.py',str(cycle)],
         'exit_code':0,'stdout':'cycle-%02d.stdout.txt'%cycle,'stderr':'cycle-%02d.stderr.txt'%cycle},
        {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
                 'competition/deepeye/evidence/codec/encoder-remainder-20261024-36/author/parser-repair1/finalize_repair.py',str(cycle)],
         'exit_code':0,'stdout':'finalize.stdout.txt','stderr':'finalize.stderr.txt'},
    ],
    'finished_utc':datetime.now(timezone.utc).isoformat(),
})
dest = out/'RESULT.json'
if dest.exists(): raise RuntimeError('refusing existing final result')
dest.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
hashes = {f.relative_to(out).as_posix():sha(f) for f in sorted(out.rglob('*'))
          if f.is_file() and f.name != 'artifact_hashes.json' and f.name not in ('finalize.stdout.txt','finalize.stderr.txt')}
(out/'artifact_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'negative_count':result['negative_count'],
                  'main14_rejected':result['main14_rejected'],'false_accepts':result['false_accepts'],
                  'cycles':cycle,'protected_verified':len(baseline['protected']),
                  'runner_sha256':sha(current_runner),'result_path':str(dest),
                  'result_sha256':sha(dest)},indent=2))
