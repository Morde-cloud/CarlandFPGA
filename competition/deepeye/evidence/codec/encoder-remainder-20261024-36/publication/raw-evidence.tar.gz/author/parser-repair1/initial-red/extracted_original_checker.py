if re.search(r'TB_FAIL|\*\* (?:Error|Fatal):',transcript):
    raise RuntimeError('simulation failure marker')
if transcript.count('TB_DONE encoder_remainder_candidate PASS') != 1:
    raise RuntimeError('missing/excess completion marker')
passed_ids = re.findall(r'TB_CASE id=(\d+) .* PASS',transcript)
assert [int(i) for i in passed_ids] == list(range(len(cases)))
summaries = re.findall(r'TB_SUMMARY (.*)',transcript)
assert len(summaries) == 1
summary = {k:int(v) for k,v in re.findall(r'(\w+)=(\d+)',summaries[0])}
assert summary['valid'] == len(cases) and summary['invalid'] == 6
assert summary['abort'] == 24 and summary['recovery'] == 24
assert summary['completed'] == len(cases)+6+24
assert summary['reset'] == 12 and summary['cancel'] == 12
assert len(re.findall(r'TB_ABORT .* PASS',transcript)) == 24
assert len(re.findall(r'TB_INVALID .* PASS',transcript)) == 6
trace = out/'public_ports.txt'
with trace.open('r',encoding='ascii') as f:
    first_cycle, last_cycle, lines = None,None,0
    for line in f:
        observed_cycle = int(line.split()[0])
        if first_cycle is None: first_cycle = observed_cycle
        if last_cycle is not None: assert observed_cycle == last_cycle+1
        last_cycle = observed_cycle; lines += 1
assert first_cycle == 4 and last_cycle == summary['cycles']
assert lines == summary['cycles']-3
