"""Replay saved positive/red evidence and targeted negatives, without vendor calls."""
from pathlib import Path
import ast
import copy
import hashlib
import importlib.util
import json
import re
import shutil
import sys
import time
from datetime import datetime, timezone

sys.dont_write_bytecode = True
base = Path(__file__).resolve().parent
p = base.parents[4]
cycle = int(sys.argv[1])
assert cycle in (1,2)
out = base/('cycle-%02d' % cycle)
out.mkdir()
(out/'mutations').mkdir()
runner = p/'tools/codec/run_encoder_remainder_candidate.py'
shutil.copyfile(runner,out/runner.name)
original = base.parent/'attempt-01'
transcript_path = original/'logs/vsim.stdout.txt'
trace_path = original/'public_ports.txt'
fixture_path = original/'fixtures.json'
text = transcript_path.read_bytes().decode('utf-8')
rows = trace_path.read_bytes().decode('ascii').splitlines(keepends=True)
fixtures = json.loads(fixture_path.read_bytes())
modspec = importlib.util.spec_from_file_location('encoder_remainder_repaired',runner)
module = importlib.util.module_from_spec(modspec)
modspec.loader.exec_module(module)
checks = []
result = {'work_id':'B-ENCODER-REMAINDER-PARSER-REPAIR-20261024-36-r1',
          'thread_id':'01a16a34-b419-7942-9a7b-2b033142446b',
          'turn_id':'01a16a47-b325-7122-9876-fd41bf56efbb',
          'job_id':'child-afb057bcc4014cd38495defd9df87caf',
          'cycle':cycle,'started_utc':datetime.now(timezone.utc).isoformat(),
          'status':'running','vendor_runs':0,'checks':checks,'argv':[sys.executable]+sys.argv,
          'cwd':str(Path.cwd()),'sources':{str(f):hashlib.sha256(f.read_bytes()).hexdigest()
            for f in (runner,transcript_path,trace_path,fixture_path)},
          'main_independent_evidence':'Main-reported independent 1559 cases and mutants are background only; not rerun or accepted by worker.',
          'contract':{'id':'DEEPEYE-HUMAN-LOCK-20261014','revision':1,'ids':['H%02d'%i for i in range(1,16)],
                      'pin':'f5989cd5defce561f9ba98e6b18fc2682945f0a2',
                      'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'},
          'not_run':['formal_29','B01','B03','B06','R03','synthesis','implementation','timing_closure','CDC','board','system','final_acceptance']}


def save():
    (out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')


def check(name, transcript=text, trace_rows=None, cases=None, positive=False, recipe=None):
    if trace_rows is None: trace_rows = rows
    if cases is None: cases = fixtures
    rec = {'name':name,'expected_accept':positive,'recipe':recipe}
    t0 = time.monotonic()
    try:
        parsed = module.check_saved_run(transcript,iter(trace_rows),cases)
        rec['accepted'] = True
        if positive: result['positive_parsed'] = parsed
    except module.EvidenceError as exc:
        rec['accepted'] = False; rec['error'] = str(exc)
    except Exception as exc:
        rec['accepted'] = False; rec['unexpected_exception'] = type(exc).__name__+': '+str(exc)
    rec['duration_seconds'] = time.monotonic()-t0
    rec['pass'] = rec['accepted'] == positive and 'unexpected_exception' not in rec
    rec['transcript_sha256'] = hashlib.sha256(transcript.encode('utf-8')).hexdigest()
    if transcript != text:
        namepath = out/'mutations'/(name+'.stdout.txt')
        namepath.write_bytes(transcript.encode('utf-8'))
        rec['transcript_path'] = str(namepath.relative_to(out))
    checks.append(rec)
    save()
    print(json.dumps(rec,sort_keys=True),flush=True)
    return rec['pass']


def changed_line(prefix, change):
    lines = text.splitlines()
    indices = [i for i,line in enumerate(lines) if line.startswith(prefix)]
    assert indices
    index = indices[0]
    replacement = change(lines[index])
    lines[index:index+1] = replacement if type(replacement) is list else [replacement]
    return '\n'.join(lines)+'\n'


def replace_column(index, column, value):
    old = rows[index]
    cols = old.split()
    cols[column] = value
    new = ' '.join(cols)+'\n'
    return [new if i == index else row for i,row in enumerate(rows)], {'row':index+1,'old':old,'new':new}


save()
exit_code = 1
try:
    if not check('positive_unchanged',positive=True):
        raise RuntimeError('unchanged positive rejected; stop this bounded qualification cycle')
    # The actual vendor runner must invoke the pure checker; no vendor is launched here.
    tree = ast.parse(runner.read_text(encoding='utf-8'))
    main = next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name == 'main')
    calls = [n for n in ast.walk(main) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)
             and n.func.id == 'check_saved_run']
    if len(calls) != 1 or [ast.unparse(a) for a in calls[0].args] != ['transcript','f','cases']:
        raise RuntimeError('actual runner checker integration absent or changed')
    result['actual_runner_integration'] = 'AST confirms exactly check_saved_run(transcript, f, cases) in main'
    red_result = json.loads((base/'initial-red/RESULT.json').read_bytes())
    if red_result['false_accepts'] != 14: raise RuntimeError('unexpected main red evidence')
    for probe in red_result['probes']:
        red_path = base/'initial-red'/(probe['name']+'.stdout.txt')
        if hashlib.sha256(red_path.read_bytes()).hexdigest() != probe['sha256']:
            raise RuntimeError('red fixture drift '+probe['name'])
        check('main14_'+probe['name'],transcript=red_path.read_bytes().decode('utf-8'))

    # Each valid-case numeric field; each abort numeric field; invalid identity.
    for key in ('id','n','e','raw','k','bits','bytes'):
        check('case_field_'+key,transcript=changed_line('# TB_CASE ',lambda s,k=key:
              re.sub(r'\b'+k+r'=(\d+)',lambda m:k+'='+str(int(m.group(1))+1),s,count=1)))
    for key in ('id','which','stage'):
        check('abort_field_'+key,transcript=changed_line('# TB_ABORT ',lambda s,k=key:
              re.sub(r'\b'+k+r'=(\d+)',lambda m:k+'='+str(int(m.group(1))+1),s,count=1)))
    check('invalid_field_id',transcript=changed_line('# TB_INVALID ',lambda s:s.replace('200000','200099')))
    for kind in ('CASE','INVALID','ABORT','SUMMARY','DONE'):
        prefix = '# TB_'+kind+' '
        check(kind.lower()+'_prefix',transcript=changed_line(prefix,lambda s:'bogus '+s))
        check(kind.lower()+'_suffix',transcript=changed_line(prefix,lambda s:s+' bogus'))
        check(kind.lower()+'_duplicate',transcript=changed_line(prefix,lambda s:[s,s]))
        check(kind.lower()+'_missing',transcript=changed_line(prefix,lambda s:[]))
        lines = text.splitlines(); at=next(i for i,s in enumerate(lines) if s.startswith(prefix))
        lines[at],lines[at+1]=lines[at+1],lines[at]
        check(kind.lower()+'_reorder',transcript='\n'.join(lines)+'\n')
        if kind != 'DONE':
            check(kind.lower()+'_unknown_field',transcript=changed_line(prefix,lambda s:s+' unknown=0'))
            check(kind.lower()+'_duplicate_field',transcript=changed_line(prefix,lambda s:s+' '+s.split()[2]))
    for key in module.SUMMARY_FIELDS:
        check('summary_counter_'+key,transcript=changed_line('# TB_SUMMARY ',lambda s,k=key:
              re.sub(r'\b'+k+r'=(\d+)',lambda m:k+'='+str(int(m.group(1))+1),s,count=1)))
    check('unknown_tb_record',transcript=changed_line('# TB_DONE ',lambda s:['# TB_UNKNOWN PASS',s]))
    check('summary_key_order',transcript=changed_line('# TB_SUMMARY ',lambda s:s.replace('valid=297 invalid=6','invalid=6 valid=297')))
    check('summary_leading_zero',transcript=changed_line('# TB_SUMMARY ',lambda s:s.replace('valid=297','valid=0297')))

    # Unique, correctly placed simulator termination and exact pinned time/instance.
    terminal_prefixes = ('# ** Note: $finish', '#    Time:', '# End time:', '# Errors:')
    for i,prefix in enumerate(terminal_prefixes):
        check('terminal_%d_duplicate'%i,transcript=changed_line(prefix,lambda s:[s,s]))
        check('terminal_%d_missing'%i,transcript=changed_line(prefix,lambda s:[]))
        check('terminal_%d_suffix'%i,transcript=changed_line(prefix,lambda s:s+' bogus'))
    check('terminal_time_value',transcript=changed_line('#    Time:',lambda s:s.replace('5051150','5051160')))
    check('terminal_time_unit',transcript=changed_line('#    Time:',lambda s:s.replace(' ns ',' ps ')))
    check('terminal_iteration',transcript=changed_line('#    Time:',lambda s:s.replace('Iteration: 1','Iteration: 2')))
    check('terminal_instance',transcript=changed_line('#    Time:',lambda s:s.replace('/tb_encoder','/other_encoder')))
    check('terminal_finish_line',transcript=changed_line('# ** Note: $finish',lambda s:s.replace('(329)','(328)')))
    check('terminal_elapsed',transcript=changed_line('# End time:',lambda s:s.replace('0:00:02','0:00:03')))
    check('terminal_errors',transcript=changed_line('# Errors:',lambda s:s.replace('Errors: 0','Errors: 1')))
    check('terminal_warnings',transcript=changed_line('# Errors:',lambda s:s.replace('Warnings: 0','Warnings: 1')))
    check('terminal_extra_line',transcript=text+'# unexpected trailer\n')
    check('terminal_conflicting_error',transcript=text.replace('# TB_CASE id=0','# ** Error: injected\n# TB_CASE id=0',1))

    # Fixed-width trace grammar, all four recorded ready/valid signals, masks and values.
    first_sample = next(i for i,r in enumerate(rows) if r.split()[4] == '11')
    first_meta = next(i for i,r in enumerate(rows) if r.split()[5][0] == '1')
    first_data = next(i for i,r in enumerate(rows) if r.split()[6][0] == '1')
    cfg_accept = next(i for i,r in enumerate(rows) if r.split()[3] == '11')
    cfg_stall = next(i for i,r in enumerate(rows) if r.split()[3] == '10')
    mutations = (
        ('trace_unknown_binary',0,2,'x0'), ('trace_bad_hex',0,8,'000000000x'),
        ('trace_metadata_width',0,8,'00000000000'), ('trace_data_overflow',0,9,'200'),
        ('trace_sample_width',0,10,'00000'), ('trace_candidate_width',0,11,'4'),
        ('trace_case_identity',0,1,'1'), ('trace_cycle_origin',0,0,'5'),
        ('trace_ready_mismatch',0,7,'00'), ('trace_valid_mismatch',first_meta,11,'0'),
        ('trace_invalid_metadata_mask',0,8,'0000000001'), ('trace_invalid_data_mask',0,9,'001'),
        ('trace_accepted_sample_value',first_sample,10,'0001'),
        ('trace_metadata_numeric',first_meta,8,'0042002003'),
        ('trace_output_byte_numeric',first_data,9,'002'), ('trace_output_last_numeric',first_data,9,'001'),
        ('trace_cfg_counter',cfg_accept,3,'01'), ('trace_sample_counter',first_sample,4,'01'),
        ('trace_meta_counter',first_meta,5,'01'), ('trace_data_counter',first_data,6,'01'),
        ('trace_stall_counter',cfg_stall,3,'00'),
    )
    for name,index,column,value in mutations:
        mutated, recipe = replace_column(index,column,value)
        check(name,trace_rows=mutated,recipe=recipe)
    check('trace_missing_column',trace_rows=[rows[0].rsplit(' ',1)[0]+'\n']+rows[1:],recipe={'remove_last_column_row':1})
    check('trace_extra_column',trace_rows=[rows[0].rstrip()+' 0\n']+rows[1:],recipe={'extra_column_row':1})
    check('trace_drop_row',trace_rows=rows[:1]+rows[2:],recipe={'drop_row':2})
    check('trace_duplicate_row',trace_rows=rows[:1]+rows,recipe={'duplicate_row':1})
    check('trace_truncated',trace_rows=rows[:-1],recipe={'drop_last_row':True})
    check('trace_no_final_newline',trace_rows=rows[:-1]+[rows[-1].rstrip()],recipe={'strip_final_newline':True})
    check('trace_empty',trace_rows=[],recipe={'empty_trace':True})

    # Saved fixture changes must not silently qualify original observed outputs.
    for key in ('sample_count','e','k','valid_bit_count','mode','payload_hex'):
        altered = copy.deepcopy(fixtures)
        f = altered[0]['fixture']
        f[key] = {'sample_count':2,'e':1,'k':0,'valid_bit_count':15,'mode':'unknown','payload_hex':'0001'}[key]
        path = out/'mutations'/('fixture_'+key+'.json')
        path.write_text(json.dumps(altered),encoding='utf-8')
        check('fixture_'+key,cases=altered,recipe={'fixture_path':str(path.relative_to(out))})
    altered = copy.deepcopy(fixtures); altered[0]['samples']=[1]; altered[0]['fixture']['payload_hex']='0001'
    (out/'mutations/fixture_conflicting_samples.json').write_text(json.dumps(altered),encoding='utf-8')
    check('fixture_conflicting_samples',cases=altered,recipe={'fixture_path':'mutations/fixture_conflicting_samples.json'})
    baseline = json.loads((base/'baseline.json').read_bytes())
    drift = [path for path,digest in baseline['protected'].items()
             if hashlib.sha256(Path(path).read_bytes()).hexdigest() != digest]
    result['protected_drift'] = drift
    if drift: raise RuntimeError('protected input drift')
    result['main14_rejected'] = sum(c['pass'] for c in checks if c['name'].startswith('main14_'))
    result['negative_count'] = sum(not c['expected_accept'] for c in checks)
    result['false_accepts'] = sum(c['accepted'] and not c['expected_accept'] for c in checks)
    result['failures'] = [c['name'] for c in checks if not c['pass']]
    if result['failures']: raise RuntimeError('qualification failures: '+','.join(result['failures']))
    result['status'] = 'author_offline_parser_qualification_pass'
    exit_code = 0
except Exception as exc:
    result['status'] = 'failed'; result['error'] = type(exc).__name__+': '+str(exc)
finally:
    result['exit_code'] = exit_code
    result['finished_utc'] = datetime.now(timezone.utc).isoformat()
    save()
    hashes = {f.relative_to(out).as_posix():hashlib.sha256(f.read_bytes()).hexdigest()
              for f in out.rglob('*') if f.is_file()}
    (out/'artifact_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:result.get(k) for k in ('status','negative_count','main14_rejected','false_accepts','failures','error')},sort_keys=True),flush=True)
raise SystemExit(exit_code)
