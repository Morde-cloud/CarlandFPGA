# B-ENCODER-REMAINDER-MAIN-VERIFY-20261024-36-v1

Task DEEPEYE-IMPLEMENTATION-20261014/v1; main thread
01a13b55-095b-7461-8dd5-5476a130bd82. H01-H15 requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.

The main algebra and 1,966,035 feasible transition checks are frozen in
main/preinspection-01/MAIN_FREEZE.json before reading the candidate. This
checks all reachable signed n for every allowed E with feasible predictor
endpoints/midpoint; it is not the full Cartesian sample/predictor space.

After the author actually completes:

1. Verify lease terminal result, owned diff, exact source hash, original-core
   unchanged pin, process exit codes and raw logs. Inspect each signed width
   and capture/reset/cancel branch against the main proof. Reject added state,
   added latency, live s_data use during reconstruction or a changed q/z rule.
2. Reuse the frozen independent op08 1,559-case mathematical byte oracle and
   external-port testbench. Add a separate candidate instance on identical
   inputs and compare every visible valid/ready/counter-free payload endpoint
   each post-reset cycle, masking payload fields only when invalid. Record
   every original accepted sample/header/data event and verify against the
   frozen bit-string oracle. This is new execution of a reused reference.
3. Run a small set of actual compiled candidate-only mutations: missing
   negative Euclidean-remainder correction and incorrect sample capture.
   Require a concrete numeric counterexample, not a compile failure. Freeze
   strict complete/unique marker grammar and preserve all failures.
4. Only after software review succeeds, run one fresh bounded OOC synthesis
   of the exact candidate at xc7z020clg400-1 with the original Vivado2026.1
   tool hashes, maxThreads2 and same post-synthesis 10ns diagnostic clock.
   Compare resources, DSP use and actual setup path with original op33
   encoder -4.379ns and block-stream -4.349ns reports. Do not rerun original
   synthesis or modify production dependencies for the experiment.

Do not promote a local candidate into the original encoder while worker35
is consuming its frozen source. Any later adoption requires a separately
recorded exclusive transfer, precise same-commit requalification of dependent
stream/queue behavior and a scoped handoff. Candidate synthesis is not whole
design implementation, calibrated clock, timing closure, CDC/RDC or board
acceptance. All29 formal cards remain not_run. Physical board A only.
