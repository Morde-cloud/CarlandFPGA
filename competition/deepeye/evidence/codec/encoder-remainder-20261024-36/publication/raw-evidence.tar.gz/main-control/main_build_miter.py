from pathlib import Path
import hashlib,json
P=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye');E=P/'evidence/codec/encoder-remainder-20261024-36/main';F=E/'preinspection-01';f=json.loads((F/'MAIN_FREEZE.json').read_bytes());p=F/'main_encoder_port_tb.sv';b=p.read_bytes();assert hashlib.sha256(b).hexdigest()==f['pins']['evidence/codec/block-encoder-20261018-08/main/main_encoder_port_tb.sv']['sha256'];s=b.decode()
outs=[('cfg_ready',1),('s_ready',1),('meta_valid',1),('meta_error',2),('meta_count',8),('meta_e',4),('meta_raw',1),('meta_k',4),('meta_valid_bits',12),('meta_bytes',9),('m_valid',1),('m_data',8),('m_last',1)]
ins=['clk','rst','cancel','cfg_valid','cfg_count','cfg_e','s_valid','s_data','s_last','meta_ready','m_ready'];decl='\n  // Candidate observed only through its public endpoints.\n'
for n,w in outs:decl+='  wire '+('['+str(w-1)+':0] ' if w>1 else '')+'c_'+n+';\n'
decl+='  deepeye_block_encoder_remainder_candidate candidate(\n'+',\n'.join('    .'+n+'('+n+')' for n in ins)+',\n'+',\n'.join('    .'+n+'(c_'+n+')' for n,_ in outs)+'\n  );\n'
def expr(n,w,prefix):
 if n.startswith('meta_') and n!='meta_valid':return prefix+'meta_valid?'+prefix+n+':'+str(w)+"'d0"
 if n in ('m_data','m_last'):return prefix+'m_valid?'+prefix+n+':'+str(w)+"'d0"
 return prefix+n
decl+='  wire [52:0] original_public={'+','.join(expr(n,w,'') for n,w in outs)+'};\n'
decl+='  wire [52:0] candidate_public={'+','.join(expr(n,w,'c_') for n,w in outs)+'};\n'
anchor='  deepeye_block_encoder dut(.*);';assert anchor in s;s=s.replace(anchor,anchor+decl)
anchor='    cycles=cycles+1;';assert anchor in s;s=s.replace(anchor,anchor+'\n    if(cycles>1 && candidate_public !== original_public) begin\n      $display("MAIN_REMAINDER_MISMATCH cycle=%0d expected=%h actual=%h",cycles,original_public,candidate_public);\n      $fatal(1,"MAIN_REMAINDER_NUMERIC_FAILURE");\n    end')
anchor='$display("MAIN_PORT_COMPLETE cycles=%0d",cycles);';assert anchor in s;s=s.replace(anchor,anchor+'$display("MAIN_REMAINDER_COMPLETE cycles=%0d ports=13",cycles);')
tb=P/'tests/rtl/codec/main_tb_encoder_remainder.sv';tb.parent.mkdir(parents=True,exist_ok=True);assert not tb.exists();tb.write_text(s,encoding='utf-8',newline='\n')
out=E/'miter-design-01';out.mkdir(exist_ok=False);(out/tb.name).write_bytes(tb.read_bytes());(out/'DESIGN.json').write_text(json.dumps({'scope':'13public endpoints everypost-initial edge; originalclock/cases frozenfromindependentop08; expectedbyteoracle remainsindependent; candidate source not inspected','tb_sha256':hashlib.sha256(tb.read_bytes()).hexdigest(),'fields':outs,'width':53,'candidate_source_read':False},indent=2)+'\n');print(json.dumps({'ports':len(outs),'tb_sha256':hashlib.sha256(tb.read_bytes()).hexdigest()}))
