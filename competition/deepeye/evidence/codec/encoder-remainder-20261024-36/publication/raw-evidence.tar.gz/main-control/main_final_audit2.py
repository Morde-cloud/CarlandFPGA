from pathlib import Path
import hashlib,importlib.util,json,re,sys,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/encoder-remainder-20261024-36';A=E/'author/attempt-01';Q=E/'author/parser-repair1';O=E/'main/final-audit-02';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
terminal=get(D/'parser-repair1-terminal.json')[0];assert terminal['terminal'] and terminal['status']=='completed' and not terminal['stale']
repair=get(Q/'RESULT.json');assert repair['exit_code']==0 and repair['vendor_runs']==0 and repair['false_accepts']==0 and not repair['failures'] and not repair['protected_drift']
runner=P/'tools/codec/run_encoder_remainder_candidate.py';assert sha(runner)==repair['runner_sha256_after']
spec=importlib.util.spec_from_file_location('main36_final_parser',runner);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
raw=(A/'logs/vsim.stdout.txt').read_text();lines=(A/'public_ports.txt').read_text().splitlines(keepends=True);cases=get(A/'fixtures.json');positive=m.check_saved_run(raw,iter(lines),cases)
checks=[]
for f in sorted((E/'main/author-parser-qualification-02').glob('*.stdout.txt')):
 try:m.check_saved_run(f.read_text(),iter(lines),cases)
 except m.EvidenceError as ex:checks.append({'name':f.name,'rejected':True,'reason':str(ex)})
 else:raise AssertionError('main red accepted '+f.name)
assert len(checks)==14
recipes=[]
for name,col,pred in [('sample_value',10,lambda x:x[4]=='11'),('metadata_value',8,lambda x:x[5][0]=='1'),('data_value',9,lambda x:x[6][0]=='1')]:
 i=next(i for i,line in enumerate(lines) if pred(line.split()));z=lines[i].split();z[col]=format(int(z[col],16)^1,'0'+str(len(z[col]))+'x');recipes.append({'name':name,'index':i,'replacement':' '.join(z)+'\n'})
for name,col,val in [('case_id',1,'999'),('cycle',0,'5'),('ready_mismatch',7,'00'),('illegal_binary',2,'0x'),('wide_hex',8,'00000000000')]:
 z=lines[0].split();z[col]=val;recipes.append({'name':name,'index':0,'replacement':' '.join(z)+'\n'})
for r in recipes:
 def altered():
  for i,line in enumerate(lines):yield r['replacement'] if i==r['index'] else line
 try:m.check_saved_run(raw,altered(),cases)
 except m.EvidenceError as ex:checks.append({'name':r['name'],'rejected':True,'reason':str(ex),'recipe':r})
 else:raise AssertionError('trace mutation accepted '+r['name'])
verified=[]
def verify(p,h):
 assert sha(p)==h,str(p);verified.append({'path':str(p.relative_to(W)),'sha256':h,'bytes':p.stat().st_size})
for n,h in get(Q/'artifact_hashes.json').items():verify(Q/n,h)
for n,h in get(Q/'baseline.json')['protected'].items():verify(Path(n),h)
for x in get(E/'main/raw-audit-01/RESULT.json')['verified_records']:verify(W/x['path'],x['sha256'])
for f in (E/'main').rglob('INPUTS.json'):
 for n,x in get(f).items():verify(f.parent/'inputs'/Path(n).name,x['sha256'])
for f in (E/'main').rglob('RESULT.json'):
 x=get(f)
 if 'ports_sha256' in x:verify(f.parent/'ports.txt',x['ports_sha256'])
for c in repair['commands']:assert c['exit_code']==0
assert sha(P/'fpga/codec/deepeye_block_encoder_remainder_candidate.sv')=='9cd6f8347139b19db318ef2e0a349784e452f9703773afebae689875bc180018'
assert sha(P/'fpga/codec/deepeye_block_encoder.sv')=='870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5'
ooc=get(E/'main/ooc-reopen-01/RESULT.json');assert ooc['same_resources_timing_after_actual_reopen'] and ooc['actual_reopened_checkpoints']==1
main=get(E/'main/positive-01/RESULT.json');assert main['status']=='PASS';mutants=get(E/'main/compiled-mutants-01/RESULT.json');assert mutants['actual_compiled_mutants']==2
for r in mutants['records']:assert r['counterexample']['actual']!=r['counterexample']['expected'] and r['exit']==0
result={'status':'ACCEPTED_CANDIDATE_SOFTWARE_AND_OOC_DIAGNOSTIC_ONLY','accepted_candidate':True,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','candidate_sha256':sha(P/'fpga/codec/deepeye_block_encoder_remainder_candidate.sv'),'original_sha256':sha(P/'fpga/codec/deepeye_block_encoder.sv'),'runner_sha256':sha(runner),'main_math_feasible_cases':1966035,'main_cases':1559,'main_cycles':main['stats']['monitor_totals']['cycles'],'main_port_comparisons':main['public_port_comparisons'],'compiled_mutants':mutants,'author_original_commands':9,'author_original_cases':positive['summary']['valid'],'author_trace_rows':positive['trace_rows'],'author_repair_negatives':repair['negative_count'],'main_parser_checks':checks,'parsed_positive':positive,'protected_files_verified':len(get(Q/'baseline.json')['protected']),'verified_records':verified,'ooc':ooc,'acceptance_notes':['Candidate only; original production encoder and operation35 dependencies remain unchanged.','Main independent proof and bitstring reference reuse with fresh execution; arithmetic sweep not full2^32 space. Original author oracle reuses publishedgolden, separately disclosed.','Author trace records original payload and candidate ready/valid, not candidate payload; live main miter checked candidate payload. Parser tied to current exactTB grammar.','Original main failednegativefixture and initialOOCdirectoryguard failure retained; no vendor replay. One fresh candidate synthesis and one actual DCP readback.','OOC candidate WNS+0.561ns vsoriginal-4.379ns underpost-synthesis10nsdiagnostic only; LUT+12 FF+18 DSP1to0. PS7DRCwarning and10warnings retained, I/Oconstraintsincomplete. OOCdriver warning_bearing summarydefault0 corrected byper-run independentrecord to1; originalreceiptpreserved.','All29/B01/B03/B06/R03/implementation/timingclosure/CDC_RDC/board/system remainnot_run; physicalboardAonly.']}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8');print(json.dumps({'status':result['status'],'verified_records':len(verified),'main_parser_negatives':len(checks),'candidate_wns':ooc['candidate']['timing']['WNS'],'author_repair_negatives':repair['negative_count']}))
