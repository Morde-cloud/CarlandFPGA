from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/encoder-remainder-20261024-36/main/preinspection-01';E.mkdir(parents=True,exist_ok=False)
names=['evidence/codec/block-encoder-20261018-08/main/main_encoder_review.py','evidence/codec/block-encoder-20261018-08/main/main_encoder_port_tb.sv','evidence/codec/block-encoder-20261018-08/main/main_acceptance.json','fpga/codec/deepeye_block_encoder.sv'];pins={}
for n in names:
 b=(P/n).read_bytes();old=subprocess.check_output(['git','-C',str(W),'show','bbfb11439b35e0866a6d2486f3857b92ed6cf529:competition/deepeye/'+n]);assert b==old,n;(E/Path(n).name).write_bytes(b);pins[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
spec=importlib.util.spec_from_file_location('op08_codec_main',E/'main_encoder_review.py');m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);cases=m.build_cases();(E/'historical_cases.json').write_text(json.dumps(cases,separators=(',',':'))+'\n')
rows=[];first_negative=None;checked=0
for e in (0,1,2,4,8):
 count=0;bad_mutant=0;d=2*e+1
 for n in range(e-65535,e+65536):
  lo=max(0,e-n);hi=min(65535,65535+e-n);assert lo<=hi
  a=abs(n);divq,rem=divmod(a,d);q=divq if n>=0 else -divq-int(rem!=0);qref=n//d;assert q==qref
  r=d-rem if n<0 and rem else rem;assert 0<=r<d and n==q*d+r
  for p in sorted({lo,hi,(lo+hi)//2}):
   x=n+p-e;assert 0<=x<=65535
   original=p+q*d;replacement=x+e-r;assert original==replacement and -8<=replacement<=65543
   clamped=max(0,min(65535,original));assert abs(x-clamped)<=e
   wrong=max(0,min(65535,x+e-rem))
   if wrong!=clamped:
    bad_mutant+=1
    if first_negative is None:first_negative={'n':n,'p':p,'x':x,'E':e,'rem_abs':rem,'expected':clamped,'wrong_no_euclidean_fix':wrong}
   count+=1
 checked+=count;rows.append({'E':e,'n_values':131071,'feasible_p_checks':count,'negative_sign_mutant_rejections':bad_mutant})
assert first_negative is not None
proof='''# Main remainder reconstruction design proof

For accepted E in {0,1,2,4,8}, let d=2E+1 and n=x-p+E.
The existing restoring divider yields abs(n)=a*d+r_abs, 0<=r_abs<d.
For n>=0, q=a and r_euclidean=r_abs. For n<0, q=-a when
r_abs=0, otherwise q=-a-1 and r_euclidean=d-r_abs. Hence
n=q*d+r_euclidean in both cases, and p+q*d=x+E-r_euclidean.
This identity holds for every feasible x,p in[0,65535], independently of the
previous predictor. n fits signed18, abs(n) fits unsigned17, d<=17,
r_euclidean<=16 and x+E-r_euclidean is within[-8,65543]. Signed25
arithmetic with explicit zero extensions exactly preserves original clamps.
The new captured sample must be updated at the same accepted nonfirst valid
ST_LOAD edge, then held through all17 divider cycles and ST_DIV_FIN. No live
s_data read, state/cycle/handshake change or changed q/z/Rice/RAW rule is allowed.
This is an algebra proof and bounded software check, not RTL timing acceptance.
Main historical op08 public-port stimulus/reference reuse is explicit; newly
executed candidate results must get fresh actual commands/source hashes/logs.
'''
(E/'MAIN_PROOF.md').write_text(proof,encoding='utf-8',newline='\n')
rec={'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-ENCODER-REMAINDER-MAIN-VERIFY-20261024-36-v1','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','reference_commit':'bbfb11439b35e0866a6d2486f3857b92ed6cf529','candidate_source_read':False,'pins':pins,'historical_cases':len(cases),'cases_sha256':hashlib.sha256((E/'historical_cases.json').read_bytes()).hexdigest(),'proof_sha256':hashlib.sha256((E/'MAIN_PROOF.md').read_bytes()).hexdigest(),'checked_feasible_transitions':checked,'coverage':rows,'negative_control':first_negative,'scope':'main mathematical proof, exhaustive reachable n and feasible p endpoints/midpoint, not full Cartesian x/p enumeration or simulation. ActualRTL and OOC review pending.','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(E/'MAIN_FREEZE.json').write_text(json.dumps(rec,indent=2)+'\n');(D/'MAIN_PREINSPECTION_FREEZE.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'historical_cases':len(cases),'math_checks':checked,'negative_control':first_negative}))
