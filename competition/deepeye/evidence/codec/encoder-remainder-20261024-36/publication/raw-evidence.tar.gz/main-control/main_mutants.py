from pathlib import Path
import datetime,hashlib,json,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/encoder-remainder-20261024-36/main';S=P/'fpga/codec/deepeye_block_encoder_remainder_candidate.sv';b=S.read_bytes();assert hashlib.sha256(b).hexdigest()=='9cd6f8347139b19db318ef2e0a349784e452f9703773afebae689875bc180018';s=b.decode()
needle="r_euclid = (div_neg && (div_rem != 6'd0))\n                   ? ({1'b0, d_calc} - div_rem) : div_rem;";assert needle in s
variants={'negative_remainder_not_euclidean':s.replace(needle,'r_euclid = div_rem;'),'sample_capture_zero':s.replace('cur_sample <= s_data;',"cur_sample <= 16'd0;")};assert variants['sample_capture_zero']!=s
out=E/'compiled-mutants-01';out.mkdir(exist_ok=False);records=[]
for name,text in variants.items():
 p=out/(name+'.sv');p.write_text(text,encoding='utf-8',newline='\n');run=out/name;argv=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(P/'tools/codec/main_verify_encoder_remainder.py'),'--out',str(run),'--candidate',str(p),'--negative']
 (out/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
 cp=subprocess.run(argv,cwd=W,capture_output=True,creationflags=0x08000000,timeout=650);(out/(name+'.stdout.bin')).write_bytes(cp.stdout);(out/(name+'.stderr.bin')).write_bytes(cp.stderr);rec={'name':name,'exit':cp.returncode,'stdout_sha256':hashlib.sha256(cp.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(cp.stderr).hexdigest()};(out/(name+'.process.json')).write_text(json.dumps(rec,indent=2));assert cp.returncode==0,(name,cp.stderr[-1500:].decode())
 r=json.loads((run/'RESULT.json').read_bytes());assert r['status']=='EXPECTED_NUMERIC_REJECTION';rec['counterexample']={k:r[k] for k in ['cycle','expected','actual']};records.append(rec);assert hashlib.sha256(S.read_bytes()).hexdigest()==hashlib.sha256(b).hexdigest()
(out/'RESULT.json').write_text(json.dumps({'actual_compiled_mutants':len(records),'records':records,'candidate_source_unchanged':True},indent=2)+'\n');print(json.dumps({'mutants':len(records),'cycles':[r['counterexample']['cycle'] for r in records]}))
