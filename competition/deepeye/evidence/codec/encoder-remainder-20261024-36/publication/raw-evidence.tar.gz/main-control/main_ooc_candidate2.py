"""One new candidate OOC run; original19 synthesis results are never replayed."""
from pathlib import Path
import hashlib,importlib.util,json,sys,subprocess,os
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/codec/encoder-remainder-20261024-36';D=Path(__file__).parent
H='9cd6f8347139b19db318ef2e0a349784e452f9703773afebae689875bc180018'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
gate=read(E/'main/SOFTWARE_REVIEW.json');assert gate['status']=='ACCEPTED_BOUNDED_SOFTWARE' and gate['candidate_sha256']==H
src=P/'fpga/codec/deepeye_block_encoder_remainder_candidate.sv';assert sha(src)==H
rp=P/'tools/build/run_ooc_qualification.py';assert sha(rp)=='04a47aee3ce44c7576c8d879baf27a8701b5cde3e17a3ef0000954c8b0c3ea11'
assert sha(P/'fpga/build_qualification/ooc_qualification.tcl')=='54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9'
spec=importlib.util.spec_from_file_location('published_ooc33_runner',rp);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
thread=os.environ.get('CODEX_THREAD_ID');assert thread=='01a13b55-095b-7461-8dd5-5476a130bd82'
ps=subprocess.run(['powershell','-NoProfile','-Command','@(Get-Process -Name vivado -ErrorAction SilentlyContinue).Count'],capture_output=True);assert ps.returncode==0 and ps.stdout.strip()==b'0'
args=m.parse_arguments(['--output',str(E/'main/ooc-candidate-01'),'--author-thread',thread,'--author-turn','not_exposed_by_exec','--parent-thread',thread,'--parent-turn','not_exposed_by_exec','--timeout-seconds','900'])
out=Path(args.output).resolve();assert out.parent==(E/'main').resolve() and out.name=='ooc-candidate-01';out.mkdir(exist_ok=False);state=m.initial_result(args,W,out)
state.update(operation_id='B-DEEPEYE-ENCODER-REMAINDER-20261024-36',work_id='B-ENCODER-REMAINDER-MAIN-OOC-20261024-36-v1')
state['totals']['planned']=1
state['selection']={'candidate_only':True,'production_source_unchanged':True,'baseline':'operation33 original encoder -4.379ns, reused actual run, not rerun','software_gate_sha256':sha(E/'main/SOFTWARE_REVIEW.json'),'inventory_adaptation':'Original19 frozen sources plus exact local candidate; imported classifier PINS explicitly extended to20 in memory. Tcl and launch/classification function bytes unchanged. Only candidate top synthesized.','full_timing_closure':'not_run'}
try:
 m.verify_contract(state,W);state['source']=m.prepare_source_snapshot(state,W,out)
 b=src.read_bytes();gitpath='competition/deepeye/fpga/codec/deepeye_block_encoder_remainder_candidate.sv';relative=Path(gitpath).relative_to('competition/deepeye');target=out/'source_snapshot'/relative;target.write_bytes(b)
 blob=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest();pin=m.SourcePin(gitpath,'deepeye_block_encoder_remainder_candidate','clock:clk',blob,len(b))
 m.PINS=(*m.PINS,pin)
 original_listing=Path(state['source']['source_list_path']).read_bytes();listing=out/'source_snapshot'/'CANDIDATE_SOURCES.txt';listing.write_bytes(original_listing+b'\n'+str(target.resolve()).encode('utf-8')+b'\n')
 state['candidate']={'path':str(src),'sha256':H,'git_blob_calculated_not_committed':blob,'snapshot':str(target),'input_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip(),'source_list_sha256':sha(listing),'source_count':20}
 state['tool']=m.prepare_tool(args.tool_root);state['harness']=m.prepare_harness(W,out)
 put(out/'PREFLIGHT.json',{k:state[k] for k in ['selection','source','candidate','tool','harness','contract_verification']})
 (out/'main_ooc_candidate.py').write_bytes(Path(__file__).read_bytes())
 process,stdout,stderr=m.launch_vivado(pin,1,out,listing,state['harness'],state['tool'],900)
 run=m.classify_run(pin,1,out,process,stdout,stderr);state['runs']=[run];state['totals'].update(attempted=1,artifacts_complete=int(run['status']=='artifact_complete'),failed=int(run['status']!='artifact_complete'));state['overall_status']=run['status']
except Exception as ex:state.update(overall_status='failed',fatal_error=repr(ex));raise
finally:
 state['completed_at_utc']=m.utc_now();state['candidate_source_unchanged']=sha(src)==H;m.write_json(out/'RESULT.json',state)
print(json.dumps({'overall_status':state['overall_status'],'totals':state['totals'],'candidate_unchanged':state['candidate_source_unchanged']}))
raise SystemExit(0 if state['overall_status']=='artifact_complete' else 1)
