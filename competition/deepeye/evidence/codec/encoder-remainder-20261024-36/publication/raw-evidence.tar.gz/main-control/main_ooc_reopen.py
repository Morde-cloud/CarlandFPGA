from pathlib import Path
import ast,datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/codec/encoder-remainder-20261024-36';A=E/'main/ooc-candidate-01';O=E/'main/ooc-reopen-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def get(p):return json.loads(p.read_bytes())
helper=R/'.local/deployment/node-b/evidence/b06-ooc-20261024-33/main_audit_and_reopen.py';tree=ast.parse(helper.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('table','timing')];assert len(nodes)==2;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'))
(O/'source_table_timing_helper.py').write_bytes(helper.read_bytes())
s=get(A/'RESULT.json');r=s['runs'][0];run=A/'runs'/r['run_id'];assert r['status']=='artifact_complete' and r['exit_code']==0 and s['candidate_source_unchanged']
verified={}
def visit(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and re.fullmatch('[0-9a-f]{64}',str(x.get('sha256',''))):
   p=Path(x['path']);assert p.is_file() and sha(p)==x['sha256'];verified[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(s)
proc=get(run/'PROCESS.json');assert not proc['timed_out'] and proc['exit_code']==0 and proc['pid']==r['pid']
diag=get(run/'DIAGNOSTICS.json');assert not diag['critical_warnings'] and not diag['error_lines'] and not diag['marker_validation_failures'];assert len(diag['warnings'])==10
drc=re.findall(r'^\s*([A-Z][A-Z0-9]+-\d+)#\d+\s+(Warning|Error|Critical Warning)\s*$',(run/'reports/drc.rpt').read_text(),re.M);assert len(drc)==1
values={'resources':table(run/'reports/utilization.rpt'),'timing':timing(run/'reports/timing_summary.rpt'),'drc':drc,'warnings':len(diag['warnings']),'checks':dict(re.findall(r'^\d+\. checking ([a-z_]+) \((\d+)\)',(run/'reports/check_timing.rpt').read_text(),re.M))}
baseline=get(P/'evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/REPORT_READBACK.json');base=next(x for x in baseline['rows'] if x['top']=='deepeye_block_encoder')
dcp=run/'ooc.dcp';dh=sha(dcp);q=lambda p:'{'+p.as_posix()+'}'
lines=['set_param general.maxThreads 2','puts "MAIN36_DCP_BEGIN"','open_checkpoint '+q(dcp),'puts "MAIN36_DESIGN|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"','foreach c [get_clocks] {puts "MAIN36_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}','report_utilization -file '+q(O/'utilization.rpt'),'report_timing_summary -file '+q(O/'timing_summary.rpt'),'close_design','puts "MAIN36_DCP_END"','exit 0'];script=O/'reopen.tcl';script.write_text('\n'.join(lines)+'\n')
env=os.environ.copy()
for d in ('tmp','cache','work'):(O/d).mkdir()
for k in ('TEMP','TMP','TMPDIR'):env[k]=str(O/'tmp')
env['XILINX_LOCAL_USER_DATA']=str(O/'cache')
tool=Path('D:/pynq/AMD2026/2026.1/Vivado/bin/vivado.bat');assert sha(tool)=='a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b'
argv=[r'C:\Windows\System32\cmd.exe','/d','/c',str(tool),'-mode','batch','-nojournal','-nolog','-notrace','-source',str(script)]
put(O/'INTENT.json',{'argv':argv,'cwd':str(O/'work'),'script_sha256':sha(script),'dcp_sha256':dh,'scope':'one checkpoint read/report, no synthesis or implementation replay','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
t=time.monotonic();p=subprocess.Popen(argv,cwd=O/'work',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(O/'STARTED.json',{'pid':p.pid})
timed=False
try:stdout,stderr=p.communicate(timeout=240)
except subprocess.TimeoutExpired:
 timed=True;p.kill();stdout,stderr=p.communicate()
(O/'stdout.bin').write_bytes(stdout);(O/'stderr.bin').write_bytes(stderr);put(O/'PROCESS.json',{'pid':p.pid,'exit_code':p.returncode,'timed_out':timed,'elapsed':time.monotonic()-t,'stdout_sha256':sha(O/'stdout.bin'),'stderr_sha256':sha(O/'stderr.bin')});assert p.returncode==0 and not timed
txt=stdout.decode();assert not re.search(r'^\s*(ERROR:|CRITICAL WARNING:)',txt,re.M)
markers=[x for x in txt.splitlines() if 'MAIN36_' in x];assert markers==['MAIN36_DCP_BEGIN','MAIN36_DESIGN|part=xc7z020clg400-1|ports='+str(r['markers']['design_port_count'])+'|clocks=1','MAIN36_CLOCK|name=clk|period=10.000','MAIN36_DCP_END'],markers
assert table(O/'utilization.rpt')==values['resources'] and timing(O/'timing_summary.rpt')==values['timing'];assert sha(dcp)==dh
put(O/'RESULT.json',{'status':'ACCEPTED_BOUNDED_OOC_DIAGNOSTIC_COMPARISON','baseline_original_run_reused':base,'candidate':values,'same_resources_timing_after_actual_reopen':True,'actual_reopened_checkpoints':1,'verified_record_files':verified,'driver_aggregate_erratum':'Original OOC driver retained warning_bearing=0 default instead of deriving it; actual per-run diagnostics record10warnings/1DRC/0critical. Correct warning_bearing=1, clean_drc=0. Original receipt not rewritten.','first_preflight_failure':'Original main_ooc_candidate.py rejected oldoperation33 outputguard before any vendorlaunch; main_ooc_candidate2.py uses explicit freshowned36folder. Actualsynthesiscount1.','no_product_acceptance':'This is post-synthesis diagnostic10ns only; I/Odelays missing; no place/route/full build/B06/CDC_RDC/board/system. All29not_run; Aonlyboard.'})
print(json.dumps({'baseline':base['timing']['WNS'],'candidate':values['timing']['WNS'],'resources':values['resources'],'baseline_resources':base['utilization'],'warnings':values['warnings'],'drc':drc,'reopen_exit':p.returncode,'verified_files':len(verified)}))
