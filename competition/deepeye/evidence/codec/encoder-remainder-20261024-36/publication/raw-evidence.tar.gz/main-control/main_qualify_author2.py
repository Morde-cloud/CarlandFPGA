from pathlib import Path
import hashlib,json,re,textwrap
P=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye')
A=P/'evidence/codec/encoder-remainder-20261024-36/author/attempt-01'
O=P/'evidence/codec/encoder-remainder-20261024-36/main/author-parser-qualification-02'
O.mkdir(parents=True,exist_ok=False)
src=(P/'tools/codec/run_encoder_remainder_candidate.py').read_text(encoding='utf-8')
(O/'original_runner.py').write_text(src,encoding='utf-8')
start=src.index("        if re.search(r'TB_FAIL|")
end=src.index("        result['simulation'] = summary",start)
snippet=textwrap.dedent(src[start:end])
(O/'extracted_original_checker.py').write_text(snippet,encoding='utf-8')
cases=json.loads((A/'fixtures.json').read_text(encoding='utf-8'))
raw=(A/'logs/vsim.stdout.txt').read_text(encoding='utf-8')
def check(text):
    ns={'re':re,'transcript':text,'cases':cases,'out':A}
    exec(compile(snippet,'extracted_original_checker.py','exec'),ns)
    return ns['summary']
assert check(raw)['cycles']==505115
probes={
 'prefixed_done':raw.replace('# TB_DONE encoder_remainder_candidate PASS','# NOT_TB_DONE encoder_remainder_candidate PASS'),
 'suffixed_done':raw.replace('# TB_DONE encoder_remainder_candidate PASS','# TB_DONE encoder_remainder_candidate PASS trailing'),
 'wrong_case_metadata':re.sub(r'(# TB_CASE id=0 n=)\d+',r'\g<1>999',raw),
 'wrong_invalid_ids':raw.replace('TB_INVALID id=200000','TB_INVALID id=999999'),
 'wrong_abort_stage':raw.replace('TB_ABORT id=300000 which=0 stage=0','TB_ABORT id=300000 which=1 stage=99'),
 'duplicate_summary_key':raw.replace('TB_SUMMARY valid=297','TB_SUMMARY valid=999 valid=297'),
}
for k in ('cfg','samples','meta','data','cfgstall','samplestall','metastall','datastall'):
    probes['wrong_'+k]=re.sub(r'(?<= )'+k+r'=\d+',k+'=999999',raw)
results=[]
for name,text in probes.items():
    if text==raw: raise AssertionError('ineffective mutation '+name)
    f=O/(name+'.stdout.txt');f.write_text(text,encoding='utf-8')
    try: check(text); accepted=True;error=None
    except Exception as e:accepted=False;error=repr(e)
    results.append({'name':name,'accepted':accepted,'error':error,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
r={'status':'REJECTED_AUTHOR_PARSER_QUALIFICATION','method':'Exact old checker statements extracted without modification; saved transcript mutations; original unchanged trace and fixtures. No vendor run.', 'positive':True,'false_accepts':sum(x['accepted'] for x in results),'probes':results,'original_runner_sha256':hashlib.sha256((P/'tools/codec/run_encoder_remainder_candidate.py').read_bytes()).hexdigest()}
(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'probes':len(results),'false_accepts':r['false_accepts']}))
