from pathlib import Path
import hashlib,json,importlib.util,sys,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/codec/encoder-remainder-20261024-36';E35=P/'evidence/stream/buffered-block-stream-20261024-35'
O=E/'main/raw-audit-01';O.mkdir(exist_ok=False,parents=True)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p): return json.loads(p.read_bytes())
verified=[]
def verify(p,h):
 assert sha(p)==h,str(p)
 verified.append({'path':str(p.relative_to(W)),'sha256':h,'bytes':p.stat().st_size})
for n,h in get(E/'author/attempt-01/artifact_hashes.json').items():verify(E/'author/attempt-01'/n,h)
author=get(E/'author/RESULT.json');assert author['exit_code']==0 and author['source_drift']==[]
for c in author['commands']:
 assert c['exit_code']==0,c['name']
 for s in ('stdout','stderr'):verify(E/'author'/c[s],c[s+'_sha256'])
for n,x in author['sources'].items():
 verify(E/'author/attempt-01/source'/Path(x['path']).name,x['sha256'])
 if n!='runner':verify(Path(x['path']),x['sha256'])
main_commands=[]
for f in sorted((E/'main').rglob('*.command.json')):
 if '/inputs/' in f.as_posix():continue
 c=get(f);assert c['exit_code']==0 and not c['timed_out'],str(f)
 stem=f.name.removesuffix('.command.json')
 for s in ('stdout','stderr'):verify(f.parent/(stem+'.'+s+'.bin'),c[s+'_sha256'])
 main_commands.append({'file':str(f.relative_to(E)),'pid':c['pid'],'exit_code':c['exit_code'],'diagnostic_failures':c['diagnostic_failures']})
for f in (E/'main').rglob('INPUTS.json'):
 pins=get(f)
 for n,x in pins.items():verify(f.parent/'inputs'/Path(n).name,x['sha256'])
for n in ('positive-01','compiled-mutants-01/negative_remainder_not_euclidean','compiled-mutants-01/sample_capture_zero'):
 d=E/'main'/n
 if not (d/'RESULT.json').exists():continue
 j=get(d/'RESULT.json');verify(d/'ports.txt',j['ports_sha256'])
assert get(E/'main/positive-01/RESULT.json')['status']=='PASS'
spec=importlib.util.spec_from_file_location('terminal_checker',P/'tools/codec/main_verify_encoder_remainder.py');mod=importlib.util.module_from_spec(spec);sys.modules[spec.name]=mod;spec.loader.exec_module(mod)
raw=(E/'main/positive-01/vsim.stdout.bin').read_text(encoding='utf-8');cycles=get(E/'main/positive-01/RESULT.json')['stats']['monitor_totals']['cycles'];mod.terminal(raw,cycles)
neg=[]
for token in ('MAIN_PORT_COMPLETE','MAIN_REMAINDER_COMPLETE'):
 row=next(x for x in raw.splitlines() if token in x)
 for name,text in [('prefix',raw.replace(row,row.replace(token,'NOT_'+token))),('suffix',raw.replace(row,row+' bad')),('duplicate',raw.replace(row,row+'\n'+row)),('missing',raw.replace(row,'')),('wrongcycles',raw.replace(row,row.replace(str(cycles),str(cycles+1))))]:
  try:mod.terminal(text,cycles)
  except AssertionError:neg.append({'token':token,'kind':name,'rejected':True})
  else:raise AssertionError((token,name))
v35=[]
for x in get(E35/'author/evidence-index.json'):
 p=P/x['path'];assert p.stat().st_size==x['bytes'];verify(p,x['sha256']);v35.append(x)
c35=get(E35/'author/attempt-03/commands.json')
for c in c35:
 assert c['exit_code']==0 and not c['timed_out']
 for s in ('stdout','stderr'):verify(E35/'author'/c[s]['path'],c[s]['sha256'])
verify(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json','6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8')
result={'status':'RAW_EVIDENCE_VERIFIED_PARSER_REPAIRS_PENDING','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author36_commands':len(author['commands']),'main36_commands':main_commands,'main36_terminal_negatives':neg,'author35_original_index_files':len(v35),'author35_qualified_commands':len(c35),'verified_records':verified,'scope':'Original actual logs, snapshots and exits. Candidate and wrapper software evidence only. Author runners awaiting bounded repairs; no formal acceptance or synthesis result.'}
(O/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:len(v) if isinstance(v,list) else v for k,v in result.items() if k!='scope'}))
