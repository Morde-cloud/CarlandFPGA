# Main remainder reconstruction design proof

For accepted E in {0,1,2,4,8}, let d=2E+1 and n=x-p+E.
The existing restoring divider yields abs(n)=a*d+r_abs, 0<=r_abs<d.
For n>=0, q=a and r_euclidean=r_abs. For n<0, q=-a when
r_abs=0, otherwise q=-a-1 and r_euclidean=d-r_abs. Hence
n=q*d+r_euclidean in both cases, and p+q*d=x+E-r_euclidean.
This identity holds for every feasible x,p in[0,65535], independently of the
previous predictor. n fits signed18, abs(n) fits unsigned17, d<=17,
r_euclidean<=16 and x+E-r_euclidean is within[-8,65543]. Signed25
arithmetic with explicit zero extensions exactly preserves original clamps.
The new captured sample must be updated at the same accepted nonfirst valid
ST_LOAD edge, then held through all17 divider cycles and ST_DIV_FIN. No live
s_data read, state/cycle/handshake change or changed q/z/Rice/RAW rule is allowed.
This is an algebra proof and bounded software check, not RTL timing acceptance.
Main historical op08 public-port stimulus/reference reuse is explicit; newly
executed candidate results must get fresh actual commands/source hashes/logs.
