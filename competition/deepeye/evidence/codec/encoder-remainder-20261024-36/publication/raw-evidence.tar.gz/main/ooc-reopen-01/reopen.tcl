set_param general.maxThreads 2
puts "MAIN36_DCP_BEGIN"
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-20261024-36/main/ooc-candidate-01/runs/01_deepeye_block_encoder_remainder_candidate/ooc.dcp}
puts "MAIN36_DESIGN|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN36_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-20261024-36/main/ooc-reopen-01/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-20261024-36/main/ooc-reopen-01/timing_summary.rpt}
close_design
puts "MAIN36_DCP_END"
exit 0
