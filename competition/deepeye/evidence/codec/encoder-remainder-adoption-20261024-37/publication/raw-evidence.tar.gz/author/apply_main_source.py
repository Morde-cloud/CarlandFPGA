"""Apply the exact main-designed byte file after publication/source checks."""
from pathlib import Path
from datetime import datetime, timezone
import difflib
import hashlib
import json
import os
import shutil
import subprocess

OUT = Path(__file__).resolve().parent
P = OUT.parents[3]
W = P.parents[1]
BASE = '51e2090ebaa601a928a522f11677c6689e7d5a1a'
EXPECTED = '4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532'
OLD = '870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5'
def digest(data): return hashlib.sha256(data).hexdigest()
def save(path,data): path.write_text(json.dumps(data,indent=2)+'\n',encoding='utf-8')
if (OUT/'ADOPTION.json').exists(): raise RuntimeError('refusing repeated adoption')
for name in ('fpga/codec/encoder_remainder_adoption.md','tools/codec/run_encoder_remainder_adoption.py'):
    if (P/name).exists(): raise RuntimeError('unexpected existing new owned file '+name)
receipt_path = Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/encoder-remainder-publish-20261024-36/remote-verify/receipt.json')
receipt = json.loads(receipt_path.read_bytes())
if receipt['status'] != 'PUBLISHED_COMPLETED_REVIEW' or receipt['head'] != BASE or receipt['source'] != '4afcddb9fb6637f74dca2e8e78a676517d80bf3a':
    raise RuntimeError('publication gate mismatch')
if len(receipt['verified_files']) != 15 or receipt['operations'][0]['raw_members'] != 418:
    raise RuntimeError('publication counts mismatch')
freeze = OUT.parent/'main/preinspection-01'
design = json.loads((freeze/'MAIN_DESIGN.json').read_bytes())
if design['base_head'] != BASE or design['expected_production_sha256'] != EXPECTED:
    raise RuntimeError('main design identity mismatch')
protected = {}
for rel,info in design['pins'].items():
    raw = (P/rel).read_bytes()
    if digest(raw) != info['sha256'] or len(raw) != info['bytes']:
        raise RuntimeError('frozen input drift '+rel)
    if rel != 'fpga/codec/deepeye_block_encoder.sv': protected[str(P/rel)] = digest(raw)
dirty = W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json'
protected[str(dirty)] = digest(dirty.read_bytes())
target = P/'fpga/codec/deepeye_block_encoder.sv'
old, new = target.read_bytes(), (freeze/'EXPECTED_PRODUCTION_ENCODER.sv').read_bytes()
if digest(old) != OLD or digest(new) != EXPECTED: raise RuntimeError('production byte pin mismatch')
(OUT/'before').mkdir()
(OUT/'bootstrap-logs').mkdir()
shutil.copyfile(target,OUT/'before/deepeye_block_encoder.sv')
shutil.copyfile(freeze/'EXPECTED_PRODUCTION_ENCODER.sv',OUT/'before/EXPECTED_PRODUCTION_ENCODER.sv')
diff = ''.join(difflib.unified_diff(old.decode('utf-8').splitlines(True),new.decode('utf-8').splitlines(True),
    fromfile='before/deepeye_block_encoder.sv',tofile='adopted/deepeye_block_encoder.sv'))
(OUT/'production.diff.txt').write_text(diff,encoding='utf-8',newline='')
commands = []
with (OUT/'bootstrap-logs/git-head.stdout.txt').open('wb') as stdout, (OUT/'bootstrap-logs/git-head.stderr.txt').open('wb') as stderr:
    cmd = ['git','rev-parse','HEAD']
    proc = subprocess.Popen(cmd,cwd=W,stdout=stdout,stderr=stderr,shell=False)
    rc = proc.wait(timeout=30)
commands.append({'argv':cmd,'cwd':str(W),'pid':proc.pid,'exit_code':rc,
                 'stdout':'bootstrap-logs/git-head.stdout.txt','stderr':'bootstrap-logs/git-head.stderr.txt'})
if rc != 0 or (OUT/'bootstrap-logs/git-head.stdout.txt').read_text().strip() != BASE:
    raise RuntimeError('base head mismatch')
record = {'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,
    'work_id':'B-ENCODER-REMAINDER-ADOPTION-20261024-37-v1',
    'thread_id':'01a16a34-b419-7942-9a7b-2b033142446b','turn_id':'01a16a5d-732e-7753-b8cb-2a95f0b75e43',
    'job_id':'child-d3e4efec61394705a4d0bf0f15248044','self_validation_execution_allowed':True,
    'pid':os.getpid(),'at_utc':datetime.now(timezone.utc).isoformat(),'base_head':BASE,
    'old_production_sha256':OLD,'expected_production_sha256':EXPECTED,
    'protected_dependencies':protected,'commands':commands,'state':'intent_saved_before_write',
    'publication_gate':{'status':receipt['status'],'head':receipt['head'],'source':receipt['source'],
                        'files':15,'archive_members':418,'receipt_path':str(receipt_path),
                        'receipt_sha256':digest(receipt_path.read_bytes())},
    'main_design_sha256':digest((freeze/'MAIN_DESIGN.json').read_bytes()),
    'diff_sha256':digest((OUT/'production.diff.txt').read_bytes()),
    'contract':{'id':'DEEPEYE-HUMAN-LOCK-20261014','revision':1,'ids':['H%02d'%i for i in range(1,16)],
                'pin':'f5989cd5defce561f9ba98e6b18fc2682945f0a2',
                'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'}}
save(OUT/'ADOPTION.json',record)
target.write_bytes(new)
if target.read_bytes() != new: raise RuntimeError('written source mismatch')
record['state'] = 'exact_main_bytes_applied'
record['actual_production_sha256'] = digest(target.read_bytes())
save(OUT/'ADOPTION.json',record)
print(json.dumps({'state':record['state'],'sha256':record['actual_production_sha256'],
                  'protected_dependencies':len(protected),'publication_gate':receipt['status']}))
