"""Index completed actual author evidence without rerunning any process test."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import os
import sys

out = Path(__file__).resolve().parent
p = out.parents[3]
def sha(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()
result = json.loads((out/'attempt-01/RESULT.json').read_bytes())
if result['status'] != 'author_adoption_bounded_pass' or result['exit_code'] != 0:
    raise RuntimeError('no successful author attempt')
if result['source_drift'] or result['protected_drift']: raise RuntimeError('recorded dependency drift')
verified = 0
for name,digest in json.loads((out/'attempt-01/artifact_hashes.json').read_bytes()).items():
    if sha(out/'attempt-01'/name) != digest: raise RuntimeError('artifact mismatch '+name)
    verified += 1
for name,info in result['sources'].items():
    if sha(Path(info['path'])) != info['sha256']: raise RuntimeError('post-run source drift '+name)
    info['snapshot'] = 'attempt-01/'+info['snapshot']
for command in result['commands']:
    command['stdout'] = 'attempt-01/'+command['stdout']
    command['stderr'] = 'attempt-01/'+command['stderr']
adoption = json.loads((out/'ADOPTION.json').read_bytes())
protected = adoption['protected_dependencies']
if any(sha(Path(name)) != value for name,value in protected.items()): raise RuntimeError('protected dependency changed')
production = p/'fpga/codec/deepeye_block_encoder.sv'
if sha(production) != '4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532':
    raise RuntimeError('final production hash mismatch')
result.update({
    'author_result_scope':'Implemented exact main-designed source and fresh bounded author software/ModelSim evidence only.',
    'attempt_result':'attempt-01/RESULT.json','attempt_result_sha256':sha(out/'attempt-01/RESULT.json'),
    'verified_attempt_artifacts':verified,'meaningful_repairs':0,'fresh_attempts':1,
    'new_production_sha256':sha(production),
    'protected_dependency_hashes_before':protected,
    'protected_dependency_count':len(protected),
    'publication_gate_before_source_edit':adoption['publication_gate'],
    'exact_diff':'production.diff.txt','exact_diff_sha256':sha(out/'production.diff.txt'),
    'original_snapshot':'before/deepeye_block_encoder.sv',
    'original_snapshot_sha256':sha(out/'before/deepeye_block_encoder.sv'),
    'expected_snapshot':'before/EXPECTED_PRODUCTION_ENCODER.sv',
    'expected_snapshot_sha256':sha(out/'before/EXPECTED_PRODUCTION_ENCODER.sv'),
    'self_validation_execution_allowed':True,
    'changed_paths':['competition/deepeye/fpga/codec/deepeye_block_encoder.sv',
                     'competition/deepeye/fpga/codec/encoder_remainder_adoption.md',
                     'competition/deepeye/tools/codec/run_encoder_remainder_adoption.py',
                     'competition/deepeye/evidence/codec/encoder-remainder-adoption-20261024-37/author/'],
    'raw_evidence_index':{
        'invocation_stdout':'attempt-01.stdout.txt','invocation_stderr':'attempt-01.stderr.txt',
        'raw_process_records':'attempt-01/RESULT.json','process_stdout_stderr':'attempt-01/logs/',
        'simulator_transcript':'attempt-01/transcript.txt','trace':'attempt-01/public_ports.txt',
        'terminal_mutations':'attempt-01/terminal-probes/',
        'bootstrap_receipt':'ADOPTION.json','bootstrap_stdout':'apply.stdout.txt','bootstrap_stderr':'apply.stderr.txt',
        'source_before_after_diff':'production.diff.txt'},
    'entry_commands':[
        {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
                 'competition/deepeye/evidence/codec/encoder-remainder-adoption-20261024-37/author/apply_main_source.py'],
         'exit_code':0,'stdout':'apply.stdout.txt','stderr':'apply.stderr.txt'},
        {'argv':result['argv'],'pid':result['pid'],'exit_code':0,'stdout':'attempt-01.stdout.txt','stderr':'attempt-01.stderr.txt'},
        {'argv':[sys.executable,'-B','-X','utf8',str(Path(__file__).resolve())],
         'pid':os.getpid(),'exit_code':0,'stdout':'finalize.stdout.txt','stderr':'finalize.stderr.txt'},
    ],
    'finished_utc':datetime.now(timezone.utc).isoformat(),
})
dest = out/'RESULT.json'
if dest.exists(): raise RuntimeError('refusing prior final result')
dest.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
hashes = {f.relative_to(out).as_posix():sha(f) for f in sorted(out.rglob('*'))
          if f.is_file() and f.name != 'artifact_hashes.json' and f.name not in ('finalize.stdout.txt','finalize.stderr.txt')}
(out/'artifact_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'status':result['status'],'result_path':str(dest),'result_sha256':sha(dest),
                  'new_production_sha256':sha(production),'verified_attempt_artifacts':verified,
                  'protected_dependency_count':len(protected),'meaningful_repairs':0,
                  'summary':result['strict_reconciliation']['summary']},indent=2))
