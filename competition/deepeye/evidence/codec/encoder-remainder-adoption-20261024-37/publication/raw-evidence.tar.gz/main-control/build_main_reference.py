from pathlib import Path
import hashlib,json,re
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/codec/encoder-remainder-adoption-20261024-37/main';F=E/'preinspection-01';O=E/'reference-design-01';O.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def replace_once(b,a,c):
 assert b.count(a)==1,(a,b.count(a));return b.replace(a,c)
core=(F/'deepeye_block_encoder.sv').read_bytes();stream=(F/'deepeye_block_stream.sv').read_bytes();tb=(F/'main_tb_buffered_block_stream.sv').read_bytes()
oldcore=replace_once(core,b'module deepeye_block_encoder (',b'module main37_frozen_encoder (')
oldstream=replace_once(stream,b'module deepeye_block_stream',b'module main37_frozen_block_stream');oldstream=re.sub(rb'\bdeepeye_block_encoder(?=\s+\w+\s*\()',b'main37_frozen_encoder',oldstream);assert oldstream!=stream and b'main37_frozen_encoder' in oldstream
newtb=replace_once(tb,b'deepeye_block_stream source(',b'main37_frozen_block_stream source(')
for n,b in [('main37_frozen_encoder.sv',oldcore),('main37_frozen_block_stream.sv',oldstream),('main_tb_encoder_adoption_stream.sv',newtb)]:
 (O/n).write_bytes(b)
(P/'tests/rtl/codec/main_tb_encoder_adoption_stream.sv').write_bytes(newtb)
transitive={}
for origin in [P/'evidence/stream/buffered-block-stream-20261024-35/main/preinspection-01/independent_model.py',P/'evidence/stream/buffered-block-stream-20261024-35/main/preinspection-01/main_verify_encoded_frame_queue.py',P/'evidence/stream/buffered-block-stream-20261024-35/main/miter-design-01/DESIGN.json']:
 b=origin.read_bytes();(O/origin.name).write_bytes(b);transitive[origin.name]={'source':str(origin),'sha256':sha(b)}
manifest={'purpose':'Fresh37 integratedadoptedcore-vs-frozenoldchain comparison. Frozen35stimulus, model and publicendpoint monitor reused unchanged except reference stream module name. No new independentmath oracle claimed.','old_core_original_sha256':sha(core),'old_stream_original_sha256':sha(stream),'old_tb_original_sha256':sha(tb),'frozen_reference_encoder_sha256':sha(oldcore),'frozen_reference_stream_sha256':sha(oldstream),'new_tb_sha256':sha(newtb),'transitive':transitive,'candidateadoption_semantics':'Main EXPECTED_PRODUCTION bytes; worker37 not yet complete, no adopted source execution in this preparation.'}
(O/'REFERENCE.json').write_text(json.dumps(manifest,indent=2)+'\n');print(json.dumps({'new_tb_sha256':sha(newtb),'frozen_reference_only':True}))
