from pathlib import Path
import datetime,hashlib,json,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/codec/encoder-remainder-adoption-20261024-37';D=Path(__file__).parent;O=E/'main/final-audit-01'
def get(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2,ensure_ascii=False)
O.mkdir(exist_ok=False)
freeze=get(E/'main/preinspection-01/MAIN_DESIGN.json');software=get(E/'main/SOFTWARE_REVIEW.json');author=get(E/'main/author-audit-01/RESULT.json');ooc=get(E/'main/integrated-reopen-01/RESULT.json');terminal=get(D/'native-terminal.json')[0]
assert terminal['terminal'] and terminal['status']=='completed' and not terminal['stale']
tr=json.loads(terminal['result']['text']);assert sha(Path(tr['result_path']))==tr['result_sha256']
for name,expected in tr['source_hashes'].items():
 if name=='production':assert sha(P/'fpga/codec/deepeye_block_encoder.sv')==expected
assert sha(P/'fpga/codec/deepeye_block_encoder.sv')==freeze['expected_production_sha256']
for n,v in freeze['pins'].items():
 if n!='fpga/codec/deepeye_block_encoder.sv':assert sha(P/n)==v['sha256']
assert sha(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
verified={}
for source,base in [(author['verified_records'],E),(ooc['verified_files'],E)]:
 for n,v in source.items():
  p=Path(n)
  if not p.is_absolute():p=base/n
  assert p.is_file(),p
  expected=v['sha256'] if isinstance(v,dict) else v
  assert sha(p)==expected,p
  verified[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
assert software['status']=='ACCEPTED_INTEGRATED_SOFTWARE_ONLY' and author['source_equals_main_expected'] and len(author['terminal_negative_probes'])==3
assert software['positive']['external']['miter_port_comparisons']==4054242 and software['compiled_mutant']['cycle']==1099
assert len(software['actual_main_commands'])==8 and author['actual_commands']==12
for c in software['actual_main_commands']:
 p=E/'main'/c['path'];assert sha(p)==c['sha256'];a=get(p);assert c['exit_code']==0
 verified[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
first=get(E/'main/integrated-ooc-01/RESULT.json');recovery=get(R/'.local/b37r1/RESULT.json')
assert len(first['runs'])==2 and [x['exit_code'] for x in first['runs']]==[0,1]
assert len(recovery['runs'])==1 and recovery['runs'][0]['exit_code']==0
assert '[Common 17-680]' in recovery['recovery_decision']['original_error']
assert sha(E/'main/integrated-ooc-01/RESULT.json')==recovery['recovery_decision']['prior_result_sha256']
assert 'TypeError' in (D/'main-ooc.stderr.txt').read_text(encoding='utf-8-sig')
for stem,code in [('main-ooc',1),('path-recovery',0),('reopen',0),('author-audit',0),('main-positive',0),('main-mutant',0)]:
 assert int((D/(stem+'.exit.txt')).read_text(encoding='utf-8-sig').strip())==code
assert ooc['actual_reopened_dcps']==2 and [x['timing']['WNS'] for x in ooc['rows']]==['0.491','0.389']
assert get(E/'main/integrated-reopen-01/PROCESS.json')['exit_code']==0
contract=json.loads(subprocess.check_output(['git','-C',str(W),'show','f5989cd5defce561f9ba98e6b18fc2682945f0a2:docs/competition/deepeye-2026/immutable_scope.json']))
h=hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804' and len(contract['requirements'])==15
result={'status':'ACCEPTED_BOUNDED_PRODUCTION_ADOPTION_AND_OOC_DIAGNOSTICS','accepted_adoption':True,'operation_id':'B-DEEPEYE-ENCODER-REMAINDER-ADOPTION-20261024-37','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requirements_sha256':h,'production_sha256':freeze['expected_production_sha256'],'original_sha256':freeze['pins']['fpga/codec/deepeye_block_encoder.sv']['sha256'],'worker_terminal':{k:terminal[k] for k in ('job_id','native_agent_id','status','terminal','stale','updated_at')},'main_edges':130783,'main_public_comparisons':4054242,'main_commands':8,'main_compiled_mutants':1,'main_mutant_rejection_cycle':1099,'author_commands':12,'author_valid_cases':297,'author_trace_rows':505112,'author_terminal_negative_probes':3,'verified_records':verified,'ooc':ooc,'actual_synthesis_attempts':3,'complete_final_top_artifacts':2,'actual_dcp_reopens':2,'failed_attempts_retained':['Original wrapper synthesis completed; DCP export exceeded Windows260-byte path; exit1; no checkpoint.','Original main driver aggregation then raised int(None) TypeError.','Fresh explicit wrapper-only short-path recovery succeeded without RTL/tool/Tcl changes; successful stream not rerun.'],'acceptance_notes':['Main37 compares actual adopted core through unchanged stream/wrapper with independently namespaced frozen old core/stream. Stimulus/math/reference and common queue reused explicitly.','Author comparator shares adopted candidate arithmetic; it is not independent old-chain proof. Strict saved-run checker and all297fixture cases are reused.','Main software receipt predated observed author completion; this terminal audit now confirms actual completion and preserved raw evidence.','Two independent DCP reopens reproduce resources and timing; same post-synthesis10nsdiagnostic only. ZPS7-1/warnings/I/O timing gaps retained. No place/route or calibrated physical claim.','Internal block payload may reach256B; no production TRACE<=32B or public ABI claim.','All29/B01/B03/B06/R03/fullproduct/implementation/timingclosure/CDC_RDC/board/system not_run. A-only physical board.']}
put(O/'RESULT.json',result);print(json.dumps({'status':result['status'],'verified':len(verified),'source':result['production_sha256'],'ooc_attempts':3,'dcps':2}))
