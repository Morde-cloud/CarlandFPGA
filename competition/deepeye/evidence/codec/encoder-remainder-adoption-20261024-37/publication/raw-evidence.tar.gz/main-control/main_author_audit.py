from pathlib import Path
import hashlib,importlib.util,json,sys,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/codec/encoder-remainder-adoption-20261024-37';A=E/'author';D=Path(__file__).parent;O=E/'main/author-audit-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
t=get(D/'native-terminal.json')[0];assert t['terminal'] and not t['stale'] and t['status']=='completed'
r=get(A/'RESULT.json');assert r['exit_code']==0 and r['status']=='author_adoption_bounded_pass' and not r['source_drift'] and not r['protected_drift']
verified=[]
def verify(p,h):
 assert sha(p)==h,str(p);verified.append({'path':str(p.relative_to(W)),'sha256':h,'bytes':p.stat().st_size})
for n,h in get(A/'attempt-01/artifact_hashes.json').items():verify(A/'attempt-01'/n,h)
adoption=get(A/'ADOPTION.json');assert adoption['state']=='exact_main_bytes_applied'
for n,h in adoption['protected_dependencies'].items():verify(Path(n),h)
for name,x in r['sources'].items():verify(Path(x['path']),x['sha256']);verify(A/'attempt-01/inputs'/Path(x['path']).name,x['sha256'])
for c in r['commands']:
 assert c['exit_code']==0 and not c.get('timed_out',False) and c['pid']>0
 for k in ('stdout','stderr'):
  p=A/c[k]
  if not p.exists():p=A/'attempt-01'/c[k]
  verify(p,c[k+'_sha256'])
helper=P/'tools/codec/run_encoder_remainder_candidate.py';assert sha(helper)=='559a315f4c0d7a5f51912a66d207629e5defe282930d05390bce913dffb7db43';spec=importlib.util.spec_from_file_location('main37_author_checker',helper);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
raw=(A/'attempt-01/logs/vsim.stdout.txt').read_text();cases=get(A/'attempt-01/fixtures.json')
with (A/'attempt-01/public_ports.txt').open() as f:positive=m.check_saved_run(raw,f,cases)
checks=[]
for f in (A/'attempt-01/terminal-probes').glob('*.stdout.txt'):
 try:
  with (A/'attempt-01/public_ports.txt').open() as lines:m.check_saved_run(f.read_text(),lines,cases)
 except m.EvidenceError as ex:checks.append({'name':f.name,'rejected':True,'reason':str(ex)})
 else:raise AssertionError('terminal red accepted')
assert len(checks)==3
current=A/'attempt-01/public_ports.txt';prior=P/'evidence/codec/encoder-remainder-20261024-36/author/attempt-01/public_ports.txt';assert current.read_bytes()==prior.read_bytes()
assert sha(P/'fpga/codec/deepeye_block_encoder.sv')=='4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532'
record={'status':'AUTHOR_BOUNDED_ADOPTION_EVIDENCE_VERIFIED','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'terminal_job':t['job_id'],'actual_commands':len(r['commands']),'positive':positive,'terminal_negative_probes':checks,'source_equals_main_expected':True,'trace_identical_to_prior36':True,'verified_records':verified,'scope':'Reusedauthor golden/candidate/TB/checker, not independentoldchainproof. Main37 independentoldchain comparison is separatelyexecuted. No adoptionOOC orformalapproval inferred here.'}
(O/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'status':record['status'],'commands':len(r['commands']),'verified_records':len(verified),'trace_identical_prior36':True}))
