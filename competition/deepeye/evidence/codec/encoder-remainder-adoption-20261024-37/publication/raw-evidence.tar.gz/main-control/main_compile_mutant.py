from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/codec/encoder-remainder-adoption-20261024-37/main';O=E/'compiled-mutant-01';O.mkdir(exist_ok=False)
core=P/'fpga/codec/deepeye_block_encoder.sv';original=core.read_bytes();h=hashlib.sha256(original).hexdigest();assert h=='4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532';needle=b'cur_sample <= s_data;';assert original.count(needle)==1
mut=original.replace(needle,b"cur_sample <= 16'd0;");src=O/'mutated_core.sv';src.write_bytes(mut);out=O/'run'
argv=[sys.executable,'-B','-X','utf8',str(P/'tools/codec/main_verify_encoder_adoption_stream.py'),'--out',str(out),'--mutant',str(src)];(O/'INTENT.json').write_text(json.dumps({'argv':argv,'original_sha256':h,'mutant_sha256':hashlib.sha256(mut).hexdigest(),'mutation':'newaccepted sample capture forcedzero; frozenOLDreference unchanged'},indent=2))
with (O/'stdout.txt').open('wb') as so,(O/'stderr.txt').open('wb') as se:r=subprocess.run(argv,stdout=so,stderr=se,timeout=300)
assert hashlib.sha256(core.read_bytes()).hexdigest()==h;result=json.loads((out/'RESULT.json').read_bytes());assert r.returncode==0 and result['status']=='EXPECTED_NUMERIC_REJECTION'
(O/'RESULT.json').write_text(json.dumps({'status':'ACTUAL_COMPILED_NUMERIC_REJECTION','exit_code':r.returncode,'cycle':result['cycle'],'expected':result['expected'],'actual':result['actual'],'production_unchanged':True},indent=2));print(json.dumps({'cycle':result['cycle'],'exit':r.returncode}))
