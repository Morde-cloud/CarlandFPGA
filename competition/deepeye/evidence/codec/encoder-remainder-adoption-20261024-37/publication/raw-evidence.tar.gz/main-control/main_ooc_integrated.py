"""Two fresh integrated OOC diagnostics, gated by actual37 software review."""
from pathlib import Path
import hashlib,importlib.util,json,os,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/codec/encoder-remainder-adoption-20261024-37';D=Path(__file__).parent;BASE='51e2090ebaa601a928a522f11677c6689e7d5a1a';CORE='4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def get(p):return json.loads(p.read_bytes())
gate=get(E/'main/SOFTWARE_REVIEW.json');assert gate['status']=='ACCEPTED_INTEGRATED_SOFTWARE_ONLY' and gate['production_encoder_sha256']==CORE
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W).decode().strip()==BASE
rp=P/'tools/build/run_ooc_qualification.py';assert sha(rp)=='04a47aee3ce44c7576c8d879baf27a8701b5cde3e17a3ef0000954c8b0c3ea11'
assert sha(P/'fpga/build_qualification/ooc_qualification.tcl')=='54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9'
spec=importlib.util.spec_from_file_location('op37_ooc33_harness',rp);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
ps=subprocess.run(['powershell','-NoProfile','-Command','@(Get-Process -Name vivado -ErrorAction SilentlyContinue).Count'],capture_output=True);assert ps.returncode==0 and ps.stdout.strip()==b'0'
thread=os.environ.get('CODEX_THREAD_ID');assert thread=='01a13b55-095b-7461-8dd5-5476a130bd82'
out=(E/'main/integrated-ooc-01').resolve();assert out.parent==(E/'main').resolve();out.mkdir(exist_ok=False)
args=m.parse_arguments(['--output',str(out),'--author-thread',thread,'--author-turn','not_exposed_by_exec','--parent-thread',thread,'--parent-turn','not_exposed_by_exec','--timeout-seconds','900']);s=m.initial_result(args,W,out);s.update(operation_id='B-DEEPEYE-ENCODER-ADOPTION-20261024-37',work_id='B-ENCODER-ADOPTION-MAIN-OOC-20261024-37-v1');s['totals']['planned']=2
s['selection']={'harness_reuse':'Published operation33 launch/Tcl/classifier; PINS explicit20source inventory configured in memory; actualpayload snapshots declared below. Only blockstream andbufferedwrapper top syntheses.','baseline':'old blockstream op33 WNS-4.349ns reused, no old synthesis rerun; bufferedwrapper has no prior OOCbaseline.','software_review_sha256':sha(E/'main/SOFTWARE_REVIEW.json'),'production_source_commit':'uncommitted exact37adoption atop'+BASE,'no_timingclosure':True}
try:
 m.verify_contract(s,W);pins=[];records=[];snapshot=out/'source_snapshot';snapshot.mkdir()
 original=list(m.PINS);wrapperpath='competition/deepeye/fpga/stream/deepeye_buffered_block_stream.sv'
 wb=subprocess.check_output(['git','show',BASE+':'+wrapperpath],cwd=W);wblob=hashlib.sha1(b'blob '+str(len(wb)).encode()+b'\0'+wb).hexdigest();original.append(m.SourcePin(wrapperpath,'deepeye_buffered_block_stream','clock:clk',wblob,len(wb)))
 for pin in original:
  committed=subprocess.check_output(['git','show',BASE+':'+pin.git_path],cwd=W);actual=(W/pin.git_path).read_bytes()
  if pin.module=='deepeye_block_encoder':assert hashlib.sha256(actual).hexdigest()==CORE;provenance='main-approved uncommitted37adoption'
  else:assert actual==committed and hashlib.sha1(b'blob '+str(len(actual)).encode()+b'\0'+actual).hexdigest()==pin.blob;provenance='exactpublished '+BASE
  blob=hashlib.sha1(b'blob '+str(len(actual)).encode()+b'\0'+actual).hexdigest();new=m.SourcePin(pin.git_path,pin.module,pin.clock_mode,blob,len(actual));pins.append(new);dest=snapshot/Path(pin.git_path).relative_to('competition/deepeye');dest.parent.mkdir(exist_ok=True,parents=True);dest.write_bytes(actual);records.append({'path':str(dest),'sha256':sha(dest),'bytes':len(actual),'git_path':pin.git_path,'git_blob_calculated':blob,'provenance':provenance})
 m.PINS=tuple(pins);listing=snapshot/'SOURCES.txt';listing.write_text('\n'.join(x['path'] for x in records)+'\n',encoding='utf-8');s['source']={'base':BASE,'count':20,'records':records,'list_sha256':sha(listing)};put(out/'SOURCE_MANIFEST.json',s['source'])
 s['tool']=m.prepare_tool(args.tool_root);s['harness']=m.prepare_harness(W,out);put(out/'PREFLIGHT.json',{k:s[k] for k in ('source','selection','tool','harness','contract_verification')});(out/'main_ooc_integrated.py').write_bytes(Path(__file__).read_bytes())
 s['runs']=[]
 for i,name in enumerate(('deepeye_block_stream','deepeye_buffered_block_stream'),1):
  pin=next(x for x in pins if x.module==name);process,stdout,stderr=m.launch_vivado(pin,i,out,listing,s['harness'],s['tool'],900);run=m.classify_run(pin,i,out,process,stdout,stderr);s['runs'].append(run);s['totals']['attempted']+=1
  s['totals']['artifacts_complete']+=int(run['status']=='artifact_complete');s['totals']['failed']+=int(run['status']!='artifact_complete');s['totals']['clean_drc']+=int(run['engineering_findings']['clean_drc']);s['totals']['warning_bearing']+=int(run['diagnostics']['warning_count']>0 or run['diagnostics']['critical_warning_count']>0);m.write_json(out/'RESULT.json',s)
  if run['status']!='artifact_complete':break
 s['overall_status']='artifacts_complete' if s['totals']['artifacts_complete']==2 else 'failed'
except Exception as ex:s.update(overall_status='failed',fatal_error=repr(ex));raise
finally:s['completed_at_utc']=m.utc_now();m.write_json(out/'RESULT.json',s)
print(json.dumps({'status':s['overall_status'],'totals':s['totals']}));raise SystemExit(0 if s['overall_status']=='artifacts_complete' else 1)
