from pathlib import Path
import ast,datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/codec/encoder-remainder-adoption-20261024-37';A=E/'main/integrated-ooc-01';O=E/'main/integrated-reopen-01'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
s=get(A/'RESULT.json');assert s['overall_status']=='artifacts_complete' and len(s['runs'])==2;O.mkdir(exist_ok=False)
helper=R/'.local/deployment/node-b/evidence/b06-ooc-20261024-33/main_audit_and_reopen.py';tree=ast.parse(helper.read_text());nodes=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ('table','timing')];assert len(nodes)==2;exec(compile(ast.Module(body=nodes,type_ignores=[]),str(helper),'exec'));(O/'source_table_timing_helper.py').write_bytes(helper.read_bytes())
verified={}
def visit(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and re.fullmatch('[0-9a-f]{64}',str(x.get('sha256',''))):
   p=Path(x['path']);assert p.is_file() and sha(p)==x['sha256'];verified[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(s);rows=[]
for r in s['runs']:
 d=A/'runs'/r['run_id'];proc=get(d/'PROCESS.json');diag=get(d/'DIAGNOSTICS.json');assert r['status']=='artifact_complete' and r['exit_code']==proc['exit_code']==0 and not proc['timed_out'];assert not diag['critical_warnings'] and not diag['error_lines'] and not diag['marker_validation_failures']
 drc=re.findall(r'^\s*([A-Z][A-Z0-9]+-\d+)#\d+\s+(Warning|Error|Critical Warning)\s*$',(d/'reports/drc.rpt').read_text(),re.M);assert len(drc)==r['diagnostics']['drc_violation_count']
 rows.append({'top':r['top'],'run_dir':str(d),'dcp_sha256':sha(d/'ooc.dcp'),'ports':r['markers']['design_port_count'],'clocks':r['markers']['clocks'],'resources':table(d/'reports/utilization.rpt'),'timing':timing(d/'reports/timing_summary.rpt'),'drc':drc,'warnings':len(diag['warnings']),'check_timing':dict(re.findall(r'^\d+\. checking ([a-z_]+) \((\d+)\)',(d/'reports/check_timing.rpt').read_text(),re.M))})
q=lambda p:'{'+p.as_posix()+'}';lines=['set_param general.maxThreads 2','puts "MAIN37_REOPEN_BEGIN|count=2"']
for r in rows:
 d=O/r['top'];d.mkdir();lines+=['open_checkpoint '+q(Path(r['run_dir'])/'ooc.dcp'),'puts "MAIN37_DESIGN|top='+r['top']+'|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"','foreach c [get_clocks] {puts "MAIN37_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}','report_utilization -file '+q(d/'utilization.rpt'),'report_timing_summary -file '+q(d/'timing_summary.rpt'),'close_design']
lines+=['puts "MAIN37_REOPEN_END|count=2"','exit 0'];script=O/'reopen.tcl';script.write_text('\n'.join(lines)+'\n');env=os.environ.copy()
for n in ('tmp','cache','work'):(O/n).mkdir()
for k in ('TEMP','TMP','TMPDIR'):env[k]=str(O/'tmp')
env['XILINX_LOCAL_USER_DATA']=str(O/'cache');tool=Path('D:/pynq/AMD2026/2026.1/Vivado/bin/vivado.bat');assert sha(tool)=='a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b'
argv=[r'C:\Windows\System32\cmd.exe','/d','/c',str(tool),'-mode','batch','-nojournal','-nolog','-notrace','-source',str(script)];put(O/'INTENT.json',{'argv':argv,'cwd':str(O/'work'),'script_sha256':sha(script),'dcp_inputs':rows,'scope':'two checkpointread/report, no synthesis/implementation'});t=time.monotonic();p=subprocess.Popen(argv,cwd=O/'work',env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(O/'STARTED.json',{'pid':p.pid})
timed=False
try:stdout,stderr=p.communicate(timeout=240)
except subprocess.TimeoutExpired:
 timed=True;p.kill();stdout,stderr=p.communicate()
(O/'stdout.bin').write_bytes(stdout);(O/'stderr.bin').write_bytes(stderr);put(O/'PROCESS.json',{'pid':p.pid,'exit_code':p.returncode,'timed_out':timed,'elapsed':time.monotonic()-t,'stdout_sha256':sha(O/'stdout.bin'),'stderr_sha256':sha(O/'stderr.bin')});assert p.returncode==0 and not timed;txt=stdout.decode();assert not re.search(r'^\s*(ERROR:|CRITICAL WARNING:)',txt,re.M)
expected=['MAIN37_REOPEN_BEGIN|count=2']
for r in rows:expected+=['MAIN37_DESIGN|top='+r['top']+'|part=xc7z020clg400-1|ports='+str(r['ports'])+'|clocks=1','MAIN37_CLOCK|name=clk|period=10.000']
expected+=['MAIN37_REOPEN_END|count=2'];assert [x for x in txt.splitlines() if 'MAIN37_' in x]==expected
for r in rows:
 d=O/r['top'];assert table(d/'utilization.rpt')==r['resources'] and timing(d/'timing_summary.rpt')==r['timing'];assert sha(Path(r['run_dir'])/'ooc.dcp')==r['dcp_sha256']
baseline=get(P/'evidence/build/ooc-20261024-33/main/independent-artifact-audit-01/REPORT_READBACK.json');base=next(x for x in baseline['rows'] if x['top']=='deepeye_block_stream')
put(O/'RESULT.json',{'status':'BOUNDED_INTEGRATED_OOC_ARTIFACTS_REVIEWED','actual_reopened_dcps':2,'rows':rows,'baseline_blockstream_reused':base,'verified_files':verified,'scope':'Samepost-synthesis10nsdiagnostic only. No place/route/I/Oclosure/CDC_RDC/B06/board/system. All29not_run. Do notsum nestedtopresources.','operation_alias_note':'OOCdriver used B-DEEPEYE-ENCODER-ADOPTION-20261024-37 localdiagnostic identifier; canonicalhandoff is B-DEEPEYE-ENCODER-REMAINDER-ADOPTION-20261024-37. Same actual two runs, no duplicateexecution.'});print(json.dumps({'rows':[{k:r[k] for k in ('top','resources','timing','warnings','drc')} for r in rows],'reopened':2,'verified_files':len(verified)}))
