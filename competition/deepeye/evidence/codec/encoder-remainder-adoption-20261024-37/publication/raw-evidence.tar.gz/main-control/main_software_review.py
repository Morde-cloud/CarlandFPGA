from pathlib import Path
import hashlib,json,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/codec/encoder-remainder-adoption-20261024-37/main'
def get(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
H='4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532';assert sha(P/'fpga/codec/deepeye_block_encoder.sv')==H==get(E/'preinspection-01/MAIN_DESIGN.json')['expected_production_sha256']
positive=get(E/'positive-01/RESULT.json');negative=get(E/'compiled-mutant-01/RESULT.json');assert positive['status']=='PASS' and negative['status']=='ACTUAL_COMPILED_NUMERIC_REJECTION' and negative['cycle']==1099
receipts=[]
for folder in (E/'positive-01',E/'compiled-mutant-01/run'):
 for f in folder.glob('*.command.json'):
  x=get(f);assert x['exit_code']==0 and not x['timed_out'];name=f.name.removesuffix('.command.json')
  for k in ('stdout','stderr'):assert sha(folder/(name+'.'+k+'.bin'))==x[k+'_sha256']
  receipts.append({'path':str(f.relative_to(E)),'sha256':sha(f),'pid':x['pid'],'exit_code':0})
 for n,x in get(folder/'INPUTS.json').items():assert sha(folder/'inputs'/n)==x['sha256']
 for n in ('trace.txt','buffered_trace.txt'):assert sha(folder/n)==get(folder/'RESULT.json')[n]['sha256']
assert len(receipts)==8
old=P/'evidence/stream/buffered-block-stream-20261024-35/main/positive-01/RESULT.json';prior=get(old)
assert positive['trace.txt']==prior['trace.txt'] and positive['buffered_trace.txt']==prior['buffered_trace.txt']
record={'status':'ACCEPTED_INTEGRATED_SOFTWARE_ONLY','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-ENCODER-REMAINDER-ADOPTION-MAIN-20261024-37-v1','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','production_encoder_sha256':H,'old_encoder_sha256':'870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5','main_scope':'New production core through actualunchanged blockstream+wrapper35 compared with independentlynamespaced frozenOLDcore+OLDstream and unchanged commonqueue. Oldreference/model/stimulus reused. Source bytes exactlyequal main-approved arithmetic with onlymodulename/workcomment adoption from36.','actual_main_commands':receipts,'positive':positive,'compiled_mutant':negative,'trace_equal_to_prior35':True,'author_status':'Worker37 still separately finishing its own evidence; this main approval concerns fixedhash snapshot independentlytested above. No claim author terminal/acceptance yet. Final37handoff waits actualauthorcompletion/rawreview.','next':'One fresh OOC eachforblockstream andbufferedwrapper using exact20source snapshot; no baseline/vendor replay.','limits':'Boundedsoftware only. All29/B01/B03/B06/R03/implementation/timingclosure/CDC_RDC/board/system not_run; boardAonly.'}
with (E/'SOFTWARE_REVIEW.json').open('x',encoding='utf-8') as f:json.dump(record,f,indent=2)
print(json.dumps({'status':record['status'],'commands':len(receipts),'trace_equal_prior':True}))
