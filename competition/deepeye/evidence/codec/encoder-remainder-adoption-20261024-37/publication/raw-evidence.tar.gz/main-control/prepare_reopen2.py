from pathlib import Path
p=Path(__file__).parent
s=(p/'main_reopen_integrated.py').read_text()
s=s.replace("s=get(A/'RESULT.json');assert s['overall_status']=='artifacts_complete' and len(s['runs'])==2;O.mkdir(exist_ok=False)","s=get(A/'RESULT.json'); recovery=R/'.local/b37r1'; recovered=get(recovery/'RESULT.json'); assert len(s['runs'])==2 and s['runs'][0]['status']=='artifact_complete' and s['runs'][1]['exit_code']==1; assert recovered['overall_status']=='artifact_complete' and len(recovered['runs'])==1; selected=[(A,s['runs'][0]),(recovery,recovered['runs'][0])]; O.mkdir(exist_ok=False)")
s=s.replace('visit(s);rows=[]','visit(s);visit(recovered);rows=[]')
s=s.replace("for r in s['runs']:\n d=A/'runs'/r['run_id'];", "for parent,r in selected:\n d=parent/'runs'/r['run_id'];")
s=s.replace("Same actual two runs, no duplicateexecution.","Three actual synth attempts: original successful stream, original wrapper synthesis with DCP export failure, explicit new shortpath wrapper recovery. Two final checkpoints reopened. Original alias identifies first two attempts only.")
assert 'for parent,r in selected:' in s
with (p/'main_reopen_integrated2.py').open('x',encoding='utf-8') as f:f.write(s)
