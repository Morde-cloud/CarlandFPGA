set_param general.maxThreads 2
puts "MAIN37_REOPEN_BEGIN|count=2"
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-adoption-20261024-37/main/integrated-ooc-01/runs/01_deepeye_block_stream/ooc.dcp}
puts "MAIN37_DESIGN|top=deepeye_block_stream|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN37_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-adoption-20261024-37/main/integrated-reopen-01/deepeye_block_stream/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-adoption-20261024-37/main/integrated-reopen-01/deepeye_block_stream/timing_summary.rpt}
close_design
open_checkpoint {D:/pynq/CarlandFPGA/.local/b37r1/runs/01_deepeye_buffered_block_stream/ooc.dcp}
puts "MAIN37_DESIGN|top=deepeye_buffered_block_stream|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN37_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-adoption-20261024-37/main/integrated-reopen-01/deepeye_buffered_block_stream/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/encoder-remainder-adoption-20261024-37/main/integrated-reopen-01/deepeye_buffered_block_stream/timing_summary.rpt}
close_design
puts "MAIN37_REOPEN_END|count=2"
exit 0
