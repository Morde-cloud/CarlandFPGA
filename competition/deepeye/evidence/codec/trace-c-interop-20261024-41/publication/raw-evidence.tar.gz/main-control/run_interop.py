from pathlib import Path
from collections import Counter
import datetime,hashlib,importlib.util,json,os,platform,sys,time
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/trace-c-interop-20261024-41/main';Q=D.parent/'trace-c-interop-preconditions-20261024';B=P/'evidence/codec/trace-payload-20261024-38';F=B/'main/preinspection-01';E.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
started=datetime.datetime.now(datetime.timezone.utc).isoformat();put(E/'PROCESS_STARTED.json',{'pid':os.getpid(),'argv':sys.argv,'cwd':os.getcwd(),'python_executable':sys.executable,'python_version':sys.version,'platform':platform.platform(),'started_utc':started});pins={};result={'status':'RUNNING'}
try:
 croot=Q/'downloaded/competition/deepeye/evidence/ai/trace_candidate_decode';cp=croot/'candidate_decode.py';assert sha(cp)=='b02010280b72d3a94842db627f733df9c1fa6ecfe54f572509d57869d2d3d72c'
 for rel,v in get(Q/'FETCHED.json')['files'].items():assert sha(Q/'downloaded'/rel)==v['sha256']
 manifest=get(Q/'downloaded/handoffs/c/C-DEEPEYE-TRACE-CANDIDATE-DECODE-20261018-14/manifest.json');assert manifest['request']['code_commit']=='3c1e584942bab4207b694f27ed116efb84ceedd7';assert manifest['request_hash']==hashlib.sha256(json.dumps(manifest['request'],sort_keys=True,ensure_ascii=False,separators=(',',':')).encode()).hexdigest()
 prefix='competition/deepeye/evidence/ai/trace_candidate_decode/candidate_decode.py';assert manifest['files'][prefix]['sha256']==sha(cp)
 index=get(B/'publication/RAW_INDEX.json')['files'];raw=B/'main/positive-01/trace.txt';assert sha(raw)=='5a5f5d28e1a1718b7c7cd38b16300186d7f9279fb3c02729833fa1053a0bb874'==index['main/positive-01/trace.txt']['sha256']
 for p,n in [(F/'main_vectors.json','main/preinspection-01/main_vectors.json'),(F/'main_reference.py','main/preinspection-01/main_reference.py')]:assert sha(p)==index[n]['sha256']
 sources=[(cp,'candidate_decode.py'),(F/'main_vectors.json','b38_vectors.json'),(F/'main_reference.py','b38_reference.py'),(raw,'b38_actual_public_trace.txt'),(Path(__file__),'run_interop.py'),(D/'MAIN_SPEC.md','MAIN_SPEC.md'),(Q/'FETCHED.json','C_FETCHED.json'),(Q/'downloaded/handoffs/c/C-DEEPEYE-TRACE-CANDIDATE-DECODE-20261018-14/manifest.json','C_HANDOFF_MANIFEST.json')]
 inp=E/'inputs';inp.mkdir()
 for p,n in sources:(inp/n).write_bytes(p.read_bytes());pins[n]={'sha256':sha(p),'bytes':p.stat().st_size,'original':str(p)}
 put(E/'INPUTS.json',pins);spec=importlib.util.spec_from_file_location('fixed_c_decoder',(inp/'candidate_decode.py'));decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
 vectors=get(F/'main_vectors.json')['cases'];actual={x['id']:{'meta':[],'data':[]} for x in vectors};trace_rows=0
 with raw.open() as f:
  for line in f:
   z=line.split()
   if z[0]!='T':continue
   trace_rows+=1;cid=int(z[2])
   if cid<0:continue
   a=actual[cid]
   if z[11]=='1' and z[12]=='1':a['meta'].append(tuple(int(x,16) for x in z[13:16]))
   if z[16]=='1' and z[17]=='1':a['data'].append((int(z[19],16),int(z[18])))
 assert trace_rows==804872 and len(actual)==len(vectors)==746
 rows=[];errors=[];counts=Counter();points_count=0;allbytes=0
 for v in vectors:
  cid=v['id'];cfg=v['cfg'];q=v['expected'];a=actual[cid];assert a['meta']==[(q['error'],len(q['bytes']),q['tick'])];payload=bytes(x[0] for x in a['data']);assert payload==bytes(q['bytes']);assert [x[1] for x in a['data']]==[int(i==len(payload)-1) for i in range(len(payload))]
  if q['error']:
   assert not payload;counts['b_error_'+str(q['error'])]+=1;continue
  allbytes+=len(payload);binding={'session':cfg['session'],'e':cfg['e'],'config_epoch':0}
  try:
   decoded=decoder.decode_payload(payload,binding);n=cfg['count'];valid=bool(cfg['valid']);held=bool(cfg['held']);mode='raw' if q['raw'] else 'rice';values=[]
   if valid:
    if q['raw']:values=list(v['samples'])
    else:
     values=[v['samples'][0]]
     for original in v['samples'][1:]:
      previous=values[-1];numerator=original-previous+cfg['e'];denominator=2*cfg['e']+1;quant=numerator//denominator;values.append(max(0,min(65535,previous+quant*denominator)))
    assert all(abs(x-y)<=(0 if q['raw'] else cfg['e']) for x,y in zip(v['samples'],values))
   points=[]
   for j in range(n):
    tick=cfg['tick']+j*cfg['tick_stride'];points.append({'index':cfg['index']+j*cfg['index_stride'],'tick_ms':tick,'value':values[j] if valid else None,'valid':valid,'saturated':bool(cfg['saturated']),'held':held,'source_fault':bool(cfg['source_fault']),'source_tick_ms':(cfg['source_tick'] if held else tick) if valid else None})
   metadata=21+(4 if n>1 else 0)+((2 if cfg['tick']-cfg['source_tick']<=65535 else 8) if held else 0)
   ledger={'count':n,'value_count':n if valid else 0,'selected_raw_bytes':2*n if valid else 0,'significant_bits':q['significant_bits'],'stored_code_bytes':len(payload)-metadata,'padding_bits':(len(payload)-metadata)*8-q['significant_bits'],'metadata_bytes':metadata,'payload_bytes':len(payload),'outer_overhead_bytes':14,'frame_bytes':len(payload)+14,'line_bits_8n1':(len(payload)+14)*10}
   expected={'channel':cfg['channel'],'e':cfg['e'],'mode':mode,'k':q['k'],'count':n,'significant_bits':q['significant_bits'],'first_index':cfg['index'],'first_tick_ms':cfg['tick'],'index_stride':cfg['index_stride'] if n>1 else None,'tick_stride_ms':cfg['tick_stride'] if n>1 else None,'held_origin':cfg['source_tick'] if held else None,'points':points,'byte_ledger':ledger}
   assert decoded==expected,(decoded,expected);counts['success']+=1;counts[mode]+=1;counts['E'+str(cfg['e'])]+=1;points_count+=len(points);rows.append({'case':cid,'payload_hex':payload.hex(),'binding':binding,'decoded':decoded})
  except Exception as ex:errors.append({'case':cid,'payload_hex':payload.hex(),'binding':binding,'error':repr(ex)})
 assert allbytes==10445
 put(E/'CASE_RESULTS.json',rows);put(E/'MISMATCHES.json',errors)
 result.update(status='PASS_B38_ACTUAL_PAYLOAD_C_FIXED_DECODER' if not errors else 'INTEROPERABILITY_MISMATCH',b_head='bf60e80927ed38511d30ffe96ebd419fae0a275c',b_source='879f0af84aba596e11185df86f6722999e640673',c_head=get(Q/'FETCHED.json')['head'],c_source=manifest['request']['code_commit'],c_request_hash=manifest['request_hash'],c_decoder_sha256=sha(cp),actual_trace_rows=trace_rows,actual_bytes=allbytes,cases=len(vectors),counts=dict(counts),decoded_points=points_count,mismatches=len(errors),scope='Exact B38 candidate payload bytes decoded by unchanged C offline candidate only. Frame overhead ledger is arithmetic, not executed outer frame/UART. config_epoch0 synthetic and unused by payload decode. No ABI/type7/sourceclock/BOOT/runtime/formal/board grant; all29not_run.')
 assert not errors,errors[:3]
except Exception as ex:result.update(failure=repr(ex));raise
finally:
 result.update(finished_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),pid=os.getpid(),input_pins=pins,requirements_sha256='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804');put(E/'RESULT.json',result);print(json.dumps({k:v for k,v in result.items() if k!='input_pins'}))
