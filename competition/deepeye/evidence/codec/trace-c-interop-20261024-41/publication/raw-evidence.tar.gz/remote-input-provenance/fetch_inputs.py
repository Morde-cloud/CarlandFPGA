from pathlib import Path
import base64,hashlib,importlib.util,json
O=Path(__file__).parent;E=O.parent;s=importlib.util.spec_from_file_location('interop_transport',E/'trace-payload-publish-20261024-38/delivery38.py');m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.O=O;m.WORK='B-TRACE-C-INTEROP-PRECONDITIONS-20261024-v1';m.OP='B-TRACE-C-INTEROP-PRECONDITIONS-20261024'
C=m.new_client('c-exact-inputs','Read exact C offline candidate decoder and provenance at discovered PR25 head; no executable launch or remote mutation')
info=json.loads((O/'DISCOVERY.json').read_bytes());tree=json.loads((O/'c-readback/000002-c-tree.response.json').read_bytes());entries={x['path']:x for x in tree['tree']};prefix='competition/deepeye/evidence/ai/trace_candidate_decode/'
paths=[prefix+x for x in ['candidate_decode.py','report.md','release.json','input_manifest.json','artifact_manifest.json','main_review/main-review.json']]+['handoffs/c/C-DEEPEYE-TRACE-CANDIDATE-DECODE-20261018-14/manifest.json']
found={}
try:
 for i,path in enumerate(paths):
  row=entries[path];obj=C.api('blob-'+str(i),'repos/'+info['repo']+'/git/blobs/'+row['sha']);assert obj['sha']==row['sha'] and obj['encoding']=='base64';b=base64.b64decode(obj['content']);assert len(b)==row['size'] and hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==row['sha'];p=O/'downloaded'/path;p.parent.mkdir(parents=True,exist_ok=True)
  with p.open('xb') as f:f.write(b)
  found[path]={'sha256':hashlib.sha256(b).hexdigest(),'git_blob':row['sha'],'bytes':len(b)}
 with (O/'FETCHED.json').open('x',encoding='utf-8') as f:json.dump({'head':info['head'],'repo':info['repo'],'files':found},f,indent=2)
 C.finish('EXACT_C_OFFLINE_INPUTS_RETRIEVED',head=info['head'],files=found)
except Exception as e:C.finish('STOPPED_RECONCILE',error=repr(e));raise
