from pathlib import Path
import hashlib,importlib.util,json
O=Path(__file__).parent;E=O.parent
source=E/'trace-payload-publish-20261024-38/delivery38.py';s=importlib.util.spec_from_file_location('interop_transport',source);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);m.O=O;m.WORK='B-TRACE-C-INTEROP-PRECONDITIONS-20261024-v1';m.OP='B-TRACE-C-INTEROP-PRECONDITIONS-20261024'
C=m.new_client('c-readback','Read current C PR25 exact head and tree paths for bounded future interoperability with published B38 raw bytes; no remote mutation, no product claim')
try:
 p=C.api('pr25','repos/carolwjade/CarlandFPGA/pulls/25');repo=p['head']['repo']['full_name'];head=p['head']['sha'];tree=C.api('c-tree','repos/'+repo+'/git/trees/'+head+'?recursive=1');assert not tree.get('truncated')
 selected=[x for x in tree['tree'] if x['type']=='blob' and x['path'].startswith('competition/deepeye/') and ('trace' in x['path'].lower()) and (x['path'].endswith('.py') or x['path'].endswith('.md')) and '/evidence/' not in x['path']]
 result={'head':head,'repo':repo,'state':p['state'],'draft':p['draft'],'selected_paths':selected,'scope':'Precondition discovery only; savedC reports independently decoded previousBcandidate. No new interoperability claim.'}
 with (O/'DISCOVERY.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
 C.finish('READ_ONLY_CANDIDATE_LOCATED',**result)
except Exception as e:C.finish('STOPPED_RECONCILE',error=repr(e));raise
