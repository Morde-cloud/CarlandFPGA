from pathlib import Path
from collections import Counter
import datetime,hashlib,importlib.util,json,os,sys,subprocess
R=Path('D:/pynq/CarlandFPGA'); W=R/'.local/worktrees/deepeye-implementation-20261014'; P=W/'competition/deepeye'
D=Path(__file__).parent; O=P/'evidence/codec/trace-frame-c-interop-20261024-48/main'; B=P/'evidence/codec/trace-frame-candidate-20261024-45'; Q=D.parent/'trace-c-interop-preconditions-20261024'
H='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def crc(data):
 v=65535
 for b in data:
  for bit in range(7,-1,-1):
   carry=((v>>15)^((b>>bit)&1))&1;v=(v<<1)&65535
   if carry:v^=0x1021
 return v
def reseal(a):return bytes(a[:-2])+crc(a[2:-2]).to_bytes(2,'little')
assert crc(b'123456789')==0x29b1
O.mkdir(parents=True,exist_ok=False); put(O/'STARTED.json',{'pid':os.getpid(),'argv':sys.argv,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':sys.version,'main':'01a13b55-095b-7461-8dd5-5476a130bd82'}); result={'status':'RUNNING'}
try:
 contract=subprocess.run(['git','show','f5989cd5defce561f9ba98e6b18fc2682945f0a2:docs/competition/deepeye-2026/immutable_scope.json'],cwd=W,capture_output=True,check=True).stdout
 assert hashlib.sha256(json.dumps(json.loads(contract)['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()==H
 raw=B/'main/positive-01/trace.txt'; assert sha(raw)=='657fb3f6c8f0e8444682171a3479cb69e7412deb89a13cf1b6682a63edfe039e'
 f=B/'main/preinspection-01'; freeze=get(f/'FREEZE.json')
 assert sha(f/'main_vectors.json')==freeze['files']['main_vectors.json']
 assert get(B/'main/positive-01/RESULT.json')['status'].startswith('PASS')
 cp=Q/'downloaded/competition/deepeye/evidence/ai/trace_candidate_decode/candidate_decode.py'; assert sha(cp)=='b02010280b72d3a94842db627f733df9c1fa6ecfe54f572509d57869d2d3d72c'
 inputs=[(raw,'actual45_trace_reference'),(f/'main_vectors.json','vectors.json'),(B/'main/positive-01/RESULT.json','B45_RESULT.json'),(Path(__file__),'run_interop.py'),(D/'MAIN_SPEC.md','MAIN_SPEC.md')]
 for rel,v in get(Q/'FETCHED.json')['files'].items():
  p=Q/'downloaded'/rel;assert sha(p)==v['sha256'];inputs.append((p,'c-fixed/'+rel))
 pins={n:{'path':str(p),'bytes':p.stat().st_size,'sha256':sha(p)} for p,n in inputs}; put(O/'INPUTS.json',pins)
 inp=O/'inputs';inp.mkdir();(inp/'contract.json').write_bytes(contract)
 for p,n in inputs:
  if n=='actual45_trace_reference':continue
  t=inp/n;t.parent.mkdir(parents=True,exist_ok=True);t.write_bytes(p.read_bytes())
 put(O/'EXECUTION_FREEZE.json',{'script_sha256':sha(Path(__file__)),'spec_sha256':sha(D/'MAIN_SPEC.md'),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'expected_normal':746,'expected_recovery':106,'expected_abort':106,'negatives_per_normal_success':8,'disclosure':'Existing41 C API and prior independent45 vectors were inspected; new interop spec/script frozen before this execution. Not a new independent C-authored test.'})
 spec=importlib.util.spec_from_file_location('fixed_c48',cp); decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
 vectors=get(f/'main_vectors.json')['cases'];vm={v['id']:v for v in vectors};actual={};trows=qrows=0;fields=['count','e','session','channel','index','tick','index_stride','tick_stride','valid','saturated','held','source_fault','source_tick']
 def entry(cid):return actual.setdefault(cid,{'cfg':[],'data':[],'result':[],'abort':[]})
 with raw.open(encoding='ascii') as stream:
  for line in stream:
   a=line.split();kind=a[0]
   if kind=='T':
    trows+=1;cid=int(a[2]);assert int(a[1])==trows
    if cid==-1:continue
    x=entry(cid)
    if a[11:13]==['1','1']:x['data'].append([int(a[14],16),int(a[13]),int(a[15],16)])
    if a[16:18]==['1','1']:x['result'].append([int(a[18],16),int(a[19],16)])
   elif kind=='Q':qrows+=1
   elif kind=='C':entry(int(a[2]))['cfg'].append([int(z,16) for z in a[3:]])
   elif kind=='A':entry(int(a[2]))['abort'].append([int(z) for z in a[3:]])
 assert trows==qrows==1175060 and sum(len(x['data']) for x in actual.values())==22677
 def expected(v):
  c=v['cfg'];q=v['expected'];n=c['count'];valid=bool(c['valid']);held=bool(c['held']);values=[]
  if valid:
   if q['raw']:values=list(v['samples'])
   else:
    values=[v['samples'][0]]
    for original in v['samples'][1:]:
     previous=values[-1];quant=(original-previous+c['e'])//(2*c['e']+1);values.append(max(0,min(65535,previous+quant*(2*c['e']+1))))
   assert all(abs(x-y)<=(0 if q['raw'] else c['e']) for x,y in zip(v['samples'],values))
  points=[]
  for j in range(n):
   tick=c['tick']+j*c['tick_stride'];points.append({'index':c['index']+j*c['index_stride'],'tick_ms':tick,'value':values[j] if valid else None,'valid':valid,'saturated':bool(c['saturated']),'held':held,'source_fault':bool(c['source_fault']),'source_tick_ms':(c['source_tick'] if held else tick) if valid else None})
  metadata=21+(4 if n>1 else 0)+((2 if c['tick']-c['source_tick']<=65535 else 8) if held else 0);length=len(q['bytes'])
  ledger={'count':n,'value_count':n if valid else 0,'selected_raw_bytes':2*n if valid else 0,'significant_bits':q['significant_bits'],'stored_code_bytes':length-metadata,'padding_bits':(length-metadata)*8-q['significant_bits'],'metadata_bytes':metadata,'payload_bytes':length,'outer_overhead_bytes':14,'frame_bytes':length+14,'line_bits_8n1':(length+14)*10}
  return {'channel':c['channel'],'e':c['e'],'mode':'raw' if q['raw'] else 'rice','k':q['k'],'count':n,'significant_bits':q['significant_bits'],'first_index':c['index'],'first_tick_ms':c['tick'],'index_stride':c['index_stride'] if n>1 else None,'tick_stride_ms':c['tick_stride'] if n>1 else None,'held_origin':c['source_tick'] if held else None,'points':points,'byte_ledger':ledger,'sequence':v['seq'],'config_epoch':v['epoch']}
 counts=Counter();rows=[];neg=[];aborts=[];total=points=0
 for cid,x in sorted(actual.items()):
  if x['abort']:
   assert len(x['abort'])==1 and not x['result'];v=vm[24];packet=bytes(a[0] for a in x['data']);assert packet==bytes(v['frame'][:len(packet)])
   complete=len(packet)==len(v['frame']);aborts.append({'case':cid,'mode_stage_position':x['abort'][0],'emitted_bytes':len(packet),'emitted_hex':packet.hex(),'complete_frame_already_emitted':complete});counts['abort_complete_frame_prefix' if complete else 'abort_partial_or_empty_prefix']+=1;continue
  v=vm[cid] if cid>=0 else vm[24];assert cid>=0 or -2106<=cid<=-2001
  assert x['cfg']==[[v['cfg'][k] for k in fields]+[v['epoch'],v['seq']]]
  assert x['result']==[[v['expected']['error'],len(v['frame'])]];packet=bytes(a[0] for a in x['data']);assert packet==bytes(v['frame'])
  assert [a[1:] for a in x['data']]==[[int(i==len(packet)-1),len(packet)] for i in range(len(packet))]
  if v['expected']['error']:
   assert cid>=0 and not packet;counts['normal_error_'+str(v['expected']['error'])]+=1;continue
  c=v['cfg'];binding={'session':c['session'],'e':c['e'],'config_epoch':v['epoch']}
  assert packet[:6]==bytes([165,90,3,7,len(packet)-14,v['epoch']]) and int.from_bytes(packet[6:8],'little')==v['seq'] and int.from_bytes(packet[8:12],'little')==(c['tick']&0xffffffff)
  assert int.from_bytes(packet[-2:],'little')==crc(packet[2:-2])
  decoded=decoder.decode_frame(packet,binding);want=expected(v);assert decoded==want,(cid,decoded,want)
  counts['normal_success' if cid>=0 else 'recovery_success']+=1;total+=len(packet);points+=len(decoded['points']);rows.append({'case':cid,'packet_hex':packet.hex(),'binding':binding,'decoded':decoded})
  if cid<0:continue
  mutants=[]
  a=bytearray(packet);a[-1]^=1;mutants.append(('corrupt_crc',bytes(a)))
  for name,index in [('invalid_version',2),('invalid_type',3),('length_mismatch',4),('tick_low_mismatch',8),('wrong_epoch',5)]:
   a=bytearray(packet);a[index]^=1;mutants.append((name,reseal(a)))
  mutants.extend([('truncated',packet[:-1]),('extra_byte',packet+b'\x00')])
  for name,b in mutants:
   assert b!=packet
   try:decoder.decode_frame(b,binding)
   except decoder.Reject as ex:neg.append({'case':cid,'recipe':name,'mutated_sha256':hashlib.sha256(b).hexdigest(),'rejection':str(ex)})
   else:raise AssertionError(('C_false_accept',cid,name))
 assert counts['normal_success']==371 and counts['recovery_success']==106 and len(aborts)==106 and len(neg)==2968
 assert sum(counts['normal_error_'+str(i)] for i in (1,2,3))==375 and total==20515
 for p,n in inputs:assert sha(p)==pins[n]['sha256']
 put(O/'DECODED_CASES.json',rows);put(O/'NEGATIVES.json',neg);put(O/'ABORT_BOUNDARY.json',aborts)
 result.update(status='PASS_ACTUAL_B45_FRAMES_FIXED_C_OFFLINE_DECODER',trace_rows=trows+qrows,decoded_frames=len(rows),decoded_frame_bytes=total,decoded_points=points,counts=dict(counts),negative_rejections=len(neg),c_head=get(Q/'FETCHED.json')['head'],c_decoder_sha256=sha(cp),b_rtl_sha256='ceff0930c2403eabe73bdd8a8cfe7bbb868ca33029d026a6a240c8d50a06a5cc',scope='Saved actual RTL frame handshakes to unchanged fixed C decode_frame only. Existing source and oracle reused, fresh offline execution. Abort prefixes are not recalled: no rollback/stateful history/cache/continuous sequence/UART/ABI/BOOT/clock/runtime/formal/board claim. B45 qualifier pending separately.')
except Exception as ex:result.update(status='FAILED',error=repr(ex));raise
finally:
 result.update(pid=os.getpid(),requirements_sha256=H,utc=datetime.datetime.now(datetime.timezone.utc).isoformat());put(O/'RESULT.json',result);print(json.dumps(result))
