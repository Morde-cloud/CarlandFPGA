# TRACE frame OOC47 diagnostic

Exactly one actual Vivado2026.1 OOC of the pinned top plus four pinned dependencies.
Read RESULT.json, PROCESS.json and DIAGNOSTICS.json for exact inputs, argv,
child-only environment, original Windows job/process handles, all PID exits,
warnings and report hashes. No source, runner or product notes were edited.

Actual result: LUT2430, FF2957, DSP2, BRAM0; diagnostic WNS+0.556ns.
Ten console warnings and four DRC violations remain unwaived: DPIP-1(2),
DPOP-2(1), ZPS7-1(1). There are289 input and33 output ports without delay.
HD.CLK_SRC and OOC DRC coverage gaps remain. The10ns clock was created only
after synthesis. This is not timing closure or engineering/product acceptance.

The original Windows job ended active0 with every tracked PID exit captured.
Nonzero helper exits are retained, including findstr.exe exits1, without
substituting them for the actual cmd/Vivado exit0. There was no vendor replay.
The original46 failed driver and all existing46 author/short artifacts remain
byte-identical. Pinned Tcl retains original33 comments/B06 marker names.

45 qualifier repair is separate;45 was not accepted at dispatch. This hardware
evidence does not promote45, a public ABI, TRACE admission or full-product
status. Main owns independent DCP reopening and acceptance. All29 formal cards,
including B01/B03/B06/R03, remain not_run; no motion grant. Board work is A only.
H01-H15 requirements SHA256:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design:1011259415a0916054eb580687612580bc1e5f09.
