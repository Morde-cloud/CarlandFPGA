"""Freeze actual evidence for one completed47 OOC; no process/vendor creation."""
from pathlib import Path
import hashlib
import json
import re
import os
import sys
import datetime

A=Path(__file__).resolve().parent
S=Path("D:/pynq/CarlandFPGA/.local/b47")
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(p):return json.loads(Path(p).read_text(encoding="utf-8"))
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
assert not (A/"ARTIFACT_MANIFEST.json").exists()
result=load(A/"RESULT.json")
assert result["status"]=="artifacts_complete_diagnostic_only" and result["vendor_launches"]==1 and result["synthesis_complete"]
assert result["job_id"]=="child-f2e3c7deb83249eaac6b63240dfba2b8"
process=result["process"]
members=process["members"]
engine=[m for m in members if Path(m.get("image","")).name.lower()=="vivado.exe"]
assert len(engine)==1 and engine[0]["exit_code"]==process["exit_code"]==0
assert process["job_accounting"]["TotalProcesses"]==len(members) and process["job_accounting"]["ActiveProcesses"]==0
assert not process["active_pids_at_end"] and not process["timed_out"]
assert all(isinstance(m.get("exit_code"),int) for m in members)
assert all(sha(p["path"])==p["sha256"] for p in result["input_pins"])
old=load(A/"ORIGINAL_EVIDENCE_BEFORE.json")
assert all(sha(p)==h for p,h in old.items())
for name,refs in result["outputs"].items():
    assert sha(refs["original"]["path"])==sha(refs["export"]["path"])==refs["export"]["sha256"]
source_refs=result["input_pins"][:5]
assert len(source_refs)==5 and len({r["sha256"] for r in source_refs})==5
for r in source_refs:
    assert sha(A/"snapshot"/Path(r["path"]).name)==r["sha256"]
diagnostics=result["diagnostics"]
assert diagnostics["diagnostic_wns_ns"]==0.556
assert len(diagnostics["warnings"])==10 and not diagnostics["critical_warnings"] and not diagnostics["errors"]
assert diagnostics["check_timing"]["no_input_delay"]==289 and diagnostics["check_timing"]["no_output_delay"]==33
assert diagnostics["drc_violation_count"]==sum(v["checks"] for v in diagnostics["drc_rules"])==4
util=(A/"reports/utilization.rpt").read_text(encoding="utf-8")
latch=re.search(r"^\|\s*Register as Latch\s*\|\s*([0-9]+)\s*\|",util,re.M)
assert latch
extra=dict(source_pins=source_refs,result_sha256=sha(A/"RESULT.json"),dcp_sha256=sha(A/"ooc.dcp"),
           latches=int(latch[1]),original46_preserved_files=len(old),
           verification_process=dict(pid=os.getpid(),argv=sys.argv,cwd=os.getcwd(),python=sys.executable,
                                     utc=datetime.datetime.now(datetime.timezone.utc).isoformat()),
           no_new_vendor_process=True)
save(A/"FINAL_HASH_VERIFICATION.json",extra)
note="""# TRACE frame OOC47 diagnostic

Exactly one actual Vivado2026.1 OOC of the pinned top plus four pinned dependencies.
Read RESULT.json, PROCESS.json and DIAGNOSTICS.json for exact inputs, argv,
child-only environment, original Windows job/process handles, all PID exits,
warnings and report hashes. No source, runner or product notes were edited.

Actual result: LUT2430, FF2957, DSP2, BRAM0; diagnostic WNS+0.556ns.
Ten console warnings and four DRC violations remain unwaived: DPIP-1(2),
DPOP-2(1), ZPS7-1(1). There are289 input and33 output ports without delay.
HD.CLK_SRC and OOC DRC coverage gaps remain. The10ns clock was created only
after synthesis. This is not timing closure or engineering/product acceptance.

The original Windows job ended active0 with every tracked PID exit captured.
Nonzero helper exits are retained, including findstr.exe exits1, without
substituting them for the actual cmd/Vivado exit0. There was no vendor replay.
The original46 failed driver and all existing46 author/short artifacts remain
byte-identical. Pinned Tcl retains original33 comments/B06 marker names.

45 qualifier repair is separate;45 was not accepted at dispatch. This hardware
evidence does not promote45, a public ABI, TRACE admission or full-product
status. Main owns independent DCP reopening and acceptance. All29 formal cards,
including B01/B03/B06/R03, remain not_run; no motion grant. Board work is A only.
H01-H15 requirements SHA256:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design:1011259415a0916054eb580687612580bc1e5f09.
"""
(A/"README.md").write_text(note,encoding="utf-8",newline="\n")
payload=dict(task=result["task"],work=result["work"],operation=result["operation"],job_id=result["job_id"],
             agent_id=result["agent_id"],turn_id=result["turn_id"],parent_id=result["parent_id"],
             status=result["status"],result=str(A/"RESULT.json"),result_sha256=sha(A/"RESULT.json"),
             dcp=str(A/"ooc.dcp"),dcp_sha256=sha(A/"ooc.dcp"),source_pins=source_refs,
             actual_run=dict(launches=1,replays=0,cmd_pid=process["pid"],cmd_exit=process["exit_code"],
                             vivado_pid=engine[0]["pid"],vivado_exit=engine[0]["exit_code"],
                             elapsed_seconds=process["elapsed_seconds"],tracked_members=len(members),
                             active_at_end=0,all_exits_captured=True,nonzero_helpers=diagnostics["nonzero_helper_exits"]),
             diagnostic=dict(LUT=int(diagnostics["utilization"]["Slice LUTs"]),
                             FF=int(diagnostics["utilization"]["Slice Registers"]),DSP=2,BRAM=0,
                             latches=int(latch[1]),clock_ns=10,WNS_ns=diagnostics["diagnostic_wns_ns"],
                             warnings=10,critical_warnings=0,errors=0,drc_violations=4,drc_rules=diagnostics["drc_rules"],
                             no_input_delay=289,no_output_delay=33),
             preservation=dict(original46_files_unchanged=len(old),all5sources_Tcl_tools_protected_input_unchanged=True),
             contract=result["contract"],all29="not_run",B01="not_run",B03="not_run",B06="not_run",R03="not_run",
             limits="Diagnostic synthesis only. No timing closure or45/ABI/product/board acceptance. Separate45 qualifier repair remains independent. No source edits or vendor replay; main reopens DCP.")
save(A/"COMPLETION_PAYLOAD.json",payload)
def records(root):
    return [dict(path=p.relative_to(root).as_posix(),bytes=p.stat().st_size,sha256=sha(p))
            for p in sorted(root.rglob("*")) if p.is_file()]
short=records(S)
save(A/"SHORT_ARTIFACT_MANIFEST.json",dict(root=str(S),files=short))
author=records(A)
save(A/"ARTIFACT_MANIFEST.json",dict(root=str(A),files=author))
print(json.dumps(dict(result_sha256=sha(A/"RESULT.json"),dcp_sha256=sha(A/"ooc.dcp"),
                      manifest_sha256=sha(A/"ARTIFACT_MANIFEST.json"),author_files=len(author),short_files=len(short),
                      cmd_pid=process["pid"],vivado_pid=engine[0]["pid"],members=len(members),
                      all_actual_exits=True,elapsed_seconds=process["elapsed_seconds"],
                      original46_files_unchanged=len(old),diagnostic=payload["diagnostic"]),ensure_ascii=True))
