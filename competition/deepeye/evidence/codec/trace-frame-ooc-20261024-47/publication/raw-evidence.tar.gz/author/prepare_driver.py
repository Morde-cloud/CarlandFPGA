"""Derive a fresh one-operation driver; never execute or alter old46 driver."""
from pathlib import Path
import ast
import hashlib
import json

A=Path(__file__).resolve().parent
P=A.parents[3]
OLD=P/"evidence/acquisition/scan-lane-ooc-20261024-46/author"
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
manifest=json.loads((OLD/"ARTIFACT_MANIFEST.json").read_text(encoding="utf-8"))
pin=next(e["sha256"] for e in manifest["files"] if e["path"]=="run_one_ooc.py")
assert sha(OLD/"run_one_ooc.py")==pin
text=(OLD/"run_one_ooc.py").read_text(encoding="utf-8")
def replace(old,new):
    global text
    assert old in text,old[:80]
    text=text.replace(old,new)
replace('.local/b46','.local/b47')
replace('B-SCAN-LANE-OOC-20261024-46-v1','B-TRACE-FRAME-OOC-20261024-47-v1')
replace('B-DEEPEYE-SCAN-LANE-OOC-20261024-46','B-DEEPEYE-TRACE-FRAME-OOC-20261024-47')
replace('child-edf2df40d2e346f390b28cbd76dcdce0','child-f2e3c7deb83249eaac6b63240dfba2b8')
replace('01a16d5d-69d8-7d11-a749-3e2f78b72f2d','01a16d6d-7c5f-7ba3-b1a9-919936b1d7ac')
replace('TOP="deepeye_scan_lane_stream"','TOP="deepeye_trace_frame_candidate"')
replace('run_id=b46','run_id=b47')
replace('actual operation46','actual operation47')
replace('evidence/scan-lane-ooc-20261024-46/MAIN_SPEC.md','evidence/trace-frame-ooc-20261024-47/MAIN_SPEC.md')
sources=[
 ("fpga/codec/deepeye_trace_frame_candidate.sv","ceff0930c2403eabe73bdd8a8cfe7bbb868ca33029d026a6a240c8d50a06a5cc"),
 ("fpga/codec/deepeye_trace_payload_timing_candidate.sv","0d5ba11fe199708f8376c718bbf3484431adc8dd6e847666451b1b5e873cec7b"),
 ("fpga/codec/deepeye_block_encoder.sv","4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532"),
 ("fpga/transport/deepeye_wire_serializer.sv","efc6082f6f5dff215b100f718b12d87d4c6467db7b968a24f846802dc6a19885"),
 ("fpga/transport/deepeye_crc16_byte.sv","8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f"),
]
replace('PINS={\n P/"fpga/acquisition/deepeye_scan_lane_stream.sv":"b3c9d2024d9325191538cf08fec9a652ff8ff0ae316ec9af96078f85cf5be3cc",',
        "SOURCES="+repr(sources)+"\nPINS={**{P/rel:h for rel,h in SOURCES},")
replace('    source=A/"snapshot/deepeye_scan_lane_stream.sv"\n','')
replace('    sources.write_text(source.as_posix()+"\\n",encoding="utf-8",newline="\\n")',
        '    sources.write_text("\\n".join((A/"snapshot"/Path(rel).name).as_posix() for rel,_ in SOURCES)+"\\n",encoding="utf-8",newline="\\n")')
replace('    wanted=["BEGIN","USER_DATA","VERSION","PART","THREADS","SOURCE_READ","SOURCE_COUNT","SYNTH_BEGIN","SYNTH_DONE",\n            "DESIGN","CLOCK","REPORT","REPORT","REPORT","REPORT","CHECKPOINT","END"]',
        '    wanted=["BEGIN","USER_DATA","VERSION","PART","THREADS"]+["SOURCE_READ"]*5+["SOURCE_COUNT","SYNTH_BEGIN","SYNTH_DONE",\n            "DESIGN","CLOCK","REPORT","REPORT","REPORT","REPORT","CHECKPOINT","END"]')
replace('    require("B06_OOC_SOURCE_COUNT|count=1" in markers,"source count mismatch")',
        '    require("B06_OOC_SOURCE_COUNT|count=5" in markers,"source count mismatch")\n'
        '    reads=[x for x in markers if x.startswith("B06_OOC_SOURCE_READ|")]\n'
        '    require(reads==[f"B06_OOC_SOURCE_READ|index={i}|path={(A/\'snapshot\'/Path(rel).name).as_posix()}" for i,(rel,_) in enumerate(SOURCES,1)],"source order/path mismatch")')
replace('    require(all(m.get("exit_code")==0 for m in process["members"]),"nonzero/unknown actual child exit")',
        '    require(all(isinstance(m.get("exit_code"),int) for m in process["members"]),"unknown actual child exit")\n'
        '    require(all(m["exit_code"]==0 for m in process["members"] if Path(m.get("image","")).name.lower()=="vivado.exe"),"actual Vivado child nonzero")')
replace('    diagnostics=dict(warnings=warnings,critical_warnings=critical,errors=errors,markers=markers,',
        '    check_text=(A/"reports/check_timing.rpt").read_text(encoding="utf-8")\n'
        '    check_counts={name:int(count) for name,count in re.findall(r"^\\d+\\. checking ([a-z_]+) \\((\\d+)\\)$",check_text,re.M)}\n'
        '    drc_text=(A/"reports/drc.rpt").read_text(encoding="utf-8")\n'
        '    drc_rules=[dict(rule=m[0],severity=m[1],description=m[2].strip(),checks=int(m[3])) for m in re.findall(r"^\\|\\s*([A-Z0-9_-]+)\\s*\\|\\s*(Warning|Error|Critical Warning)\\s*\\|\\s*([^|]+)\\|\\s*(\\d+)\\s*\\|",drc_text,re.M)]\n'
        '    drc_marker=next(x for x in markers if x.startswith("B06_OOC_REPORT|kind=drc|"))\n'
        '    drc_count=int(re.search(r"\\|violation_count=([0-9]+)\\|",drc_marker)[1])\n'
        '    diagnostics=dict(warnings=warnings,critical_warnings=critical,errors=errors,markers=markers,\n'
        '                     check_timing=check_counts,drc_violation_count=drc_count,drc_rules=drc_rules,\n'
        '                     nonzero_helper_exits=[m for m in process["members"] if m["exit_code"]!=0],')
replace('    acceptance=P/"evidence/acquisition/scan-lane-stream-20261024-44/main/qualifier-review-01/RESULT.json"\n'
        '    require(load(acceptance)["status"]=="PASS_BOUNDED_LANE_STREAM_AND_REPAIRED_QUALIFIER","main receipt mismatch")\n'
        '    state["main_acceptance_receipt"]=record(acceptance)\n',
        '    state["parent45_context"]="Main reported independent746normal+106recovery+106abort and3compiledmutants. Separate qualifier repair active;45overall notaccepted at dispatch. This hardware diagnostic cannot promote45/ABI/product status."\n'
        '    binding=load(R/".local/deployment/node-b/evidence/trace-frame-ooc-20261024-47/binding-private.json")\n'
        '    require(binding["job_id"]==state["job_id"] and binding["native_agent_id"]==state["agent_id"],"binding mismatch")\n')
replace('    for name in ("author","author-qualifier-repair1"):\n'
        '        parent=P/"evidence/acquisition/scan-lane-stream-20261024-44"/name\n'
        '        for p in parent.rglob("*"):\n'
        '            if p.is_file():original[str(p)]=sha(p)',
        '    for parent in (P/"evidence/acquisition/scan-lane-ooc-20261024-46/author",R/".local/b46"):\n'
        '        for p in parent.rglob("*"):\n'
        '            if p.is_file():original[str(p)]=sha(p)')
replace('    for rel in ("fpga/acquisition/deepeye_scan_lane_stream.sv","fpga/build_qualification/ooc_qualification.tcl"):',
        '    for rel in [rel for rel,_ in SOURCES]+["fpga/build_qualification/ooc_qualification.tcl"]:')
replace('"original44/44r1 evidence changed"','"original46 evidence changed"')
replace('    state.update(status="artifacts_complete_diagnostic_only",original_evidence_files_unchanged=len(original))',
        '    state.update(status="artifacts_complete_diagnostic_only",original46_evidence_files_unchanged=len(original))')
text=text.replace('No statistics','No statistics')
ast.parse(text)
target=A/"run_one_ooc.py"
assert not target.exists()
target.write_text(text,encoding="utf-8",newline="\n")
meta=dict(old_driver_path=str(OLD/"run_one_ooc.py"),old_driver_sha256=pin,new_driver_sha256=sha(target),
          policy="Source/tool pins and original Windows job mechanics reused; five sources/top47/short47 only. Helper nonzero exits retained; no requirement that every helper exit0. No old code/evidence changed.",
          source_pins=sources)
(A/"DRIVER_DERIVATION.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(meta))
