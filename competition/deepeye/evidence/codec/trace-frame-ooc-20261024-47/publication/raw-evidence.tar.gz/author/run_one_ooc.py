"""Exactly one unchanged-source Vivado OOC diagnostic; Windows job tracked."""
import ctypes as C
from ctypes import wintypes as T
import datetime
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import traceback
import _winapi
import msvcrt

sys.dont_write_bytecode=True
A=Path(__file__).resolve().parent
P=A.parents[3]
R=Path("D:/pynq/CarlandFPGA")
SHORT=R/".local/b47"
TOP="deepeye_trace_frame_candidate"
TOOL=Path("D:/pynq/AMD2026/2026.1/Vivado")
CMD=Path("C:/Windows/System32/cmd.exe")
PS=Path("C:/Windows/System32/WindowsPowerShell/v1.0/powershell.exe")
SOURCES=[('fpga/codec/deepeye_trace_frame_candidate.sv', 'ceff0930c2403eabe73bdd8a8cfe7bbb868ca33029d026a6a240c8d50a06a5cc'), ('fpga/codec/deepeye_trace_payload_timing_candidate.sv', '0d5ba11fe199708f8376c718bbf3484431adc8dd6e847666451b1b5e873cec7b'), ('fpga/codec/deepeye_block_encoder.sv', '4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532'), ('fpga/transport/deepeye_wire_serializer.sv', 'efc6082f6f5dff215b100f718b12d87d4c6467db7b968a24f846802dc6a19885'), ('fpga/transport/deepeye_crc16_byte.sv', '8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f')]
PINS={**{P/rel:h for rel,h in SOURCES},
 P/"fpga/build_qualification/ooc_qualification.tcl":"54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9",
 P/"tools/build/run_ooc_qualification.py":"04a47aee3ce44c7576c8d879baf27a8701b5cde3e17a3ef0000954c8b0c3ea11",
 TOOL/"bin/vivado.bat":"a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b",
 TOOL/"bin/unwrapped/win64.o/vivado.exe":"3a4e9e3f03d20cd1994dc2eff44566af7a10eaaae04429e9d460bffe3b0e86e4",
 R/".local/worktrees/deepeye-implementation-20261014/handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json":"6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8",
}

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
def load(p):return json.loads(Path(p).read_text(encoding="utf-8-sig"))
def record(p):return dict(path=str(p),bytes=Path(p).stat().st_size,sha256=sha(p))
def require(v,why):
    if not v:raise RuntimeError(why)

K=C.WinDLL("kernel32",use_last_error=True)
SIZE=C.c_size_t
class BASIC_LIMIT(C.Structure):
    _fields_=[("PerProcessUserTimeLimit",C.c_longlong),("PerJobUserTimeLimit",C.c_longlong),
              ("LimitFlags",T.DWORD),("MinimumWorkingSetSize",SIZE),("MaximumWorkingSetSize",SIZE),
              ("ActiveProcessLimit",T.DWORD),("Affinity",SIZE),("PriorityClass",T.DWORD),("SchedulingClass",T.DWORD)]
class IO(C.Structure):
    _fields_=[(s,C.c_ulonglong) for s in ("ReadOperationCount","WriteOperationCount","OtherOperationCount",
                                        "ReadTransferCount","WriteTransferCount","OtherTransferCount")]
class EXTENDED_LIMIT(C.Structure):
    _fields_=[("BasicLimitInformation",BASIC_LIMIT),("IoInfo",IO),("ProcessMemoryLimit",SIZE),
              ("JobMemoryLimit",SIZE),("PeakProcessMemoryUsed",SIZE),("PeakJobMemoryUsed",SIZE)]
class ASSOCIATION(C.Structure):
    _fields_=[("CompletionKey",C.c_void_p),("CompletionPort",T.HANDLE)]
class ACCOUNTING(C.Structure):
    _fields_=[("TotalUserTime",C.c_longlong),("TotalKernelTime",C.c_longlong),
              ("ThisPeriodTotalUserTime",C.c_longlong),("ThisPeriodTotalKernelTime",C.c_longlong),
              ("TotalPageFaultCount",T.DWORD),("TotalProcesses",T.DWORD),
              ("ActiveProcesses",T.DWORD),("TotalTerminatedProcesses",T.DWORD)]
def api(name,restype,argtypes):
    fn=getattr(K,name);fn.restype=restype;fn.argtypes=argtypes;return fn
CreateJob=api("CreateJobObjectW",T.HANDLE,[C.c_void_p,T.LPCWSTR])
SetJob=api("SetInformationJobObject",T.BOOL,[T.HANDLE,C.c_int,C.c_void_p,T.DWORD])
AssignJob=api("AssignProcessToJobObject",T.BOOL,[T.HANDLE,T.HANDLE])
QueryJob=api("QueryInformationJobObject",T.BOOL,[T.HANDLE,C.c_int,C.c_void_p,T.DWORD,C.c_void_p])
TerminateJob=api("TerminateJobObject",T.BOOL,[T.HANDLE,T.UINT])
CreatePort=api("CreateIoCompletionPort",T.HANDLE,[T.HANDLE,T.HANDLE,SIZE,T.DWORD])
GetEvent=api("GetQueuedCompletionStatus",T.BOOL,[T.HANDLE,C.POINTER(T.DWORD),C.POINTER(SIZE),C.POINTER(C.c_void_p),T.DWORD])
OpenProc=api("OpenProcess",T.HANDLE,[T.DWORD,T.BOOL,T.DWORD])
GetExit=api("GetExitCodeProcess",T.BOOL,[T.HANDLE,C.POINTER(T.DWORD)])
Wait=api("WaitForSingleObject",T.DWORD,[T.HANDLE,T.DWORD])
Resume=api("ResumeThread",T.DWORD,[T.HANDLE])
Close=api("CloseHandle",T.BOOL,[T.HANDLE])
Image=api("QueryFullProcessImageNameW",T.BOOL,[T.HANDLE,T.DWORD,T.LPWSTR,C.POINTER(T.DWORD)])
def checked(v):
    if not v:raise C.WinError(C.get_last_error())
    return v
def accounting(job):
    info=ACCOUNTING();checked(QueryJob(job,1,C.byref(info),C.sizeof(info),None))
    return {name:int(getattr(info,name)) for name,_ in ACCOUNTING._fields_}
def active_pids(job):
    buf=C.create_string_buffer(8+8*1024)
    checked(QueryJob(job,3,buf,C.sizeof(buf),None))
    n=C.c_ulong.from_buffer(buf,4).value
    return [int(x) for x in (SIZE*n).from_buffer(buf,8)]

def busy_processes(index):
    code="Get-CimInstance Win32_Process -Filter \"Name='vivado.exe'\" | Select-Object ProcessId,ParentProcessId,ExecutablePath,CommandLine | ConvertTo-Json -Compress"
    argv=[str(PS),"-NoProfile","-NonInteractive","-Command",code]
    started=utc()
    p=subprocess.Popen(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=subprocess.CREATE_NO_WINDOW)
    out,err=p.communicate(timeout=30)
    stem=A/"logs"/f"busy-{index:02d}"
    stem.with_suffix(".stdout.bin").write_bytes(out);stem.with_suffix(".stderr.bin").write_bytes(err)
    save(stem.with_suffix(".json"),dict(argv=argv,pid=p.pid,started_utc=started,ended_utc=utc(),
                                      exit_code=p.returncode,stdout_sha256=hashlib.sha256(out).hexdigest(),
                                      stderr_sha256=hashlib.sha256(err).hexdigest()))
    require(p.returncode==0,"process inventory failed")
    text=out.decode("utf-8-sig").strip()
    rows=json.loads(text) if text else []
    return rows if isinstance(rows,list) else [rows]

def wait_idle():
    start=time.monotonic();snapshots=[]
    while True:
        rows=busy_processes(len(snapshots))
        snapshots.append(dict(utc=utc(),processes=rows))
        save(A/"BUSY_GATE.json",dict(bound_seconds=300,snapshots=snapshots))
        if not rows:return
        remaining=300-(time.monotonic()-start)
        require(remaining>0,"Vivado busy after bounded300s; no launch")
        print("B46 waiting on existing Vivado process handles",flush=True)
        handles=[OpenProc(0x100000,False,int(r["ProcessId"])) for r in rows]
        try:
            live=[h for h in handles if h]
            if live:Wait(live[0],int(min(10,remaining)*1000))
            else:time.sleep(min(1,remaining))
        finally:
            for h in handles:
                if h:Close(h)

def run_one():
    work,tmp,cache=[SHORT/name for name in ("work","tmp","cache")]
    for path in (work,tmp,cache):path.mkdir()
    tcl=A/"snapshot/ooc_qualification.tcl"
    sources=A/"snapshot/SOURCES.txt"
    sources.write_text("\n".join((A/"snapshot"/Path(rel).name).as_posix() for rel,_ in SOURCES)+"\n",encoding="utf-8",newline="\n")
    argv=[str(CMD),"/d","/c",str(TOOL/"bin/vivado.bat"),"-mode","batch","-notrace",
          "-journal",str(A/"logs/vivado.jou"),"-log",str(A/"logs/vivado.log"),
          "-source",str(tcl),"-tclargs",str(SHORT),TOP,str(sources),"clock:clk"]
    overrides=dict(TEMP=str(tmp),TMP=str(tmp),TMPDIR=str(tmp),XILINX_LOCAL_USER_DATA=str(cache),PYTHONDONTWRITEBYTECODE="1")
    env=os.environ.copy();env.update(overrides)
    job=checked(CreateJob(None,None))
    port=checked(CreatePort(T.HANDLE(-1),None,0,1))
    limit=EXTENDED_LIMIT();limit.BasicLimitInformation.LimitFlags=0x2000
    checked(SetJob(job,9,C.byref(limit),C.sizeof(limit)))
    association=ASSOCIATION(1,port);checked(SetJob(job,7,C.byref(association),C.sizeof(association)))
    handles={};members={};proc_handle=thread_handle=None;timed_out=False;started=time.monotonic()
    process=dict(argv=argv,command_line=subprocess.list2cmdline(argv),cwd=str(work),environment_overrides=overrides,
                 started_utc=utc(),timeout_seconds=600,hidden=True,creationflags=0x08000000|0x00000004|0x00000400,
                 launch="native _winapi.CreateProcess using subprocess argv/list2cmdline; suspended until original Windows job assigned",
                 isolation="original job and process handles retained until accounting active0; no attach/replay")
    events=A/"logs/job-events.jsonl"
    try:
        with (A/"logs/vivado.stdout.bin").open("wb") as out,(A/"logs/vivado.stderr.bin").open("wb") as err,open(os.devnull,"rb") as inp,events.open("w",encoding="utf-8",newline="\n") as ev:
            info=subprocess.STARTUPINFO()
            info.dwFlags=subprocess.STARTF_USESTDHANDLES|subprocess.STARTF_USESHOWWINDOW
            info.wShowWindow=0
            for f in (out,err,inp):os.set_inheritable(f.fileno(),True)
            info.hStdInput=msvcrt.get_osfhandle(inp.fileno())
            info.hStdOutput=msvcrt.get_osfhandle(out.fileno())
            info.hStdError=msvcrt.get_osfhandle(err.fileno())
            proc_handle,thread_handle,pid,tid=_winapi.CreateProcess(str(CMD),subprocess.list2cmdline(argv),None,None,True,
                                                                 process["creationflags"],env,str(work),info)
            handles[pid]=proc_handle
            process.update(pid=pid,thread_id=tid,source_list=record(sources),assigned_to_job_before_resume=True)
            checked(AssignJob(job,proc_handle))
            save(A/"PROCESS_STARTED.json",process)
            require(Resume(thread_handle)!=0xffffffff,"ResumeThread failed")
            Close(thread_handle);thread_handle=None
            def capture(member_pid):
                if member_pid not in members:
                    members[member_pid]=dict(pid=member_pid,first_observed_utc=utc())
                if member_pid not in handles:
                    h=OpenProc(0x101000,False,member_pid)
                    if h:handles[member_pid]=h
                    else:members[member_pid]["open_handle_error"]=C.get_last_error()
                if member_pid in handles and "image" not in members[member_pid]:
                    buf=C.create_unicode_buffer(32768);size=T.DWORD(len(buf))
                    if Image(handles[member_pid],0,buf,C.byref(size)):members[member_pid]["image"]=buf.value
            capture(pid)
            while True:
                message=T.DWORD();key=SIZE();member=C.c_void_p()
                ok=GetEvent(port,C.byref(message),C.byref(key),C.byref(member),250)
                if ok:
                    row=dict(utc=utc(),message=message.value,completion_key=key.value,pid=member.value)
                    ev.write(json.dumps(row)+"\n");ev.flush()
                    if message.value in (6,7,8) and member.value:
                        capture(int(member.value))
                        if message.value in (7,8):members[int(member.value)]["exit_notification"]=message.value
                elif C.get_last_error()!=258:
                    raise C.WinError(C.get_last_error())
                for member_pid in active_pids(job):capture(member_pid)
                for member_pid,h in handles.items():
                    if Wait(h,0)==0:
                        code=T.DWORD();checked(GetExit(h,C.byref(code)))
                        members[member_pid]["exit_code"]=code.value
                acct=accounting(job)
                if acct["ActiveProcesses"]==0:break
                if time.monotonic()-started>=600:
                    timed_out=True;checked(TerminateJob(job,124))
                    process["timeout_termination"]=dict(utc=utc(),method="TerminateJobObject original owned job",exit_code=124)
                    require(Wait(proc_handle,10000)==0,"owned job timeout cleanup did not settle")
            # Drain notifications after active0; all original handles remain open.
            while True:
                message=T.DWORD();key=SIZE();member=C.c_void_p()
                if not GetEvent(port,C.byref(message),C.byref(key),C.byref(member),0):break
                ev.write(json.dumps(dict(utc=utc(),message=message.value,completion_key=key.value,pid=member.value))+"\n")
                if message.value in (6,7,8) and member.value:
                    capture(int(member.value))
                    if message.value in (7,8):members[int(member.value)]["exit_notification"]=message.value
            for member_pid,h in handles.items():
                if Wait(h,0)==0:
                    code=T.DWORD();checked(GetExit(h,C.byref(code)));members[member_pid]["exit_code"]=code.value
            process.update(ended_utc=utc(),elapsed_seconds=time.monotonic()-started,timed_out=timed_out,
                           exit_code=members[pid].get("exit_code"),job_accounting=accounting(job),
                           members=list(members.values()),active_pids_at_end=active_pids(job))
            save(A/"PROCESS.json",process)
    finally:
        if thread_handle:Close(thread_handle)
        Close(job)
        for h in handles.values():Close(h)
        Close(port)
    return process

def classify(process):
    text=(A/"logs/vivado.stdout.bin").read_bytes().decode("utf-8",errors="replace")
    err=(A/"logs/vivado.stderr.bin").read_bytes().decode("utf-8",errors="replace")
    lines=text.splitlines()+err.splitlines()
    warnings=[x for x in lines if x.startswith("WARNING:")]
    critical=[x for x in lines if x.startswith("CRITICAL WARNING:")]
    errors=[x for x in lines if x.startswith(("ERROR:","FATAL:","B06_OOC_TCL_ERROR|"))]
    markers=[x for x in text.splitlines() if x.startswith("B06_OOC_")]
    wanted=["BEGIN","USER_DATA","VERSION","PART","THREADS"]+["SOURCE_READ"]*5+["SOURCE_COUNT","SYNTH_BEGIN","SYNTH_DONE",
            "DESIGN","CLOCK","REPORT","REPORT","REPORT","REPORT","CHECKPOINT","END"]
    require([x.split("|")[0].removeprefix("B06_OOC_") for x in markers]==wanted,"marker sequence mismatch")
    require("B06_OOC_VERSION|value=2026.1" in markers,"version mismatch")
    require(f"B06_OOC_SYNTH_DONE|top={TOP}|status=complete" in markers,"synthesis not complete")
    require(markers[-1]==f"B06_OOC_END|run_id=b47|top={TOP}|status=artifact_complete","artifact marker mismatch")
    require("B06_OOC_THREADS|requested=2|actual=2" in markers,"thread count mismatch")
    require("B06_OOC_SOURCE_COUNT|count=5" in markers,"source count mismatch")
    reads=[x for x in markers if x.startswith("B06_OOC_SOURCE_READ|")]
    require(reads==[f"B06_OOC_SOURCE_READ|index={i}|path={(A/'snapshot'/Path(rel).name).as_posix()}" for i,(rel,_) in enumerate(SOURCES,1)],"source order/path mismatch")
    require(process["exit_code"]==0 and not process["timed_out"] and not errors,"actual command failure")
    require(process["job_accounting"]["ActiveProcesses"]==0 and not process["active_pids_at_end"],"job still active")
    require(len(process["members"])==process["job_accounting"]["TotalProcesses"],"incomplete process member evidence")
    require(all(isinstance(m.get("exit_code"),int) for m in process["members"]),"unknown actual child exit")
    require(all(m["exit_code"]==0 for m in process["members"] if Path(m.get("image","")).name.lower()=="vivado.exe"),"actual Vivado child nonzero")
    require(any(Path(m.get("image","")).name.lower()=="vivado.exe" for m in process["members"]),"Vivado child identity missing")
    (A/"reports").mkdir()
    exported={}
    for rel in ("reports/utilization.rpt","reports/timing_summary.rpt","reports/check_timing.rpt","reports/drc.rpt","ooc.dcp"):
        p=SHORT/rel;require(p.is_file() and p.stat().st_size>0,"required synthesis output missing "+rel)
        target=A/rel
        require(not target.exists(),"refuse overwrite "+str(target))
        shutil.copyfile(p,target);require(sha(p)==sha(target),"export hash mismatch "+rel)
        exported[rel]=dict(original=record(p),export=record(target))
    util=(A/"reports/utilization.rpt").read_text(encoding="utf-8")
    utilization={}
    for label in ("Slice LUTs","Slice Registers","DSPs","Block RAM Tile"):
        match=re.search(r"^\|\s*"+re.escape(label)+r"\*?\s*\|\s*([0-9,.]+)\s*\|",util,re.M)
        utilization[label]=match[1] if match else None
    require(all(v is not None for v in utilization.values()),"utilization parsing incomplete")
    timing=(A/"reports/timing_summary.rpt").read_text(encoding="utf-8")
    at=timing.find("WNS(ns)")
    require(at>=0,"WNS header missing")
    slack=re.search(r"^\s*(-?[0-9]+\.[0-9]+)\s+",timing[at:],re.M)
    require(slack is not None,"diagnostic WNS missing")
    check_text=(A/"reports/check_timing.rpt").read_text(encoding="utf-8")
    check_counts={name:int(count) for name,count in re.findall(r"^\d+\. checking ([a-z_]+) \((\d+)\)$",check_text,re.M)}
    drc_text=(A/"reports/drc.rpt").read_text(encoding="utf-8")
    drc_rules=[dict(rule=m[0],severity=m[1],description=m[2].strip(),checks=int(m[3])) for m in re.findall(r"^\|\s*([A-Z0-9_-]+)\s*\|\s*(Warning|Error|Critical Warning)\s*\|\s*([^|]+)\|\s*(\d+)\s*\|",drc_text,re.M)]
    drc_marker=next(x for x in markers if x.startswith("B06_OOC_REPORT|kind=drc|"))
    drc_count=int(re.search(r"\|violation_count=([0-9]+)\|",drc_marker)[1])
    diagnostics=dict(warnings=warnings,critical_warnings=critical,errors=errors,markers=markers,
                     check_timing=check_counts,drc_violation_count=drc_count,drc_rules=drc_rules,
                     nonzero_helper_exits=[m for m in process["members"] if m["exit_code"]!=0],
                     diagnostic_wns_ns=float(slack[1]),utilization=utilization,
                     io_delay_gaps="Only post-synthesis 10ns clk; no input/output delays supplied. Raw check_timing/DRC retained.",
                     tcl_mapping="Unchanged pinned qualification Tcl retains original operation33 comments/B06 markers; actual operation47 metadata is in this author result.",
                     acceptance="Diagnostic synthesis only; no timing closure or product/board acceptance.")
    save(A/"DIAGNOSTICS.json",diagnostics)
    return dict(outputs=exported,diagnostics=diagnostics)

state=dict(task="DEEPEYE-IMPLEMENTATION-20261014/v1",work="B-TRACE-FRAME-OOC-20261024-47-v1",
           operation="B-DEEPEYE-TRACE-FRAME-OOC-20261024-47",job_id="child-f2e3c7deb83249eaac6b63240dfba2b8",
           agent_id="01a16a34-b419-7942-9a7b-2b033142446b",turn_id="01a16d6d-7c5f-7ba3-b1a9-919936b1d7ac",
           parent_id="01a13b55-095b-7461-8dd5-5476a130bd82",status="in_progress",vendor_launches=0,
           contract=dict(id="DEEPEYE-HUMAN-LOCK-20261014/revision1",pin="f5989cd5defce561f9ba98e6b18fc2682945f0a2",
                         requirements_sha256="c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804",
                         ids=[f"H{i:02d}" for i in range(1,16)],frozen_design="1011259415a0916054eb580687612580bc1e5f09"),
           all_29_formal_cards="not_run",B01="not_run",B03="not_run",B06="not_run",R03="not_run",
           board="not_run; A only",motion_grant=False,timing_closure="not_claimed",part="xc7z020clg400-1",
           threads=2,clock="diagnostic10nsclk created after synthesis only",started_utc=utc(),
           python=dict(executable=sys.executable,version=sys.version,pid=os.getpid(),argv=sys.argv))
try:
    require(os.environ.get("CODEX_THREAD_ID")==state["agent_id"],"canonical agent mismatch")
    require(not (A/"RESULT.json").exists() and not SHORT.exists(),"fresh author result and short directory required")
    save(A/"RESULT.json",state)
    for p,expected in PINS.items():require(sha(p)==expected,"exact input/tool pin mismatch "+str(p))
    state["input_pins"]=[record(p) for p in PINS]
    state["native_cmd"]=record(CMD)
    state["parent45_context"]="Main reported independent746normal+106recovery+106abort and3compiledmutants. Separate qualifier repair active;45overall notaccepted at dispatch. This hardware diagnostic cannot promote45/ABI/product status."
    binding=load(R/".local/deployment/node-b/evidence/trace-frame-ooc-20261024-47/binding-private.json")
    require(binding["job_id"]==state["job_id"] and binding["native_agent_id"]==state["agent_id"],"binding mismatch")
    original={}
    for parent in (P/"evidence/acquisition/scan-lane-ooc-20261024-46/author",R/".local/b46"):
        for p in parent.rglob("*"):
            if p.is_file():original[str(p)]=sha(p)
    save(A/"ORIGINAL_EVIDENCE_BEFORE.json",original)
    (A/"snapshot").mkdir();(A/"logs").mkdir()
    for rel in [rel for rel,_ in SOURCES]+["fpga/build_qualification/ooc_qualification.tcl"]:
        target=A/"snapshot"/Path(rel).name;target.write_bytes((P/rel).read_bytes())
        require(sha(target)==PINS[P/rel],"snapshot mismatch")
    spec=R/".local/deployment/node-b/evidence/trace-frame-ooc-20261024-47/MAIN_SPEC.md"
    (A/"MAIN_SPEC.snapshot.md").write_bytes(spec.read_bytes());state["spec"]=record(spec)
    save(A/"RESULT.json",state)
    wait_idle()
    SHORT.mkdir()
    state["vendor_launches"]=1
    save(A/"RESULT.json",state)
    process=run_one();state["process"]=process
    state["synthesis_complete"]=any(x.startswith("B06_OOC_SYNTH_DONE|") for x in
        (A/"logs/vivado.stdout.bin").read_bytes().decode("utf-8",errors="replace").splitlines())
    state.update(classify(process))
    for p,expected in PINS.items():require(sha(p)==expected,"read-only pin changed "+str(p))
    require(all(sha(p)==h for p,h in original.items()),"original46 evidence changed")
    state.update(status="artifacts_complete_diagnostic_only",original46_evidence_files_unchanged=len(original))
except Exception as error:
    state.update(status="failed_preserved",error=type(error).__name__+": "+str(error),traceback=traceback.format_exc())
finally:
    state["ended_utc"]=utc()
    save(A/"RESULT.json",state)
print(json.dumps(dict(status=state["status"],vendor_launches=state["vendor_launches"],result=str(A/"RESULT.json"),
                      error=state.get("error"),diagnostics=state.get("diagnostics")),ensure_ascii=True),flush=True)
sys.exit(0 if state["status"]=="artifacts_complete_diagnostic_only" else 1)
