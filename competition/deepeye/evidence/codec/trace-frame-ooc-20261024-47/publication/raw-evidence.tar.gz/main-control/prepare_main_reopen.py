from pathlib import Path
import hashlib,json
D=Path(__file__).parent;source=D.parent/'scan-lane-ooc-20261024-46/main_reopen46.py';s=source.read_text();original=hashlib.sha256(source.read_bytes()).hexdigest()
changes=[
 ("evidence/acquisition/scan-lane-ooc-20261024-46","evidence/codec/trace-frame-ooc-20261024-47"),
 ("a=get(A/'FINAL_RESULT.json');assert a['vendor_launches']==1 and not a['vendor_replay'] and a['synthesis_complete'] and a['report_export_complete']","a=get(A/'RESULT.json');assert a['vendor_launches']==1 and a['synthesis_complete'] and a['status']=='artifacts_complete_diagnostic_only'"),
 ("for v in a['input_pins']:assert sha(Path(v['path']))==v['sha256']","for v in tr['source_pins']:assert sha(Path(v['path']))==v['sha256']\nfor v in a['input_pins']:assert sha(Path(v['path']))==v['sha256']"),
 ('eeb32fb10b50ec3633da1bd9bdc6c1d862f68df56ba9b22b012fc304f7cf4591','a2882850632f15b7777f6d06188e2f6aa66e0b103681d7653e86672f66630342'),
 ("{'Slice LUTs':97,'Slice Registers':451,'Block RAM Tile':0,'DSPs':0}","{'Slice LUTs':2430,'Slice Registers':2957,'Block RAM Tile':0,'DSPs':2}"),
 ("times['WNS']=='7.172'","times['WNS']=='0.556'"),
 ('MAIN46_','MAIN47_'),('ports=642','ports=323'),
 ("diag['console_warning_count']==2 and diag['drc_violation_count']==1 and diag['check_timing']['no_input_delay']==452 and diag['check_timing']['no_output_delay']==189","len(diag['warnings'])==10 and not diag['critical_warnings'] and not diag['errors'] and diag['drc_violation_count']==4 and diag['check_timing']['no_input_delay']==289 and diag['check_timing']['no_output_delay']==33"),
 ('B-DEEPEYE-SCAN-LANE-OOC-20261024-46','B-DEEPEYE-TRACE-FRAME-OOC-20261024-47'),
 ("'source_sha256':tr['source_sha256']","'source_pins':tr['source_pins']"),
 ("'author_driver_failure':'Initial driverexit1 aftertwofindstr.exe exits1. Preserved original process/log/result. Separate no-process collector exported existing artifacts, no vendor replay.'","'author_process_boundary':'One actual OOC;cmd/Vivado exit0, two original findstr.exe helper exits1 retained; original Windows job12members/allterminal. No vendor replay.'"),
 ('One10ns post-synth diagnostic, +7.172ns not timingclosure;2consolewarnings/1ZPS7-1DRC/452inputand189outputdelaygaps andHD.CLK_SRCunset retained.','One10ns post-synth diagnostic, +0.556ns not timingclosure;10consolewarnings/4DRC(2DPIP-1,1DPOP-2,1ZPS7-1)/289inputand33outputdelaygaps andHD.CLK_SRCunset retained.45qualifier acceptance separately pending.')
]
for old,new in changes:
 assert old in s,old
 s=s.replace(old,new)
target=D/'main_reopen47.py';assert not target.exists();target.write_text(s,encoding='utf-8')
with (D/'MAIN_REOPEN_DERIVATION.json').open('x',encoding='utf-8') as f:json.dump({'source':str(source),'sha256':original,'changes':changes,'target_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scope':'Main-defined exact47 pins and diagnostic checks, same actual DCP read/report method; no synthesis.'},f,indent=2)
print(target)
