# B TRACE payload RTL candidate: fixed main design

Task DEEPEYE-IMPLEMENTATION-20261014/version1. Work B-TRACE-PAYLOAD-RTL-20261024-38-v1. Operation B-DEEPEYE-TRACE-PAYLOAD-RTL-20261024-38. Main thread01a13b55-095b-7461-8dd5-5476a130bd82 retains design and acceptance. Main records this before reading any worker38 source. Source base0885ed48b9edc48be7fd20135e8c141a485218d4, exact published source8d69443de35585b8b8e4f8bbd499b1406f23421d.

Read all H01-H15 at contract f5989cd5defce561f9ba98e6b18fc2682945f0a2. Canonical requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804; DEEPEYE-HUMAN-LOCK-20261014/revision1. Frozen design1011259415a0916054eb580687612580bc1e5f09. Full3D/UI/solid volume collisions/freecamera/editablelayouts/equalblue-redcompletepassage/hiddentruth/causalobservations/substantiveonline3DPC AI/bothcontrolchains preserved. A alone physicalboard. All29formal remainnot_run.

## Purpose and scope

Implement ONE complete already-selected block's candidate payload in synthesizable RTL using the unchanged reviewed inner encoder. Candidate rules are the existing offline TRACE revision1 including TC01/TC02 corrections, not new public ABI. No outer header/CRC/UART, splitting/selection, sequence allocation, scheduler, BOOT, acquisition authenticity, clock/TTL or motion permission. This prepares a missing B-owned integration component while A's public TRACE acceptance remains gated.

Exact read-only dependencies:

|path relative to competition/deepeye|SHA256|
|---|---|
|fpga/codec/deepeye_block_encoder.sv|4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532|
|golden/codec/trace_candidate.py|a489ac34b49976532803b34f006f8bc24103548f34ddd55cc2ecaedc529a9642|
|golden/codec/trace_candidate_layout.json|0de9a9a303ed691c645beba2ba9d39c7eb2261a8df336ea321f5055a07436e9c|
|golden/codec/trace_candidate_vectors.json|e9fb59aa20324ebdeffb25ac89f43e42a085b3d49cec3ee9104ff551d9409bf2|
|golden/codec/TRACE_CANDIDATE.md|f702db7239082570a26856091a3131293b7df610c76d7af830415ed40a08d56b|
|golden/codec/codec_reference.py|2e24e01c7e8cc9a010f9c0f26d94091b33676b7394f0f7344ca5bf938fefbfd5|

## Fixed module interface

Module deepeye_trace_payload_candidate, no parameters. clk,rst,cancel synchronous active high as original encoder; one transaction at a time. cfg_valid/ready latch all fields atomically:
cfg_count[7:0], cfg_e[3:0] actual E value, cfg_session[31:0], cfg_channel[1:0], cfg_first_index[31:0], cfg_first_tick[63:0], cfg_index_stride[15:0], cfg_tick_stride[15:0], cfg_valid_sample, cfg_saturated, cfg_held, cfg_source_fault (each1bit), cfg_source_tick[63:0].
s_valid/s_ready,s_data[15:0],s_last supply only valid block sample words. For invalid quality-only blocks no sample is accepted. cfg contains a uniform quality mask and arithmetic acquisition progression; caller owns real provenance, not this adapter. This interface does not accept per-point varying quality or origin; callers must already split such blocks.
Output meta_valid/meta_ready, meta_error[1:0], meta_bytes[5:0], meta_tick[31:0]; m_valid/m_ready,m_data[7:0],m_last. No other ports, status counters or policy. meta_tick=low32(first_tick) on success. On any error meta_bytes=0,meta_tick=0 and NO bytes; error codes0ok,1invalidconfig,2samplelength/innererror,3payloadbudget. Error1 priority before accepting samples. Error2 before budget. Successful metadata followed by exactly meta_bytes bytehandshakes; output not visible until a whole validated <=32B payload is stored. Stable metadata/bytes under stalls. Last asserted only on final valid byte. Meta and data handshakes gated low while rst/cancel. No phantom success or old output after abort.

## Validation and algorithm fixed by main

1. Count1..128; E exactly0/1/2/4/8. For count1 require both strides0 (canonical hardware input); for count>1 require both strides1..65535. Check lastindex<=uint32max and lasttick<=uint64max with explicit widened arithmetic, never wrap. Session may be0 because existing candidate permits it. Channel hardware width already0..3.
2. Invalid block: saturated=held=0, source_tick=0. Valid fresh: source_tick=first_tick. Valid held: source_tick<first_tick. Derive age with widened subtraction; age1..65535 =>2-byte littleendian age, otherwise8-byte littleendian absolute origin with long_source_tick flag. Age cannot underflow. Same held origin for entire block.
3. Prefix follows pinned21-byte layout exactly: revision1, settings Ecode/RAW/k, qualitychannel/valid/saturated/held/sourcefault/long/reservedzero, count, significantbits, sessionLE32, firstindexLE32, firsttickLE64. Append stridesLE16x2 onlycount>1, heldextension onlyheld, thencode. All bytes including metadata+anchor+padding count toward32.
4. Invalid block is quality-only: RAW1,k0,bits0,noanchor/data; code bytes0. Budget still checked. (All legal invalid configurations here fit21or25.) No core config or sample handshake for invalid blocks.
5. Valid block uses exact frozen core to choose minimal significant-bit Rice k. Retain original accepted samples in bounded private128x16 RAM so byte-tie Rice->RAW preserves ORIGINAL samples even at E>0. Never write core RAM via hierarchy or modify core. Capture only accepted s_valid&&s_ready. Respect exact s_last; malformed final marker causes one error2 and no payload. Treat any innercore error as error2, with internal synchronous discard/reinitialization before accepting next cfg. Do not wait indefinitely for missing samples that core already rejected. Ordinary absent valid/ready may stall; no newtimeout policy.
6. Candidate stored-byte choice: Rice only if !core_raw and core_bytes < 2*count. Otherwise RAW,k0,bits=16*count from originalsamples. This is different from core bit-level choice. Core output big-endian RAW/anchor must not be copied unmodified: candidateRAW writes each original sample LE; candidateRice swaps its first two anchor bytes and leaves remaining MSB-first Rice/padding bytes unchanged. Validate/carry exactdeclared bit/byte counts; no stale reads. If metadata+chosen code exceeds32 (or bits cannot fitbyte, impliedbybudget), error3 before exposing output. A private synchronous core cancel pulse on reject is allowed; it must not leak into nexttransaction or count as externalreset. Drain/capture successful core output before exposing meta; do not leave busy core orphaned whenRAW is selected.
7. RAM need not clear on rst/cancel but everyread mustfollowwrite fromcurrenttransaction. Internal FIFOs/state finite, no combinationalunboundedloops/divisionofwidevalues/newmultiplyinthevaluepath; index/tickoverflow boundedwidth arithmetic okay. No delays/initial/fileIO/DPI inRTL. No asynchronousdomain or pinclaims. Errorhandling can take internal cycles, but cfgready muststayfalse until core and adapter ready forfreshblock.

## Worker ownership and verification

Only five write paths beneath worktree competition/deepeye:
fpga/codec/deepeye_trace_payload_candidate.sv
fpga/codec/trace_payload_candidate.md
tests/rtl/codec/tb_trace_payload_candidate.sv
tools/codec/run_trace_payload_candidate.py
evidence/codec/trace-payload-20261024-38/author/

Read-only parent spec/private lease, taskbook, dependencies and historical evidence. No edits to core/golden/layout/vector, othermain/oracles/oldlogs, publicschema/registers/A/C, services/credentials/queues or Gitpublication. No Vivado for this assignment; actual ModelSim SE-6410.7 CLI hidden on existingD:/modelsim1/win64. Python R/.local/venv/Scripts/python.exe. Newfresh evidence output, explicitcommand/argv/cwd/PID/stdout/stderr/exit/source+toolhash. Independently snapshotallinputs and before/afterprotectedhashes. Main may publish37 concurrently; pinnedsourcebytes are exactabove.

Author uses existing trace_candidate.encode_payload with supplied uniformpoints to generate exactexpected bytes, explicitly reused model. Cover manualpublishedvectors, bothbyte-tie cases [0,64] and[0,2048,4096], Eall,RAW/Rice/endian/padding/budgetjustfitandoneover,41equalfreshpoints=32B vs42exceeds, invalidquality, heldshort1/65535 andlong65536, firsttickunderflow, uint32/64endoverflow, stride/countlimits, badcfg/bads_last, distinctsamplewords provingendian, everyphasecancel/reset andfreshrecovery, metadata+bytestalls, backtoback. Compare publicports andbytes, neverDUTinternalstates as acceptanceoracle. Negative tests verify no success/bytes onerrors; preserve actualstimulus and completepublictrace includingcfgfields/samplehandshake/meta/payload. Strict anchored unique pass/completeconsistentstats from owntrace; reject missing/duplicate/conflicting/suffix/substringmarkers/truncation. At most2boundedrepair cycles; afterlimit reportrootcause/evidence instead of indefinite retries. Save allfailedattempts.

Acceptance here is author deliverable readiness only; main later freezes and executes separate reference/mutants and evaluates source. Worker must not claim product/B01/R03 acceptance or physics. Report terminal result via native_complete and supported native finalevent. No peer/group messages. [需桌面回合]/[需本人操作] only for real blockers; no serviceorcredential action. Flashmax routeactual402 preserved; nativeGit/shell+ModelSim fallback authorized, no repeatbillingretry. Keep package/scriptimports portable fromrepositorypaths; reject input/outputalias/preexistingoutput. Existingoriginalprotected dirty handoffinput remains untouched.
