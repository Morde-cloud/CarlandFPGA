from pathlib import Path
import hashlib
import json
import shutil
import sys

out=Path(__file__).resolve().parent
parent=Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/trace-payload-rtl-20261024-38/MAIN_SPEC.md')
expected='0545a23843e92f1c7f4bdeec0e268a2cbfb2a246c77c0ee7641db0162a48bc48'
if hashlib.sha256(parent.read_bytes()).hexdigest()!=expected:raise RuntimeError('main spec drift')
if (out/'MAIN_SPEC.md').exists():raise RuntimeError('no replay')
shutil.copyfile(parent,out/'MAIN_SPEC.md')
record=dict(thread_id='01a16a34-b419-7942-9a7b-2b033142446b',turn_id='01a16a74-81a4-7973-a589-e6836a661fb1',
 job_id='child-bb04a8f43c384313bc9da87067a93d1a',execution_allowed=True,spec_sha256=expected,
 initial_lease_read='Reservation envelope inspected privately; self-validation succeeded before project execution.',
 python_version=sys.version)
(out/'bootstrap.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
