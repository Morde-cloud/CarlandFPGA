"""Preserve/replay the offline ordering gap; no vendor process is launched."""
from pathlib import Path
import hashlib
import importlib.util
import json
import sys
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
name=sys.argv[1]
out=root/name
out.mkdir()
runner=root.parents[3]/'tools/codec/run_trace_payload_candidate.py'
spec=importlib.util.spec_from_file_location('trace38_checked',runner);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=root/'attempt-01'
text=(base/'logs/vsim.stdout.txt').read_bytes().decode('utf-8')
rows=(base/'public_ports.txt').read_bytes().decode('ascii').splitlines(keepends=True)
cases=json.loads((base/'cases.json').read_bytes())
tb=(base/'inputs/tb_trace_payload_candidate.sv').read_text().splitlines()
finish=next(i+1 for i,s in enumerate(tb) if '$fclose(trace_fd);$display("TP_DONE' in s)
cfg=0;index=None
for i,line in enumerate(rows):
 c=line.split()
 if c[1]!='0':break
 if cfg and c[14]!='11' and c[17]=='00':index=i;break
 if c[3]=='11':cfg+=1
if index is None:raise RuntimeError('no handshake gap row')
cols=rows[index].split();cols[17]='10';cols[18]='0';cols[19]='%02x'%(len(bytes.fromhex(cases[0]['payload_hex'])));cols[20]='%08x'%cases[0]['meta_tick']
changed=' '.join(cols)+'\n'
original_result=json.loads((base/'RESULT.json').read_bytes())
stalls=original_result['reconciliation']['summary']['metastall']
forged=text.replace('metastall=%d'%stalls,'metastall=%d'%(stalls+1))
(out/'forged.stdout.txt').write_bytes(forged.encode())
record=dict(runner_sha256=hashlib.sha256(runner.read_bytes()).hexdigest(),base_trace_sha256=hashlib.sha256((base/'public_ports.txt').read_bytes()).hexdigest(),
 recipe=dict(row=index+1,original=rows[index],replacement=changed,summary_metastall_delta=1),
 method='Insert fixture-equal stalled metadata before sample acceptance; reconcile numeric stall count. No RTL/vendor change.')
try:
 m.check_saved(forged,(changed if i==index else s for i,s in enumerate(rows)),cases,finish)
 record['false_accept']=True
except ValueError as exc:record['false_accept']=False;record['rejection']=str(exc)
(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
