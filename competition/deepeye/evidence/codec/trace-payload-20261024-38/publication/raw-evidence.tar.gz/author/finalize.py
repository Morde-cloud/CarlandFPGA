from pathlib import Path
from collections import Counter
from datetime import datetime,timezone
import hashlib,json,os,sys
out=Path(__file__).resolve().parent
def sha(path):
 h=hashlib.sha256()
 with path.open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
result=json.loads((out/'attempt-02/RESULT.json').read_bytes())
if result['status']!='author_bounded_pass' or result['exit_code']!=0:raise RuntimeError('final attempt not passed')
verified={}
for attempt in ('attempt-01','attempt-02'):
 count=0
 for name,digest in json.loads((out/attempt/'artifact_hashes.json').read_bytes()).items():
  if sha(out/attempt/name)!=digest:raise RuntimeError(attempt+' artifact drift '+name)
  count+=1
 verified[attempt]=count
for name,info in result['sources'].items():
 if sha(Path(info['path']))!=info['sha256']:raise RuntimeError('latest source drift '+name)
 info['snapshot']='attempt-02/'+info['snapshot']
for name,digest in result['protected_hashes_before'].items():
 if sha(Path(name))!=digest:raise RuntimeError('protected drift '+name)
for command in result['commands']:
 command['stdout']='attempt-02/'+command['stdout'];command['stderr']='attempt-02/'+command['stderr']
pre=json.loads((out/'pre-repair1/RESULT.json').read_bytes());post=json.loads((out/'post-repair1/RESULT.json').read_bytes())
if pre['false_accept'] is not True or post['false_accept'] is not False:raise RuntimeError('repair reproducer evidence incomplete')
cases=json.loads((out/'attempt-02/cases.json').read_bytes())
normal=[c for c in cases if c['kind']==0]
success=[c for c in normal if c['error']==0]
first=json.loads((out/'attempt-01/RESULT.json').read_bytes())
rtl='fpga/codec/deepeye_trace_payload_candidate.sv'
if first['sources'][rtl]['sha256']!=result['sources'][rtl]['sha256']:raise RuntimeError('unexpected RTL repair')
result.update({
 'quality_main_thread_id':'01a13b55-095b-7461-8dd5-5476a130bd82',
 'self_validation_execution_allowed':True,'node':'B','board_access':False,
 'evidence_scope':'Author deliverable readiness only; main independent review/acceptance remains required.',
 'changed_paths':['competition/deepeye/fpga/codec/deepeye_trace_payload_candidate.sv',
  'competition/deepeye/fpga/codec/trace_payload_candidate.md','competition/deepeye/tests/rtl/codec/tb_trace_payload_candidate.sv',
  'competition/deepeye/tools/codec/run_trace_payload_candidate.py','competition/deepeye/evidence/codec/trace-payload-20261024-38/author/'],
 'full_modelsim_attempts':2,'bounded_verification_repairs':1,'rtl_repairs':0,
 'verified_attempt_artifacts':verified,'attempt_result':'attempt-02/RESULT.json',
 'attempt_result_sha256':sha(out/'attempt-02/RESULT.json'),
 'initial_qualifier_false_accept':{'path':'pre-repair1/RESULT.json','sha256':sha(out/'pre-repair1/RESULT.json'),
  'preserved':True,'fixed_by':'require input completion and valid/data persistence under stalls'},
 'post_repair_rejection':{'path':'post-repair1/RESULT.json','sha256':sha(out/'post-repair1/RESULT.json'),
  'reason':post['rejection']},
 'functional_coverage':{'ordinary_cases':len(normal),'manual_literal_vectors':8,
  'ordinary_error_codes':dict(Counter(c['error'] for c in normal)),
  'ordinary_success_raw':sum(bool(bytes.fromhex(c['payload_hex'])[1]&8) for c in success),
  'ordinary_success_rice':sum(not bool(bytes.fromhex(c['payload_hex'])[1]&8) for c in success),
  'success_payload_lengths':sorted({len(bytes.fromhex(c['payload_hex'])) for c in success}),
  'count_and_quality_boundaries':'fixtures include manual, TC01 two ties/E>0 originals,41/42 point,held1/65535/65536,long origin,end overflow,stride/count,early/missinglast,error2-before-budget',
  'abort_strategy':'two byte modes x 171 post-last offsets x reset/cancel, config/partial division/idle/output boundaries, each followed by fresh recovery; no DUT hierarchy acceptance oracle'},
 'parser_negative_count':len(result['parser_negatives']),
 'raw_evidence':{'actual_processes':'attempt-02/RESULT.json','all_tool_stdio':'attempt-02/logs/',
  'transcript':'attempt-02/transcript.txt','full_public_ports':'attempt-02/public_ports.txt',
  'stimulus':'attempt-02/cases.txt','expected_fixtures':'attempt-02/cases.json',
  'parser_negatives':'attempt-02/negative-parser/','initial_positive':'attempt-01/RESULT.json',
  'qualification_failure':'pre-repair1/RESULT.json','repair_reason':'REPAIR1_REASON.txt'},
 'entry_commands':[
  {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
   'competition/deepeye/evidence/codec/trace-payload-20261024-38/author/bootstrap.py'],
   'exit_code':0,'stdout':'bootstrap.stdout.txt','stderr':'bootstrap.stderr.txt'},
  {'argv':first['argv'],'pid':first['pid'],'exit_code':first['exit_code'],'stdout':'attempt-01.stdout.txt','stderr':'attempt-01.stderr.txt'},
  {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
   'competition/deepeye/evidence/codec/trace-payload-20261024-38/author/check_order_gap.py','pre-repair1'],
   'exit_code':0,'stdout':'pre-repair1.stdout.txt','stderr':'pre-repair1.stderr.txt'},
  {'argv':['D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe','-B','-X','utf8',
   'competition/deepeye/evidence/codec/trace-payload-20261024-38/author/check_order_gap.py','post-repair1'],
   'exit_code':0,'stdout':'post-repair1.stdout.txt','stderr':'post-repair1.stderr.txt'},
  {'argv':result['argv'],'pid':result['pid'],'exit_code':result['exit_code'],'stdout':'attempt-02.stdout.txt','stderr':'attempt-02.stderr.txt'},
  {'argv':[sys.executable,'-B','-X','utf8',str(Path(__file__).resolve())],'pid':os.getpid(),'exit_code':0,
   'stdout':'finalize.stdout.txt','stderr':'finalize.stderr.txt'}],
 'finished_utc':datetime.now(timezone.utc).isoformat()})
dest=out/'RESULT.json'
if dest.exists():raise RuntimeError('refusing prior final result')
dest.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
hashes={f.relative_to(out).as_posix():sha(f) for f in sorted(out.rglob('*')) if f.is_file() and f.name!='artifact_hashes.json' and f.name not in ('finalize.stdout.txt','finalize.stderr.txt')}
(out/'artifact_hashes.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=result['status'],result_path=str(dest),result_sha256=sha(dest),
 source_hashes={name:info['sha256'] for name,info in result['sources'].items() if not info['protected']},
 verified_attempt_artifacts=verified,protected_dependencies=len(result['protected_hashes_before']),
 source_drift=result['source_drift'],protected_drift=result['protected_drift'],
 parser_negative_count=len(result['parser_negatives']),summary=result['reconciliation']['summary'],
 functional_coverage=result['functional_coverage']),indent=2))
