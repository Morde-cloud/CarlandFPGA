from pathlib import Path
import datetime,hashlib,json,re,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/trace-payload-20261024-38';O=E/'main/final-audit-01';O.mkdir(exist_ok=False)
def get(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
freeze=get(E/'main/preinspection-01/MAIN_FREEZE.json');author=get(E/'author/RESULT.json');audit=get(E/'main/author-audit-02/RESULT.json');positive=get(E/'main/positive-01/RESULT.json');mutants=get(E/'main/compiled-mutants-01/RESULT.json');terminal=get(D/'native-terminal.json')[1]
assert terminal['terminal'] and not terminal['stale'] and terminal['status']=='completed'
tr=json.loads(terminal['result']['text']);assert sha(Path(tr['result_path']))==tr['result_sha256']
assert freeze['author38_source_read'] is False and sha(D/'MAIN_SPEC.md')==freeze['main_spec_sha256']
for n,v in freeze['pins'].items():assert sha(P/n)==v['sha256']
for n,h in tr['source_sha256'].items():assert sha(P/n)==h
assert sha(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
assert audit['status']=='AUTHOR_EVIDENCE_RECONCILED' and audit['actual_author_commands']==30 and len(audit['probes'])==14 and not audit['false_accepts']
assert author['full_modelsim_attempts']==2 and author['bounded_verification_repairs']==1 and author['rtl_repairs']==0 and author['parser_negative_count']==16
verified=dict(audit['verified_records']);commands=[]
for n,v in verified.items():assert sha(Path(n))==v['sha256']
assert positive['status']=='PASS' and positive['score']=={'cases':746,'trace_rows':804872,'public_comparisons':23128,'byte_handshakes':10445,'complete_cfg_sample_meta_byte_history':True}
assert mutants['actual_compiled_mutants']==2 and mutants['production_unchanged']
for name in ['positive-01','mutant-byte-tie-rice','mutant-rice-anchor-endian']:
 base=E/'main'/name;a=get(base/'RESULT.json');assert a['commands']==4 and sha(base/'trace.txt')==a['trace_sha256']
 assert sha(base/'inputs/deepeye_trace_payload_candidate.sv')==a['rtl_sha256'] and sha(base/'inputs/main_tb_trace_payload_candidate.sv')==a['tb_sha256']
 assert sha(base/'inputs/deepeye_block_encoder.sv')==freeze['pins']['fpga/codec/deepeye_block_encoder.sv']['sha256']
 for stem in ['version','vlib','vlog','vsim']:
  c=get(base/(stem+'.command.json'));assert c['pid']>0 and c['exit_code']==0 and c['timeout'] is False
  for s in ['stdout','stderr']:assert sha(base/(stem+'.'+s+'.bin'))==c[s+'_sha256']
  commands.append({'path':str((base/(stem+'.command.json')).relative_to(E)),'sha256':sha(base/(stem+'.command.json')),'exit_code':c['exit_code']})
 raw=(base/'vsim.stdout.bin').read_text();assert re.search(r'^# Errors: 0, Warnings: 0$',raw,re.M) and not re.search(r'\*\* (?:Error|Fatal|Warning)',raw)
 for p in base.rglob('*'):
  if p.is_file() and not any(s in ('lib','work','__pycache__') for s in p.relative_to(base).parts) and p.suffix.lower()!='.wlf':verified[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
assert len(commands)==12
assert [(x['result']['cycle'],x['result']['case'],x['result']['reason']) for x in mutants['rows']]==[(41765,36,'payload_value'),(537,3,'payload_value')]
for stem,code in [('main-positive',0),('main-mutants',0),('author-audit',1),('author-audit2',0)]:assert int((D/(stem+'.exit.txt')).read_text(encoding='utf-8-sig').strip())==code
assert "KeyError: 'rtl'" in (D/'author-audit.stderr.txt').read_text(encoding='utf-8-sig')
contract=json.loads(subprocess.check_output(['git','-C',str(W),'show','f5989cd5defce561f9ba98e6b18fc2682945f0a2:docs/competition/deepeye-2026/immutable_scope.json']))
h=hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest();assert h==freeze['requirements_sha256']=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804' and len(contract['requirements'])==15
result={'status':'ACCEPTED_BOUNDED_TRACE_PAYLOAD_CANDIDATE_SIMULATION','accepted_candidate':True,'operation_id':'B-DEEPEYE-TRACE-PAYLOAD-RTL-20261024-38','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requirements_sha256':h,'source_sha256':tr['source_sha256'],'pins':freeze['pins'],'worker_terminal':{k:terminal[k] for k in ('job_id','native_agent_id','status','terminal','stale','updated_at')},'main':positive,'main_actual_commands':commands,'main_compiled_mutants':mutants,'author_recorded_commands':30,'author_full_modelsim_runs':2,'author_cases':1629,'author_completed':919,'author_abort_recovery_pairs':710,'author_trace_rows':282264,'author_functional_coverage':author['functional_coverage'],'author_parser_negatives':16,'main_saved_checker_negatives':14,'verified_records':verified,'failed_evidence_preserved':['Author initial checker accepted forged early stalled metadata; repaired checker rejects same saved fixture. Both actual full simulation attempts preserved; RTL unchanged.','Main author-audit-01 failed on metadata key rtl; author-audit-02 uses exact source-path key, without product reexecution.'],'source_review':['Fixed finite FSM/32-byte private payload, original128x16 samples, unchanged inner core; full payload validation before metadata; exact LE fields and Rice anchor swap.','Widened index/tick endpoint arithmetic, E/count/stride/quality/origin checks; error priority config then sample/core then budget.','Core cancel on rejected transaction, synchronous reset/discard, atomic configuration and stable stalled outputs. No new clock domain or authority.'],'acceptance_notes':['Main independently wrote Python bitstring arithmetic and field packing from fixed specification before author source inspection; no import of B golden. Existing protocol specification reused.','Post-writing crosscheck to pinned golden and eight literal manual vectors disclosed; main actual 746 RTL scenarios, complete public histories, two actual compiled mutants.','Author expected values reuse pinned golden and eight published literal vectors; final1629-case stimulus and tests are not an independent oracle.','Single already-selected uniform block only; <=32B output/error behavior is candidate payload simulation, not production TRACE/publicABI, splitting, scheduler, outer wire or authenticated source.','Operation38 synthesis/implementation/timing/CDC_RDC/board/system not_run. Prior operations actual OOC evidence remains unchanged.','All29/B01/B03/B06/R03/fullproduct not_run; physicalboardAonly.']}
put(O/'RESULT.json',result);print(json.dumps({'status':result['status'],'verified':len(verified),'main_commands':len(commands),'main_cases':746}))
