from pathlib import Path
import datetime,hashlib,json,random,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;O=P/'evidence/codec/trace-payload-20261024-38/main/preinspection-01';BASE='0885ed48b9edc48be7fd20135e8c141a485218d4'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2,ensure_ascii=False);f.write('\n')
O.mkdir(parents=True,exist_ok=False)
pins={}
for rel in ['fpga/codec/deepeye_block_encoder.sv','golden/codec/trace_candidate.py','golden/codec/trace_candidate_layout.json','golden/codec/trace_candidate_vectors.json','golden/codec/TRACE_CANDIDATE.md','golden/codec/codec_reference.py']:
 b=subprocess.check_output(['git','-C',str(W),'show',BASE+':competition/deepeye/'+rel]);assert b==(P/rel).read_bytes();target=O/Path(rel).name;target.write_bytes(b);pins[rel]={'sha256':sha(b),'bytes':len(b)}
contract=json.loads(subprocess.check_output(['git','-C',str(W),'show','f5989cd5defce561f9ba98e6b18fc2682945f0a2:docs/competition/deepeye-2026/immutable_scope.json']));h=sha(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode());assert h=='c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'
put(O/'MAIN_FREEZE.json',{'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-TRACE-PAYLOAD-MAIN-REFERENCE-20261024-38-v1','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','base_head':BASE,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requirements_sha256':h,'pins':pins,'main_spec_sha256':sha((D/'MAIN_SPEC.md').read_bytes()),'author38_source_read':False,'decision':'Independent Python bitstring arithmetic/field packing written from fixed spec before inspecting worker38; does not import B golden. Reuse of existing candidate specification disclosed. All bounded software only.'})
print(json.dumps({'frozen_pins':len(pins),'main_spec':sha((D/'MAIN_SPEC.md').read_bytes()),'directory':str(O)}))
