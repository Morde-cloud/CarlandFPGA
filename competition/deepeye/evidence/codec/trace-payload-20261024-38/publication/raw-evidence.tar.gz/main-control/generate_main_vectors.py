from pathlib import Path
import hashlib,importlib.util,json,random,sys
from main_reference import default_config,expected,config_ok,hand_checks
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;O=P/'evidence/codec/trace-payload-20261024-38/main/preinspection-01'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,indent=2);f.write('\n')
(O/'main_reference.py').write_bytes((D/'main_reference.py').read_bytes());hand_checks()
spec=importlib.util.spec_from_file_location('main38_existing_golden',O/'trace_candidate.py');gold=importlib.util.module_from_spec(spec);spec.loader.exec_module(gold)
cases=[]
def add(name,c,x,bad=None):cases.append({'id':len(cases),'name':name,'cfg':c,'samples':x,'bad_last':bad,'expected':expected(c,x,bad)})
for e in [0,1,2,4,8]:
 for count in [1,2,3,4,7,8,9,40,41,42,127,128]:
  for pattern in ['constant','ramp','alternating']:
   x=[0x1234]*count if pattern=='constant' else [min(65535,10000+i*7) for i in range(count)] if pattern=='ramp' else [0 if i%2 else 65535 for i in range(count)]
   add(f'{pattern}-e{e}-n{count}',default_config(count,e),x)
 add('byte-tie-original-e'+str(e),default_config(2,e),[0,64*(2*e+1)+e])
for age in [1,2,65535,65536,100000,0xffffffffffffffff]:
 for n in [1,2,3,41]:
  c=default_config(n);c.update(tick=age,source_tick=0,held=1);add(f'held-{age}-{n}',c,[1234]*n)
for valid in [0,1]:
 for sat in [0,1]:
  for held in [0,1]:
   for fault in [0,1]:
    for channel in range(4):
     c=default_config(3);c.update(valid=valid,saturated=sat,held=held,source_fault=fault,channel=channel,source_tick=99999 if held else 100000 if valid else 0);add(f'flags-{valid}{sat}{held}{fault}-{channel}',c,[12,12,12] if valid else [])
for n in [0,1,2,127,128,129,255]:
 for e in [0,3,5,8,15]:
  c=default_config(n,e);add(f'count-e-{n}-{e}',c,[32]*n)
for f,values in [('index',[0,0xffffffff,0xfffffffe]),('tick',[0,0xffffffff,0x100000000,0xfffffffffffffffe,0xffffffffffffffff]),('index_stride',[0,1,65535]),('tick_stride',[0,1,65535])]:
 for v in values:
  for n in [1,2,128]:
   c=default_config(n);c[f]=v
   if f=='tick':c['source_tick']=v
   add(f'bound-{f}-{v}-{n}',c,[0x1234]*n)
for n in [1,2,3,41,128]:
 for bad in sorted({0,n//2,n-1}):add(f'last-error-{n}-{bad}',default_config(n),[100+i for i in range(n)],bad)
rng=random.Random(2026102438)
for i in range(384):
 n=rng.choice([1,2,3,4,5,8,32,40,41,42,127,128]);c=default_config(n,rng.choice([0,1,2,4,8]));c.update(session=rng.getrandbits(32),channel=rng.randrange(4),index=rng.getrandbits(24),tick=rng.getrandbits(48));c['source_tick']=c['tick'];pattern=i%4
 if pattern==0:x=[rng.randrange(65536)]*n
 elif pattern==1:
  a=rng.randrange(32768);x=[a+j%7 for j in range(n)]
 elif pattern==2:x=[rng.randrange(65536) for _ in range(n)]
 else:x=[max(0,min(65535,65530-((j%3)*13))) for j in range(n)]
 add('random-'+str(i),c,x)
cross=0;budget=0
for v in cases:
 c=v['cfg'];a=v['expected']
 if not config_ok(c) or v['bad_last'] is not None:continue
 points=[dict(index=c['index']+i*c['index_stride'],tick_ms=c['tick']+i*c['tick_stride'],value=v['samples'][i] if c['valid'] else None,valid=bool(c['valid']),saturated=bool(c['saturated']),held=bool(c['held']),source_fault=bool(c['source_fault']),source_tick_ms=c['source_tick'] if c['held'] else c['tick']+i*c['tick_stride'] if c['valid'] else None) for i in range(c['count'])]
 try:b=gold.encode_payload(points,dict(session=c['session'],config_epoch=0,e=c['e']),c['channel'])
 except gold.TraceError:
  assert a['error']==3,v['name'];budget+=1
 else:assert a['error']==0 and list(b)==a['bytes'],v['name'];cross+=1
fields=['count','e','session','channel','index','tick','index_stride','tick_stride','valid','saturated','held','source_fault','source_tick']
with (O/'main_vectors.txt').open('x',encoding='ascii') as f:
 for v in cases:
  c=v['cfg'];a=v['expected'];numbers=[v['id']]+[c[k] for k in fields]+[0xffffffff if v['bad_last'] is None else v['bad_last'],a['error'],len(a['bytes']),a['tick'],len(v['samples'])]+v['samples']+a['bytes'];f.write(' '.join(format(x,'x') for x in numbers)+'\n')
put(O/'main_vectors.json',{'cases':cases,'format_fields':fields,'main_reference_sha256':sha((O/'main_reference.py').read_bytes()),'golden_crosscheck_success':cross,'golden_crosscheck_budget_rejections':budget,'hand_checks':8,'vectors_txt_sha256':sha((O/'main_vectors.txt').read_bytes()),'scope':'Preinspection independent bitstring oracle written without imports from golden; then exactpublished offlinegolden crosscheck. No author38 source read, no RTL execution yet.'});print(json.dumps({'cases':len(cases),'cross_success':cross,'cross_budget':budget,'reference_sha256':sha((O/'main_reference.py').read_bytes()),'vectors_sha256':sha((O/'main_vectors.txt').read_bytes())}))
