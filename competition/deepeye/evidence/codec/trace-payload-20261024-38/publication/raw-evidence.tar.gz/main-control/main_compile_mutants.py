from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/trace-payload-20261024-38/main';O=E/'compiled-mutants-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
core=P/'fpga/codec/deepeye_trace_payload_candidate.sv';source=core.read_text();assert sha(core)=='fb64ace453c451838110c81bf6cb4a815a96fb2668e28a306ff699beca5acef6'
mutations=[('byte-tie-rice', 'choose_raw = c_raw || (c_bytes >= raw_bytes);','choose_raw = c_raw || (c_bytes > raw_bytes);'),('rice-anchor-endian','if (drain_index==0) store_address={4\'d0,metadata_length}+10\'d1;','if (drain_index==0) store_address={4\'d0,metadata_length};')]
rows=[]
for name,before,after in mutations:
 assert source.count(before)==1
 q=O/(name+'.sv');q.write_text(source.replace(before,after),encoding='utf-8');argv=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(D/'main_run_trace38.py'),'--name','mutant-'+name,'--mutant',str(q)]
 (O/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'source_sha256':sha(core),'mutant_sha256':sha(q)},indent=2));p=subprocess.run(argv,cwd=R,capture_output=True);(O/(name+'.stdout.bin')).write_bytes(p.stdout);(O/(name+'.stderr.bin')).write_bytes(p.stderr);r=json.loads((E/('mutant-'+name)/'RESULT.json').read_bytes());rows.append({'name':name,'exit_code':p.returncode,'result':r,'mutant_sha256':sha(q)});assert p.returncode==0 and r['status']=='EXPECTED_COMPILED_REJECTION';assert sha(core)=='fb64ace453c451838110c81bf6cb4a815a96fb2668e28a306ff699beca5acef6'
(O/'RESULT.json').write_text(json.dumps({'actual_compiled_mutants':2,'rows':rows,'production_unchanged':True},indent=2));print(json.dumps(rows))
