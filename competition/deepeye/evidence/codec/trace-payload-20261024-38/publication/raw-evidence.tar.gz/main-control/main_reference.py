"""Independent main38 bit-string and field oracle, no B codec imports.

The existing candidate spec is reused; this is not a new public ABI.
Read no author38 code when deriving this model. Inputs here are finite fixtures.
"""
def default_config(count,e=0):
 return dict(count=count,e=e,session=0x78563412,channel=2,index=17,tick=100000,index_stride=1 if count>1 else 0,tick_stride=10 if count>1 else 0,valid=1,saturated=0,held=0,source_fault=0,source_tick=100000)

def config_ok(c):
 n=c['count']
 if n<1 or n>128 or c['e'] not in (0,1,2,4,8):return False
 if n==1 and (c['index_stride']!=0 or c['tick_stride']!=0):return False
 if n>1 and (c['index_stride']==0 or c['tick_stride']==0):return False
 if c['index']+(n-1)*c['index_stride']>0xffffffff or c['tick']+(n-1)*c['tick_stride']>0xffffffffffffffff:return False
 if not c['valid']:return not(c['saturated'] or c['held'] or c['source_tick'])
 return c['source_tick']<c['tick'] if c['held'] else c['source_tick']==c['tick']

def expected(c,x,bad_last=None):
 if not config_ok(c):return {'error':1,'tick':0,'bytes':[]}
 n=c['count'];e=c['e'];valid=c['valid']
 if valid and (len(x)!=n or bad_last is not None):return {'error':2,'tick':0,'bytes':[]}
 code=[];raw=1;k=0;bits=0;zs=[]
 if valid:
  pred=x[0]
  for cur in x[1:]:
   q=(cur-pred+e)//(2*e+1);zs.append(q*2 if q>=0 else -q*2-1);pred=max(0,min(65535,pred+q*(2*e+1)))
  best=None
  for candidate in range(16):
   if any((z>>candidate)>31 for z in zs):continue
   significant=16+sum((z>>candidate)+1+candidate for z in zs)
   if best is None or significant<best[0]:best=(significant,candidate)
  if best is not None and (best[0]+7)//8 < 2*n:
   bits,k=best;raw=0;body=''.join('0'*(z>>k)+'1'+(format(z&((1<<k)-1),'0'+str(k)+'b') if k else '') for z in zs);body+='0'*((-len(body))%8);code=[x[0]&255,x[0]>>8]+[int(body[i:i+8],2) for i in range(0,len(body),8)]
  else:
   bits=16*n;code=[v for sample in x for v in (sample&255,sample>>8)]
 age=c['tick']-c['source_tick'] if c['held'] else 0;long_age=int(bool(c['held']) and age>65535)
 quality=c['channel']|(valid<<2)|(c['saturated']<<3)|(c['held']<<4)|(c['source_fault']<<5)|(long_age<<6)
 prefix=[1,(0,1,2,4,8).index(e)|(raw<<3)|(k<<4),quality,n,bits]
 for field,width in [('session',4),('index',4),('tick',8)]:prefix+=list(c[field].to_bytes(width,'little'))
 if n>1:prefix+=list(c['index_stride'].to_bytes(2,'little'))+list(c['tick_stride'].to_bytes(2,'little'))
 if c['held']:prefix+=list((c['source_tick'] if long_age else age).to_bytes(8 if long_age else 2,'little'))
 payload=prefix+code
 if len(payload)>32:return {'error':3,'tick':0,'bytes':[]}
 assert 21<=len(payload)<=32 and bits<=255 and len(code)==(bits+7)//8
 return {'error':0,'tick':c['tick']&0xffffffff,'bytes':payload,'raw':raw,'k':k,'significant_bits':bits,'code_bytes':len(code),'quality':quality}

def hand_checks():
 c=default_config(1);c.update(session=0x04030201,index=0x08070605,tick=0x100f0e0d0c0b0a09,source_tick=0x100f0e0d0c0b0a09,channel=3)
 assert bytes(expected(c,[0x1234])['bytes']).hex()=='01080701100102030405060708090a0b0c0d0e0f103412'
 c=default_config(2);a=expected(c,[0,64]);assert a['raw']==1 and a['bytes'][-4:]==[0,0,64,0] and a['significant_bits']==32
 c=default_config(3);a=expected(c,[0,2048,4096]);assert a['raw']==1 and a['bytes'][-6:]==[0,0,0,8,0,16]
 c=default_config(41);a=expected(c,[0x1234]*41);assert len(a['bytes'])==32 and a['raw']==0 and a['k']==0 and a['significant_bits']==56 and a['bytes'][-7:]==[0x34,0x12,255,255,255,255,255]
 c=default_config(42);assert expected(c,[0x1234]*42)['error']==3
 c=default_config(1);c.update(valid=0,source_tick=0,channel=0);assert expected(c,[])['bytes'][:5]==[1,8,0,1,0] and len(expected(c,[])['bytes'])==21
 c=default_config(1);c.update(held=1,source_tick=99999);assert expected(c,[0x1234])['bytes'][-4:]==[1,0,0x34,0x12]
 c.update(source_tick=34464);assert len(expected(c,[0x1234])['bytes'])==31 and expected(c,[0x1234])['quality']&64
 return 8
