"""Read/cross-hash actual outputs only; never reopen Vivado or alter its result."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
import hashlib,json,re,sys,os
out=Path(__file__).resolve().parent
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
driver=out/'RESULT.json';r=json.loads(driver.read_bytes())
if r['status']!='author_artifact_complete' or r['exit_code']!=0 or r['vendor_invocations']!=1:
 raise RuntimeError('single-run artifact completion missing')
p=r['process']
if p['exit_code']!=0 or p['timed_out'] or not p['all_observed_processes_stopped'] or p['monitor_errors']:
 raise RuntimeError('actual terminal process evidence incomplete')
verified=[]
for name,item in r['artifacts'].items():
 if sha(Path(item['original']))!=item['sha256'] or sha(out/item['copy'])!=item['sha256']:
  raise RuntimeError('artifact changed: '+name)
 verified.append(name)
for path,digest in r['protected_hashes_before'].items():
 if sha(Path(path))!=digest:raise RuntimeError('protected drift '+path)
tools_after={name:sha(Path(name)) for name in r['tools']}
if any(digest!=r['tools'][name]['sha256'] for name,digest in tools_after.items()):raise RuntimeError('tool drift')
util_text=(out/'run/reports/utilization.rpt').read_text(errors='replace')
util={}
for line in util_text.splitlines():
 m=re.fullmatch(r'\|\s*(Slice LUTs\*?|Slice Registers|Block RAM Tile|DSPs|Bonded IOB)\s*\|\s*([0-9.]+)\s*\|.*',line)
 if m:
  key=m[1].rstrip('*')
  if key in util:raise RuntimeError('duplicate utilization field '+key)
  util[key]=m[2]
if set(util)!={'Slice LUTs','Slice Registers','Block RAM Tile','DSPs','Bonded IOB'}:raise RuntimeError('missing utilization field')
drc_text=(out/'run/reports/drc.rpt').read_text(errors='replace');drc=[]
for line in drc_text.splitlines():
 m=re.fullmatch(r'\|\s*([A-Z0-9]+-[0-9]+)\s*\|\s*(Warning|Critical Warning|Error)\s*\|\s*([^|]+)\|\s*([0-9]+)\s*\|',line)
 if m:drc.append(dict(rule=m[1],severity=m[2],description=m[3].strip(),count=int(m[4])))
if sum(d['count'] for d in drc)!=7:raise RuntimeError('DRC summary counter conflict')
driver_manifest=json.loads((out/'artifact_hashes.json').read_bytes())
for name,digest in driver_manifest.items():
 if sha(out/name)!=digest:raise RuntimeError('driver evidence hash changed '+name)
final=dict(r)
final.update(driver_result=dict(path=str(driver),sha256=sha(driver)),
 finalization_scope='Offline report extraction/hash verification only; no additional Vivado command or DCP reopen.',
 utilization=util,utilization_parser_note='Supplementary extraction accepts the literal Slice LUTs* footnote label; original driver RESULT and reports preserved unchanged.',
 drc_summary=drc,drc_violation_count=sum(d['count'] for d in drc),warnings_waived=False,
 warnings_index=dict(path=str(out/'WARNINGS.json'),sha256=sha(out/'WARNINGS.json'),
                    occurrences_by_file=dict(Counter(w['file'] for w in r['warnings']))),
 tool_hashes_after=tools_after,verified_artifacts=verified,verified_driver_manifest_files=len(driver_manifest),
 expected_dcp_reopen_by_main='not_run_by_worker',
 changed_paths=[str(out),'D:/pynq/CarlandFPGA/.local/b40'],
 finalizer=dict(argv=[sys.executable,'-B','-X','utf8',str(Path(__file__).resolve())],pid=os.getpid(),parent_pid=os.getppid(),exit_code=0),
 finished_utc=datetime.now(timezone.utc).isoformat())
dest=out/'FINAL_RESULT.json'
if dest.exists():raise RuntimeError('refusing existing final result')
dest.write_text(json.dumps(final,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
manifest={f.relative_to(out).as_posix():sha(f) for f in sorted(out.rglob('*')) if f.is_file() and f.name not in ('FINAL_ARTIFACT_HASHES.json','finalize.stdout.txt','finalize.stderr.txt')}
(out/'FINAL_ARTIFACT_HASHES.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=final['status'],result_path=str(dest),result_sha256=sha(dest),
 driver_result_sha256=sha(driver),wns_ns=final['timing_wns_ns'],utilization=util,drc_summary=drc,
 drc_violations=final['drc_violation_count'],dcp=final['artifacts']['ooc.dcp'],
 stopped_processes=[dict(pid=z['pid'],parent_pid=z['parent_pid'],executable=z['executable'],exit_code=z.get('exit_code'),stopped=z['stopped']) for z in p['descendants']],
 process_duration_seconds=p['duration_seconds'],verified_driver_manifest_files=len(driver_manifest),
 check_timing_categories=r.get('check_timing_categories')),indent=2))
