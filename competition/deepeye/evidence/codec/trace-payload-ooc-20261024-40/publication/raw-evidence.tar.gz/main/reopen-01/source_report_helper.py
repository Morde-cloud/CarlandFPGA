from pathlib import Path
import datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/build/ooc-20261024-33'
out=E/'main/independent-artifact-audit-01';out.mkdir(parents=True,exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def tclpath(p):return '{'+p.as_posix()+'}'
a=E/'author/main-execution-01';b=E/'author/main-mailbox-recovery-01'
ra=json.loads((a/'RESULT.json').read_bytes());rb=json.loads((b/'RESULT.json').read_bytes());assert ra['totals']['artifacts_complete']==18 and rb['totals']['artifacts_complete']==1
assert rb['runs'][0]['top']=='deepeye_snapshot_mailbox' and rb['runs'][0]['markers']['clocks']==['src_clk','dst_clk']
allruns=[(a,x) for x in ra['runs'][:-1]]+[(b,rb['runs'][0])];assert len({r['top'] for _,r in allruns})==19
verified={}
def visit(x):
 if isinstance(x,dict):
  if isinstance(x.get('path'),str) and re.fullmatch('[0-9a-f]{64}',str(x.get('sha256',''))):
   p=Path(x['path']);assert p.is_file(),p;h=sha(p);assert h==x['sha256'],p
   if 'size' in x:assert p.stat().st_size==x['size'],p
   verified[str(p)]={'sha256':h,'bytes':p.stat().st_size}
  for v in x.values():visit(v)
 elif isinstance(x,list):
  for v in x:visit(v)
visit(ra);visit(rb)
def table(p):
 text=p.read_text(errors='strict');result={}
 for l in text.splitlines():
  if l.startswith('|'):
   z=[s.strip().rstrip('*') for s in l.split('|')[1:-1]]
   if len(z)>1 and z[1].isdigit():result[z[0]]=int(z[1])
 return {k:result[k] for k in ['Slice LUTs','Slice Registers','Block RAM Tile','DSPs'] if k in result}
def timing(p):
 lines=p.read_text().splitlines();i=next(i for i,s in enumerate(lines) if 'WNS(ns)' in s);v=lines[i+2].split();assert len(v)==12,(p,v)
 return dict(zip(['WNS','TNS','setup_failing_endpoints','setup_endpoints','WHS','THS','hold_failing_endpoints','hold_endpoints','WPWS','TPWS','pulse_failing_endpoints','pulse_endpoints'],v))
rows=[]
for parent,r in allruns:
 assert r['exit_code']==0 and r['status']=='artifact_complete' and not r['failures'],r['top'];run=parent/'runs'/r['run_id']
 proc=json.loads((run/'PROCESS.json').read_bytes());assert proc['pid']==r['pid'] and proc['exit_code']==0 and not proc['timed_out']
 diag=json.loads((run/'DIAGNOSTICS.json').read_bytes());assert not diag['critical_warnings'] and not diag['error_lines'] and not diag['marker_validation_failures']
 stdout=(run/'vivado.stdout.bin').read_text();assert 'B06_OOC_END|run_id='+r['run_id']+'|top='+r['top']+'|status=artifact_complete' in stdout
 assert not re.search(r'^\s*(ERROR:|CRITICAL WARNING:)',stdout,re.M)
 drc=(run/'reports/drc.rpt').read_text();rules=re.findall(r'^\s*([A-Z][A-Z0-9]+-\d+)#\d+\s+(Warning|Error|Critical Warning)\s*$',drc,re.M)
 assert len(rules)==r['engineering_findings']['drc_violation_count'],(r['top'],rules)
 checks=dict(re.findall(r'^\d+\. checking ([a-z_]+) \((\d+)\)',(run/'reports/check_timing.rpt').read_text(),re.M))
 rows.append({'top':r['top'],'run_dir':str(run),'source_sha256':r['source_sha256'],'pid':r['pid'],'process_sha256':sha(run/'PROCESS.json'),'dcp_sha256':sha(run/'ooc.dcp'),'port_count':r['markers']['design_port_count'],'clock_ports':r['markers']['clocks'],'warnings':r['diagnostics']['warning_count'],'drc':rules,'utilization':table(run/'reports/utilization.rpt'),'timing':timing(run/'reports/timing_summary.rpt'),'check_timing':checks})
negative=[x['top'] for x in rows if x['timing']['WNS']!='NA' and float(x['timing']['WNS'])<0]
put(out/'REPORT_READBACK.json',{'executed_tops':19,'original_full_run_exit':1,'mailbox_recovery_exit':0,'rows':rows,'negative_WNS':negative,'verified_record_files':verified,'scope':'synthesis diagnostics only, all29formal/B06/timingclosure/CDC/system not_run; do not sum nestedmodule resource counts'})
selected=[x for x in rows if x['top'] in ('deepeye_block_encoder','deepeye_block_stream','deepeye_crc16_byte','deepeye_snapshot_mailbox')];assert len(selected)==4
lines=['set_param general.maxThreads 2','puts "MAIN_DCP_REOPEN_BEGIN|count=4"']
for x in selected:
 q=out/x['top'];q.mkdir();dcp=Path(x['run_dir'])/'ooc.dcp'
 lines+=['open_checkpoint '+tclpath(dcp),'puts "MAIN_DCP_DESIGN|top='+x['top']+'|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"','foreach c [get_clocks] {puts "MAIN_DCP_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}','report_utilization -file '+tclpath(q/'utilization.rpt'),'report_timing_summary -file '+tclpath(q/'timing_summary.rpt'),'close_design']
lines+=['puts "MAIN_DCP_REOPEN_END|count=4"','exit 0'];script=out/'reopen.tcl';script.write_text('\n'.join(lines)+'\n')
env=os.environ.copy();tmp=out/'tmp';tmp.mkdir();cache=out/'cache';cache.mkdir();work=out/'work';work.mkdir()
for k in ('TEMP','TMP','TMPDIR'):env[k]=str(tmp)
env['XILINX_LOCAL_USER_DATA']=str(cache)
argv=[r'C:\Windows\System32\cmd.exe','/d','/c',r'D:\pynq\AMD2026\2026.1\Vivado\bin\vivado.bat','-mode','batch','-nojournal','-nolog','-notrace','-source',str(script)]
put(out/'REOPEN_INTENT.json',{'argv':argv,'cwd':str(work),'script_sha256':sha(script),'selected_dcps':[{k:x[k] for k in ['top','run_dir','dcp_sha256']} for x in selected],'limits':'read/open4checkpoints, reportonly, no synthesis/implementation/board','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
start=time.monotonic();p=subprocess.Popen(argv,cwd=work,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(out/'REOPEN_STARTED.json',{'pid':p.pid,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
timed=False
try:stdout,stderr=p.communicate(timeout=240)
except subprocess.TimeoutExpired:
 timed=True;p.kill();stdout,stderr=p.communicate()
(out/'reopen.stdout.bin').write_bytes(stdout);(out/'reopen.stderr.bin').write_bytes(stderr)
rec={'pid':p.pid,'argv':argv,'exit':p.returncode,'timed_out':timed,'seconds':time.monotonic()-start,'stdout_sha256':sha(out/'reopen.stdout.bin'),'stderr_sha256':sha(out/'reopen.stderr.bin')};put(out/'REOPEN_PROCESS.json',rec);assert p.returncode==0 and not timed,rec
text=stdout.decode();assert not re.search(r'^\s*(ERROR:|CRITICAL WARNING:)',text,re.M)
markers=[l for l in text.splitlines() if l.startswith('MAIN_DCP_')];assert markers[0]=='MAIN_DCP_REOPEN_BEGIN|count=4' and markers[-1]=='MAIN_DCP_REOPEN_END|count=4'
for x in selected:
 expected='MAIN_DCP_DESIGN|top='+x['top']+'|part=xc7z020clg400-1|ports='+str(x['port_count'])+'|clocks='+str(len(x['clock_ports']));assert markers.count(expected)==1,(expected,markers)
 q=out/x['top'];assert table(q/'utilization.rpt')==x['utilization'];assert timing(q/'timing_summary.rpt')==x['timing'];assert sha(Path(x['run_dir'])/'ooc.dcp')==x['dcp_sha256']
put(out/'RESULT.json',{'accepted':'19bounded OOC synthesis artifacts, engineering limitations retained','reviewed_files':len(verified),'actual_reopened_dcps':4,'reopen_exit':p.returncode,'timing_resources_match':True,'negative_WNS':negative,'all29formal':'not_run','no_implementation_or_board':True,'markers':markers,'report_readback_sha256':sha(out/'REPORT_READBACK.json'),'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()})
print(json.dumps({'out':str(out),'reviewed_files':len(verified),'reopened':4,'negative_WNS':negative}))
