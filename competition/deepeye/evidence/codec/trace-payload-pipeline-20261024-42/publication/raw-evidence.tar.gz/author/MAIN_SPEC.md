# Main42 design: staged configuration validation candidate

Task DEEPEYE-IMPLEMENTATION-20261014/version1; work B-TRACE-PAYLOAD-PIPELINE-20261024-42-v1; operation B-DEEPEYE-TRACE-PAYLOAD-PIPELINE-20261024-42. Main01a13b55-095b-7461-8dd5-5476a130bd82 owns optimization design, decisions and final independent evaluation. Existing worker40 completed terminal/stalefalse and Appidle; new explicit42, no replay or source takeover.

Read all H01-H15 at f5989cd5defce561f9ba98e6b18fc2682945f0a2, DEEPEYE-HUMAN-LOCK-20261014/revision1. Canonical requirements c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804; design1011259415a0916054eb580687612580bc1e5f09. Full3D/UI/solidcollision/freecamera/layout/equalgates/fullpassage/hidden-truth/causal-observation/online3DPC-AI/bothcontrolchains unchanged. All29formalnot_run,A-onlyphysicalboard.

Evidence-backed problem:40 actual single OOC and main DCP reopen agree WNS-4.073ns,2273LUT/2743FF/2DSP,7DRCwarnings. Main critical_paths.rpt SHA50b4ae5bcc602daeded3db0b062840cb8cfd2d7f63b804278864ab572d7da5f1 shows count_q_reg[0] -> unpipelined span DSP -> widened endpoint carry -> metadata/control CE,25logic levels/13.820ns. DCP261b1d5a5363596659366277437e80206f4ccc7dbfb851fc011fef2785a1ff7e. This is post-synthesis diagnostic, no timingclosure claim.

Exact read-only baseline PR30bf60e80927ed38511d30ffe96ebd419fae0a275c/source879f0af84aba596e11185df86f6722999e640673:
- fpga/codec/deepeye_trace_payload_candidate.sv fb64ace453c451838110c81bf6cb4a815a96fb2668e28a306ff699beca5acef6
- fpga/codec/deepeye_block_encoder.sv 4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532
- Existing original38 spec/pinnedgolden/author evidence are read-only reused inputs; no changing published candidate/core/golden/othermain files.

Implement new module deepeye_trace_payload_timing_candidate in its own file. Copy exact original38 module behavior, rename top, then make ONLY the following main-selected preflight staging change. Same port header, byte layout, error priority/values and backpressure/reset/cancel behavior. cfg handshake to readiness can add exactly two internal cycles; do not claim cycle-equivalence. No other optimization or arithmetic/protocol changes.

Keep original states0..10 and four-bit state. Add SPAN=11 and ENDPOINT=12. On successful cfg handshake latch originalfields unchanged and goSPAN instead ofCHECK. SPAN clocks into registers: (a) two24-bit products using exact original8-bit unsigned(count_q-1)*16-bitstride expressions; (b)65-bit age={0,tick}-{0,source}; (c) basic_bad flag for all original count/E/stride/quality/source-origin checks EXCEPT endpointcarry. Basicbad true for count0/>128; these illegalcounts may still compute products (max255*65535 fits24) but never acceptsample/output. For count1 requirezero strides; forcount>1 requirepositive strides. Invalidquality/saturated/held/sourcezero andfresh/heldsource rules identical. SPAN->ENDPOINT.

ENDPOINT uses registered products and computes widened33-bit index+span and65-bit tick+span, clocks their top carry bits into dedicatedoverflow flags, then->CHECK. Products and age/basicbad must stay unchanged throughthis edge. CHECK rejects if basic_bad OR (count_q>1 && either endpointoverflow). It otherwise performs original successfulCHECK work using registeredage, including metadata_length,long_q,short_age. All remaining FSM/data-path logic stays identical. Reset/cancel initialize everynewregister; gates stilllowonassertedreset/cancel. No coreconfig/sampleaccept duringSPAN/ENDPOINT/CHECK, no stale metadata afterabort. Originalcore reset/discard staysunchanged. No dynamicparameters/newclocks/domains/attributes/constraintswaivers/unboundedloops.

Exclusive writes relative currentimplementation worktree:
competition/deepeye/fpga/codec/deepeye_trace_payload_timing_candidate.sv
competition/deepeye/fpga/codec/trace_payload_timing_candidate.md
competition/deepeye/tests/rtl/codec/tb_trace_payload_timing_candidate.sv
competition/deepeye/tools/codec/run_trace_payload_timing_candidate.py
competition/deepeye/evidence/codec/trace-payload-pipeline-20261024-42/author/
And sole short vendor output D:/pynq/CarlandFPGA/.local/b42/.
No original38/39runner/C/41/40 or main-owned file edits. Main maypublish other bounded evidence concurrently; exact sourcepins above remain authoritative.

Author functional check: reuse original38 vectors/golden explicitly, complete payload/metadata/error comparisons through public ports, preserve exact rawtrace. Adapt testbench to newmodulename/latency; cover reset+cancel on each newlyadded preflight edge, invalid configuration priorities andfreshrecovery, existing RAW/Rice/byte-tie/endian/padding/held/overflow/budget/stalls. Do not import main42oracle (noneassigned) or claim oldvectorsnewindependence. Strict anchored unique markers pluscompleteconsistent simulator termination; final source/TB/toolhashes/commands/PIDs/exits. Atmost2boundedfunctionalfix cycles, preservingeachactualfailure. If stillfails stop andreport.

Only if functional run passes, execute exactly ONE new candidate OOC run (no baseline40 rerun) with unchanged Tcl SHA54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9, topdeepeye_trace_payload_timing_candidate,2exactRTLinputs,xc7z020clg400-1,clk10nsdiagnostic,maxThreads2. SameVivado2026.1batSHAa5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b/exe3a4e9e3f03d20cd1994dc2eff44566af7a10eaaae04429e9d460bffe3b0e86e4. Use short.local/b42 work/tmp/cache env childonly, hidden cmd.exe /d /c. No existing directoryoverwrite.600sbounded actualprocesswait, preservefulltree/terminal/exits/reports/DCP/hashes like40. No automatictimingrepair/secondOOC/implementation/place-route/bitstream. NegativeWNS/warningsmustremain. Main independently compares/reopenslater; candidateisnotadoptedbyworker.

No service/config/credentials/queue/Gitpublication/peer/group/board. NativeWindowsvendor/Python tools fallback afteractualFlash402 twice, no billingretry. Newleaseselfvalidate canonicalthreadfirst, native_complete actualevidence thenfinal. PublicTRACEABI/type7/BOOT/sourceclock/movement permissions remainoutofscope; all29/B01/B06/R03fullproductnot_run. Report realdesktop/humanblockers onlyifactual.
