"""Mechanical implementation of the exact main42 selected staging design."""
from pathlib import Path
import hashlib,json,difflib,shutil
out=Path(__file__).resolve().parent
p=out.parents[3]
root=Path('D:/pynq/CarlandFPGA')
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def need(value,message):
 if not value:raise RuntimeError(message)
pins={
 'fpga/codec/deepeye_trace_payload_candidate.sv':'fb64ace453c451838110c81bf6cb4a815a96fb2668e28a306ff699beca5acef6',
 'fpga/codec/deepeye_block_encoder.sv':'4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532',
 'tests/rtl/codec/tb_trace_payload_candidate.sv':'6cd065e03695f345f7540cd0107e9f3acbb72ff12b131ca8cbae204f03b50dfa',
 'tools/codec/run_trace_payload_candidate.py':'f7a100a2f49ef028b6bec375fc66e86093203e1e74b6ede3f5352a2156e9439f',
 'fpga/build_qualification/ooc_qualification.tcl':'54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9'}
need(not(out/'BUILD.json').exists(),'no builder replay')
for rel,digest in pins.items():need(sha(p/rel)==digest,'baseline pin drift '+rel)
new_rtl=p/'fpga/codec/deepeye_trace_payload_timing_candidate.sv'
new_tb=p/'tests/rtl/codec/tb_trace_payload_timing_candidate.sv'
new_runner=p/'tools/codec/run_trace_payload_timing_candidate.py'
for f in (new_rtl,new_tb,new_runner):need(not f.exists(),'unexpected existing target '+str(f))
(out/'baseline').mkdir()
for rel in pins:shutil.copyfile(p/rel,out/'baseline'/Path(rel).name)
spec=root/'.local/deployment/node-b/evidence/trace-payload-pipeline-20261024-42/MAIN_SPEC.md'
shutil.copyfile(spec,out/'MAIN_SPEC.md');spec_hash=sha(spec)
old=(p/'fpga/codec/deepeye_trace_payload_candidate.sv').read_bytes()
newline='\r\n' if b'\r\n' in old else '\n'
text=old.decode().replace('\r\n','\n')
changes=[]
def replace(before,after,label):
 global text
 need(text.count(before)==1,'replacement anchor '+label)
 text=text.replace(before,after);changes.append(label)
replace('B-TRACE-PAYLOAD-RTL-20261024-38-v1','B-TRACE-PAYLOAD-PIPELINE-20261024-42-v1','work comment')
replace('// Main spec 0545a23843e92f1c7f4bdeec0e268a2cbfb2a246c77c0ee7641db0162a48bc48.',
 '// Main42 spec '+spec_hash+'.\n// Separate timing candidate; original38 behavior, two extra preflight cycles.','spec comment')
replace('module deepeye_trace_payload_candidate (','module deepeye_trace_payload_timing_candidate (','module name')
replace('OUT=9, CLEAR=10;','OUT=9, CLEAR=10, SPAN=11, ENDPOINT=12;','state additions')
replace('    logic [3:0] state;',
 '    logic [3:0] state;\n    logic [23:0] index_span_q, tick_span_q;\n    logic [64:0] age_q;\n    logic basic_bad_q, index_overflow_q, tick_overflow_q;','staging registers')
replace('    logic config_bad, choose_raw;','    logic basic_bad, config_bad, choose_raw;','basic check helper')
replace("        index_end = {1'b0,index_q}+{9'd0,index_span};", "        index_end = {1'b0,index_q}+{9'd0,index_span_q};",'registered index span')
replace("        tick_end = {1'b0,tick_q}+{41'd0,tick_span};", "        tick_end = {1'b0,tick_q}+{41'd0,tick_span_q};",'registered tick span')
begin=text.index('        config_bad = ');end=text.index('        metadata_calc = ')
before=text[begin:end]
after=before.replace('config_bad','basic_bad').replace('||index_end[32]||tick_end[64]','')
after+='        config_bad = basic_bad_q || ((count_q>1) && (index_overflow_q || tick_overflow_q));\n'
replace(before,after,'basic checks exclude registered endpoint flags')
replace("((age>65'd65535)","((age_q>65'd65535)",'registered metadata age')
replace("            meta_error<=0; meta_bytes<=0; meta_tick<=0;\n        end else begin",
 "            meta_error<=0; meta_bytes<=0; meta_tick<=0;\n            index_span_q<=0; tick_span_q<=0; age_q<=0;\n            basic_bad_q<=0; index_overflow_q<=0; tick_overflow_q<=0;\n        end else begin",'reset every added register')
replace('meta_error<=0; meta_bytes<=0; meta_tick<=0; state<=CHECK;',
 'meta_error<=0; meta_bytes<=0; meta_tick<=0; state<=SPAN;','configuration enters SPAN')
replace('                CHECK: begin',
 '                SPAN: begin\n                    index_span_q<=index_span; tick_span_q<=tick_span;\n                    age_q<=age; basic_bad_q<=basic_bad; state<=ENDPOINT;\n                end\n                ENDPOINT: begin\n                    index_overflow_q<=index_end[32]; tick_overflow_q<=tick_end[64];\n                    state<=CHECK;\n                end\n                CHECK: begin','two selected pipeline edges')
replace("long_q<=held_q && (age>65'd65535); short_age<=age[15:0];",
 "long_q<=held_q && (age_q>65'd65535); short_age<=age_q[15:0];",'CHECK consumes registered age')
need(text[text.index('                CORE_CFG:'):]==old.decode().replace('\r\n','\n')[old.decode().replace('\r\n','\n').index('                CORE_CFG:'):],
     'unexpected remaining FSM/data-path edit')
new_rtl.write_bytes(text.replace('\n',newline).encode())
(out/'candidate.diff.txt').write_text(''.join(difflib.unified_diff(old.decode().splitlines(True),new_rtl.read_bytes().decode().splitlines(True),fromfile='original38/deepeye_trace_payload_candidate.sv',tofile='candidate42/deepeye_trace_payload_timing_candidate.sv')),encoding='utf-8',newline='')
tb=(p/'tests/rtl/codec/tb_trace_payload_candidate.sv').read_text().replace('trace_payload_candidate','trace_payload_timing_candidate')
tb=tb.replace('integer cycle=0,trace_fd','integer accepted_cfg_cycle=-1000;\n    integer cycle=0,trace_fd')
anchor='            if(cfg_accepted) begin lc_cfg=lc_cfg+1;gc_cfg=gc_cfg+1;end'
need(tb.count(anchor)==1,'TB preflight anchor')
tb=tb.replace(anchor,'            if(rst||cancel)accepted_cfg_cycle=-1000;\n'
 '            if(cfg_accepted)accepted_cfg_cycle=cycle;\n'
 '            if(!rst&&!cancel&&cycle>accepted_cfg_cycle&&cycle<=accepted_cfg_cycle+3)\n'
 '                if({cfg_ready,s_ready,meta_valid,m_valid}!==4\'d0)fail("preflight public gating");\n'+anchor)
need(tb.count('@(negedge clk);expected_on=0;')==1,'TB SPAN abort anchor')
tb=tb.replace('@(negedge clk);expected_on=0;','if(kind!=8)@(negedge clk);expected_on=0;')
new_tb.write_text(tb,encoding='utf-8',newline='')
runner=(p/'tools/codec/run_trace_payload_candidate.py').read_text()
runner=runner.replace('trace_payload_candidate','trace_payload_timing_candidate').replace('TRACE-PAYLOAD-RTL-20261024-38','TRACE-PAYLOAD-PIPELINE-20261024-42')
runner=runner.replace('trace-payload-20261024-38','trace-payload-pipeline-20261024-42')
runner=runner.replace('0885ed48b9edc48be7fd20135e8c141a485218d4','bf60e80927ed38511d30ffe96ebd419fae0a275c')
runner=runner.replace('0545a23843e92f1c7f4bdeec0e268a2cbfb2a246c77c0ee7641db0162a48bc48',spec_hash)
runner=runner.replace('if kind in (1,7):full=[]','if kind in (1,7,8):full=[]')
anchor=' for which in range(2):\n  abort('
need(runner.count(anchor)==1,'fixture new edge anchor')
runner=runner.replace(anchor," for which in range(2):\n  abort('span_edge_%d'%which,[1,2],cfg_for([1,2]),8,which)\n  abort(")
runner=runner.replace('previous_metadata=None;previous_data=None','previous_metadata=None;previous_data=None;cfg_cycle=None',1)
runner=runner.replace('active=cases[idx];counts=Counter();aborted=False','active=cases[idx];counts=Counter();aborted=False;cfg_cycle=None')
anchor="  if cfg=='11':\n"
need(runner.count(anchor)==1,'checker stage anchor')
runner=runner.replace(anchor,"  if rc!='00':cfg_cycle=None\n"
 "  if cfg_cycle is not None and cycle>cfg_cycle and cycle<=cfg_cycle+3 and rc=='00':require(cfg[1]+sample[1]+meta[0]+data[0]=='0000','preflight public gating')\n"+anchor+"   cfg_cycle=cycle\n")
anchor="  dirty=w/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json';protected[str(dirty)]=sha(dirty)"
need(runner.count(anchor)==1,'protected source anchor')
extra='\n  for rel,digest in '+repr({k:v for k,v in pins.items() if 'trace_payload_candidate' in k})+'.items():\n   require(sha(p/rel)==digest,"original38 dependency drift "+rel);protected[str(p/rel)]=digest'
runner=runner.replace(anchor,anchor+extra)
runner=runner.replace("  result['case_coverage']=dict(","  result['preflight_edge_cases']={label:[c['id'] for c in cases if c['label'].startswith(prefix)] for label,prefix in [('SPAN','span_edge_'),('ENDPOINT','cfg_0_0'),('CHECK','cfg_0_1')]}\n  result['case_coverage']=dict(")
new_runner.write_text(runner,encoding='utf-8',newline='')
compile(runner,str(new_runner),'exec')
record=dict(work_id='B-TRACE-PAYLOAD-PIPELINE-20261024-42-v1',thread_id='01a16a34-b419-7942-9a7b-2b033142446b',
 turn_id='01a16d02-c5c3-7d13-b6a0-33fbef8a6a1b',job_id='child-603a06058b8f4c2585bed67111a5aa87',
 self_validation_execution_allowed=True,spec_sha256=spec_hash,baseline_pins=pins,mechanical_changes=changes,
 new_sources={str(f.relative_to(p)):sha(f) for f in (new_rtl,new_tb,new_runner)},
 diff_sha256=sha(out/'candidate.diff.txt'),latency_note='Two new preflight edges; not cycle-equivalent to original38.')
(out/'BUILD.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record,indent=2))
