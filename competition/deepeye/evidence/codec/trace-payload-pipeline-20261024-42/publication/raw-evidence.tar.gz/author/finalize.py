"""Offline cross-hash/index after one functional run and one OOC; no tool rerun."""
from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,re,os,sys
out=Path(__file__).resolve().parent
p=out.parents[3]
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for x in iter(lambda:f.read(1<<20),b''):h.update(x)
 return h.hexdigest()
def need(ok,why):
 if not ok:raise RuntimeError(why)
functional=out/'functional-01/RESULT.json';ooc=out/'RESULT.json'
f=json.loads(functional.read_bytes());r=json.loads(ooc.read_bytes());build=json.loads((out/'BUILD.json').read_bytes())
need(f['status']=='author_bounded_pass' and f['exit_code']==0,'functional not passed')
need(r['status']=='author_artifact_complete' and r['exit_code']==0 and r['vendor_invocations']==1,'single OOC not complete')
need(r['process']['exit_code']==0 and not r['process']['timed_out'] and r['process']['all_observed_processes_stopped'] and not r['process']['monitor_errors'],'process terminal evidence incomplete')
need(r['functional_gate']['sha256']==sha(functional),'functional gate/result drift')
verified_functional=0
for name,digest in json.loads((out/'functional-01/artifact_hashes.json').read_bytes()).items():
 need(sha(out/'functional-01'/name)==digest,'functional artifact drift '+name);verified_functional+=1
for name,item in r['artifacts'].items():
 need(sha(Path(item['original']))==item['sha256'] and sha(out/item['copy'])==item['sha256'],'OOC artifact drift '+name)
protected={str(p/rel):digest for rel,digest in build['baseline_pins'].items()}
protected.update(f['protected_hashes_before']);protected.update(r['protected_hashes_before'])
for name,digest in protected.items():need(sha(Path(name))==digest,'protected source drift '+name)
for name,item in f['sources'].items():need(sha(Path(item['path']))==item['sha256'],'candidate functional source drift '+name)
for name,info in r['tools'].items():need(sha(Path(name))==info['sha256'],'tool changed '+name)
need(r['spec_sha256']==build['spec_sha256']==f['spec_sha256'],'spec identity mismatch')
need(not f['source_drift'] and not f['protected_drift'] and not r['protected_drift'] and not r['short_snapshot_drift'],'recorded drift')
edge_sets=f['preflight_edge_cases'];wanted={row['id']:(edge,row['which']) for edge,items in edge_sets.items() for row in items}
need(len(wanted)==6 and all({x['which'] for x in edge_sets[k]}=={0,1} for k in ('SPAN','ENDPOINT','CHECK')),'edge stimulus coverage')
edge_receipts={}
with (out/'functional-01/public_ports.txt').open('r',encoding='ascii') as stream:
 for line in stream:
  cols=line.split();case_id=int(cols[1])
  if case_id not in wanted:continue
  row=edge_receipts.setdefault(case_id,dict(edge=wanted[case_id][0],which=wanted[case_id][1],case_id=case_id))
  if cols[3]=='11':row['accepted_cfg_cycle']=int(cols[0])
  if cols[2]!='00':row['abort_cycle']=int(cols[0]);row['reset_cancel_bits']=cols[2]
for row in edge_receipts.values():
 row['relative_edge']=row['abort_cycle']-row['accepted_cfg_cycle']
 need(row['relative_edge']=={'SPAN':1,'ENDPOINT':2,'CHECK':3}[row['edge']],'edge alignment mismatch')
 need(row['reset_cancel_bits']==('10' if row['which']==0 else '01'),'edge reset/cancel mismatch')
drc=[]
for line in (out/'run/reports/drc.rpt').read_text(errors='replace').splitlines():
 m=re.fullmatch(r'\|\s*([A-Z0-9]+-[0-9]+)\s*\|\s*(Warning|Critical Warning|Error)\s*\|\s*([^|]+)\|\s*([0-9]+)\s*\|\s*',line)
 if m:drc.append(dict(rule=m[1],severity=m[2],description=m[3].strip(),count=int(m[4])))
drc_markers=[m['fields'] for m in r['observed']['markers'] if m['marker']=='B06_OOC_REPORT' and m['fields']['kind']=='drc']
need(len(drc_markers)==1 and sum(d['count'] for d in drc)==int(drc_markers[0]['violation_count']),'DRC numeric agreement')
need(set(r['utilization'])=={'Slice LUTs','Slice Registers','Block RAM Tile','DSPs','Bonded IOB'},'resource fields incomplete')
manifest=json.loads((out/'artifact_hashes.json').read_bytes());verified_ooc_manifest=0
for name,digest in manifest.items():need(sha(out/name)==digest,'OOC driver manifest changed '+name);verified_ooc_manifest+=1
final=dict(r)
final.update(status='author_function_and_ooc_artifact_complete',
 ooc_driver_result=dict(path=str(ooc),sha256=sha(ooc)),
 functional_result=dict(path=str(functional),sha256=sha(functional),pid=f['pid'],argv=f['argv'],tools=f['tools'],
  coverage=f['case_coverage'],summary=f['reconciliation']['summary'],trace_rows=f['reconciliation']['trace_rows'],
  parser_negatives=f['parser_negatives'],sources=f['sources'],source_hashes_after=f['source_hashes_after']),
 functional_attempts=1,functional_fix_cycles=0,preflight_edge_receipts=list(edge_receipts.values()),
 candidate_sha256=sha(p/'fpga/codec/deepeye_trace_payload_timing_candidate.sv'),
 original38_sha256=sha(p/'fpga/codec/deepeye_trace_payload_candidate.sv'),
 exact_diff=dict(path=str(out/'candidate.diff.txt'),sha256=sha(out/'candidate.diff.txt')),
 protected_hashes_final={name:sha(Path(name)) for name in protected},protected_drift_final=[],
 drc_summary=drc,drc_violation_count=sum(d['count'] for d in drc),warnings_waived=False,
 verified_functional_artifacts=verified_functional,verified_ooc_driver_manifest_files=verified_ooc_manifest,
 adopted=False,cycle_equivalence_claimed=False,added_internal_preflight_cycles=2,
 main_independent_reopen='not_run_by_worker',
 changed_paths=['competition/deepeye/fpga/codec/deepeye_trace_payload_timing_candidate.sv',
  'competition/deepeye/fpga/codec/trace_payload_timing_candidate.md','competition/deepeye/tests/rtl/codec/tb_trace_payload_timing_candidate.sv',
  'competition/deepeye/tools/codec/run_trace_payload_timing_candidate.py',
  'competition/deepeye/evidence/codec/trace-payload-pipeline-20261024-42/author/','D:/pynq/CarlandFPGA/.local/b42/'],
 raw_evidence=dict(functional='functional-01/{RESULT.json,logs/,cases.json,cases.txt,public_ports.txt,transcript.txt,negative-parser/}',
  vendor='PROCESS.json,PROCESS_TREE_OBSERVATIONS.json,LAUNCH_INTENT.json,run/{stdout.bin,stderr.bin,vivado.log,vivado.jou,reports/,ooc.dcp}',
  diff='candidate.diff.txt',baseline='baseline/',warnings='WARNINGS.json'),
 limitations=['Only the exact main-selected SPAN/ENDPOINT preflight design was implemented; no other optimization or production adoption.',
  'Original38 fixture/golden coverage is explicitly reused; no new independent reference or cycle-equivalence claim.',
  'One post-synthesis diagnostic at10ns with unwaived warnings and I/O gaps. Main independently reopens/compares/evaluates; not timing closure or product acceptance.'],
 finalizer=dict(argv=[sys.executable,'-B','-X','utf8',str(Path(__file__).resolve())],pid=os.getpid(),parent_pid=os.getppid(),exit_code=0),
 finished_utc=datetime.now(timezone.utc).isoformat())
dest=out/'FINAL_RESULT.json';need(not dest.exists(),'refusing final-result overwrite')
dest.write_text(json.dumps(final,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
hashes={f.relative_to(out).as_posix():sha(f) for f in sorted(out.rglob('*')) if f.is_file() and f.name not in ('FINAL_ARTIFACT_HASHES.json','finalize.stdout.txt','finalize.stderr.txt')}
(out/'FINAL_ARTIFACT_HASHES.json').write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(status=final['status'],result_path=str(dest),result_sha256=sha(dest),candidate_sha256=final['candidate_sha256'],
 source_hashes={k:v['sha256'] for k,v in f['sources'].items() if not v['protected']},
 functional_summary=f['reconciliation']['summary'],functional_trace_rows=f['reconciliation']['trace_rows'],
 preflight_edges=list(edge_receipts.values()),wns_ns=r['timing_wns_ns'],utilization=r['utilization'],drc_summary=drc,
 dcp=r['artifacts']['ooc.dcp'],process=r['process'],verified_functional_artifacts=verified_functional,
 verified_ooc_manifest_files=verified_ooc_manifest),indent=2))
