"""One explicitly assigned OOC invocation; no vendor retry or source mutation."""
from pathlib import Path
from datetime import datetime,timezone
from collections import Counter
from ctypes import wintypes
import ctypes
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
sys.dont_write_bytecode=True

AUTHOR=Path(__file__).resolve().parent
ROOT=Path('D:/pynq/CarlandFPGA')
W=ROOT/'.local/worktrees/deepeye-implementation-20261014'
P=W/'competition/deepeye'
SHORT=ROOT/'.local/b42'
TOP='deepeye_trace_payload_timing_candidate'
HEAD='bf60e80927ed38511d30ffe96ebd419fae0a275c'
PINNED={
 'fpga/codec/deepeye_trace_payload_timing_candidate.sv':'0d5ba11fe199708f8376c718bbf3484431adc8dd6e847666451b1b5e873cec7b',
 'fpga/codec/deepeye_block_encoder.sv':'4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532',
 'fpga/build_qualification/ooc_qualification.tcl':'54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9',
 'tools/build/run_ooc_qualification.py':'04a47aee3ce44c7576c8d879baf27a8701b5cde3e17a3ef0000954c8b0c3ea11'}
BAT=Path('D:/pynq/AMD2026/2026.1/Vivado/bin/vivado.bat')
EXE=BAT.parent/'unwrapped/win64.o/vivado.exe'
CMD=Path('C:/Windows/System32/cmd.exe')
TOOLS={str(BAT):'a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b',
       str(EXE):'3a4e9e3f03d20cd1994dc2eff44566af7a10eaaae04429e9d460bffe3b0e86e4'}
SPEC=ROOT/'.local/deployment/node-b/evidence/trace-payload-pipeline-20261024-42/MAIN_SPEC.md'
CONTRACT={'id':'DEEPEYE-HUMAN-LOCK-20261014','revision':1,'ids':['H%02d'%i for i in range(1,16)],
 'pin':'f5989cd5defce561f9ba98e6b18fc2682945f0a2',
 'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804',
 'design_commit':'1011259415a0916054eb580687612580bc1e5f09'}
def utc():return datetime.now(timezone.utc).isoformat()
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1<<20),b''):h.update(b)
 return h.hexdigest()
def save(path,obj):Path(path).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
def require(ok,why):
 if not ok:raise RuntimeError(why)
def same_path(a,b):return os.path.normcase(os.path.normpath(a))==os.path.normcase(os.path.normpath(str(b.resolve())))

# Native read-only process observation. Held handles prevent PID reuse from
# being mistaken for this launch. Only descendants of this command are kept.
k32=ctypes.WinDLL('kernel32',use_last_error=True)
class Entry(ctypes.Structure):
 _fields_=[('dwSize',wintypes.DWORD),('cntUsage',wintypes.DWORD),('pid',wintypes.DWORD),
  ('heap',ctypes.c_size_t),('module',wintypes.DWORD),('threads',wintypes.DWORD),
  ('ppid',wintypes.DWORD),('priority',wintypes.LONG),('flags',wintypes.DWORD),('exe',wintypes.WCHAR*260)]
k32.CreateToolhelp32Snapshot.argtypes=[wintypes.DWORD,wintypes.DWORD];k32.CreateToolhelp32Snapshot.restype=wintypes.HANDLE
k32.Process32FirstW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)];k32.Process32FirstW.restype=wintypes.BOOL
k32.Process32NextW.argtypes=[wintypes.HANDLE,ctypes.POINTER(Entry)];k32.Process32NextW.restype=wintypes.BOOL
k32.OpenProcess.argtypes=[wintypes.DWORD,wintypes.BOOL,wintypes.DWORD];k32.OpenProcess.restype=wintypes.HANDLE
k32.CloseHandle.argtypes=[wintypes.HANDLE];k32.CloseHandle.restype=wintypes.BOOL
k32.WaitForSingleObject.argtypes=[wintypes.HANDLE,wintypes.DWORD];k32.WaitForSingleObject.restype=wintypes.DWORD
k32.GetExitCodeProcess.argtypes=[wintypes.HANDLE,ctypes.POINTER(wintypes.DWORD)];k32.GetExitCodeProcess.restype=wintypes.BOOL
k32.GetProcessTimes.argtypes=[wintypes.HANDLE]+[ctypes.POINTER(wintypes.FILETIME)]*4;k32.GetProcessTimes.restype=wintypes.BOOL
k32.TerminateProcess.argtypes=[wintypes.HANDLE,wintypes.UINT];k32.TerminateProcess.restype=wintypes.BOOL
def process_rows():
 h=k32.CreateToolhelp32Snapshot(2,0)
 require(h not in (None,ctypes.c_void_p(-1).value),'process snapshot unavailable')
 try:
  e=Entry();e.dwSize=ctypes.sizeof(e);rows=[];ok=k32.Process32FirstW(h,ctypes.byref(e))
  while ok:
   rows.append(dict(pid=int(e.pid),parent_pid=int(e.ppid),executable=e.exe))
   ok=k32.Process32NextW(h,ctypes.byref(e))
  return rows
 finally:k32.CloseHandle(h)
class Tree:
 def __init__(self,pid):
  self.root=pid;self.seen={};self.handles={};self.stop=threading.Event();self.lock=threading.RLock();self.errors=[]
  self.scan();self.thread=threading.Thread(target=self.observe,daemon=True);self.thread.start()
 def scan(self):
  rows=process_rows()
  with self.lock:
   known=set(self.seen)|{self.root};added=True
   while added:
    added=False
    for row in rows:
     if row['pid'] in known or row['parent_pid'] in known:
      pid=row['pid']
      if pid not in known:known.add(pid);added=True
      if pid not in self.seen:
       record=dict(row,first_seen_utc=utc())
       h=k32.OpenProcess(0x100000|0x1000|1,False,pid)
       if not h:h=k32.OpenProcess(0x100000|0x1000,False,pid)
       if h:
        self.handles[pid]=h
        a,b,c,d=(wintypes.FILETIME() for _ in range(4))
        if k32.GetProcessTimes(h,ctypes.byref(a),ctypes.byref(b),ctypes.byref(c),ctypes.byref(d)):
         record['creation_filetime']=int(a.dwHighDateTime)<<32|int(a.dwLowDateTime)
       else:record['open_handle_error']=ctypes.get_last_error()
       self.seen[pid]=record
   save(AUTHOR/'PROCESS_TREE_OBSERVATIONS.json',list(self.seen.values()))
 def observe(self):
  while not self.stop.wait(0.5):
   try:self.scan()
   except Exception as exc:self.errors.append(str(exc));self.stop.set()
 def states(self):
  records=[];live_pids={r['pid'] for r in process_rows()}
  with self.lock:
   for pid,record in self.seen.items():
    r=dict(record);h=self.handles.get(pid)
    if h:
     status=k32.WaitForSingleObject(h,0);r['wait_status']=int(status);r['stopped']=status==0
     code=wintypes.DWORD()
     if k32.GetExitCodeProcess(h,ctypes.byref(code)):r['exit_code']=int(code.value)
    else:
     r['stopped']=pid not in live_pids
     r['state_evidence']='PID absent from current process snapshot' if r['stopped'] else 'live PID without held handle; unconfirmed'
    records.append(r)
  return records
 def settle(self,deadline):
  while True:
   self.scan();states=self.states();live=[r for r in states if r['stopped'] is False]
   if not live:break
   remain=deadline-time.monotonic()
   if remain<=0:return False
   k32.WaitForSingleObject(self.handles[live[0]['pid']],min(int(remain*1000),0xfffffffe))
  return all(r['stopped'] is True for r in self.states())
 def finish(self):
  self.stop.set();self.thread.join(timeout=3);self.scan();records=self.states()
  for h in self.handles.values():k32.CloseHandle(h)
  return records
 def kill_owned(self):
  self.scan();receipts=[]
  for row in reversed(self.states()):
   if row['stopped'] is False:
    ok=k32.TerminateProcess(self.handles[row['pid']],124)
    receipts.append(dict(pid=row['pid'],creation_filetime=row.get('creation_filetime'),terminate_return=bool(ok),
                         error=0 if ok else ctypes.get_last_error()))
  return receipts

def read_markers(text):
 rows=[]
 for number,line in enumerate(text.splitlines(),1):
  if 'B06_OOC_' not in line:continue
  require(line.startswith('B06_OOC_'),'unanchored marker row '+str(number))
  parts=line.split('|');fields={}
  for field in parts[1:]:
   require(field.count('=')==1,'malformed marker field');key,value=field.split('=',1)
   require(key and key not in fields,'duplicate marker field');fields[key]=value
  rows.append((parts[0],fields,line))
 return rows
def parse_run(stdout):
 rows=read_markers(stdout);kinds=[r[0] for r in rows]
 expected=['B06_OOC_BEGIN','B06_OOC_USER_DATA','B06_OOC_VERSION','B06_OOC_PART','B06_OOC_THREADS',
  'B06_OOC_SOURCE_READ','B06_OOC_SOURCE_READ','B06_OOC_SOURCE_COUNT','B06_OOC_SYNTH_BEGIN','B06_OOC_SYNTH_DONE',
  'B06_OOC_DESIGN','B06_OOC_CLOCK']+['B06_OOC_REPORT']*4+['B06_OOC_CHECKPOINT','B06_OOC_END']
 failures=[]
 if kinds!=expected:failures.append('exact marker order/count mismatch')
 if any(n>1 for n in Counter(r[2] for r in rows).values()):failures.append('duplicate marker line')
 by={}
 for marker,fields,line in rows:by.setdefault(marker,[]).append(fields)
 def exact(marker,wanted,index=0):
  observed=by.get(marker,[])
  if len(observed)<=index or observed[index]!=wanted:failures.append(marker+' fields mismatch')
 exact('B06_OOC_BEGIN',dict(run_id='b42',top=TOP,clock_mode='clock:clk'))
 exact('B06_OOC_VERSION',dict(value='2026.1'))
 exact('B06_OOC_PART',dict(requested='xc7z020clg400-1',matched='1'))
 exact('B06_OOC_THREADS',dict(requested='2',actual='2'))
 exact('B06_OOC_SOURCE_COUNT',dict(count='2'))
 exact('B06_OOC_SYNTH_BEGIN',dict(top=TOP,mode='out_of_context',part='xc7z020clg400-1'))
 exact('B06_OOC_SYNTH_DONE',dict(top=TOP,status='complete'))
 exact('B06_OOC_CLOCK',dict(name='clk',port='clk',period_ns='10.000',status='created'))
 exact('B06_OOC_END',dict(run_id='b42',top=TOP,status='artifact_complete'))
 user=by.get('B06_OOC_USER_DATA',[{}])[0]
 if set(user)!={'mode','path'} or user.get('mode')!='owned_cache' or not same_path(user.get('path',''),SHORT/'cache'):failures.append('cache marker mismatch')
 for index,name in enumerate(('core.sv','trace.sv')):
  items=by.get('B06_OOC_SOURCE_READ',[]);row=items[index] if len(items)>index else {}
  if set(row)!={'index','path'} or row.get('index')!=str(index+1) or not same_path(row.get('path',''),SHORT/'s'/name):failures.append('source marker mismatch '+name)
 design=by.get('B06_OOC_DESIGN',[{}])[0]
 if set(design)!={'part','port_count'} or design.get('part')!='xc7z020clg400-1' or not re.fullmatch('[1-9][0-9]*',design.get('port_count','')):failures.append('design marker mismatch')
 for index,name in enumerate(('utilization','timing_summary','check_timing','drc')):
  items=by.get('B06_OOC_REPORT',[]);row=items[index] if len(items)>index else {}
  keys={'kind','status','path'}|({'diagnostic_only'} if name in ('timing_summary','check_timing') else {'violation_count'} if name=='drc' else set())
  if set(row)!=keys or row.get('kind')!=name or row.get('status')!='written' or not same_path(row.get('path',''),SHORT/'reports'/(name+'.rpt')):failures.append('report marker mismatch '+name)
  if name in ('timing_summary','check_timing') and row.get('diagnostic_only')!='1':failures.append('diagnostic flag mismatch')
 checkpoint=by.get('B06_OOC_CHECKPOINT',[{}])[0]
 if set(checkpoint)!={'status','path'} or checkpoint.get('status')!='written' or not same_path(checkpoint.get('path',''),SHORT/'ooc.dcp'):failures.append('checkpoint marker mismatch')
 return dict(marker_failures=failures,markers=[dict(marker=m,fields=f) for m,f,_ in rows],
             synthesis_complete=by.get('B06_OOC_SYNTH_DONE')==[dict(top=TOP,status='complete')],
             artifact_complete=not failures,design=design)

def main():
 functional_path=AUTHOR/'functional-01/RESULT.json'
 functional=json.loads(functional_path.read_bytes())
 require(functional['status']=='author_bounded_pass' and functional['exit_code']==0 and not functional['source_drift'] and not functional['protected_drift'],'functional gate not passed')
 for rel,info in functional['sources'].items():require(sha(info['path'])==info['sha256'],'functional source drift '+rel)
 require(not (AUTHOR/'RESULT.json').exists(),'existing result: no overwrite or replay')
 require(not (AUTHOR/'LAUNCH_INTENT.json').exists(),'existing launch intent: no replay')
 require(not SHORT.exists(),'short destination exists: no overwrite or replay')
 result=dict(task_id='DEEPEYE-IMPLEMENTATION-20261014',task_version=1,work_id='B-TRACE-PAYLOAD-PIPELINE-20261024-42-v1',
  operation_id='B-DEEPEYE-TRACE-PAYLOAD-PIPELINE-20261024-42',thread_id='01a16a34-b419-7942-9a7b-2b033142446b',
  turn_id='01a16d02-c5c3-7d13-b6a0-33fbef8a6a1b',job_id='child-603a06058b8f4c2585bed67111a5aa87',
  quality_main_thread_id='01a13b55-095b-7461-8dd5-5476a130bd82',self_validation_execution_allowed=True,
  contract=CONTRACT,source_head=HEAD,baseline_tested_source='879f0af84aba596e11185df86f6722999e640673',
  status='preflight',pid=os.getpid(),parent_pid=os.getppid(),python_version=sys.version,
  invocation=[sys.executable]+sys.argv,started_utc=utc(),sources={},commands=[],vendor_invocations=0,
  tcl_mapping='Unchanged op33 Tcl invoked only once for op42 and exact trace payload top; no 19-top campaign.',
  formal_29='not_run',B01='not_run',B06='not_run',R03='not_run',ModelSim='not_run',place_route='not_run',
  implementation='not_run',bitstream='not_run',timing_closure='not_run',CDC_RDC='not_run',board='not_run',system='not_run',final_acceptance='not_run')
 result['functional_gate']=dict(path=str(functional_path),sha256=sha(functional_path),status=functional['status'],source_hashes=functional['source_hashes_after'])
 result['ownership']=[str(AUTHOR),str(SHORT)];result['driver_sha256_before']=sha(Path(__file__))
 save(AUTHOR/'RESULT.json',result)
 protected={};code=1;proc=None;tree=None;process_receipt=None
 try:
  (AUTHOR/'inputs').mkdir();shutil.copyfile(SPEC,AUTHOR/'inputs/MAIN_SPEC.md');result['spec_sha256']=sha(SPEC)
  for rel,digest in PINNED.items():
   src=P/rel;require(sha(src)==digest,'pinned source drift '+rel);protected[str(src)]=digest
   snapshot=AUTHOR/'inputs'/src.name;shutil.copyfile(src,snapshot)
   result['sources'][rel]=dict(path=str(src),sha256=digest,snapshot=str(snapshot.relative_to(AUTHOR)))
  for path,digest in TOOLS.items():require(sha(path)==digest,'tool hash mismatch '+path)
  result['tools']={path:dict(sha256=digest,bytes=Path(path).stat().st_size) for path,digest in TOOLS.items()}
  result['cmd_exe']=dict(path=str(CMD),sha256=sha(CMD))
  # Contract data are read as raw Git bytes, not trusted from editable copies.
  argv=['git','show',CONTRACT['pin']+':docs/competition/deepeye-2026/immutable_scope.json']
  with (AUTHOR/'contract.stdout.bin').open('wb') as so,(AUTHOR/'contract.stderr.bin').open('wb') as se:
   gp=subprocess.Popen(argv,cwd=W,stdout=so,stderr=se,shell=False);rc=gp.wait(timeout=30)
  result['commands'].append(dict(argv=argv,cwd=str(W),pid=gp.pid,parent_pid=os.getpid(),exit_code=rc,stdout='contract.stdout.bin',stderr='contract.stderr.bin'))
  require(rc==0,'contract Git read failed')
  contract=json.loads((AUTHOR/'contract.stdout.bin').read_bytes())
  require(hashlib.sha256(json.dumps(contract['requirements'],ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()).hexdigest()==CONTRACT['requirements_sha256'],'contract hash mismatch')
  dirty=W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json';protected[str(dirty)]=sha(dirty)
  SHORT.mkdir();
  for name in ('work','tmp','cache','s'):(SHORT/name).mkdir()
  shutil.copyfile(P/'fpga/codec/deepeye_block_encoder.sv',SHORT/'s/core.sv')
  shutil.copyfile(P/'fpga/codec/deepeye_trace_payload_timing_candidate.sv',SHORT/'s/trace.sv')
  shutil.copyfile(P/'fpga/build_qualification/ooc_qualification.tcl',SHORT/'q.tcl')
  require(sha(SHORT/'q.tcl')==PINNED['fpga/build_qualification/ooc_qualification.tcl'],'Tcl snapshot drift')
  sources=[SHORT/'s/core.sv',SHORT/'s/trace.sv'];(SHORT/'sources.txt').write_text('\n'.join(s.as_posix() for s in sources)+'\n',encoding='utf-8')
  result['short_snapshots_before']={str(f):sha(f) for f in sources+[SHORT/'q.tcl',SHORT/'sources.txt']}
  env=os.environ.copy();overrides=dict(TEMP=str(SHORT/'tmp'),TMP=str(SHORT/'tmp'),TMPDIR=str(SHORT/'tmp'),XILINX_LOCAL_USER_DATA=str(SHORT/'cache'));env.update(overrides)
  argv=[str(CMD),'/d','/c',str(BAT),'-mode','batch','-journal',str(SHORT/'vivado.jou'),'-log',str(SHORT/'vivado.log'),'-notrace',
        '-source',str(SHORT/'q.tcl'),'-tclargs',str(SHORT),TOP,str(SHORT/'sources.txt'),'clock:clk']
  flags=subprocess.CREATE_NO_WINDOW|subprocess.CREATE_NEW_PROCESS_GROUP
  process_receipt=dict(argv=argv,command_line=subprocess.list2cmdline(argv),cwd=str(SHORT/'work'),shell=False,hidden=True,
   creationflags=flags,environment_overrides=overrides,environment_policy='os.environ.copy plus exactly these child-only overrides; inherited secrets not exported',
   parent_pid=os.getpid(),timeout_seconds=600,started_utc=utc(),timed_out=False,exit_code=None,pid=None,
   stdout=str(SHORT/'stdout.bin'),stderr=str(SHORT/'stderr.bin'))
  save(AUTHOR/'LAUNCH_INTENT.json',process_receipt)
  t0=time.monotonic();deadline=t0+600
  with (SHORT/'stdout.bin').open('wb') as so,(SHORT/'stderr.bin').open('wb') as se:
   result['vendor_invocations']=1;save(AUTHOR/'RESULT.json',result)
   proc=subprocess.Popen(argv,cwd=SHORT/'work',env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,shell=False,creationflags=flags)
   process_receipt['pid']=proc.pid;save(AUTHOR/'PROCESS.json',process_receipt)
   print('LAUNCHED one Vivado OOC pid=%d parent=%d timeout=600s'%(proc.pid,os.getpid()),flush=True)
   tree=Tree(proc.pid)
   try:process_receipt['exit_code']=proc.wait(timeout=max(0,deadline-time.monotonic()))
   except subprocess.TimeoutExpired:process_receipt['timed_out']=True
   settled=tree.settle(deadline) if not process_receipt['timed_out'] else False
   if not settled:
    process_receipt['timed_out']=True;process_receipt['states_at_bound']=tree.states()
    process_receipt['owned_termination']=tree.kill_owned()
    try:proc.wait(timeout=30)
    except subprocess.TimeoutExpired:pass
    tree.settle(time.monotonic()+30)
   process_receipt['exit_code']=proc.poll();process_receipt['descendants']=tree.finish();process_receipt['monitor_errors']=tree.errors;tree=None
  process_receipt['finished_utc']=utc();process_receipt['duration_seconds']=time.monotonic()-t0
  process_receipt['all_observed_processes_stopped']=all(r['stopped'] is True for r in process_receipt['descendants'])
  process_receipt['stdout_sha256']=sha(SHORT/'stdout.bin');process_receipt['stderr_sha256']=sha(SHORT/'stderr.bin')
  save(AUTHOR/'PROCESS.json',process_receipt);result['process']=process_receipt
  require(process_receipt['all_observed_processes_stopped'],'original process tree not confirmed stopped')
  require(not process_receipt['timed_out'],'single bounded command timed out; no replay')
  text=(SHORT/'stdout.bin').read_bytes().decode('utf-8',errors='replace')
  result['observed']=parse_run(text)
  require(process_receipt['exit_code']==0,'Vivado exit '+str(process_receipt['exit_code']))
  required=['reports/utilization.rpt','reports/timing_summary.rpt','reports/check_timing.rpt','reports/drc.rpt','ooc.dcp','vivado.log','vivado.jou']
  result['outputs']={name:dict(path=str(SHORT/name),exists=(SHORT/name).is_file(),bytes=(SHORT/name).stat().st_size if (SHORT/name).is_file() else 0) for name in required}
  require(all(r['exists'] and r['bytes']>0 for r in result['outputs'].values()),'required report/export missing or empty')
  require(result['observed']['artifact_complete'],'marker qualification incomplete')
  result['status']='author_artifact_complete';code=0
 except Exception as exc:
  result['status']='failed';result['error']=str(exc);result['traceback']=traceback.format_exc();(AUTHOR/'failure.txt').write_text(result['traceback'],encoding='utf-8')
  print(result['traceback'],file=sys.stderr,flush=True)
 finally:
  if tree is not None:
   # An observer/parser exception must not abandon a launched owned process.
   try:
    process_receipt['exception_cleanup']=tree.kill_owned();tree.settle(time.monotonic()+30)
    process_receipt['descendants']=tree.finish();process_receipt['monitor_errors']=tree.errors
    process_receipt['all_observed_processes_stopped']=all(r['stopped'] is True for r in process_receipt['descendants'])
    process_receipt['exit_code']=proc.poll();save(AUTHOR/'PROCESS.json',process_receipt);result['process']=process_receipt
   except Exception as exc:result['cleanup_error']=str(exc)
  warnings=[]
  if SHORT.exists():
   (AUTHOR/'run').mkdir(exist_ok=True)
   known=[SHORT/'stdout.bin',SHORT/'stderr.bin',SHORT/'vivado.log',SHORT/'vivado.jou',SHORT/'ooc.dcp',SHORT/'q.tcl',SHORT/'sources.txt']
   known+=list((SHORT/'reports').glob('*')) if (SHORT/'reports').is_dir() else []
   known+=list((SHORT/'s').glob('*')) if (SHORT/'s').is_dir() else []
   artifacts={}
   for path in known:
    if not path.is_file():continue
    rel=path.relative_to(SHORT);dest=AUTHOR/'run'/rel;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(path,dest)
    artifacts[rel.as_posix()]=dict(original=str(path),copy=str(dest.relative_to(AUTHOR)),bytes=path.stat().st_size,sha256=sha(path))
    if path.suffix in ('.log','.jou','.rpt') or path.name in ('stdout.bin','stderr.bin'):
     for number,line in enumerate(path.read_text(encoding='utf-8',errors='replace').splitlines(),1):
      if re.search(r'\bwarning\b',line,re.I):warnings.append(dict(file=rel.as_posix(),line=number,text=line))
   result['artifacts']=artifacts
   stdout_text=(SHORT/'stdout.bin').read_text(encoding='utf-8',errors='replace') if (SHORT/'stdout.bin').exists() else ''
   result['stage_receipts']={
    'synthesis_complete':stdout_text.splitlines().count('B06_OOC_SYNTH_DONE|top='+TOP+'|status=complete')==1,
    'reports':{n:bool((SHORT/'reports'/(n+'.rpt')).is_file() and (SHORT/'reports'/(n+'.rpt')).stat().st_size>0) for n in ('utilization','timing_summary','check_timing','drc')},
    'checkpoint_exists_nonempty':bool((SHORT/'ooc.dcp').is_file() and (SHORT/'ooc.dcp').stat().st_size>0)}
   result['warnings']=warnings;save(AUTHOR/'WARNINGS.json',warnings)
   util=SHORT/'reports/utilization.rpt';timing=SHORT/'reports/timing_summary.rpt';check=SHORT/'reports/check_timing.rpt'
   if util.is_file():
    result['utilization']={m[1].rstrip('*'):m[2] for line in util.read_text(errors='replace').splitlines() if (m:=re.match(r'^\|\s*(Slice LUTs\*?|Slice Registers|Block RAM Tile|DSPs|Bonded IOB)\s*\|\s*([0-9.]+)\s*\|',line))}
   if timing.is_file():
    lines=timing.read_text(errors='replace').splitlines();result['timing_wns_ns']=None
    for i,line in enumerate(lines):
     if re.match(r'^\s*WNS\(ns\)\s+TNS\(ns\)',line):
      for row in lines[i+1:i+5]:
       m=re.match(r'^\s*(-?[0-9]+\.[0-9]+)\s+(-?[0-9]+\.[0-9]+)',row)
       if m:result['timing_wns_ns']=m[1];result['timing_tns_ns']=m[2];break
      break
   if check.is_file():result['check_timing_categories']=[line for line in check.read_text(errors='replace').splitlines() if re.search(r'checking\s+\w+\s*\([0-9]+\)',line,re.I)]
  result['protected_hashes_before']=protected;result['protected_hashes_after']={name:sha(name) for name in protected}
  result['protected_drift']=[name for name,digest in protected.items() if result['protected_hashes_after'][name]!=digest]
  if result['protected_drift']:result['status']='failed';result['error']='protected source drift';code=1
  result['short_snapshots_after']={name:sha(name) for name in result.get('short_snapshots_before',{})}
  result['short_snapshot_drift']=[name for name,digest in result.get('short_snapshots_before',{}).items() if result['short_snapshots_after'][name]!=digest]
  result['driver_sha256_after']=sha(Path(__file__))
  if result['short_snapshot_drift'] or result['driver_sha256_before']!=result['driver_sha256_after']:
   result['status']='failed';result['error']='snapshot/driver drift';code=1
  result['finished_utc']=utc();result['exit_code']=code;result['limitations']=['One post-synthesis 10ns OOC diagnostic only; no I/O constraints, placement/routing, closure or product acceptance.',
   'Warnings, ZPS7-1 and I/O timing gaps are retained, not waived. Main independently reopens DCP and evaluates.',
   'Only this assigned top and two exact source snapshots were launched; no model/RTL optimization, old-run replay or 19-top campaign.']
  save(AUTHOR/'RESULT.json',result)
  save(AUTHOR/'artifact_hashes.json',{f.relative_to(AUTHOR).as_posix():sha(f) for f in sorted(AUTHOR.rglob('*')) if f.is_file() and f.name!='artifact_hashes.json' and f.name not in ('driver.stdout.txt','driver.stderr.txt')})
 print(json.dumps(dict(status=result['status'],vendor_invocations=result['vendor_invocations'],process_exit=result.get('process',{}).get('exit_code'),
  process_tree_stopped=result.get('process',{}).get('all_observed_processes_stopped'),synthesis_complete=result.get('observed',{}).get('synthesis_complete'),
  wns_ns=result.get('timing_wns_ns'),utilization=result.get('utilization'),result_path=str(AUTHOR/'RESULT.json'),result_sha256=sha(AUTHOR/'RESULT.json')),indent=2),flush=True)
 return code
if __name__=='__main__':raise SystemExit(main())
