"""Reuse owned40 process receipts/launch pattern for one fresh42 top, gated by function."""
from pathlib import Path
import hashlib,json
out=Path(__file__).resolve().parent
p=out.parents[3]
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def require(ok,message):
 if not ok:raise RuntimeError(message)
functional=out/'functional-01/RESULT.json'
f=json.loads(functional.read_bytes())
require(f['status']=='author_bounded_pass' and f['exit_code']==0 and not f['source_drift'] and not f['protected_drift'],'functional gate failed')
require(not Path('D:/pynq/CarlandFPGA/.local/b42').exists(),'existing short output; no replay')
destination=out/'ooc.py';require(not destination.exists(),'existing OOC driver; no replay')
old_dir=p/'evidence/codec/trace-payload-ooc-20261024-40/author'
old_result=json.loads((old_dir/'RESULT.json').read_bytes())
old=old_dir/'run.py';require(sha(old)==old_result['driver_sha256_before']==old_result['driver_sha256_after'],'owned40 helper drift')
rtl=p/'fpga/codec/deepeye_trace_payload_timing_candidate.sv';rtl_hash=sha(rtl)
require(rtl_hash==f['sources']['fpga/codec/deepeye_trace_payload_timing_candidate.sv']['sha256'],'functional RTL drift')
text=old.read_text()
for before,after in [
 ('deepeye_trace_payload_candidate','deepeye_trace_payload_timing_candidate'),
 ('fb64ace453c451838110c81bf6cb4a815a96fb2668e28a306ff699beca5acef6',rtl_hash),
 ("'.local/b40'","'.local/b42'"),("run_id='b40'","run_id='b42'"),
 ('trace-payload-ooc-20261024-40','trace-payload-pipeline-20261024-42'),
 ('B-TRACE-PAYLOAD-OOC-20261024-40-v1','B-TRACE-PAYLOAD-PIPELINE-20261024-42-v1'),
 ('B-DEEPEYE-TRACE-PAYLOAD-OOC-20261024-40','B-DEEPEYE-TRACE-PAYLOAD-PIPELINE-20261024-42'),
 ('01a16cef-389f-7ed3-85d5-bb9826ef7515','01a16d02-c5c3-7d13-b6a0-33fbef8a6a1b'),
 ('child-44c3d263aff44ad1bccb9016e7e456d0','child-603a06058b8f4c2585bed67111a5aa87'),
 ("tested_source='879f0af84aba596e11185df86f6722999e640673'","baseline_tested_source='879f0af84aba596e11185df86f6722999e640673'"),
 ('invoked only once for op40','invoked only once for op42'),
 ('Slice LUTs|Slice Registers',r'Slice LUTs\*?|Slice Registers'),
 ("result['utilization']={m[1]:m[2]","result['utilization']={m[1].rstrip('*'):m[2]")]:
 require(before in text,'missing helper adaptation '+before);text=text.replace(before,after)
anchor='def main():\n'
require(text.count(anchor)==1,'driver main anchor')
text=text.replace(anchor,anchor+
 " functional_path=AUTHOR/'functional-01/RESULT.json'\n"
 " functional=json.loads(functional_path.read_bytes())\n"
 " require(functional['status']=='author_bounded_pass' and functional['exit_code']==0 and not functional['source_drift'] and not functional['protected_drift'],'functional gate not passed')\n"
 " for rel,info in functional['sources'].items():require(sha(info['path'])==info['sha256'],'functional source drift '+rel)\n")
anchor=" result['ownership']=[str(AUTHOR),str(SHORT)];result['driver_sha256_before']=sha(Path(__file__))"
require(anchor in text,'functional receipt anchor')
text=text.replace(anchor," result['functional_gate']=dict(path=str(functional_path),sha256=sha(functional_path),status=functional['status'],source_hashes=functional['source_hashes_after'])\n"+anchor)
compile(text,str(destination),'exec');destination.write_text(text,encoding='utf-8',newline='')
receipt=dict(functional_result_sha256=sha(functional),candidate_sha256=rtl_hash,
 reused_driver_path=str(old),reused_driver_sha256=sha(old),new_driver_sha256=sha(destination),
 condition='No execution by this preparation script. New driver independently enforces functional source success before its single launch.',
 vendor_output='D:/pynq/CarlandFPGA/.local/b42')
(out/'OOC_PREPARATION.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,indent=2))
