from pathlib import Path
import hashlib,importlib.util,json,re
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/trace-payload-pipeline-20261024-42';A=E/'author';O=E/'main/author-audit-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
terminal=get(D/'native-terminal.json')[0];assert terminal['terminal'] and not terminal['stale'] and terminal['status']=='completed';tr=json.loads(terminal['result']['text']);assert sha(Path(tr['result_path']))==tr['result_sha256']
verified={}
for rel,h in get(A/'FINAL_ARTIFACT_HASHES.json').items():
 p=A/rel;assert p.is_file() and sha(p)==h,p;verified[str(p)]={'sha256':h,'bytes':p.stat().st_size}
for rel,h in tr['source_sha256'].items():assert sha(P/rel)==h
command_count=0
for name in ['functional-01']:
 a=get(A/name/'RESULT.json');assert a['exit_code']==0 and not a['source_drift'] and not a['protected_drift'];assert a['sources']['fpga/codec/deepeye_trace_payload_timing_candidate.sv']['sha256']==tr['source_sha256']['fpga/codec/deepeye_trace_payload_timing_candidate.sv']
 for c in a['commands']:
  assert c['exit_code']==0 and c['pid']>0
  for stream in ['stdout','stderr']:assert sha(A/name/c[stream])==c[stream+'_sha256']
  command_count+=1
runner=P/'tools/codec/run_trace_payload_timing_candidate.py';spec=importlib.util.spec_from_file_location('checked_author42',runner);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
base=A/'functional-01';text=(base/'logs/vsim.stdout.txt').read_text();rows=(base/'public_ports.txt').read_text().splitlines(keepends=True);cases=get(base/'cases.json');tb=(base/'inputs/tb_trace_payload_timing_candidate.sv').read_text().splitlines();finish=next(i+1 for i,s in enumerate(tb) if '$fclose(trace_fd);$display("TP_DONE' in s)
positive=m.check_saved(text,iter(rows),cases,finish);probes=[]
def reject(name,t,trace,recipe):
 try:m.check_saved(t,trace,cases,finish);result={'name':name,'rejected':False,'recipe':recipe}
 except (ValueError,AssertionError) as exc:result={'name':name,'rejected':True,'reason':str(exc),'recipe':recipe}
 probes.append(result)
done='# TP_DONE trace_payload_timing_candidate PASS'
for name,t in [('substring',text.replace(done,'# NOT_'+done[2:])),('duplicate',text.replace(done,done+'\n'+done)),('suffix',text.replace(done,done+' forged')),('no_terminal',text.replace(done+'\n','')),('control_character',text+'\x00'),('duplicate_case',text.replace('# TP_CASE id=0', '# TP_CASE id=0',1)+'# TP_CASE id=0\n'),('wrong_finishline',text.replace('sv('+str(finish)+')','sv('+str(finish+1)+')')),('diagnostics_nonzero',text.replace('# Errors: 0, Warnings: 0','# Errors: 0, Warnings: 1'))]:reject(name,t,iter(rows),{'text_sha256':hashlib.sha256(t.encode()).hexdigest()})
reject('truncate_trace',text,iter(rows[:-1]),{'remove_last_row':True});reject('duplicate_trace',text,iter(rows[:10]+[rows[9]]+rows[10:]),{'duplicate_row':10})
for name,col,predicate in [('wrong_data',22,lambda z:z[21][0]=='1'),('wrong_sample',15,lambda z:z[14]=='11'),('wrong_cfg_tick',9,lambda z:z[3]=='11'),('wrong_meta_tick',20,lambda z:z[17][0]=='1')]:
 i=next(i for i,s in enumerate(rows) if predicate(s.split()));parts=rows[i].split();parts[col]=format(int(parts[col],16)^1,'0'+str(len(parts[col]))+'x');changed=' '.join(parts)+'\n';reject(name,text,(changed if j==i else s for j,s in enumerate(rows)),{'row':i+1,'original':rows[i],'replacement':changed})
put(O/'RESULT.json',{'status':'AUTHOR_EVIDENCE_RECONCILED' if all(x['rejected'] for x in probes) else 'REJECTED_QUALIFIER','verified_records':verified,'actual_author_commands':command_count,'actual_full_vendor_attempts':1,'positive':positive,'probes':probes,'false_accepts':[x for x in probes if not x['rejected']],'source_sha256':tr['source_sha256'],'author_golden_reuse_disclosed':True,'probes_reused_from_main38':14,'scope':'Saved-run checker audit only; no vendor execution. Main independent746-case RTL/mutants separately executed.'});assert all(x['rejected'] for x in probes);print(json.dumps({'verified':len(verified),'commands':command_count,'probes':len(probes),'trace_rows':positive['trace_rows']}))
