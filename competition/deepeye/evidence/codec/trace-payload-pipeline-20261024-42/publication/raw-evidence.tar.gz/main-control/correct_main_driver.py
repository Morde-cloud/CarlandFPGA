from pathlib import Path
import json,hashlib,datetime
D=Path(__file__).parent
E=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/trace-payload-pipeline-20261024-42/main')
a=E/'preinspection-01';b=E/'preinspection-02';b.mkdir(exist_ok=False)
for n in ('main_reference.py','main_vectors.json','main_vectors.txt'):(b/n).write_bytes((a/n).read_bytes())
s=(a/'main_tb_trace_payload_timing_candidate.sv').read_text()
assert s.count('repeat(3)@(negedge clk);rst=0;')==1
s=s.replace('repeat(3)@(negedge clk);rst=0;','repeat(3)@(negedge clk);rst=0;@(negedge clk); // settle reset release before immediate public-ready check')
tb=b/'main_tb_trace_payload_timing_candidate.sv';tb.write_text(s,encoding='utf-8',newline='\n')
f=json.loads((a/'MAIN_FREEZE.json').read_bytes());f.update(tb_sha256=hashlib.sha256(tb.read_bytes()).hexdigest(),author42_source_read=True,correction='Original first main simulation failed at time30ns due immediate check in same delta as reset release. Add one negedge settlement only; preserve original run/preinspection01. No product source change. First inline correction command failed Python parse before executing; this standalone script is the actual correction.',corrected_at=datetime.datetime.now(datetime.timezone.utc).isoformat())
(b/'MAIN_FREEZE.json').write_text(json.dumps(f,indent=2),encoding='utf-8')
s=(D/'main_run42.py').read_text().replace("F=E/'preinspection-01'","F=E/'preinspection-02'")
(D/'main_run42_2.py').write_text(s,encoding='utf-8',newline='\n');print(f['tb_sha256'])
