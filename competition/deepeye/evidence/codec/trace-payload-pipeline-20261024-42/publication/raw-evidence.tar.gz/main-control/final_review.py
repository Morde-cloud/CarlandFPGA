from pathlib import Path
import datetime,hashlib,json,re
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/trace-payload-pipeline-20261024-42';O=E/'main/final-review-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
term=get(D/'native-terminal.json')[0];assert term['terminal'] and term['status']=='completed' and not term['stale'];tr=json.loads(term['result']['text']);assert sha(Path(tr['result_path']))==tr['result_sha256']
author=get(E/'author/FINAL_RESULT.json');audit=get(E/'main/author-audit-01/RESULT.json');positive=get(E/'main/positive-03/RESULT.json');mutants=get(E/'main/compiled-mutants-reconcile-01/RESULT.json');ooc=get(E/'main/reopen-01/RESULT.json')
assert author['vendor_invocations']==1 and author['functional_attempts']==1 and author['functional_fix_cycles']==0 and not author['protected_drift_final']
assert audit['status']=='AUTHOR_EVIDENCE_RECONCILED' and audit['actual_author_commands']==15 and len(audit['probes'])==14 and not audit['false_accepts']
assert positive['status']=='PASS' and positive['score']=={'cases':746,'preflight_aborts':36,'trace_rows':806616,'public_comparisons':23128,'byte_handshakes':10445,'complete_cfg_sample_meta_byte_history':True}
assert mutants['actual_compiled_mutants']==3 and mutants['production_unchanged'] and ooc['status']=='OOC_ARTIFACTS_VERIFIED_DIAGNOSTIC_TIMING_MET'
assert get(E/'main/preinspection-01/MAIN_FREEZE.json')['author42_source_read'] is False
for n,h in tr['source_sha256'].items():assert sha(P/n)==h
assert sha(P/'fpga/codec/deepeye_trace_payload_candidate.sv')==tr['original38_sha256_unchanged'] and sha(P/'fpga/codec/deepeye_block_encoder.sv')==tr['core_sha256_unchanged']
files=dict(audit['verified_records']);commands=[]
for n,v in files.items():assert sha(Path(n))==v['sha256']
for name in ['positive-01','positive-02','positive-03']+['mutant-'+x['name'] for x in mutants['rows']]:
 b=E/'main'/name
 for stem in ('version','vlib','vlog','vsim'):
  c=get(b/(stem+'.command.json'));assert c['pid']>0 and c['exit_code']==0 and not c['timeout']
  for stream in ('stdout','stderr'):assert sha(b/(stem+'.'+stream+'.bin'))==c[stream+'_sha256']
  commands.append({'path':str((b/(stem+'.command.json')).relative_to(E)),'sha256':sha(b/(stem+'.command.json')),'exit_code':0})
 raw=(b/'vsim.stdout.bin').read_text();errors='0' if name=='positive-03' else '1';assert re.findall(r'^# Errors: (\d+), Warnings: (\d+)$',raw,re.M)==[(errors,'0')]
 assert re.findall(r'^# \*\* (?:Error|Fatal|Warning):.*$',raw,re.M)==([] if errors=='0' else ['# ** Fatal: MAIN42_NUMERIC_FAILURE'])
 for p in b.rglob('*'):
  if p.is_file() and not any(x in ('lib','work','__pycache__') for x in p.relative_to(b).parts) and p.suffix.lower()!='.wlf':files[str(p)]={'sha256':sha(p),'bytes':p.stat().st_size}
assert len(commands)==24
for name in ('positive-01','positive-02'):assert get(E/'main'/name/'RESULT.json')['status']=='FAILED'
assert 'cycle=3 case=-100 reason=preflight_not_idle' in (E/'main/positive-01/vsim.stdout.bin').read_text()
assert 'cycle=7 case=-100 reason=preflight_stale_after_abort' in (E/'main/positive-02/vsim.stdout.bin').read_text()
assert ooc['resources']=={'Slice LUTs':2288,'Slice Registers':2810,'Block RAM Tile':0,'DSPs':2} and ooc['timing']['WNS']=='0.556' and len(ooc['drc'])==4
scope='Main accepts separate42 candidate for subsequent B-owned bounded integration, retaining38 unchanged. One uniform selected block<=32B, same tested bytes/error priority with two extra internal config cycles. This is not cycle-equivalence, public ABI/type7 adoption or hardware enable.'
out={'status':'ACCEPTED_BOUNDED_PIPELINED_TRACE_CANDIDATE','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-TRACE-PIPELINE-MAIN-REVIEW-20261024-42-v1','operation_id':'B-DEEPEYE-TRACE-PAYLOAD-PIPELINE-20261024-42','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','source_sha256':tr['source_sha256'],'source_review':['Exact main-selected staging: SPAN registers24bit products,65bitage and basic_bad; ENDPOINT registers33/65bit endpoint carries; CHECK consumes both. Valid-count span fits24bits; invalid count0 remains basicbad.','State0..10 retained, SPAN11/ENDPOINT12 added. All new registers reset/cancel initialized; existing synchronous CLEAR protocol unchanged. No sample/core admission in new preflight stages.','Other payload/core logic unchanged; held-age threshold, LEanchor, byte-tie original samples, padding, error ordering and output holding retain prior rule. Main read exact fullsource and four-source diff; hashed originals unchanged.'],'main_positive':positive,'main_commands':commands,'main_actual_vendor_commands':24,'main_actual_simulations':6,'main_compiled_mutants':mutants,'author_functional':tr['functional'],'author_commands':15,'main_saved_checker_negatives':14,'ooc':{k:v for k,v in ooc.items() if k!='verified_author_files'},'verified_records':files,'failed_main_evidence_preserved':['positive01 immediate reset-release combinational check at30ns failed; no product change.','positive02 incorrectly demanded ready during existing CLEAR cycle at65ns; corrected bounded public driver and retained originals.','First inline correction command failed Python parse before execution.','Third actual mutant rejected atcycle8/case-100 but original unsigned-case regex failed classification; offline signed-case reconciliation preserved original FAILED result, no new simulation.'],'scope':scope,'limitations':['Author oracle reuses pinned golden; main reuses unchanged independent38bitstring oracle/746cases. New36preflight abort tests written before42source inspection, with two disclosed main timing corrections afterward.','New actual42bytes all match same independent expectations as38; operation41Cdecoder execution remains bound to38, not relabeled as a new42Crun.','One actual Vivado2026.1 OOC run and one main DCP reopen;10ns diagnostic +0.556ns versus40 -4.073ns; +15LUT/+67FF,2DSP unchanged. Four unwaivedDRC and I/Odelay gaps remain.','No place/route/implementation/timingclosure/CDC_RDC/board/system/publicABI/BOOT/authenticated clock/motion. All29/B01/B03/B06/R03/fullproductnot_run; A-onlyphysicalboard.']}
(O/'RESULT.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'status':out['status'],'verified_records':len(files),'main_commands':24,'wns_ns':ooc['timing']['WNS']}))
