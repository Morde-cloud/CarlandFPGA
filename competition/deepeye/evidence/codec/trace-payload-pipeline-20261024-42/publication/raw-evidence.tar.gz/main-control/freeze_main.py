from pathlib import Path
import ast,datetime,hashlib,json
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;OLD=D.parent/'trace-payload-rtl-20261024-38';F=P/'evidence/codec/trace-payload-pipeline-20261024-42/main/preinspection-01';F.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
oldf=P/'evidence/codec/trace-payload-20261024-38/main/preinspection-01'
for n in ('main_reference.py','main_vectors.json','main_vectors.txt'):(F/n).write_bytes((oldf/n).read_bytes())
oldtb=P/'tests/rtl/codec/main_tb_trace_payload_candidate.sv';assert sha(oldtb)=='4c0f839a9f56c5b016acb6d1e1edbe9c14656dc69d069b95014da48cf113f561'
s=oldtb.read_text().replace('MAIN38','MAIN42').replace('deepeye_trace_payload_candidate','deepeye_trace_payload_timing_candidate')
s=s.replace('integer expected_error,','integer abort_tests=0,phase,kind,mode;\n  integer expected_error,')
s=s.replace('if(cv&&cr) $fdisplay','if(logfile && cv&&cr) $fdisplay')
insert='''
  // Main independent public-only preflight abort probes. No DUT hierarchy.
  task automatic probe_preflight(input integer ph,input integer use_reset,input integer cfgmode);
    integer n;
    begin
      cid=-100-abort_tests; cv=0;sv=1;sl=1;sd=16'hbade;mr=1;orr=1;
      cn=1;ce=0;session=32'hfeed1234;ch=1;idx=17;tick=99;source_tick=99;
      istride=1;tstride=1;valid_sample=1;sat=0;held=0;sfault=0;
      case(cfgmode)
        1:cn=0;
        2:begin cn=128;idx=32'hffffffff;istride=65535;end
        3:begin cn=2;tick=64'hffffffffffffffff;source_tick=tick;tstride=65535;end
        4:begin cn=2;held=1;tick=65536;source_tick=0;end
        5:begin cn=2;valid_sample=0;sfault=1;end
      endcase
      if(cr!==1||sr!==0||mv!==0||ov!==0)fail("preflight_not_idle");
      cv=1;@(posedge clk);if(cr!==1)fail("preflight_cfg_not_accepted");@(negedge clk);cv=0;
      for(n=0;n<ph;n=n+1)begin
        @(posedge clk);if(cr!==0||sr!==0||mv!==0||ov!==0)fail("preflight_premature_admission");@(negedge clk);
      end
      if(use_reset)rst=1;else cancel=1;
      @(posedge clk);if(cr!==0||sr!==0||mv!==0||ov!==0)fail("preflight_abort_gate");
      @(negedge clk);rst=0;cancel=0;sv=0;mr=0;orr=0;
      repeat(4)begin @(posedge clk);if(cr!==1||sr!==0||mv!==0||ov!==0)fail("preflight_stale_after_abort");@(negedge clk);end
      abort_tests=abort_tests+1;
    end
  endtask
'''
s=s.replace('  initial begin\n',insert+'  initial begin\n',1)
s=s.replace('    while(!$feof(f)) begin','    for(mode=0;mode<6;mode=mode+1)for(kind=0;kind<2;kind=kind+1)for(phase=0;phase<3;phase=phase+1)probe_preflight(phase,kind,mode);\n    cid=-1;\n    while(!$feof(f)) begin',1)
s=s.replace('MAIN42_DONE cases=%0d comparisons=%0d cycles=%0d",cases,comparisons,cycle','MAIN42_DONE cases=%0d comparisons=%0d cycles=%0d preflight_aborts=%0d",cases,comparisons,cycle,abort_tests')
tb=F/'main_tb_trace_payload_timing_candidate.sv';tb.write_text(s,encoding='utf-8',newline='\n')
freeze=json.loads((oldf/'MAIN_FREEZE.json').read_bytes());freeze.update(work_id='B-TRACE-PIPELINE-MAIN-20261024-42-v1',at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),author42_source_read=False,main_spec_sha256=sha(D/'MAIN_SPEC.md'),decision='Reuse unchanged independent38bitstring oracle and746cases, originally written before38author inspection. New main public-only36preflight reset/cancel probes written before42source inspection,6config modes x2abort types x3newpreflight phases. Same main chose42staging design; child reports function/OOC completion but source has not yet been inspected.',tb_sha256=sha(tb))
(F/'MAIN_FREEZE.json').write_text(json.dumps(freeze,indent=2)+'\n',encoding='utf-8')
s=(OLD/'main_run_trace38.py').read_text().replace("trace-payload-20261024-38/main","trace-payload-pipeline-20261024-42/main").replace('MAIN38','MAIN42').replace('deepeye_trace_payload_candidate','deepeye_trace_payload_timing_candidate')
s=s.replace("tb=P/'tests/rtl/codec/main_tb_trace_payload_candidate.sv';assert sha(tb)=='4c0f839a9f56c5b016acb6d1e1edbe9c14656dc69d069b95014da48cf113f561'","tb=F/'main_tb_trace_payload_timing_candidate.sv';assert sha(tb)==freeze['tb_sha256']")
s=s.replace("cycles=(\\d+)',markers[0])","cycles=(\\d+) preflight_aborts=(\\d+)',markers[0])")
s=s.replace("assert terminal\n","assert terminal and int(terminal[4])==36\n")
s=s.replace("cid=int(a[2]);c=actual[cid];assert c['cfg']==1","cid=int(a[2]);\n   if cid<0:continue\n   c=actual[cid];assert c['cfg']==1")
s=s.replace("'cases':len(cases),'trace_rows'","'cases':len(cases),'preflight_aborts':36,'trace_rows'")
ast.parse(s);(D/'main_run42.py').write_text(s,encoding='utf-8',newline='\n')
print(json.dumps({'freeze':str(F),'tb_sha256':sha(tb),'runner_sha256':sha(D/'main_run42.py'),'cases_reused':746,'new_abort_cases':36}))
