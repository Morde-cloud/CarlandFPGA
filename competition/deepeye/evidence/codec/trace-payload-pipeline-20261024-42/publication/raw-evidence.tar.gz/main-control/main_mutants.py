from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/trace-payload-pipeline-20261024-42/main';O=E/'compiled-mutants-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
core=P/'fpga/codec/deepeye_trace_payload_timing_candidate.sv';source=core.read_text();expected='0d5ba11fe199708f8376c718bbf3484431adc8dd6e847666451b1b5e873cec7b';assert sha(core)==expected
mutations=[('omit-index-carry','index_overflow_q<=index_end[32];','index_overflow_q<=1\'b0;'),('zero-registered-age','age_q<=age; basic_bad_q<=basic_bad;','age_q<=0; basic_bad_q<=basic_bad;'),('ignore-cancel-state','if (rst || cancel) begin','if (rst) begin')]
rows=[]
for name,before,after in mutations:
 assert source.count(before)==1
 q=O/(name+'.sv');q.write_text(source.replace(before,after),encoding='utf-8',newline='\n');argv=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(D/'main_run42_3.py'),'--name','mutant-'+name,'--mutant',str(q)]
 (O/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'source_sha256':sha(core),'mutant_sha256':sha(q)},indent=2));p=subprocess.run(argv,cwd=R,capture_output=True);(O/(name+'.stdout.bin')).write_bytes(p.stdout);(O/(name+'.stderr.bin')).write_bytes(p.stderr);r=json.loads((E/('mutant-'+name)/'RESULT.json').read_bytes());rows.append({'name':name,'exit_code':p.returncode,'result':r,'mutant_sha256':sha(q)});assert p.returncode==0 and r['status']=='EXPECTED_COMPILED_REJECTION';assert sha(core)==expected
(O/'RESULT.json').write_text(json.dumps({'actual_compiled_mutants':3,'rows':rows,'production_unchanged':True},indent=2));print(json.dumps(rows))
