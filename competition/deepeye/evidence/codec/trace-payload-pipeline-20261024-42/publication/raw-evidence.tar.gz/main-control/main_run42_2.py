from pathlib import Path
import argparse,datetime,hashlib,json,os,re,subprocess,time
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/codec/trace-payload-pipeline-20261024-42/main';F=E/'preinspection-02'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,x):
 with p.open('x',encoding='utf-8') as f:json.dump(x,f,indent=2)
def command(out,name,argv,seconds):
 argv=list(map(str,argv));put(out/(name+'.intent.json'),{'argv':argv,'cwd':str(out),'utc':datetime.datetime.now(datetime.timezone.utc).isoformat()});t=time.monotonic();p=subprocess.Popen(argv,cwd=out,stdout=subprocess.PIPE,stderr=subprocess.PIPE,creationflags=0x08000000);put(out/(name+'.started.json'),{'pid':p.pid});timed=False
 try:b,e=p.communicate(timeout=seconds)
 except subprocess.TimeoutExpired:
  timed=True;p.kill();b,e=p.communicate()
 (out/(name+'.stdout.bin')).write_bytes(b);(out/(name+'.stderr.bin')).write_bytes(e);put(out/(name+'.command.json'),{'argv':argv,'pid':p.pid,'exit_code':p.returncode,'timeout':timed,'elapsed':time.monotonic()-t,'stdout_sha256':sha(out/(name+'.stdout.bin')),'stderr_sha256':sha(out/(name+'.stderr.bin'))});assert not timed and p.returncode==0,(name,p.returncode,timed);return b.decode('utf-8',errors='replace')+e.decode('utf-8',errors='replace')
def score(out,raw,vectors):
 lines=[s.removeprefix('# ') for s in raw.splitlines()];markers=[s for s in lines if s.startswith('MAIN42_')];assert len(markers)==1,markers
 terminal=re.fullmatch(r'MAIN42_DONE cases=(\d+) comparisons=(\d+) cycles=(\d+) preflight_aborts=(\d+)',markers[0]);assert terminal and int(terminal[4])==36
 cases=vectors['cases'];expected_by_id={v['id']:v for v in cases};actual={};last_cycle=0;rows=0;handshakes=0
 for line in (out/'trace.txt').read_text().splitlines():
  a=line.split();assert a
  if a[0]=='T':
   assert len(a)==20,a;cyc=int(a[1]);assert cyc==last_cycle+1;last_cycle=cyc;rows+=1;cid=int(a[2]);assert all(x in ('0','1') for x in a[3:10]+a[11:13]+a[16:19]),line
   rst,cancel,cv,cr,sv,sr,sl=map(int,a[3:10]);mv,mr=map(int,a[11:13]);ov,orr,ol=map(int,a[16:19])
   if rst or cancel:assert not(cr or sr or mv or ov)
   if cid<0:continue
   c=actual.setdefault(cid,{'cfg':0,'samples':[],'meta':[],'bytes':[],'ends':0})
   if cv and cr:c['cfg']+=1
   if sv and sr:c['samples'].append((int(a[10],16),sl))
   if mv and mr:c['meta'].append((int(a[13],16),int(a[14],16),int(a[15],16)))
   if ov and orr:c['bytes'].append((int(a[19],16),ol));handshakes+=1
  elif a[0]=='C':
   assert len(a)==16,a;cid=int(a[2]);
   if cid<0:continue
   c=actual[cid];assert c['cfg']==1
   fields=vectors['format_fields'];assert [int(x,16) for x in a[3:]]==[expected_by_id[cid]['cfg'][k] for k in fields]
  elif a[0]=='E':
   assert len(a)==6;cid=int(a[2]);c=actual[cid];c['ends']+=1;v=expected_by_id[cid];q=v['expected'];assert int(a[3])==q['error'] and int(a[4])==len(q['bytes']) and int(a[5])==len(c['samples'])
  else:raise AssertionError(line)
 assert set(actual)==set(expected_by_id)
 for cid,v in expected_by_id.items():
  c=actual[cid];q=v['expected'];assert c['cfg']==1 and c['ends']==1 and c['meta']==[(q['error'],len(q['bytes']),q['tick'])],(cid,c)
  assert c['bytes']==[(x,int(i==len(q['bytes'])-1)) for i,x in enumerate(q['bytes'])],cid
  if q['error']==1 or not v['cfg']['valid']:assert not c['samples'],cid
  else:
   n=len(v['samples']) if v['bad_last'] is None else v['bad_last']+1
   assert c['samples']==[(x,(int(i==v['cfg']['count']-1)^int(i==v['bad_last']))) for i,x in enumerate(v['samples'][:n])],cid
 assert int(terminal[1])==len(cases) and int(terminal[2])==3*len(cases)+2*handshakes and int(terminal[3])==last_cycle
 return {'cases':len(cases),'preflight_aborts':36,'trace_rows':rows,'public_comparisons':int(terminal[2]),'byte_handshakes':handshakes,'complete_cfg_sample_meta_byte_history':True}
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--name',required=True);ap.add_argument('--mutant',type=Path);a=ap.parse_args();assert re.fullmatch('[a-zA-Z0-9_-]+',a.name);out=E/a.name;out.mkdir(exist_ok=False)
 freeze=get(F/'MAIN_FREEZE.json');vectors=get(F/'main_vectors.json');assert sha(F/'main_vectors.txt')==vectors['vectors_txt_sha256'];assert sha(F/'main_reference.py')==vectors['main_reference_sha256']
 for rel,x in freeze['pins'].items():assert sha(P/rel)==x['sha256']
 tb=F/'main_tb_trace_payload_timing_candidate.sv';assert sha(tb)==freeze['tb_sha256']
 rtl=a.mutant or P/'fpga/codec/deepeye_trace_payload_timing_candidate.sv';sources=[P/'fpga/codec/deepeye_block_encoder.sv',rtl,tb];snap=out/'inputs';snap.mkdir();binding={}
 for i,p in enumerate(sources):
  name='deepeye_trace_payload_timing_candidate.sv' if i==1 else p.name;(snap/name).write_bytes(p.read_bytes());binding[name]={'source':str(p),'sha256':sha(p)}
 for p in [F/'main_reference.py',F/'main_vectors.json',F/'main_vectors.txt',Path(__file__)]:(snap/p.name).write_bytes(p.read_bytes())
 put(out/'INPUTS.json',binding);tool=Path('D:/modelsim1/win64');result={'status':'RUNNING','mutant':a.mutant is not None}
 try:
  command(out,'version',[tool/'vsim.exe','-version'],30);command(out,'vlib',[tool/'vlib.exe','lib'],30);compilelog=command(out,'vlog',[tool/'vlog.exe','-sv','-work','lib',*[snap/n for n in binding]],60);assert not re.search(r'^#?\s*\*\* (Error|Warning)',compilelog,re.M)
  raw=command(out,'vsim',[tool/'vsim.exe','-c','-work','lib','-l',out/'transcript.txt','-wlf',out/'sim.wlf','-do','run -all; quit -f','main_trace_payload','+VECTORS='+str(snap/'main_vectors.txt'),'+TRACE='+str(out/'trace.txt')],240)
  if a.mutant:
   failures=[x.removeprefix('# ') for x in raw.splitlines() if x.removeprefix('# ').startswith('MAIN42_FAIL ')];assert len(failures)==1 and 'MAIN42_DONE' not in raw;z=re.fullmatch(r'MAIN42_FAIL cycle=(\d+) case=(\d+) reason=(\w+)',failures[0]);assert z and int(z[1])>0;result.update(status='EXPECTED_COMPILED_REJECTION',cycle=int(z[1]),case=int(z[2]),reason=z[3])
  else:result.update(status='PASS',score=score(out,raw,vectors))
  result.update(trace_sha256=sha(out/'trace.txt'),rtl_sha256=sha(rtl),tb_sha256=sha(tb),commands=4)
 except Exception as ex:result.update(status='FAILED',error=repr(ex));raise
 finally:put(out/'RESULT.json',result);print(json.dumps(result))
if __name__=='__main__':main()
