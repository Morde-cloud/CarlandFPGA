from pathlib import Path
import hashlib,json,re
D=Path(__file__).parent;P=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye');E=P/'evidence/codec/trace-payload-pipeline-20261024-42/main';O=E/'compiled-mutants-reconcile-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
rows=[]
expected=[('omit-index-carry',256066,312,'badcfg_accepted_sample'),('zero-registered-age',213574,185,'payload_value'),('ignore-cancel-state',8,-100,'preflight_stale_after_abort')]
for name,cycle,cid,reason in expected:
 d=E/('mutant-'+name);raw=(d/'vsim.stdout.bin').read_text();markers=re.findall(r'^# MAIN42_FAIL cycle=(\d+) case=(-?\d+) reason=(\w+)$',raw,re.M);assert markers==[(str(cycle),str(cid),reason)] and 'MAIN42_DONE' not in raw
 assert re.findall(r'^# Errors: (\d+), Warnings: (\d+)$',raw,re.M)==[('1','0')]
 assert re.findall(r'^# \*\* (?:Error|Fatal|Warning):.*$',raw,re.M)==['# ** Fatal: MAIN42_NUMERIC_FAILURE']
 commands=[]
 for stem in ('version','vlib','vlog','vsim'):
  c=json.loads((d/(stem+'.command.json')).read_bytes());assert c['exit_code']==0 and not c['timeout'] and c['pid']>0
  for stream in ('stdout','stderr'):assert sha(d/(stem+'.'+stream+'.bin'))==c[stream+'_sha256']
  commands.append({'path':str((d/(stem+'.command.json')).relative_to(E)),'sha256':sha(d/(stem+'.command.json'))})
 original=json.loads((d/'RESULT.json').read_bytes());assert original['status']==('FAILED' if cid<0 else 'EXPECTED_COMPILED_REJECTION')
 rows.append({'name':name,'cycle':cycle,'case':cid,'reason':reason,'original_result':original,'commands':commands,'trace_sha256':sha(d/'trace.txt'),'mutant_sha256':sha(d/'inputs/deepeye_trace_payload_timing_candidate.sv'),'tb_sha256':sha(d/'inputs/main_tb_trace_payload_timing_candidate.sv')})
assert sha(P/'fpga/codec/deepeye_trace_payload_timing_candidate.sv')=='0d5ba11fe199708f8376c718bbf3484431adc8dd6e847666451b1b5e873cec7b'
out={'status':'THREE_ACTUAL_COMPILED_MUTANTS_REJECTED','actual_compiled_mutants':3,'rows':rows,'production_unchanged':True,'reconciliation':'First mutant driver classified index/age correctly; third actual compiled mutant was also rejected by new preflight check at cycle8/case-100. Original main parser regex accepted only unsigned case IDs and therefore emitted FAILED. This saved-byte reconciliation accepts signed case IDs and independently verifies exact fatal/summary/command hashes; original failed audit unchanged. No new compile or simulation.'}
(O/'RESULT.json').write_text(json.dumps(out,indent=2),encoding='utf-8');print(json.dumps({'status':out['status'],'actual_compiled_mutants':3,'new_vendor_runs':0}))
