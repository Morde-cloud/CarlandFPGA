from pathlib import Path
from collections import Counter
import ast,datetime,hashlib,importlib.util,json,os,sys
D=Path(__file__).parent;R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';B=P/'evidence/codec/trace-uart-candidate-20261024-49';Q=D.parent/'trace-c-interop-preconditions-20261024';O=P/'evidence/codec/trace-uart-c-interop-20261024-51/main';O.mkdir(parents=True,exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
def put(p,v):
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
def crc(data):
 v=65535
 for b in data:
  for bit in range(7,-1,-1):
   carry=((v>>15)^((b>>bit)&1))&1;v=(v<<1)&65535
   if carry:v^=0x1021
 return v
def reseal(b):return bytes(b[:-2])+crc(b[2:-2]).to_bytes(2,'little')
result={'status':'RUNNING','pid':os.getpid(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-TRACE-UART-C-INTEROP-20261024-51-v1','operation_id':'B-DEEPEYE-TRACE-UART-C-INTEROP-20261024-51','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82'}
try:
 assert get(B/'main/positive-resume-01/RESULT.json')['status'].startswith('PASS') and get(B/'main/compiled-mutants-01/RESULT.json')['status'].startswith('PASS')
 audit=get(B/'main/author-audit-01/RESULT.json');assert audit['status'].startswith('PASS')
 assert sha(P/'fpga/codec/deepeye_trace_uart_candidate.sv')=='8aec895f3f3d71254d63cc6b4e73dd866cb81f2c42b24a54e11b2b3dd52f08b0'
 cp=Q/'downloaded/competition/deepeye/evidence/ai/trace_candidate_decode/candidate_decode.py';assert sha(cp)=='b02010280b72d3a94842db627f733df9c1fa6ecfe54f572509d57869d2d3d72c'
 inputs=[(Path(__file__),'run_interop.py'),(D/'MAIN_SPEC.md','MAIN_SPEC.md'),(B/'main/preinspection-01/main_vectors.json','vectors.json')]
 prior=D.parent/'trace-frame-c-interop-20261024-48/run_interop.py';tree=ast.parse(prior.read_text());fn=next(n for n in ast.walk(tree) if isinstance(n,ast.FunctionDef) and n.name=='expected');ns={};exec(compile(ast.Module(body=[fn],type_ignores=[]),str(prior),'exec'),ns);expected=ns['expected'];inputs.append((prior,'reused48-reference.py'))
 for rel,v in get(Q/'FETCHED.json')['files'].items():
  p=Q/'downloaded'/rel;assert sha(p)==v['sha256'];inputs.append((p,'c-fixed/'+rel))
 ratios=[(2,1,B/'main/positive-01/ratio-2-1/trace.txt')]+[(c,b,B/f'main/positive-resume-01/ratio-{c}-{b}/trace.txt') for c,b in [(5,2),(7,2),(16,3)]]
 for c,b,path in ratios:inputs.append((path,f'actual-trace-{c}-{b}'))
 pins={n:{'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for p,n in inputs};put(O/'INPUTS.json',pins)
 snap=O/'inputs';snap.mkdir()
 for p,n in inputs:
  if n.startswith('actual-trace-'):continue
  target=snap/n;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(p.read_bytes())
 put(O/'EXECUTION_FREEZE.json',{'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'script_sha256':sha(Path(__file__)),'spec_sha256':sha(D/'MAIN_SPEC.md'),'input_hashes':pins,'oracle_reuse':'48 expected-object function and 8 malformed-frame recipes, 49 preinspection vectors. Fresh UART trace decoding; no vendor run or new C author acceptance.'})
 spec=importlib.util.spec_from_file_location('fixed_c51',cp);decoder=importlib.util.module_from_spec(spec);spec.loader.exec_module(decoder)
 vm={v['id']:v for v in get(B/'main/preinspection-01/main_vectors.json')['cases']};frames=[];aborts=[];neg=[];counts=Counter();profiles=[]
 for clock,baud,path in ratios:
  entries={};active=None;t=q=0
  def ent(cid):return entries.setdefault(cid,{'bytes':[],'report':[],'abort':[]})
  for line in path.open(encoding='ascii'):
   a=line.split();cid=int(a[2]);x=ent(cid)
   if a[0]=='T':
    t+=1;assert int(a[1])==t
    if a[13:15]==['1','1']:x['report'].append([int(a[15],16),int(a[16],16)])
   elif a[0]=='Q':
    q+=1;assert int(a[1])==q;tx=int(a[7]);busy=int(a[8]);cancel=a[3]=='1' or a[4]=='1'
    if cancel:assert tx==1 and not busy;active=None;continue
    if active is None:
     if busy:assert tx==0;active=[q,cid,0]
     else:assert tx==1
    else:
     start,owner,value=active;assert cid==owner;age=q-start;phase=age*baud//clock;assert phase<=10
     if phase==10:assert not busy and tx==1;x['bytes'].append(value);active=None
     else:
      assert busy
      if 1<=phase<=8 and age==(phase*clock+baud-1)//baud:active[2]|=tx<<(phase-1)
   elif a[0]=='A':x['abort'].append(list(map(int,a[3:])))
  assert t==q and active is None;pc=Counter()
  for cid,x in entries.items():
   if cid==-1:assert not x['bytes'] and not x['report'];continue
   v=vm[cid] if cid>=0 else vm[24];packet=bytes(x['bytes'])
   if x['abort']:
    assert not x['report'] and packet==bytes(v['frame'][:len(packet)]);complete=len(packet)==len(v['frame']);aborts.append({'ratio':[clock,baud],'case':cid,'abort':x['abort'],'bytes_hex':packet.hex(),'complete_before_cancel':complete});pc['abort_complete' if complete else 'abort_partial_or_empty']+=1;continue
   assert packet==bytes(v['frame']) and x['report']==[[v['expected']['error'],len(packet)]]
   if v['expected']['error']:assert not packet;pc['error_'+str(v['expected']['error'])]+=1;continue
   c=v['cfg'];binding={'session':c['session'],'e':c['e'],'config_epoch':v['epoch']};decoded=decoder.decode_frame(packet,binding);assert decoded==expected(v)
   assert crc(packet[2:-2])==int.from_bytes(packet[-2:],'little');pc['normal' if cid>=0 else 'recovery']+=1;pc['bytes']+=len(packet);pc['points']+=len(decoded['points']);frames.append({'ratio':[clock,baud],'case':cid,'packet_hex':packet.hex(),'binding':binding,'decoded':decoded})
   if cid<0:continue
   mutants=[('crc',packet[:-1]+bytes([packet[-1]^1])),('truncated',packet[:-1]),('extra',packet+b'\0')]
   for name,i in [('version',2),('type',3),('length',4),('tick',8),('epoch',5)]:b=bytearray(packet);b[i]^=1;mutants.append((name,reseal(b)))
   for name,b in mutants:
    try:decoder.decode_frame(b,binding)
    except decoder.Reject as ex:neg.append({'ratio':[clock,baud],'case':cid,'recipe':name,'sha256':hashlib.sha256(b).hexdigest(),'reject':str(ex)})
    else:raise AssertionError(('C_false_accept',name,cid))
  assert pc['normal']==sum(not v['expected']['error'] for v in vm.values()) and pc['recovery']==48 and pc['abort_complete']+pc['abort_partial_or_empty']==48
  counts.update(pc);profiles.append({'clock':clock,'baud':baud,'cycles':q,'counts':dict(pc),'trace_sha256':sha(path)})
 for p,n in inputs:assert sha(p)==pins[n]['sha256']
 # Actual default packet independently decoded/scored by main49 is consumed once here.
 dr=audit['independent_default_saved_trace'];default=bytes.fromhex(dr['bytes_hex']);assert dr['trace_sha256']==sha(B/'author/attempt-01/ratio-100000000-9600/public.trace')
 fx=get(B/'author/attempt-01/ratio-100000000-9600/fixture.json')['vectors'][0];c=fx['cfg'];binding={'session':c['session'],'e':c['e'],'config_epoch':c['epoch']};dd=decoder.decode_frame(default,binding);assert dd['count']==c['count'] and dd['sequence']==c['seq'];put(O/'DEFAULT_PACKET.json',{'packet_hex':default.hex(),'binding':binding,'decoded':dd,'provenance':dr})
 put(O/'DECODED_CASES.json',frames);put(O/'ABORT_PREFIXES.json',aborts);put(O/'NEGATIVES.json',neg)
 result.update(status='PASS_ACTUAL_UART_BITS_FIXED_C_OFFLINE_DECODER',profiles=profiles,counts=dict(counts),decoded_frames=len(frames),negative_rejections=len(neg),default_saved_packet_bytes=len(default),c_head=get(Q/'FETCHED.json')['head'],c_decoder_sha256=sha(cp),requirements_sha256=audit['contract_sha256'],all29='not_run',scope='Fresh offline byte decoder over four actual B49 TX traces, independent main49 vectors, unchanged fixed C candidate. Default separately consumed from independently scored actual waveform. No continuous receiver/replay/cache/rollback/live transport/public ABI/BOOT/clock/source authority or board acceptance.')
except Exception as ex:result.update(status='FAILED',error=repr(ex));raise
finally:result['utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();put(O/'RESULT.json',result);print(json.dumps(result))
