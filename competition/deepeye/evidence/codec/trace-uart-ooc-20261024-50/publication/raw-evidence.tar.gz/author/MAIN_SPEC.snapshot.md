# B50: one bounded read-only UART candidate OOC

Task DEEPEYE-IMPLEMENTATION-20261014/v1; work B-TRACE-UART-OOC-20261024-50-v1; operation B-DEEPEYE-TRACE-UART-OOC-20261024-50. Main01a13b55-095b-7461-8dd5-5476a130bd82. Reuse worker01a16a34-b419-7942-9a7b-2b033142446b only after new lease self-validation. Prior49 jobchild-879bf96dccd349c98c83260993618022 and Appturn01a16d78-a6ee-7413-8953-fa9374aeefe3 actually completed/idle, native terminal received. No product writer overlap.

First read H01-H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 at f5989cd5defce561f9ba98e6b18fc2682945f0a2; verify canonical requirements SHA256 c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804. Frozen design1011259415a0916054eb580687612580bc1e5f09. Preserve full3D/UI/solidcollision/freecamera/editablelayout/equalblue-redfullpassage/hiddentruth/causalobservations/online3DPC-AI/twochains. All29 formal/B01/B03/B06/R03/fullproduct not_run. Physical board A only.

Published PR30 head c5e9b9da2d5df2d154a558f0054b7a0ed533d513 contains45-48.49 exact structural RTL is local, unchanged from author's completed turn. Main four-ratio public-port checks passed (53normal+48recovery+48abort per ratio); original first-PRE score failure preserved and corrected without replaying completed simulation. Main mutants/qualifier/default raw evidence review still pending; this task cannot accept49.

Productroot D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye. Exactly seven read-only source snapshots:
- fpga/codec/deepeye_trace_uart_candidate.sv 8aec895f3f3d71254d63cc6b4e73dd866cb81f2c42b24a54e11b2b3dd52f08b0
- fpga/codec/deepeye_trace_frame_candidate.sv ceff0930c2403eabe73bdd8a8cfe7bbb868ca33029d026a6a240c8d50a06a5cc
- fpga/codec/deepeye_trace_payload_timing_candidate.sv 0d5ba11fe199708f8376c718bbf3484431adc8dd6e847666451b1b5e873cec7b
- fpga/codec/deepeye_block_encoder.sv 4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532
- fpga/transport/deepeye_wire_serializer.sv efc6082f6f5dff215b100f718b12d87d4c6467db7b968a24f846802dc6a19885
- fpga/transport/deepeye_crc16_byte.sv 8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f
- fpga/transport/deepeye_uart_tx.sv 5076286e4dd1598aeb2c78281bec83020c85d0711dcee9b985088ac707353c47

Use unchanged fpga/build_qualification/ooc_qualification.tcl SHA54a4d66787d2fbfe78636d1fe14f6eb448fcec1529a6f2f068c8377addec33a9. Existing47 driver is a read-only example, no rerun47. Vivado.bat a5f91ee867cea61be4355caf9f7a784c6c34351c5c1d1618562ddda299e38a8b andexe3a4e9e3f03d20cd1994dc2eff44566af7a10eaaae04429e9d460bffe3b0e86e4 underD:/pynq/AMD2026/2026.1/Vivado.

Execute one OOC topdeepeye_trace_uart_candidate at unchanged defaults100000000/9600, partxc7z020clg400-1,maxThreads2, diagnostic10nsclk after synthesis only. No parameter optimization. Hidden subprocess/cmd /d /c; retain original Windows job/process handles and allhelperexits until terminal. Beforelaunch check nootherVivado; ifbusy use ordinary bounded300s wait or reportblocked withoutlaunch. New absent-before-create R/.local/b50/ shortwork/tmp/cache; child-only TEMP/TMP/TMPDIR/XILINX_LOCAL_USER_DATA. Bound600s; no vendorretry after failure/unknown, no cleanup/globalenv/service/driver/install edits. Separate no-process collection allowed for alreadywritten artifacts, not repeated vendor execution.

Exclusivewrites ONLY competition/deepeye/evidence/codec/trace-uart-ooc-20261024-50/author/ in product worktree and R/.local/b50/. No49oroldsource/docs/runner/evidence edits. Capture source/Tcl/tool hashes, actual model/thread/turn, argv/cwd/childenv/PIDs/time/exit/terminal handle evidence, rawlogs/journal/DCP/allreports/warnings. Rehash all7sources and protecteddirtycodecinput SHA6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8. Report exact resources/WNS/TNS/endpoints/DRC/I/Ogaps; positiveWNS is not timingclosure. Main independently reopens DCP later.

No ModelSim/place-route/bitstream/CDC_RDC/scheduler/BOOT/clock/ABI/source/motion/board or remoteacceptance. No child/Git/peer/group/service/credentials/SQL. Nativefallback is localVivado/Windowsfile/PID capability after2preservedFlash402; no billingretry. Main owns design/evaluation/acceptance. Selfvalidate private newlease with canonicalactualthread before execution, complete immutable native result, then final. Real [需桌面回合]/[需本人操作] blockers to main only; ordinary eventwait, no modelpolling.
