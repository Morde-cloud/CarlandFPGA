# Single UART candidate OOC50

Exactly one actual hidden Vivado2026.1 OOC of the seven pinned source snapshots,
default CLOCK_HZ100000000/BAUD9600, xc7z020clg400-1, maxThreads2.
No parameter optimization, source, runner or product-note edits. Read RESULT.json,
PROCESS.json, DIAGNOSTICS.json and FINAL_HASH_VERIFICATION.json for exact data.

The original Windows job/process handles were retained through active0 and every
tracked helper exit was recorded. Nonzero helper exits are preserved independently
of the actual cmd/Vivado exits. No vendor replay, implementation or board run.
All reports, DCP, stdout/stderr, log and journal remain with exact hashes.

Only10ns clk was added after synthesis. HD.CLK_SRC is unset, input/output delays
are absent, and OOC connectivity DRC coverage is incomplete. All warnings and DRC
violations remain unwaived. Positive WNS/TNS is not timing closure. The reused,
unchanged Tcl retains its original33 comments/B06 marker names; metadata identifies50.

Main owns independent DCP reopening and critical evaluation.49 remained under main
mutant/qualifier/default-evidence review at dispatch;50 cannot accept49, a public
ABI, clock/baud/source/control authority, motion grant, or the full product.
All29 formal cards, including B01/B03/B06/R03, remain not_run. Physical board A only.
H01-H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 requirements SHA256:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design1011259415a0916054eb580687612580bc1e5f09.
