"""Freeze one actual50 diagnostic; no process or vendor launch."""
from pathlib import Path
import hashlib
import json
import re
import sys
import os
import datetime
A=Path(__file__).resolve().parent
S=Path("D:/pynq/CarlandFPGA/.local/b50")
def load(p):return json.loads(Path(p).read_text(encoding="utf-8"))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,v):p.write_text(json.dumps(v,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
assert not (A/"ARTIFACT_MANIFEST.json").exists()
r=load(A/"RESULT.json")
assert r["status"]=="artifacts_complete_diagnostic_only" and r["vendor_launches"]==1 and r["synthesis_complete"]
assert r["job_id"]=="child-8f0f3fdd4f634b8ebd3a3c1010d55f6e"
assert os.environ["CODEX_THREAD_ID"]==r["agent_id"]
assert r["model"]=="gpt-6.1-sol" and r["effort"]=="max"
assert r["top_defaults"]==dict(CLOCK_HZ=100000000,BAUD=9600,parameter_overrides=[])
p=r["process"]
engine=[m for m in p["members"] if Path(m.get("image","")).name.lower()=="vivado.exe"]
assert len(engine)==1 and engine[0]["exit_code"]==p["exit_code"]==0
assert len(p["members"])==p["job_accounting"]["TotalProcesses"] and p["job_accounting"]["ActiveProcesses"]==0
assert not p["active_pids_at_end"] and not p["timed_out"]
assert all(isinstance(m.get("exit_code"),int) for m in p["members"])
for ref in r["input_pins"]:assert sha(ref["path"])==ref["sha256"],ref["path"]
sources=r["input_pins"][:7]
assert len({v["path"] for v in sources})==7
for ref in sources:assert sha(A/"snapshot"/Path(ref["path"]).name)==ref["sha256"]
for refs in r["outputs"].values():
    assert sha(refs["original"]["path"])==sha(refs["export"]["path"])==refs["export"]["sha256"]
prior=load(A/"ORIGINAL_EVIDENCE_BEFORE.json")
assert all(sha(path)==h for path,h in prior.items())
d=r["diagnostics"]
timing=d["timing_summary_metrics"]
assert timing["WNS_ns"]==d["diagnostic_wns_ns"]
assert d["drc_violation_count"]==sum(row["checks"] for row in d["drc_rules"])
util=(A/"reports/utilization.rpt").read_text(encoding="utf-8")
latch=re.search(r"^\|\s*Register as Latch\s*\|\s*([0-9]+)\s*\|",util,re.M)
assert latch
facts=dict(LUT=int(d["utilization"]["Slice LUTs"]),FF=int(d["utilization"]["Slice Registers"]),
           DSP=int(d["utilization"]["DSPs"]),BRAM=float(d["utilization"]["Block RAM Tile"]),
           latches=int(latch[1]),timing=timing,check_timing=d["check_timing"],drc_rules=d["drc_rules"],
           drc_violation_count=d["drc_violation_count"],console_warning_count=len(d["warnings"]),
           critical_warning_count=len(d["critical_warnings"]),error_count=len(d["errors"]))
save(A/"FINAL_HASH_VERIFICATION.json",dict(result_sha256=sha(A/"RESULT.json"),dcp_sha256=sha(A/"ooc.dcp"),
    exact7sources=sources,read_only_inputs_unchanged=True,preserved_earlier_files=len(prior),facts=facts,
    verification_process=dict(pid=os.getpid(),argv=sys.argv,cwd=os.getcwd(),python=sys.executable,
                              utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),vendor_launches=0)))
note="""# Single UART candidate OOC50

Exactly one actual hidden Vivado2026.1 OOC of the seven pinned source snapshots,
default CLOCK_HZ100000000/BAUD9600, xc7z020clg400-1, maxThreads2.
No parameter optimization, source, runner or product-note edits. Read RESULT.json,
PROCESS.json, DIAGNOSTICS.json and FINAL_HASH_VERIFICATION.json for exact data.

The original Windows job/process handles were retained through active0 and every
tracked helper exit was recorded. Nonzero helper exits are preserved independently
of the actual cmd/Vivado exits. No vendor replay, implementation or board run.
All reports, DCP, stdout/stderr, log and journal remain with exact hashes.

Only10ns clk was added after synthesis. HD.CLK_SRC is unset, input/output delays
are absent, and OOC connectivity DRC coverage is incomplete. All warnings and DRC
violations remain unwaived. Positive WNS/TNS is not timing closure. The reused,
unchanged Tcl retains its original33 comments/B06 marker names; metadata identifies50.

Main owns independent DCP reopening and critical evaluation.49 remained under main
mutant/qualifier/default-evidence review at dispatch;50 cannot accept49, a public
ABI, clock/baud/source/control authority, motion grant, or the full product.
All29 formal cards, including B01/B03/B06/R03, remain not_run. Physical board A only.
H01-H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 requirements SHA256:
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design1011259415a0916054eb580687612580bc1e5f09.
"""
(A/"README.md").write_text(note,encoding="utf-8",newline="\n")
payload=dict(task=r["task"],work=r["work"],operation=r["operation"],job_id=r["job_id"],
 agent_id=r["agent_id"],turn_id=r["turn_id"],model=r["model"],effort=r["effort"],parent_id=r["parent_id"],
 status=r["status"],result=str(A/"RESULT.json"),result_sha256=sha(A/"RESULT.json"),
 dcp=str(A/"ooc.dcp"),dcp_sha256=sha(A/"ooc.dcp"),source_pins=sources,defaults=r["top_defaults"],
 actual_run=dict(launches=1,replays=0,cmd_pid=p["pid"],cmd_exit=p["exit_code"],
                 vivado_pid=engine[0]["pid"],vivado_exit=engine[0]["exit_code"],
                 elapsed_seconds=p["elapsed_seconds"],tracked_members=len(p["members"]),active_at_end=0,
                 all_actual_exits_captured=True,nonzero_helpers=d["nonzero_helper_exits"]),
 diagnostic=facts,preservation=dict(earlier_files_unchanged=len(prior),all7sources_Tcl_tools_protected_input_unchanged=True),
 contract=r["contract"],all29="not_run",B01="not_run",B03="not_run",B06="not_run",R03="not_run",
 limits="Only50 source-read-only OOC diagnostics. No49 acceptance, timing closure, ABI/source/clock/baud/motion authority, implementation or board claim. Main independently reopens DCP.")
save(A/"COMPLETION_PAYLOAD.json",payload)
def records(root):
    return [dict(path=v.relative_to(root).as_posix(),bytes=v.stat().st_size,sha256=sha(v))
            for v in sorted(root.rglob("*")) if v.is_file()]
short=records(S)
save(A/"SHORT_ARTIFACT_MANIFEST.json",dict(root=str(S),files=short))
files=records(A)
save(A/"ARTIFACT_MANIFEST.json",dict(root=str(A),files=files))
print(json.dumps(dict(result_sha256=sha(A/"RESULT.json"),dcp_sha256=sha(A/"ooc.dcp"),
                      manifest_sha256=sha(A/"ARTIFACT_MANIFEST.json"),author_files=len(files),
                      short_files=len(short),facts=facts,cmd_pid=p["pid"],vivado_pid=engine[0]["pid"],
                      members=len(p["members"]),active_at_end=0,elapsed_seconds=p["elapsed_seconds"],
                      preserved_earlier_files=len(prior)),ensure_ascii=True))
