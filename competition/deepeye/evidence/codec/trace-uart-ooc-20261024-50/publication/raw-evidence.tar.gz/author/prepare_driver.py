"""Prepare new50 only; read47 example as text, never import/execute/alter it."""
from pathlib import Path
import hashlib
import ast
import json
A=Path(__file__).resolve().parent
P=A.parents[3]
OLD=P/"evidence/codec/trace-frame-ooc-20261024-47/author/run_one_ooc.py"
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(OLD)=="af5b13231db6eac9345cea3a5da9def5c94b17c1b5033af447f3f4c5c2bd4ae8"
text=OLD.read_text(encoding="utf-8")
def replace(before,after):
    global text
    assert before in text,before[:80]
    text=text.replace(before,after)
replace('.local/b47','.local/b50')
replace('TOP="deepeye_trace_frame_candidate"','TOP="deepeye_trace_uart_candidate"')
replace('B-TRACE-FRAME-OOC-20261024-47-v1','B-TRACE-UART-OOC-20261024-50-v1')
replace('B-DEEPEYE-TRACE-FRAME-OOC-20261024-47','B-DEEPEYE-TRACE-UART-OOC-20261024-50')
replace('child-f2e3c7deb83249eaac6b63240dfba2b8','child-8f0f3fdd4f634b8ebd3a3c1010d55f6e')
replace('01a16d6d-7c5f-7ba3-b1a9-919936b1d7ac','01a16e79-7bd4-7502-9cd1-a6a3f14e9f3c')
replace('run_id=b47','run_id=b50')
replace('actual operation47','actual operation50')
replace('evidence/trace-frame-ooc-20261024-47/MAIN_SPEC.md','evidence/trace-uart-ooc-20261024-50/MAIN_SPEC.md')
sources=[
 ("fpga/codec/deepeye_trace_uart_candidate.sv","8aec895f3f3d71254d63cc6b4e73dd866cb81f2c42b24a54e11b2b3dd52f08b0"),
 ("fpga/codec/deepeye_trace_frame_candidate.sv","ceff0930c2403eabe73bdd8a8cfe7bbb868ca33029d026a6a240c8d50a06a5cc"),
 ("fpga/codec/deepeye_trace_payload_timing_candidate.sv","0d5ba11fe199708f8376c718bbf3484431adc8dd6e847666451b1b5e873cec7b"),
 ("fpga/codec/deepeye_block_encoder.sv","4cb79428ef89096742e293516c4696caf985048d8185f531fe92eaa485c8d532"),
 ("fpga/transport/deepeye_wire_serializer.sv","efc6082f6f5dff215b100f718b12d87d4c6467db7b968a24f846802dc6a19885"),
 ("fpga/transport/deepeye_crc16_byte.sv","8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f"),
 ("fpga/transport/deepeye_uart_tx.sv","5076286e4dd1598aeb2c78281bec83020c85d0711dcee9b985088ac707353c47"),
]
start=text.index("SOURCES=");end=text.index("\nPINS=",start)
text=text[:start]+"SOURCES="+repr(sources)+text[end:]
replace('["SOURCE_READ"]*5','["SOURCE_READ"]*7')
replace('B06_OOC_SOURCE_COUNT|count=5','B06_OOC_SOURCE_COUNT|count=7')
start=text.index('    state["parent45_context"]=')
end=text.index('    original={}',start)
text=text[:start]+(
 '    state["parent49_context"]="Main four-ratio public-port checks passed.49 mutants/qualifier/default review still pending at dispatch;50 hardware evidence cannot accept49 or product."\n'
 '    state["model"]="gpt-6.1-sol";state["effort"]="max"\n'
 '    state["model_provenance"]="Own exact turn_context metadata in PREFLIGHT_READS.json"\n'
 '    state["top_defaults"]={"CLOCK_HZ":100000000,"BAUD":9600,"parameter_overrides":[]}\n'
)+text[end:]
replace('    for parent in (P/"evidence/acquisition/scan-lane-ooc-20261024-46/author",R/".local/b46"):',
        '    for parent in (P/"evidence/codec/trace-frame-ooc-20261024-47/author",R/".local/b47",P/"evidence/codec/trace-uart-candidate-20261024-49/author"):')
replace('original46 evidence changed','preserved earlier evidence changed')
replace('original46_evidence_files_unchanged','preserved_evidence_files_unchanged')
replace('    diagnostics=dict(warnings=warnings,critical_warnings=critical,errors=errors,markers=markers,',
        '    numeric=re.search(r"^\\s*(-?[0-9]+\\.[0-9]+)\\s+([^\\n]+)$",timing[at:],re.M)\n'
        '    require(numeric is not None,"timing summary numeric row missing")\n'
        '    columns=numeric[0].split();require(len(columns)==12,"timing summary endpoint columns")\n'
        '    keys=["WNS_ns","TNS_ns","TNS_failing_endpoints","TNS_total_endpoints","WHS_ns","THS_ns","THS_failing_endpoints","THS_total_endpoints","WPWS_ns","TPWS_ns","TPWS_failing_endpoints","TPWS_total_endpoints"]\n'
        '    timing_metrics={key:(int(value) if "endpoints" in key else float(value)) for key,value in zip(keys,columns)}\n'
        '    diagnostics=dict(warnings=warnings,critical_warnings=critical,errors=errors,markers=markers,\n'
        '                     timing_summary_metrics=timing_metrics,')
ast.parse(text)
target=A/"run_one_ooc.py"
assert not target.exists()
target.write_text(text,encoding="utf-8",newline="\n")
meta=dict(old_readonly_example=str(OLD),old_sha256=sha(OLD),new_driver_sha256=sha(target),
          sources=sources,policy="Exactly one new50 default-parameter OOC. Same original Windows job/handle tracking; no old driver/vendor replay or source edits.")
(A/"DRIVER_DERIVATION.json").write_text(json.dumps(meta,ensure_ascii=False,indent=2)+"\n",encoding="utf-8",newline="\n")
print(json.dumps(meta))
