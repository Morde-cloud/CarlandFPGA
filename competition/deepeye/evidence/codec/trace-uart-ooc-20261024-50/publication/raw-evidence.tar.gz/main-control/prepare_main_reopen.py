from pathlib import Path
import hashlib,json
D=Path(__file__).parent;source=D.parent/'trace-frame-ooc-20261024-47/main_reopen47.py';s=source.read_text()
changes=[('trace-frame-ooc-20261024-47','trace-uart-ooc-20261024-50'),("D/'native-terminal.json'","D/'native-terminal-wait1.json'"),('a2882850632f15b7777f6d06188e2f6aa66e0b103681d7653e86672f66630342','8f075d49a0a1b588109de327556562d33522e149de1c01aec50d3786453e7881'),("{'Slice LUTs':2430,'Slice Registers':2957,'Block RAM Tile':0,'DSPs':2}","{'Slice LUTs':2468,'Slice Registers':2996,'Block RAM Tile':0,'DSPs':2}"),('MAIN47_','MAIN50_'),('ports=323','ports=308'),("['no_input_delay']==289","['no_input_delay']==288"),("['no_output_delay']==33","['no_output_delay']==19"),('B-DEEPEYE-TRACE-FRAME-OOC-20261024-47','B-DEEPEYE-TRACE-UART-OOC-20261024-50'),('289inputand33outputdelaygaps','288inputand19outputdelaygaps'),('45qualifier acceptance separately pending.','49simulatedUART acceptance is separate; no actualbaud/calibration grant.')]
for a,b in changes:assert a in s,a;s=s.replace(a,b)
target=D/'main_reopen50.py';assert not target.exists();target.write_text(s,encoding='utf-8',newline='\n')
with (D/'MAIN_REOPEN_DERIVATION.json').open('x',encoding='utf-8') as f:json.dump({'source':str(source),'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'changes':changes,'new_sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scope':'Main one exact DCP read/report; no resynthesis. Expected totalports308 from unchanged interface and author timing diagnostics288inputs19outputs+clock.'},f,indent=2)
print(target)
