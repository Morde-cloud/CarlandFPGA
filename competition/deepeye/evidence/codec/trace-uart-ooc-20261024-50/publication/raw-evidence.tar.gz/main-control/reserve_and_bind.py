from pathlib import Path
import json,subprocess,sys,datetime
D=Path(__file__).parent;R=Path('D:/pynq/CarlandFPGA');thread='01a16a34-b419-7942-9a7b-2b033142446b'
def put(p,v):
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
args={'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-TRACE-UART-OOC-20261024-50-v1','ownership':['.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/trace-uart-ooc-20261024-50/author','.local/b50'],'reason':'Local Vivado/Windows original-process handle and DCP capability after two actual Flash402. One main-defined diagnostic OOC for exact49RTL; main independently reviews. Prior49job and actual Appturn completed.','text':'Read '+str(D/'MAIN_SPEC.md')+'. Selfvalidate newlease canonical'+thread+'; only2exclusive evidence/scratch paths. No49source edits; H01-H15 fixedhash/A-onlyboard/all29not_run. Execute one bounded original-handle OOC, no replay; actual evidence to main.'}
put(D/'reserve-args.json',args)
def call(action,arg,out):
 p=subprocess.run([sys.executable,'-B','-X','utf8','-m','fpga_mesh.project_cli',action,'--args-file',str(arg)],cwd=R,capture_output=True,timeout=60,creationflags=0x08000000)
 (D/(action+'.stderr.bin')).write_bytes(p.stderr)
 assert p.returncode==0,(action,p.returncode)
 data=json.loads(p.stdout);put(out,data);return data
n=call('native_reserve',D/'reserve-args.json',D/'native-private.json')
assert not n.get('duplicate'), 'Do not START duplicate; inspect persisted result'
put(D/'bind-args-private.json',{'job_id':n['job_id'],'lease_token':n['lease_token'],'agent_id':thread})
b=call('native_validate',D/'bind-args-private.json',D/'binding-private.json');assert b['execution_allowed']
put(D/'wait-args.json',{'job_ids':[n['job_id']]})
receipt={'job_id':n['job_id'],'native_agent_id':thread,'execution_allowed':b['execution_allowed'],'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'START_sent':False,'token_printed':False};put(D/'RESERVED.json',receipt);print(json.dumps(receipt))
