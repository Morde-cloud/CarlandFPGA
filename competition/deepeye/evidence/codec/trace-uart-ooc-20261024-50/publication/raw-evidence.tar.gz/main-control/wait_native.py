from pathlib import Path
import subprocess,sys,json,datetime
D=Path(__file__).parent;R=Path('D:/pynq/CarlandFPGA')
def put(p,v):
 with p.open('x',encoding='utf-8') as f:json.dump(v,f,indent=2)
put(D/'WAIT_ACTION_CORRECTION.json',{'previous_action':'child_wait','actual_exit':1,'actual_error':'RuntimeError: unknown local control action','source_check':'fpga_mesh/child_control.py line726 recognizes wait; rejected request created no wait or job. Empty native-terminal.json retained.','corrected_action':'wait','no_START_replay':True})
put(D/'START_RECEIPT.json',{'threadId':'01a16a34-b419-7942-9a7b-2b033142446b','tool':'mcp__codex_app__send_message_to_thread','result':{'threadId':'01a16a34-b419-7942-9a7b-2b033142446b'},'isError':False,'delivery_not_execution':True})
argv=[sys.executable,'-B','-X','utf8','-m','fpga_mesh.project_cli','wait','--args-file',str(D/'wait-args.json')]
with (D/'native-terminal-wait1.json').open('xb') as o,(D/'wait1.stderr.bin').open('xb') as e:
 p=subprocess.Popen(argv,cwd=R,stdout=o,stderr=e,creationflags=0x08000000)
 put(D/'WAIT_STARTED.json',{'pid':p.pid,'argv':argv,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'ordinary_program_wait':True,'no_model_poll':True})
 code=p.wait();put(D/'WAIT_EXIT.json',{'pid':p.pid,'exit_code':code});print(json.dumps({'pid':p.pid,'exit_code':code}))
