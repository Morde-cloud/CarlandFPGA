set_param general.maxThreads 2
puts "MAIN50_REOPEN_BEGIN"
open_checkpoint {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/trace-uart-ooc-20261024-50/author/ooc.dcp}
puts "MAIN50_DESIGN|part=[get_property PART [current_design]]|ports=[llength [get_ports]]|clocks=[llength [get_clocks]]"
foreach c [get_clocks] {puts "MAIN50_CLOCK|name=[get_property NAME $c]|period=[get_property PERIOD $c]"}
report_utilization -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/trace-uart-ooc-20261024-50/main/reopen-01/utilization.rpt}
report_timing_summary -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/trace-uart-ooc-20261024-50/main/reopen-01/timing_summary.rpt}
report_timing -delay_type max -max_paths 10 -path_type full_clock_expanded -input_pins -file {D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye/evidence/codec/trace-uart-ooc-20261024-50/main/reopen-01/critical_paths.rpt}
close_design
puts "MAIN50_REOPEN_END"
exit 0
