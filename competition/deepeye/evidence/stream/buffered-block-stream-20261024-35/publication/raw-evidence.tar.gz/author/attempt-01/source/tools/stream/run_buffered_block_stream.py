#!/usr/bin/env python3
"""Bounded ModelSim author fixture; no design or product acceptance authority.

Reuses the pinned published codec reference, never the main's oracle. All new
files (including vendor tool scratch files) are confined to the owned author
directory. Each invocation reserves a fresh numbered attempt and preserves it.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
import types
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
REPO = ROOT.parents[1]
AUTHOR = ROOT / "evidence/stream/buffered-block-stream-20261024-35/author"
SOURCE_COMMIT = "bbfb11439b35e0866a6d2486f3857b92ed6cf529"
CONTRACT_COMMIT = "f5989cd5defce561f9ba98e6b18fc2682945f0a2"
REQUIREMENTS_SHA = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
AGENT_ID = "01a16a27-3458-7103-a4ab-cd06fd084da7"
JOB_ID = "child-64ceef15f6da43d180d604be08e43c43"
WORK_ID = "B-BUFFERED-BLOCK-STREAM-20261024-35-native-recovery1"
PINS = {
    "fpga/codec/deepeye_block_encoder.sv":
        "870bc5dcfe9a3a82124cf5d305082964b9a6ebf3447c13f1a92ec052a591d8a5",
    "fpga/stream/deepeye_block_stream.sv":
        "c8f8c0d99769efc64a91402ee23e7157368ff90ec765db5c413f02546715fff4",
    "fpga/stream/deepeye_encoded_frame_queue.sv":
        "68f9b655794a722a5cb285ac1c87749ea7acea7dcd6c1650536d1f1094c2e76a",
    "golden/codec/codec_reference.py":
        "2e24e01c7e8cc9a010f9c0f26d94091b33676b7394f0f7344ca5bf938fefbfd5",
    "golden/codec/known_vectors.json":
        "c1eee67b73b8cdd449ac72b2a77c78f714eaf448b1216b16296488881ac10e99",
}
OWNED_SOURCES = (
    "fpga/stream/deepeye_buffered_block_stream.sv",
    "tests/rtl/stream/tb_buffered_block_stream.sv",
    "tools/stream/run_buffered_block_stream.py",
    "fpga/stream/buffered_block_stream_candidate.md",
)
PHASES = (
    "raw_fill", "encoding", "metadata_boundary", "encoded_fill",
    "output_stall", "final_data", "final_error_metadata",
)
# Counts follow the authored control flow; they are not inferred from a DUT log.
CASE_CHECKS = [
    ("valid_vectors", 3),
    ("error_order_duplicate_tags", 3),
    ("full_queue_frontend_backpressure", 5),
    ("final_data_metadata_same_edge_credit", 2),
    ("error_metadata_same_edge_credit", 2),
    ("full_error_metadata_retirement_bubble", 3),
]
CASE_CHECKS += [(f"{op}_{phase}", 6 if op == "cancel" else 5)
                for phase in PHASES for op in ("cancel", "reset")]
CASE_CHECKS += [("reset_over_cancel_priority", 5)]


class FixtureFailure(RuntimeError):
    pass


def now():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return hashlib.sha256(data).hexdigest()


def save_json(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")


def run_command(attempt, records, argv, timeout=60):
    """Persist raw streams and actual exit even on failure/timeout."""
    index = len(records) + 1
    stem = f"command-{index:02d}"
    rec = {
        "argv": [str(x) for x in argv], "cwd": str(attempt),
        "started_at": now(), "timeout_seconds": timeout,
        "hidden_window": os.name == "nt",
    }
    opts = {}
    if os.name == "nt":
        si = subprocess.STARTUPINFO()
        si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        si.wShowWindow = subprocess.SW_HIDE
        opts = {"startupinfo": si, "creationflags": subprocess.CREATE_NO_WINDOW}
    start = time.monotonic()
    try:
        proc = subprocess.Popen(rec["argv"], cwd=attempt,
                                stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                                **opts)
        rec["pid"] = proc.pid
        try:
            stdout, stderr = proc.communicate(timeout=timeout)
            rec["timed_out"] = False
        except subprocess.TimeoutExpired:
            rec["timed_out"] = True
            if os.name == "nt":
                cleanup = subprocess.run(
                    ["taskkill.exe", "/PID", str(proc.pid), "/T", "/F"],
                    capture_output=True, **opts, timeout=15)
                (attempt / f"{stem}.timeout-cleanup.stdout.bin").write_bytes(cleanup.stdout)
                (attempt / f"{stem}.timeout-cleanup.stderr.bin").write_bytes(cleanup.stderr)
                rec["cleanup_exit_code"] = cleanup.returncode
            else:
                proc.kill()
            stdout, stderr = proc.communicate(timeout=15)
        rec["exit_code"] = proc.returncode
    except OSError as exc:
        stdout, stderr = b"", str(exc).encode("utf-8")
        rec.update(exit_code=None, timed_out=False, launch_error=str(exc))
    rec.update(finished_at=now(), elapsed_seconds=time.monotonic() - start)
    for name, data in (("stdout", stdout), ("stderr", stderr)):
        path = attempt / f"{stem}.{name}.bin"
        path.write_bytes(data)
        rec[name] = {"path": str(path.relative_to(AUTHOR)),
                     "sha256": digest(data), "bytes": len(data)}
    records.append(rec)
    save_json(attempt / "commands.json", records)
    if rec["timed_out"] or rec["exit_code"] != 0:
        raise FixtureFailure(f"{stem}: exit={rec['exit_code']} timeout={rec['timed_out']}")
    return stdout, stderr


def reject_diagnostics(raw):
    text = raw.decode("utf-8", errors="strict")
    for line in text.splitlines():
        line = line[2:] if line.startswith("# ") else line
        tally = re.fullmatch(r"(?:End time: .*? )?Errors: ([0-9]+), Warnings: ([0-9]+)", line)
        # ModelSim's end-time and diagnostic tally may occupy separate lines.
        if tally:
            if tuple(map(int, tally.groups())) != (0, 0):
                raise FixtureFailure("nonzero ModelSim diagnostic tally")
            continue
        if re.search(r"\b(?:warning|fatal|error)\b", line, re.IGNORECASE):
            raise FixtureFailure(f"ModelSim diagnostic: {line}")
        if re.search(r"Errors:\s*[1-9]|Warnings:\s*[1-9]", line):
            raise FixtureFailure(f"nonzero embedded tally: {line}")
    return text


def make_vectors():
    ref = types.ModuleType("published_codec_reference")
    ref.__file__ = str(ROOT / "golden/codec/codec_reference.py")
    exec(compile(Path(ref.__file__).read_bytes(), ref.__file__, "exec"), ref.__dict__)
    known = json.loads((ROOT / "golden/codec/known_vectors.json").read_bytes())
    vectors = []
    verified_known = 0

    def add(name, samples, e, count=None, error=0, lasts=None, fixture=None):
        nonlocal verified_known
        count = len(samples) if count is None else count
        if not error:
            computed = ref.encode_block(samples, e)
            if fixture is not None:
                if computed != fixture:
                    raise FixtureFailure(f"published fixture mismatch: {name}")
                verified_known += 1
            fixture = computed
            meta = {
                "count": count, "e": e, "raw": int(fixture["mode"] == "raw"),
                "k": fixture["k"] or 0, "bits": fixture["valid_bit_count"],
                "payload": list(bytes.fromhex(fixture["payload_hex"])),
            }
        else:
            meta = {"count": 0, "e": 0, "raw": 1, "k": 0, "bits": 0, "payload": []}
        vectors.append({
            "name": name, "samples": samples, "e": e, "count": count,
            "error": error,
            "lasts": lasts if lasts is not None else
                [int(i == len(samples) - 1) for i in range(len(samples))],
            "expected": meta,
        })

    add("single_anchor", [0x1234], 0)
    add("two_near", [90, 91], 1)
    add("long_raw_extrema", [0, 65535] * 64, 0)
    add("invalid_count_zero", [], 0, count=0, error=1)
    add("early_last", [12], 0, count=4, error=2, lasts=[1])
    add("late_last", [12, 13], 0, count=2, error=2, lasts=[0, 0])
    for ei, e in enumerate((0, 1, 2, 4, 8)):
        for ni, n in enumerate((1, 2, 127, 128)):
            pattern = (ei + ni) % 5
            if pattern == 0:
                values = [0] * n
            elif pattern == 1:
                values = [1000 + 11 * i for i in range(n)]
            elif pattern == 2:
                values = [32000 + (i % 17) * 123 if i % 34 < 17
                          else 32000 - (i % 17) * 123 for i in range(n)]
            elif pattern == 3:
                values = [0 if i % 2 == 0 else 65535 for i in range(n)]
            else:
                values = []
                state = 0x350024
                for _ in range(n):
                    state = (1664525 * state + 1013904223) & 0xFFFFFFFF
                    values.append(state >> 16)
            add(f"matrix_n{n}_e{e}_pattern{pattern}", values, e)
    for count in (129, 255):
        add(f"invalid_count_{count}", [], 0, count=count, error=1)
    for e in (3, 15):
        add(f"invalid_e_{e}", [], e, count=2, error=1)
    for group in ("hand_vectors", "raw_noisy_examples", "raw_step_examples"):
        for item in known[group]:
            add(item["id"], item["samples"], item["e"], fixture=item["fixture"])
    return vectors, verified_known


def write_include(path, vectors):
    lines = [
        "// Author expectations from the pinned published codec reference.",
        "localparam int V_SINGLE=0, V_SMALL=1, V_LONG=2, V_ERR=3;",
        f"localparam int V_TOTAL={len(vectors)};",
        "int v_count [0:V_TOTAL-1], v_e [0:V_TOTAL-1], v_error [0:V_TOTAL-1];",
        "int v_send [0:V_TOTAL-1], v_meta_count [0:V_TOTAL-1], v_meta_e [0:V_TOTAL-1];",
        "int v_raw [0:V_TOTAL-1], v_k [0:V_TOTAL-1], v_bits [0:V_TOTAL-1];",
        "int v_bytes [0:V_TOTAL-1];",
        "logic [15:0] v_samples [0:V_TOTAL-1][0:127];",
        "logic [7:0] v_payload [0:V_TOTAL-1][0:255];",
        "bit v_last [0:V_TOTAL-1][0:127];",
        "task automatic load_vectors;",
        "begin",
    ]
    for i, v in enumerate(vectors):
        meta = v["expected"]
        fields = {"count": v["count"], "e": v["e"], "error": v["error"],
                  "send": len(v["samples"]), "meta_count": meta["count"],
                  "meta_e": meta["e"], "raw": meta["raw"], "k": meta["k"],
                  "bits": meta["bits"], "bytes": len(meta["payload"])}
        lines += [f"v_{key}[{i}]={val};" for key, val in fields.items()]
        lines += [f"v_samples[{i}][{j}]=16'h{sample:04x}; v_last[{i}][{j}]={v['lasts'][j]};"
                  for j, sample in enumerate(v["samples"])]
        lines += [f"v_payload[{i}][{j}]=8'h{byte:02x};"
                  for j, byte in enumerate(meta["payload"])]
    lines += ["end", "endtask"]
    path.write_text("\n".join(lines) + "\n", encoding="ascii")


def parse_suite(raw, vectors):
    """Whole-line grammar: ordered suite/cases/checks/identities/terminal/diag."""
    text = reject_diagnostics(raw)
    lines = []
    for original in text.splitlines():
        line = original[2:] if original.startswith("# ") else original
        if "BBS_" in line:
            if not line.startswith("BBS_"):
                raise FixtureFailure("prefixed protocol marker")
            lines.append(line)
        elif re.search(r"\b(?:PASS|FAIL)\b", line):
            raise FixtureFailure("bare protocol trailer")
    if not lines or lines[0] != "BBS_SUITE_BEGIN version=1":
        raise FixtureFailure("missing/duplicate suite begin")
    pos = 1
    checks = 0
    admitted = {}
    completed = {}
    per_case = []
    for cid, (name, expected_checks) in enumerate(CASE_CHECKS):
        expected = f"BBS_CASE_BEGIN case={cid} name={name}"
        if pos >= len(lines) or lines[pos] != expected:
            raise FixtureFailure(f"case order: expected {expected}")
        pos += 1
        local_checks = 0
        while pos < len(lines) and not lines[pos].startswith("BBS_CASE_END "):
            line = lines[pos]
            admit = re.fullmatch(r"BBS_ADMIT id=([0-9]+) case=([0-9]+) vector=([0-9]+) tag=([0-9]+)", line)
            term = re.fullmatch(r"BBS_TERMINAL id=([0-9]+) case=([0-9]+) outcome=(ok|error|cancel|reset)", line)
            check = re.fullmatch(r"BBS_CHECK seq=([0-9]+) case=([0-9]+) label=([a-z][a-z0-9_]*) observed=(-?[0-9]+) expected=(-?[0-9]+) result=PASS", line)
            if admit:
                ident, case, vid, tag = map(int, admit.groups())
                if case != cid or ident != len(admitted) or not 0 <= vid < len(vectors) or tag > 65535:
                    raise FixtureFailure("invalid admission identity")
                admitted[ident] = {"case": case, "vector": vid, "tag": tag}
            elif term:
                ident, case, outcome = term.groups()
                ident, case = int(ident), int(case)
                if case != cid or ident not in admitted or ident in completed:
                    raise FixtureFailure("duplicate/unadmitted terminal")
                if ident != len(completed):
                    raise FixtureFailure("out-of-order terminal")
                vec = vectors[admitted[ident]["vector"]]
                if outcome in ("ok", "error") and (outcome == "error") != bool(vec["error"]):
                    raise FixtureFailure("conflicting terminal outcome")
                completed[ident] = outcome
            elif check:
                seq, case = map(int, check.groups()[:2])
                if case != cid or seq != checks + 1:
                    raise FixtureFailure("duplicate/out-of-order check")
                checks += 1
                local_checks += 1
            else:
                raise FixtureFailure(f"invalid/duplicate protocol record: {line}")
            pos += 1
        expected = f"BBS_CASE_END case={cid} name={name} checks={expected_checks} failures=0"
        if pos >= len(lines) or lines[pos] != expected or local_checks != expected_checks:
            raise FixtureFailure(f"case tally mismatch: {name}")
        if len(admitted) != len(completed):
            raise FixtureFailure("case ended with unresolved admissions")
        per_case.append({"case": cid, "name": name, "checks": local_checks})
        pos += 1
    if pos >= len(lines):
        raise FixtureFailure("missing suite tally")
    tally = re.fullmatch(r"BBS_SUITE_TALLY cases=([0-9]+) checks=([0-9]+) admissions=([0-9]+) terminals=([0-9]+) metadata=([0-9]+) payload_bytes=([0-9]+) invariant_cycles=([0-9]+)", lines[pos])
    if not tally:
        raise FixtureFailure("malformed suite tally")
    cases, reported_checks, admissions, terminals, metadata, payload, cycles = map(int, tally.groups())
    if (cases, reported_checks, admissions, terminals) != (
            len(CASE_CHECKS), checks, len(admitted), len(completed)) or cycles < 1:
        raise FixtureFailure("suite totals conflict")
    if lines[pos + 1:] != ["BBS_DIAG failures=0 watchdog=0 live=0", "BBS_FINAL result=PASS"]:
        raise FixtureFailure("missing/duplicate/suffixed final diagnostic")
    return {
        "cases": per_case, "checks": checks, "admissions": admissions,
        "terminals": terminals, "metadata_observed": metadata,
        "payload_bytes_observed": payload, "invariant_cycles": cycles,
        "outcome_counts": {k: list(completed.values()).count(k)
                           for k in ("ok", "error", "cancel", "reset")},
        "admission_ledger": [
            {"id": ident, **value, "outcome": completed[ident]}
            for ident, value in admitted.items()],
    }


def parser_negative_controls(raw, vectors):
    """Reject mutated transcripts; these are parser tests, not DUT mutations."""
    text = raw.decode("utf-8")
    marker = "# BBS_FINAL result=PASS" if "# BBS_FINAL result=PASS" in text else "BBS_FINAL result=PASS"
    tests = {
        "prefixed_marker": text.replace(marker, "junk " + marker, 1),
        "suffixed_marker": text.replace(marker, marker + " junk", 1),
        "duplicate_final": text + "\n" + marker + "\n",
        "duplicate_field": text.replace("BBS_FINAL result=PASS", "BBS_FINAL result=PASS result=PASS", 1),
        "bare_trailer": text + "\n# PASS\n",
        "conflicting_result": text.replace("BBS_FINAL result=PASS", "BBS_FINAL result=FAIL", 1),
        "warning": text + "\n# ** Warning: synthetic parser probe\n",
        "fatal": text + "\n# ** Fatal: synthetic parser probe\n",
        "nonzero_diagnostics": text + "\n# Errors: 1, Warnings: 0\n",
        "duplicate_case": text.replace("BBS_CASE_BEGIN case=0 name=valid_vectors",
                                       "BBS_CASE_BEGIN case=0 name=valid_vectors\n# BBS_CASE_BEGIN case=0 name=valid_vectors", 1),
        "missing_terminal": re.sub(r"^.*BBS_TERMINAL id=0 .*\n", "", text, count=1, flags=re.M),
        "missing_diagnostic": text.replace("BBS_DIAG failures=0 watchdog=0 live=0", "", 1),
    }
    results = []
    for name, mutant in tests.items():
        try:
            parse_suite(mutant.encode("utf-8"), vectors)
        except (FixtureFailure, IndexError) as exc:
            results.append({"name": name, "rejected": True, "reason": str(exc)})
        else:
            raise FixtureFailure(f"parser accepted negative control {name}")
    return results


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--attempt", type=int, required=True, choices=(1, 2, 3))
    parser.add_argument("--modelsim", type=Path, default=Path("D:/modelsim1/win64"))
    args = parser.parse_args()
    attempt = AUTHOR / f"attempt-{args.attempt:02d}"
    attempt.mkdir(parents=True, exist_ok=False)
    records = []
    result = {
        "status": "running", "started_at": now(), "task_id": "DEEPEYE-IMPLEMENTATION-20261014",
        "task_version": 1, "work_id": WORK_ID,
        "canonical_agent_id": AGENT_ID, "job_id": JOB_ID,
        "environment_thread_id": os.environ.get("CODEX_THREAD_ID"),
        "attempt": args.attempt, "simulation": "not_run",
        "requirements_ids": [f"H{i:02d}" for i in range(1, 16)],
        "requirements_sha256": REQUIREMENTS_SHA,
        "source_commit": SOURCE_COMMIT,
        "author_reference_reuse": "pinned published codec_reference.py + known_vectors.json",
        "acceptance": "not_run; quality main owns independent acceptance",
        "commands": [],
    }
    try:
        # Pin original bytes; no checkout, dependency editing, or main oracle.
        snapshots = attempt / "source"
        before = {}
        for rel in (*PINS, *OWNED_SOURCES):
            data = (ROOT / rel).read_bytes()
            before[rel] = digest(data)
            if rel in PINS and before[rel] != PINS[rel]:
                raise FixtureFailure(f"working pin mismatch {rel}")
            dest = snapshots / rel
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(data)
        result["source_hashes_before"] = before
        for rel in PINS:
            out, err = run_command(attempt, records, [
                "git", "-C", str(REPO), "show",
                f"{SOURCE_COMMIT}:competition/deepeye/{rel}"])
            if err or digest(out) != PINS[rel]:
                raise FixtureFailure(f"Git blob pin mismatch {rel}")
        out, err = run_command(attempt, records, [
            "git", "-C", str(REPO), "show",
            f"{CONTRACT_COMMIT}:docs/competition/deepeye-2026/immutable_scope.json"])
        contract = json.loads(out)
        actual = digest(json.dumps(contract["requirements"], ensure_ascii=False,
                                   sort_keys=True, separators=(",", ":")).encode("utf-8"))
        if err or actual != REQUIREMENTS_SHA:
            raise FixtureFailure("fixed contract hash mismatch")
        result["verified_contract_sha256"] = actual
        vectors, known_count = make_vectors()
        save_json(attempt / "vectors.json", vectors)
        write_include(attempt / "bbs_vectors.svh", vectors)
        result.update(vectors=len(vectors), published_fixtures_verified=known_count,
                      vector_include_sha256=digest((attempt / "bbs_vectors.svh").read_bytes()))
        for exe in ("vlog.exe", "vsim.exe"):
            out, err = run_command(attempt, records, [args.modelsim / exe, "-version"], timeout=15)
            reject_diagnostics(out + err)
        run_command(attempt, records, [sys.executable, "--version"], timeout=15)
        out, err = run_command(attempt, records, [args.modelsim / "vlib.exe", "work"])
        reject_diagnostics(out + err)
        rtl = [ROOT / rel for rel in PINS if rel.endswith(".sv")]
        out, err = run_command(attempt, records, [
            args.modelsim / "vlog.exe", "-sv", "-work", "work",
            f"+incdir+{attempt.as_posix()}", *rtl,
            ROOT / OWNED_SOURCES[0], ROOT / OWNED_SOURCES[1]])
        reject_diagnostics(out + err)
        result["simulation"] = "running"
        out, err = run_command(attempt, records, [
            args.modelsim / "vsim.exe", "-c", "-onfinish", "stop",
            "-l", "vsim.transcript.txt", "work.tb_buffered_block_stream",
            "-do", "onerror {quit -code 2}; onbreak {quit -code 3}; run -all; quit -code 0"])
        parsed = parse_suite(out + err, vectors)
        result["simulation"] = "passed"
        result["bounded_checks"] = parsed
        result["parser_negative_controls"] = parser_negative_controls(out + err, vectors)
        after = {rel: digest((ROOT / rel).read_bytes()) for rel in before}
        result["source_hashes_after"] = after
        if after != before:
            raise FixtureFailure("source changed during the attempt")
        result["status"] = "author_checks_passed"
    except Exception as exc:
        result.update(status="failed", error=f"{type(exc).__name__}: {exc}")
        if result["simulation"] == "running":
            result["simulation"] = "failed"
    result.update(finished_at=now(), commands=records)
    save_json(attempt / "run-result.json", result)
    print(json.dumps({k: result.get(k) for k in
                      ("status", "simulation", "attempt", "vectors", "error")}))
    return 0 if result["status"] == "author_checks_passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
