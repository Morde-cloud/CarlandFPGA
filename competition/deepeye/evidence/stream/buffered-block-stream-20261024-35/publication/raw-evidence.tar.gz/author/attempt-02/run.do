onerror {quit -code 2}
run -all
quit -code 0
