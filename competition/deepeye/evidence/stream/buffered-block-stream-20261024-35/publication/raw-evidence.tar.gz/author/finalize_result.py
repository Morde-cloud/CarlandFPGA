"""Freeze bounded worker evidence without running another simulation."""
import difflib
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

A = Path(__file__).resolve().parent
W = A.parents[3]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")


assert not (A / "RESULT.json").exists(), "never overwrite a completed result"
accepted = json.loads((A / "attempt-03/run-result.json").read_bytes())
assert accepted["status"] == "author_checks_passed"
identity = json.loads((A / "runtime-identity.json").read_bytes())
contexts = identity["filtered_entries"]
session = next(e for e in contexts if e["type"] == "session_meta")
turn = [e for e in contexts if e["type"] == "turn_context"][-1]
assert session["id"] == accepted["canonical_agent_id"]
source_hashes = {rel: sha(W / rel) for rel in accepted["source_hashes_after"]}
assert source_hashes == accepted["source_hashes_before"] == accepted["source_hashes_after"]
transfer = json.loads((A / "recovery-inputs/TRANSFER.json").read_bytes())
for rel, entry in transfer["files"].items():
    if "sha256" in entry:
        assert sha(A / "recovery-inputs" / Path(rel).name) == entry["sha256"]

rel = "fpga/stream/deepeye_buffered_block_stream.sv"
original = (A / "recovery-inputs" / Path(rel).name).read_text(encoding="utf-8")
current = (W / rel).read_text(encoding="utf-8")
assert current == original.replace(
    "    assign stream_meta_ready = out_meta_ready;\n"
    "    assign stream_m_ready    = out_ready;\n\n", "", 1)
diff = "".join(difflib.unified_diff(
    original.splitlines(keepends=True), current.splitlines(keepends=True),
    fromfile="preserved-failed-partial/deepeye_buffered_block_stream.sv",
    tofile=rel))
(A / "wrapper-recovery.diff").write_text(diff, encoding="utf-8")
attempts = []
for number in (1, 2, 3):
    directory = A / f"attempt-{number:02d}"
    record = json.loads((directory / "run-result.json").read_bytes())
    attempts.append({
        "attempt": number, "status": record["status"],
        "error": record.get("error"), "simulation": record["simulation"],
        "receipt": str((directory / "run-result.json").relative_to(W)),
        "receipt_sha256": sha(directory / "run-result.json"),
        "commands": str((directory / "commands.json").relative_to(W)),
        "source_hashes": record["source_hashes_before"],
    })

# The index excludes itself and RESULT.json to avoid circular digests.
index = []
for path in sorted(A.rglob("*")):
    if path.is_file() and path.name not in ("RESULT.json", "evidence-index.json"):
        index.append({"path": str(path.relative_to(W)).replace("\\", "/"),
                      "bytes": path.stat().st_size, "sha256": sha(path)})
save(A / "evidence-index.json", index)
owned_files = [
    "fpga/stream/deepeye_buffered_block_stream.sv",
    "fpga/stream/buffered_block_stream_candidate.md",
    "tests/rtl/stream/tb_buffered_block_stream.sv",
    "tools/stream/run_buffered_block_stream.py",
]
result = {
    "schema": 1,
    "status": "author_checks_passed",
    "task_id": "DEEPEYE-IMPLEMENTATION-20261014", "task_version": 1,
    "work_id": accepted["work_id"],
    "operation_id": "B-DEEPEYE-BUFFERED-BLOCK-STREAM-20261024-35",
    "job_id": accepted["job_id"],
    "canonical_agent_id": session["id"], "actual_turn_id": turn["turn_id"],
    "actual_runtime": {
        "model_provider": session["model_provider"],
        "model": turn["model"], "effort": turn["effort"],
        "cli_version": session["cli_version"],
        "identity_receipt": "runtime-identity.json",
    },
    "main_thread": "01a13b55-095b-7461-8dd5-5476a130bd82",
    "lease_validation": {
        "tool": "mcp__fpga_mesh__fpga_native_validate",
        "execution_allowed": True,
        "receipt": "startup-tool-records.json",
    },
    "scope": {
        "node": "B", "role": "bounded_native_implementation_worker",
        "worktree": str(W), "ownership": owned_files + [
            "evidence/stream/buffered-block-stream-20261024-35/author/"],
        "inputs_commit": accepted["source_commit"],
        "frozen_design": "1011259415a0916054eb580687612580bc1e5f09",
        "observed_worktree_head_at_start": "8d15e4637c7a9943824a80c4ebe44690e161e9cd",
    },
    "contract": {
        "id": "DEEPEYE-HUMAN-LOCK-20261014", "revision": 1,
        "commit": "f5989cd5defce561f9ba98e6b18fc2682945f0a2",
        "requirements_ids": accepted["requirements_ids"],
        "requirements_sha256": accepted["verified_contract_sha256"],
        "verification": "requirements array canonical JSON; ensure_ascii=False, sort_keys=True, separators=(',', ':'); compared to fixed expected hash",
    },
    "changed_files": [
        {"path": rel, "sha256": source_hashes[rel],
         "bytes": (W / rel).stat().st_size} for rel in owned_files],
    "evidence_directory": {
        "path": str(A.relative_to(W)).replace("\\", "/"),
        "index": "evidence-index.json", "index_sha256": sha(A / "evidence-index.json"),
        "indexed_files": len(index),
    },
    "final_source_pins": source_hashes,
    "dependency_changes": [],
    "partial_recovery": {
        "prior_job_id": transfer["old_job"]["job_id"],
        "prior_terminal_failure": transfer["old_job"]["error"],
        "original_files": transfer["files"],
        "preserved_directory": "recovery-inputs/",
        "wrapper_diff": "wrapper-recovery.diff",
        "original_red": "static inspection of preserved conflicting ready drivers; original incomplete fixture was not run or accepted",
        "correction": "Only two extra ready assignments and their following blank line removed; queue ready outputs exclusively drive internal ready nets",
    },
    "attempts": attempts,
    "meaningful_harness_repair_cycles": 2,
    "actual_modelsim_simulations": 3,
    "qualified_author_attempt": 3,
    "recovery_history": "recovery-history.json",
    "simulation": {
        "status": "passed", "scope": "public-port author behavioral fixture only",
        "tool": "ModelSim SE-64 10.7 (2017.12 Dec 7 2017)",
        "process_exit_code": 0, "runner_exit_code": 0,
        "compiler_errors": 0, "compiler_warnings": 0,
        "simulator_errors": 0, "simulator_warnings": 0,
        "command_records": "attempt-03/commands.json",
        "raw_stdout": "attempt-03/command-12.stdout.bin",
        "raw_stderr": "attempt-03/command-12.stderr.bin",
        "receipt": "attempt-03/run-result.json",
        "test_vectors": accepted["vectors"],
        "published_fixtures_verified": accepted["published_fixtures_verified"],
        "bounded_checks": accepted["bounded_checks"],
        "parser_negative_controls": accepted["parser_negative_controls"],
        "watchdogs": {"tool_process_seconds": 60, "testbench_clock_cycles": 3000000},
        "source_hashes_unchanged_during_run_and_at_closure": True,
    },
    "commands": {
        "explicit_invocations": [
            f"D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe -X utf8 evidence/stream/buffered-block-stream-20261024-35/author/invoke.py {n}"
            for n in (1, 2, 3)],
        "reproduction_from_fresh_author_attempt_directory":
            "D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe -X utf8 tools/stream/run_buffered_block_stream.py --attempt 3",
        "no_replay": "Attempts 1-3 already exist and are immutable evidence; do not rerun in place. Main owns any new independent operation.",
        "all_exact_argv_cwd_exit_raw_stream_hashes": [
            f"attempt-{n:02d}/commands.json" for n in (1, 2, 3)],
        "invocation_raw_streams": [
            f"invocation-{n:02d}.stdout.bin / invocation-{n:02d}.stderr.bin" for n in (1, 2, 3)],
    },
    "bounded_findings": [
        "One unchanged block_stream plus one unchanged encoded_frame_queue at default STAT_W=32, with shared clock/reset/cancel and direct stage diagnostics.",
        "Exact metadata/payload comparisons for valid count/E matrix and pinned published hand/noise/step fixtures; original cfg/last errors remain ordered frames.",
        "Duplicate tags tracked as distinct admission identities; raw and encoded stage counters remain separate.",
        "Queue-full frontend backpressure, metadata/byte stability, old-full retirement bubbles, and old-one simultaneous input-metadata/output-terminal credit exercised.",
        "Public-port reset/cancel in raw fill, early encoding, metadata boundary, encoded fill, output stall, final data and error metadata; reset-over-cancel priority and explicit post-clear reuse exercised.",
        "113 admissions resolved once: 82 successful outputs, 13 error outputs, 8 explicit cancellations, 10 resets. Raw/encoded overlapping reservations never create duplicate terminal credit.",
    ],
    "limitations": [
        "Author reference reuse: published codec_reference.py and known_vectors.json; no main oracle read/import.",
        "79,667 is invariant-observed clock cycles, not a fabricated count of individual assertions.",
        "Queue fault injection and counter saturation were not exercised through the legal producer composition.",
        "Encoding boundary inferred from public sealed raw reservation, zero queue admissions and early elapsed cycles; no private DUT state inspected.",
        "No timing, CDC/RDC, throughput, TRACE <=32B, source-clock/ADC/DMA/QoS/BOOT/public ABI or full B03 claim.",
        "Parent's separate OOC reports, including reported negative diagnostic WNS, were not run, changed or accepted by this worker.",
    ],
    "stages": {
        "author_modelsim_behavioral": "passed",
        "synthesis": "not_run", "implementation": "not_run", "timing": "not_run",
        "physical_board": "not_run", "CDC_RDC": "not_run", "system": "not_run",
    },
    "formal_acceptance": {
        "all_29_cards": "not_run", "B01": "not_run", "B03": "not_run",
        "B04": "not_run", "B06": "not_run", "R03": "not_run",
        "full_product": "not_run", "authority": "quality main only",
    },
    "finished_at": datetime.now(timezone.utc).isoformat(),
}
save(A / "RESULT.json", result)
print(json.dumps({
    "status": result["status"], "result": str(A / "RESULT.json"),
    "result_sha256": sha(A / "RESULT.json"), "changed_files": result["changed_files"],
    "indexed_evidence_files": len(index),
    "wrapper_diff": diff,
}, indent=2))
