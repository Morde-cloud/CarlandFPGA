"""Capture each explicit runner invocation, including its raw process result."""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

base = Path(__file__).resolve().parent
number = int(sys.argv[1])
if number not in (1, 2, 3):
    raise SystemExit("attempt outside assigned bound")
record = base / f"invocation-{number:02d}.json"
if record.exists():
    raise SystemExit("invocation already preserved; do not replay")
root = base.parents[3]
argv = [sys.executable, "-X", "utf8", str(root / "tools/stream/run_buffered_block_stream.py"),
        "--attempt", str(number)]
opts = {}
if os.name == "nt":
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    opts = {"startupinfo": si, "creationflags": subprocess.CREATE_NO_WINDOW}
entry = {"argv": argv, "cwd": str(root),
         "started_at": datetime.now(timezone.utc).isoformat()}
record.write_text(json.dumps(entry, indent=2), encoding="utf-8")
proc = subprocess.run(argv, cwd=root, capture_output=True, **opts)
(base / f"invocation-{number:02d}.stdout.bin").write_bytes(proc.stdout)
(base / f"invocation-{number:02d}.stderr.bin").write_bytes(proc.stderr)
entry.update(exit_code=proc.returncode,
             finished_at=datetime.now(timezone.utc).isoformat())
record.write_text(json.dumps(entry, indent=2) + "\n", encoding="utf-8")
print(proc.stdout.decode("utf-8", "replace"), end="")
print(proc.stderr.decode("utf-8", "replace"), end="", file=sys.stderr)
raise SystemExit(proc.returncode)
