# Parser repair basis

Task DEEPEYE-IMPLEMENTATION-20261014/v1; work
B-BUFFERED-BLOCK-PARSER-REPAIR-20261024-35-r1. This is saved-log parser work.
No ModelSim, Vivado, RTL, testbench, timing, or physical-board run was performed.
All 29 formal cards remain not_run; the quality main owns acceptance.

The exact original runner is preserved in inputs/run_buffered_block_stream.py,
SHA256 54d30bd0ceb97898eb39e22833176439faca3ae089a7078734ca2d80cfae7c39.
The full unchanged testbench is pinned at
8b3cf8c310ad13ae63da7925f3a7a6dd853c1ed32195b24f2091606827a17933.
The wrapper remains
8f1596ba50d0979e97f68e5ba125eab9b125f2b073f143d71e9be425522080d1.

## Checks and admissions

The runner's fixed_case_plan is a transcription of the unchanged TB driver:
lines 546-666 give the six initial cases; interruption_case and clear_once
give the seven cancel/reset pairs; lines 673-683 give reset-over-cancel.
It requires the exact per-case check labels in order, their planned numeric
expected values, and observed == expected for each PASS. Expected byte counts
come from vector payload lengths; success/error counts come from the input
vectors. It also checks the planned vector/tag/outcome sequence independently
of reported tally totals. check-cycle-01/fixed-testcase-plan.json records
this source-derived plan. It is not learned from candidate log check records.

## Metadata and payload tallies

For each admission ledger identity ending in ok, count one header and the
published vector's full payload length. For each error terminal, count one
header and no payload. For reset/cancel terminals, use the explicit phase
plan below. Each row applies separately to cancel and reset.

| Interrupted phase | Partial output headers | Partial output bytes | TB basis |
|---|---:|---:|---|
| raw_fill | 0 | 0 | Raw block remains in input fill |
| encoding | 0 | 0 | Sealed raw block, zero queue metadata admissions |
| metadata_boundary | 0 | 0 | Clear gates transfers before error metadata enters queue |
| encoded_fill | 0 | 0 | Queue is receiving; no sealed output frame |
| output_stall | 1 | 0 | Lines 499-509 accept the SINGLE header, stall its first byte, then open a raw fill |
| final_data | 1 | len(SINGLE payload)-1 | Lines 511-515 call wait_final; only the nonfinal byte is accepted |
| final_error_metadata | 0 | 0 | Error header remains stalled before clear |

clear_once asserts reset/cancel before the next step; the step monitor's clear
branch records terminal outcomes but accepts no output on that edge. Explicit
post-clear SINGLE reuse is an ordinary ok terminal and is already counted in
the ledger. In reset-over-cancel, the older header is stalled and the other
block is in raw fill, so neither contributes partial output.

This derives the four partial headers in cases 14, 15, 16, 17, and the two
partial bytes in cases 16, 17. The saved positive's computed totals are 99
headers and 1999 bytes. These totals are results of the ledger/vector/phase
calculation, not constants in the parser.

## Invariant-cycle tally

The pinned TB has timescale 1ns/1ps, clk starts low, and always #5 toggles it.
The first rising edge at t=5ns does not call step. The driver starts at the
first falling edge t=10ns (line 543). The first step observes the rising edge
t=15ns, increments observed_cycles at t=16ns, and returns at t=20ns.
Every subsequent step returns exactly 10ns later. All driver waits after the
initial gate are expressed through step. The last end_case returns at a
falling edge, followed immediately by the normal $finish at source line 690.

Therefore N observed steps imply finish_time_ns = 10*(N+1), so
N = finish_time_ns // 10 - 1. The parser validates divisibility, positivity,
and the pinned watchdog horizon. It does not pin the observed N.

The saved ModelSim time is accepted only in this unique, anchored sequence
after BBS_FINAL: $finish note identifying the pinned source and finish line;
time/iteration/top-instance line; matching Break and Stopped lines; End time;
zero-error/zero-warning tool diagnostic trailer. Missing, duplicated,
reordered, conflicting, or unassociated records fail closed. In the saved
positive, 796680ns derives 79667 observed steps.

## Portability and limits

parse_suite takes an optional tb_path for an exact pinned source copy and
otherwise uses the repository-relative public TB path. Log source paths may
use another drive/prefix and either path separator. No C-node private
controller path or local lease/configuration file is needed by the parser.
Two synthetic saved-log path substitutions passed: POSIX and Windows-style
compile paths. This is parser-format evidence, not execution on node C.
An altered full TB source copy was rejected.

The supported finish envelope is the actual saved ModelSim 10.7 format.
Missing or unsupported independent timing records fail closed and require
genuine additional evidence; tally values alone are insufficient.

One Python qualification cycle reproduced all 203 original false acceptances
on the exact original runner, then rejected all 203 with the repaired runner.
The unchanged original 12 controls and 230 additional mutations were rejected.
This includes every check's expected-only mutation, equal-but-wrong numeric
pair, label-order swap, tally +/-1, and finish/time/trailer/source probes.
The saved positive passed. Original author evidence hashes match before/after.
