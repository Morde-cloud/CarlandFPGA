"""Freeze the scoped parser-only result; no vendor tools or reruns."""
import ast
import difflib
import hashlib
import json
import shutil
from datetime import datetime, timezone
from pathlib import Path

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[4]
AUTHOR = BASE.parent
RUNNER = ROOT / "tools/stream/run_buffered_block_stream.py"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")


assert not (BASE / "RESULT.json").exists(), "do not overwrite a frozen result"
check_dir = BASE / "check-cycle-01"
checked = json.loads((check_dir / "run-result.json").read_bytes())
assert checked["status"] == "saved_log_parser_checks_passed"
runner_hash = sha(RUNNER)
assert runner_hash == checked["runner_sha256"] == sha(check_dir / "runner-under-test.py")
assert sha(ROOT / "tests/rtl/stream/tb_buffered_block_stream.sv") == checked["full_tb_sha256"]
assert sha(ROOT / "fpga/stream/deepeye_buffered_block_stream.sv") == checked["wrapper_sha256"]
before = json.loads((check_dir / "original-author-hashes-before.json").read_bytes())
assert all(sha(AUTHOR / rel) == expected for rel, expected in before.items())
assert before == json.loads((check_dir / "original-author-hashes-after.json").read_bytes())
tree = ast.parse(RUNNER.read_bytes())
numeric_pins = [n.value for n in ast.walk(tree)
                if isinstance(n, ast.Constant) and type(n.value) is int
                and n.value in (99, 1999, 79667)]
assert not numeric_pins, "observed tally constants must not become expected-value pins"
scope = Path(r"D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/buffered-block-stream-20261024-35/PARSER_REPAIR1_SCOPE.md")
shutil.copyfile(scope, BASE / "inputs/PARSER_REPAIR1_SCOPE.md")
rollout = Path(r"C:/Users/15378/.codex/sessions/2026/10/24/rollout-2026-10-24T03-05-16-01a16a27-3458-7103-a4ab-cd06fd084da7.jsonl")
session = None
turn = None
for line in rollout.open(encoding="utf-8"):
    entry = json.loads(line)
    payload = entry.get("payload", {})
    if entry.get("type") == "session_meta":
        session = {k: payload.get(k) for k in
                   ("id", "cwd", "originator", "cli_version", "model_provider")}
    elif entry.get("type") == "turn_context":
        turn = {k: payload.get(k) for k in ("turn_id", "cwd", "model", "effort")}
assert session and session["id"] == "01a16a27-3458-7103-a4ab-cd06fd084da7"
assert turn and turn["turn_id"]
save(BASE / "runtime-identity.json",
     {"source": str(rollout), "session": session, "turn": turn,
      "filter": "only non-secret session/turn identity fields"})
contract_path = AUTHOR / "attempt-03/command-06.stdout.bin"
contract = json.loads(contract_path.read_bytes())
contract_hash = hashlib.sha256(json.dumps(
    contract["requirements"], ensure_ascii=False, sort_keys=True,
    separators=(",", ":")).encode("utf-8")).hexdigest()
assert contract_hash == "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
original = (BASE / "inputs/run_buffered_block_stream.py").read_text(encoding="utf-8")
current = RUNNER.read_text(encoding="utf-8")
(BASE / "runner-repair.diff").write_text("".join(difflib.unified_diff(
    original.splitlines(keepends=True), current.splitlines(keepends=True),
    fromfile="preserved-original/run_buffered_block_stream.py",
    tofile="tools/stream/run_buffered_block_stream.py")), encoding="utf-8")
invocation = json.loads((BASE / "invocation-01.json").read_bytes())
assert invocation["exit_code"] == 0
assert (BASE / "invocation-01.stderr.bin").read_bytes() == b""
index = [{"path": str(p.relative_to(ROOT)).replace("\\", "/"),
          "bytes": p.stat().st_size, "sha256": sha(p)}
         for p in sorted(BASE.rglob("*"))
         if p.is_file() and p.name not in ("RESULT.json", "evidence-index.json")]
save(BASE / "evidence-index.json", index)
result = {
    "schema": 1, "status": "bounded_saved_log_parser_checks_passed",
    "task_id": "DEEPEYE-IMPLEMENTATION-20261014", "task_version": 1,
    "work_id": "B-BUFFERED-BLOCK-PARSER-REPAIR-20261024-35-r1",
    "job_id": "child-4111b9f63949411fbf0f6690561bce2f",
    "canonical_agent_id": session["id"], "actual_turn_id": turn["turn_id"],
    "actual_runtime": {"provider": session["model_provider"],
                       "model": turn["model"], "effort": turn["effort"],
                       "cli_version": session["cli_version"],
                       "receipt": "runtime-identity.json"},
    "main_thread": "01a13b55-095b-7461-8dd5-5476a130bd82",
    "native_validation": {"execution_allowed": True, "receipt": "tool-receipts.json"},
    "ownership": ["tools/stream/run_buffered_block_stream.py",
                  "evidence/stream/buffered-block-stream-20261024-35/author/parser-repair1/"],
    "source": {
        "runner_before_sha256": checked["original_runner_sha256"],
        "runner_after_sha256": runner_hash,
        "runner_bytes": RUNNER.stat().st_size,
        "pinned_tb_sha256": checked["full_tb_sha256"],
        "unchanged_wrapper_sha256": checked["wrapper_sha256"],
        "original_author_result_sha256": sha(AUTHOR / "RESULT.json"),
        "runner_unchanged_during_qualification_and_at_closure": True,
        "original_author_files_unchanged": len(before),
        "original_author_evidence_unchanged": True,
        "diff": "runner-repair.diff",
    },
    "contract": {
        "id": "DEEPEYE-HUMAN-LOCK-20261014", "revision": 1,
        "commit": "f5989cd5defce561f9ba98e6b18fc2682945f0a2",
        "requirements_ids": [r["id"] for r in contract["requirements"]],
        "requirements_sha256": contract_hash,
        "verification_source": "original saved git-show raw bytes at author/attempt-03/command-06.stdout.bin; canonical array rehashed against fixed expected value",
        "frozen_design": "1011259415a0916054eb580687612580bc1e5f09",
    },
    "bounded_changes": [
        "Require PASS observed == expected and exact source-derived per-case label order and numeric expected values.",
        "Require source-derived vector/tag/terminal sequences for each fixed testcase.",
        "Recompute metadata and payload from admitted identities, outcomes, published vector lengths and explicit interrupted-output phase contributions.",
        "Derive invariant cycles from a unique anchored ModelSim finish/time/trailer association and the full pinned TB timeline; reject changed source pins.",
    ],
    "qualification": {
        "scope": "Python parsing of original saved ModelSim logs only",
        "code_fix_cycles": 1, "allowed_maximum_cycles": 2,
        "process_exit_code": 0, "vendor_executions": 0,
        "original_positive_accepted": checked["original_positive_accepted"],
        "exact_old_runner_false_acceptances_reproduced": checked["original_false_acceptances_reproduced"],
        "main_red_fixtures_rejected": checked["main_red_fixtures_rejected"],
        "original_author_controls_rejected": checked["original_controls_rejected"],
        "targeted_mutations_rejected": checked["targeted_mutations_rejected"],
        "altered_full_tb_pin_probe": checked["altered_tb_pin_probe"],
        "portability_controls": checked["portability_controls"],
        "parsed_saved_counts": checked["parsed_counts"],
        "tally_derivation": checked["tally_derivation"],
        "observed_tally_constants_not_hardcoded": not numeric_pins,
        "receipt": "check-cycle-01/run-result.json",
        "baseline": "check-cycle-01/original-runner-baseline.json",
        "main_rejections": "check-cycle-01/main-red-rejections.json",
        "original_controls": "check-cycle-01/original-negative-control-results.json",
        "targeted_probes": "check-cycle-01/targeted-probe-results.json",
        "fixed_plan": "check-cycle-01/fixed-testcase-plan.json",
        "derivation_notes": "DERIVATION.md",
    },
    "commands": {
        "outer_tool_command": "& 'D:/pynq/CarlandFPGA/.local/venv/Scripts/python.exe' -X utf8 'evidence/stream/buffered-block-stream-20261024-35/author/parser-repair1/invoke_qualification.py' 1",
        "cwd": str(ROOT), "argv": invocation["argv"],
        "raw_record": "invocation-01.json", "actual_exit_code": invocation["exit_code"],
        "stdout": {"path": "invocation-01.stdout.bin", "sha256": sha(BASE / "invocation-01.stdout.bin")},
        "stderr": {"path": "invocation-01.stderr.bin", "sha256": sha(BASE / "invocation-01.stderr.bin")},
        "tool_receipts": "tool-receipts.json",
    },
    "evidence": {"index": "evidence-index.json", "index_sha256": sha(BASE / "evidence-index.json"),
                 "indexed_files": len(index), "preserved_inputs": "inputs/",
                 "original_files_and_red_fixtures_not_overwritten": True},
    "limits": [
        "This is a new bounded parser repair; the old completed lease and original author RESULT were not used for writes.",
        "Qualification uses saved logs, not a new RTL simulation or vendor execution.",
        "The fixed testcase plan is bound to the full TB hash; a changed testbench needs a newly derived plan.",
        "Supported finish envelope is the saved ModelSim 10.7 format; insufficient or unsupported records fail closed.",
        "Path portability probes are synthetic parser inputs, not execution on node C.",
        "No independent RTL acceptance, timing acceptance, or full-product acceptance is claimed.",
    ],
    "blocker": None,
    "formal_acceptance": {"all_29_cards": "not_run", "B01": "not_run", "B03": "not_run",
                          "B04": "not_run", "B06": "not_run", "R03": "not_run",
                          "physical_board": "not_run", "system": "not_run",
                          "authority": "quality main only"},
    "finished_at": datetime.now(timezone.utc).isoformat(),
}
save(BASE / "RESULT.json", result)
print(json.dumps({"status": result["status"], "result": str(BASE / "RESULT.json"),
                  "result_sha256": sha(BASE / "RESULT.json"), "runner_sha256": runner_hash,
                  "actual_turn_id": turn["turn_id"], "evidence_files": len(index),
                  "original_author_files_unchanged": len(before)}, indent=2))
