"""Preserve exact Python-only qualification invocation and raw streams."""
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

base = Path(__file__).resolve().parent
cycle = int(sys.argv[1])
assert cycle in (1, 2)
record = base / f"invocation-{cycle:02d}.json"
assert not record.exists(), "never replay a preserved invocation"
argv = [sys.executable, "-X", "utf8", str(base / "qualify_saved_logs.py"),
        "--cycle", str(cycle)]
opts = {}
if os.name == "nt":
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = subprocess.SW_HIDE
    opts = {"startupinfo": si, "creationflags": subprocess.CREATE_NO_WINDOW}
entry = {"argv": argv, "cwd": str(base.parents[4]),
         "started_at": datetime.now(timezone.utc).isoformat(),
         "vendor_executions": 0}
record.write_text(json.dumps(entry, indent=2), encoding="utf-8")
proc = subprocess.run(argv, cwd=base.parents[4], capture_output=True, **opts)
(base / f"invocation-{cycle:02d}.stdout.bin").write_bytes(proc.stdout)
(base / f"invocation-{cycle:02d}.stderr.bin").write_bytes(proc.stderr)
entry.update(exit_code=proc.returncode,
             finished_at=datetime.now(timezone.utc).isoformat())
record.write_text(json.dumps(entry, indent=2) + "\n", encoding="utf-8")
print(proc.stdout.decode("utf-8", "replace"), end="")
print(proc.stderr.decode("utf-8", "replace"), end="", file=sys.stderr)
raise SystemExit(proc.returncode)
