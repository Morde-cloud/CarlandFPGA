"""Only Python parsing of preserved logs; never invoke a vendor executable."""
import argparse
import hashlib
import json
import re
import sys
import traceback
import types
from datetime import datetime, timezone
from pathlib import Path

sys.dont_write_bytecode = True
BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[4]
AUTHOR = BASE.parent
INPUT = BASE / "inputs"
RUNNER = ROOT / "tools/stream/run_buffered_block_stream.py"
EXPECTED_OLD_SHA = "54d30bd0ceb97898eb39e22833176439faca3ae089a7078734ca2d80cfae7c39"
TB_SHA = "8b3cf8c310ad13ae63da7925f3a7a6dd853c1ed32195b24f2091606827a17933"
WRAPPER_SHA = "8f1596ba50d0979e97f68e5ba125eab9b125f2b073f143d71e9be425522080d1"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + "\n",
                    encoding="utf-8")


def load_module(path, name):
    module = types.ModuleType(name)
    module.__file__ = str(path)
    exec(compile(path.read_bytes(), str(path), "exec"), module.__dict__)
    def forbidden(*args, **kwargs):
        raise AssertionError("vendor execution is outside parser-only scope")
    module.run_command = forbidden
    return module


def original_author_hashes():
    return {str(p.relative_to(AUTHOR)).replace("\\", "/"): sha(p)
            for p in AUTHOR.rglob("*")
            if p.is_file() and BASE not in p.parents}


def targeted_mutations(raw):
    text = raw.decode("utf-8")
    checks = list(re.finditer(
        r"BBS_CHECK seq=([0-9]+) case=([0-9]+) label=([a-z0-9_]+) "
        r"observed=(-?[0-9]+) expected=(-?[0-9]+) result=PASS", text))
    for match in checks:
        seq, case, label, observed, expected = match.groups()
        replacement = match[0].replace(f"expected={expected}", f"expected={int(expected)+1}")
        yield f"expected-only-{seq}", text[:match.start()] + replacement + text[match.end():]
        replacement = (match[0].replace(f"observed={observed}", f"observed={int(observed)+1}")
                       .replace(f"expected={expected}", f"expected={int(expected)+1}"))
        yield f"equal-but-wrong-planned-value-{seq}", text[:match.start()] + replacement + text[match.end():]
    first, second = checks[:2]
    swapped = text[:first.start()] + first[0].replace(f"label={first[3]}", f"label={second[3]}")
    swapped += text[first.end():second.start()] + second[0].replace(f"label={second[3]}", f"label={first[3]}")
    swapped += text[second.end():]
    yield "check-label-order-swap", swapped
    for field in ("metadata", "payload_bytes", "invariant_cycles"):
        match = re.search(fr"\b{field}=([0-9]+)", text)
        for amount in (-1, 1):
            yield f"{field}-delta-{amount:+d}", (
                text[:match.start(1)] + str(int(match[1]) + amount) + text[match.end(1):])
    lines = text.splitlines(keepends=True)
    note_index = next(i for i, line in enumerate(lines) if "** Note: $finish" in line)
    time_index = note_index + 1
    finish_note = lines[note_index]
    time_line = lines[time_index]
    yield "finish-missing", text.replace(finish_note, "", 1)
    yield "finish-duplicated", text.replace(finish_note, finish_note * 2, 1)
    yield "finish-prefixed", text.replace(finish_note, "junk " + finish_note, 1)
    yield "finish-suffixed", text.replace(finish_note, finish_note.rstrip("\r\n") + " junk\n", 1)
    yield "time-missing", text.replace(time_line, "", 1)
    yield "time-duplicated", text.replace(time_line, time_line * 2, 1)
    stamp = re.search(r"Time: ([0-9]+) ns", time_line)
    for delta in (-10, 1, 10):
        changed = time_line.replace(stamp[1], str(int(stamp[1]) + delta), 1)
        yield f"time-wrong-{delta:+d}", text.replace(time_line, changed, 1)
    yield "time-wrong-instance", text.replace("Instance: /tb_buffered_block_stream",
                                               "Instance: /wrong_fixture", 1)
    yield "time-before-finish", text.replace(finish_note + time_line, time_line + finish_note, 1)
    moved = list(lines)
    final_index = next(i for i, line in enumerate(lines) if "BBS_FINAL result=PASS" in line)
    moved[final_index], moved[note_index] = moved[note_index], moved[final_index]
    yield "finish-before-final", "".join(moved)
    yield "finish-wrong-source-line", text.replace(
        finish_note, re.sub(r"\([0-9]+\)", "(1)", finish_note), 1)
    yield "finish-wrong-source-file", text.replace(
        finish_note, finish_note.replace("tb_buffered_block_stream.sv", "wrong_fixture.sv"), 1)
    stop_line = next(line for line in lines if line.startswith("# Stopped at "))
    yield "stop-source-conflict", text.replace(
        stop_line, stop_line.replace("tb_buffered_block_stream.sv", "wrong_fixture.sv"), 1)
    break_line = next(line for line in lines if line.startswith("# Break at "))
    yield "break-duplicated", text.replace(break_line, break_line * 2, 1)
    end_line = next(line for line in lines if line.startswith("# End time:"))
    yield "end-trailer-missing", text.replace(end_line, "", 1)
    yield "end-trailer-duplicated", text.replace(end_line, end_line * 2, 1)
    diagnostic = next(line for line in lines if line.startswith("# Errors:"))
    yield "tool-diagnostic-missing", text.replace(diagnostic, "", 1)
    yield "tool-diagnostic-duplicated", text.replace(diagnostic, diagnostic * 2, 1)
    yield "time-after-trailer", text + time_line
    yield "unassociated-finish-at-start", finish_note + text
    yield "admission-vector-plan-conflict", text.replace(
        "BBS_ADMIT id=0 case=0 vector=0", "BBS_ADMIT id=0 case=0 vector=1", 1)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--cycle", type=int, choices=(1, 2), required=True)
    args = ap.parse_args()
    out = BASE / f"check-cycle-{args.cycle:02d}"
    out.mkdir(exist_ok=False)
    result = {
        "status": "running", "cycle": args.cycle,
        "started_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Python qualification against saved logs only",
        "vendor_executions": 0,
    }
    try:
        assert sha(INPUT / "run_buffered_block_stream.py") == EXPECTED_OLD_SHA
        runner_start_sha = sha(RUNNER)
        (out / "runner-under-test.py").write_bytes(RUNNER.read_bytes())
        assert sha(ROOT / "tests/rtl/stream/tb_buffered_block_stream.sv") == TB_SHA
        assert sha(ROOT / "fpga/stream/deepeye_buffered_block_stream.sv") == WRAPPER_SHA
        assert sha(RUNNER) == runner_start_sha, "runner changed during qualification"
        before = original_author_hashes()
        save(out / "original-author-hashes-before.json", before)
        vectors = json.loads((INPUT / "vectors.json").read_bytes())
        raw = (INPUT / "positive.stdout.bin").read_bytes() + (INPUT / "positive.stderr.bin").read_bytes()
        old = load_module(INPUT / "run_buffered_block_stream.py", "original_saved_parser")
        new = load_module(RUNNER, "repaired_saved_parser")
        generated, _ = new.make_vectors()
        assert generated == vectors, "saved vectors differ from published deterministic expectations"
        reds = sorted((INPUT / "main-red-fixtures").glob("*.log"))
        assert len(reds) == 203
        old_positive = old.parse_suite(raw, vectors)
        baseline = []
        for path in reds:
            try:
                old.parse_suite(path.read_bytes(), vectors)
            except old.FixtureFailure as exc:
                baseline.append({"fixture": path.name, "accepted": False, "reason": str(exc)})
            else:
                baseline.append({"fixture": path.name, "accepted": True})
        save(out / "original-runner-baseline.json", baseline)
        assert all(x["accepted"] for x in baseline), "main red fixtures not reproduced on exact original runner"
        positive = new.parse_suite(raw, vectors)
        save(out / "positive-parse.json", positive)
        save(out / "fixed-testcase-plan.json", new.fixed_case_plan(vectors))
        rejected = []
        for path in reds:
            try:
                new.parse_suite(path.read_bytes(), vectors)
            except new.FixtureFailure as exc:
                rejected.append({"fixture": path.name, "sha256": sha(path),
                                 "rejected": True, "reason": str(exc)})
            else:
                rejected.append({"fixture": path.name, "sha256": sha(path), "rejected": False})
        save(out / "main-red-rejections.json", rejected)
        assert all(x["rejected"] for x in rejected), "repaired parser still accepts a main red fixture"
        control_dir = out / "original-negative-controls"
        control_dir.mkdir()
        original_parse = new.parse_suite
        captured = []
        def capture_control(control_raw, control_vectors):
            number = len(captured) + 1
            path = control_dir / f"control-{number:02d}.log"
            path.write_bytes(control_raw)
            try:
                original_parse(control_raw, control_vectors)
            except new.FixtureFailure as exc:
                captured.append({"file": path.name, "sha256": sha(path),
                                 "rejected": True, "reason": str(exc)})
                raise
            else:
                captured.append({"file": path.name, "rejected": False})
        new.parse_suite = capture_control
        try:
            original_controls = new.parser_negative_controls(raw, vectors)
        finally:
            new.parse_suite = original_parse
        save(out / "original-negative-control-results.json", captured)
        assert len(original_controls) == 12 and len(captured) == 12
        assert all(x["rejected"] for x in captured)
        targeted_dir = out / "targeted-probes"
        targeted_dir.mkdir()
        targeted = []
        for name, mutant in targeted_mutations(raw):
            assert mutant != raw.decode("utf-8"), f"probe did not change input: {name}"
            path = targeted_dir / f"{name}.log"
            path.write_text(mutant, encoding="utf-8", newline="")
            try:
                new.parse_suite(mutant.encode("utf-8"), vectors)
            except new.FixtureFailure as exc:
                targeted.append({"name": name, "sha256": sha(path),
                                 "rejected": True, "reason": str(exc)})
            else:
                targeted.append({"name": name, "sha256": sha(path), "rejected": False})
        save(out / "targeted-probe-results.json", targeted)
        assert all(x["rejected"] for x in targeted), "a targeted parser mutation was accepted"
        # Public source pin + arbitrary node compile paths; no .local controller.
        text = raw.decode("utf-8")
        old_prefix = re.search(r"\$finish\s+: (.+?)/tests/rtl/stream/", text)[1]
        portable = []
        for name, prefix in (("node-c-posix", "/work/node-c/project/competition/deepeye"),
                             ("node-c-windows", "C:/public/project/competition/deepeye")):
            changed = text.replace(old_prefix, prefix)
            if name.endswith("windows"):
                changed = "\n".join(
                    line.replace("/", "\\") if any(
                        marker in line for marker in ("** Note: $finish", "# Break at", "# Stopped at"))
                    else line for line in changed.split("\n"))
            path = out / f"portable-{name}.log"
            path.write_text(changed, encoding="utf-8", newline="")
            parsed = new.parse_suite(changed.encode("utf-8"), vectors,
                                     tb_path=INPUT / "tb_buffered_block_stream.sv")
            assert parsed["tally_derivation"] == positive["tally_derivation"]
            portable.append({"name": name, "accepted": True, "sha256": sha(path)})
        altered_tb = out / "altered-testbench-pin.sv"
        altered_tb.write_bytes((INPUT / "tb_buffered_block_stream.sv").read_bytes() + b"\n// probe\n")
        try:
            new.parse_suite(raw, vectors, tb_path=altered_tb)
        except new.FixtureFailure as exc:
            pin_probe = {"rejected": True, "reason": str(exc), "sha256": sha(altered_tb)}
        else:
            raise AssertionError("altered full testbench pin was accepted")
        after = original_author_hashes()
        save(out / "original-author-hashes-after.json", after)
        assert before == after, "original author evidence changed"
        assert sha(ROOT / "tests/rtl/stream/tb_buffered_block_stream.sv") == TB_SHA
        assert sha(ROOT / "fpga/stream/deepeye_buffered_block_stream.sv") == WRAPPER_SHA
        result.update(
            status="saved_log_parser_checks_passed",
            original_runner_sha256=EXPECTED_OLD_SHA, runner_sha256=sha(RUNNER),
            full_tb_sha256=TB_SHA, wrapper_sha256=WRAPPER_SHA,
            original_positive_accepted=True, original_false_acceptances_reproduced=len(baseline),
            main_red_fixtures_rejected=len(rejected), original_controls_rejected=len(captured),
            targeted_mutations_rejected=len(targeted), portability_controls=portable,
            altered_tb_pin_probe=pin_probe, original_author_evidence_unchanged=True,
            tally_derivation=positive["tally_derivation"],
            parsed_counts={k: positive[k] for k in ("checks", "admissions", "terminals",
                          "metadata_observed", "payload_bytes_observed", "invariant_cycles")},
        )
    except Exception as exc:
        result.update(status="failed", error=repr(exc), traceback=traceback.format_exc())
    result["finished_at"] = datetime.now(timezone.utc).isoformat()
    save(out / "run-result.json", result)
    print(json.dumps(result))
    return 0 if result["status"] == "saved_log_parser_checks_passed" else 1


if __name__ == "__main__":
    raise SystemExit(main())
