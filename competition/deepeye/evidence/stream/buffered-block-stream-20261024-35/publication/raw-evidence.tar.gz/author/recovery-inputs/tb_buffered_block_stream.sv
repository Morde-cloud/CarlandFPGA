// Public-port author fixture for the bounded buffered block-stream candidate.

`timescale 1ns/1ps

module tb_buffered_block_stream;
    `include bbs_vectors.svh

    localparam int MAX_CYCLES = 3_000_000;
    localparam logic [15:0] TAG_BASE = 16'h3500;

    logic clk = 1'b0;
    always #5 clk = ~clk;

    logic rst = 1'b1;
    logic cancel = 1'b0;
    logic cfg_valid = 1'b0;
    logic [7:0] cfg_count = 8'd0;
    logic [3:0] cfg_e = 4'd0;
    logic [15:0] cfg_tag = 16'd0;
    logic s_valid = 1'b0;
    logic [15:0] s_data = 16'd0;
    logic s_last = 1'b0;
    logic out_meta_ready = 1'b0;
    logic out_ready = 1'b0;

    logic cfg_ready;
    logic s_ready;
    logic out_meta_valid;
    logic [15:0] out_meta_tag;
    logic [1:0] out_meta_error;
    logic [7:0] out_meta_count;
    logic [3:0] out_meta_e;
    logic out_meta_raw;
    logic [3:0] out_meta_k;
    logic [11:0] out_meta_valid_bits;
    logic [8:0] out_meta_bytes;
    logic out_valid;
    logic [7:0] out_data;
    logic out_last;
    logic [1:0] stream_level;
    logic stream_filling;
    logic [1:0] queue_level;
    logic queue_receiving;
    logic queue_faulted;
    logic queue_fault_event;
    logic [1:0] queue_fault_code;
    logic [31:0] stream_stat_cfg;
    logic [31:0] stream_stat_samples;
    logic [31:0] stream_stat_ok;
    logic [31:0] stream_stat_error;
    logic [31:0] stream_stat_aborted;
    logic [31:0] queue_stat_meta;
    logic [31:0] queue_stat_in_bytes;
    logic [31:0] queue_stat_retired;
    logic [31:0] queue_stat_aborted;
    logic [31:0] queue_stat_fault;

    string active_case = startup;
    int suite_cases = 0;
    int suite_checks = 0;
    int suite_failures = 0;
    int case_checks = 0;
    int case_failures = 0;
    int cycle_count = 0;
    bit watchdog_fired = 1'b0;

    deepeye_buffered_block_stream dut (
        .clk(clk), .rst(rst), .cancel(cancel),
        .cfg_valid(cfg_valid), .cfg_ready(cfg_ready),
        .cfg_count(cfg_count), .cfg_e(cfg_e), .cfg_tag(cfg_tag),
        .s_valid(s_valid), .s_ready(s_ready), .s_data(s_data), .s_last(s_last),
        .out_meta_valid(out_meta_valid), .out_meta_ready(out_meta_ready),
        .out_meta_tag(out_meta_tag), .out_meta_error(out_meta_error),
        .out_meta_count(out_meta_count), .out_meta_e(out_meta_e),
        .out_meta_raw(out_meta_raw), .out_meta_k(out_meta_k),
        .out_meta_valid_bits(out_meta_valid_bits),
        .out_meta_bytes(out_meta_bytes),
        .out_valid(out_valid), .out_ready(out_ready),
        .out_data(out_data), .out_last(out_last),
        .stream_level(stream_level), .stream_filling(stream_filling),
        .queue_level(queue_level), .queue_receiving(queue_receiving),
        .queue_faulted(queue_faulted), .queue_fault_event(queue_fault_event),
        .queue_fault_code(queue_fault_code),
        .stream_stat_cfg(stream_stat_cfg),
        .stream_stat_samples(stream_stat_samples),
        .stream_stat_ok(stream_stat_ok),
        .stream_stat_error(stream_stat_error),
        .stream_stat_aborted(stream_stat_aborted),
        .queue_stat_meta(queue_stat_meta),
        .queue_stat_in_bytes(queue_stat_in_bytes),
        .queue_stat_retired(queue_stat_retired),
        .queue_stat_aborted(queue_stat_aborted),
        .queue_stat_fault(queue_stat_fault)
    );

    always @(posedge clk) begin
        cycle_count <= cycle_count + 1;
        if (cycle_count > MAX_CYCLES && !watchdog_fired) begin
            watchdog_fired <= 1'b1;
            $finish;
        end
    end

    // PART2
endmodule
