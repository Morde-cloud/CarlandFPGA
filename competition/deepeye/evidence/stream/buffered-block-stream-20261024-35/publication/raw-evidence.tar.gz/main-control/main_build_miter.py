from pathlib import Path
import hashlib,json
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/stream/buffered-block-stream-20261024-35/main';F=E/'preinspection-01';D=Path(__file__).parent
f=json.loads((F/'MAIN_FREEZE.json').read_bytes());n='tests/rtl/stream/main_tb_encoded_frame_queue.sv';raw=(F/Path(n).name).read_bytes();assert hashlib.sha256(raw).hexdigest()==f['pins'][n]['sha256']
s=raw.decode();s=s[s.index('module main_queue_composition;'):s.index('module main_queue_guard')].strip()+'\n';s=s.replace('module main_queue_composition;','module main_buffered_miter;')
outs=[('cfg_ready',1,'cfg_ready'),('s_ready',1,'s_ready'),('out_meta_valid',1,'out_meta_valid'),('out_meta_tag',16,'out_meta_tag'),('out_meta_error',2,'out_meta_error'),('out_meta_count',8,'out_meta_count'),('out_meta_e',4,'out_meta_e'),('out_meta_raw',1,'out_meta_raw'),('out_meta_k',4,'out_meta_k'),('out_meta_valid_bits',12,'out_meta_valid_bits'),('out_meta_bytes',9,'out_meta_bytes'),('out_valid',1,'out_valid'),('out_data',8,'out_data'),('out_last',1,'out_last'),('stream_level',2,'stream_level'),('stream_filling',1,'stream_filling'),('queue_level',2,'level'),('queue_receiving',1,'receiving'),('queue_faulted',1,'faulted'),('queue_fault_event',1,'fault_event'),('queue_fault_code',2,'fault_code'),('stream_stat_cfg',32,'stream_cfg'),('stream_stat_samples',32,'stream_samples'),('stream_stat_ok',32,'stream_ok'),('stream_stat_error',32,'stream_error'),('stream_stat_aborted',32,'stream_aborted'),('queue_stat_meta',32,'sm'),('queue_stat_in_bytes',32,'si'),('queue_stat_retired',32,'sr'),('queue_stat_aborted',32,'sa'),('queue_stat_fault',32,'sf')]
inputs=['clk','rst','cancel','cfg_valid','cfg_count','cfg_e','cfg_tag','s_valid','s_data','s_last','out_meta_ready','out_ready']
iw=[('rst',1),('cancel',1),('cfg_valid',1),('cfg_count',8),('cfg_e',4),('cfg_tag',16),('s_valid',1),('s_data',16),('s_last',1),('out_meta_ready',1),('out_ready',1)]
def expr(n,w,ref,prefix):
 sig=prefix+n if prefix else ref
 if n.startswith('out_meta_') and n!='out_meta_valid':return (prefix+'out_meta_valid')+'?'+sig+':'+str(w)+"'d0"
 if n in ('out_data','out_last'):return (prefix+'out_valid')+'?'+sig+':'+str(w)+"'d0"
 return sig
width=sum(w for _,w,_ in outs)
decl='\n// Independent wrapper miter: only buffered_dut public ports are observed.\n'
for n,w,_ in outs:decl+='wire '+('['+str(w-1)+':0] ' if w>1 else '')+'b_'+n+';\n'
decl+='deepeye_buffered_block_stream buffered_dut(\n'+',\n'.join(' .'+n+'('+n+')' for n in inputs)+',\n'+',\n'.join(' .'+n+'(b_'+n+')' for n,_,_ in outs)+'\n);\n'
decl+='wire ['+str(width-1)+':0] buffered_public={'+','.join(expr(n,w,r,'b_') for n,w,r in outs)+'};\n'
decl+='wire ['+str(width-1)+':0] reference_public={'+','.join(expr(n,w,r,'') for n,w,r in outs)+'};\n'
decl+='wire ['+str(sum(w for _,w in iw)-1)+':0] external_inputs={'+','.join(n for n,w in iw)+'};\ninteger btf;string btrace_path;\n'
s=s.replace('always #5 clk=~clk;',decl+'\nalways #5 clk=~clk;',1)
anchor=' $fdisplay(tf,"C %0d %h %h %h",cycles,stimulus,observed,source_observed);'
assert anchor in s
replacement=anchor+'\n $fdisplay(btf,"B %0d %h %h",cycles,external_inputs,buffered_public);\n if(cycles>0 && buffered_public !== reference_public) begin\n  $display("MAIN_BUFFERED_MISMATCH cycle=%0d expected=%h actual=%h",cycles,reference_public,buffered_public);\n  $fatal(1,"MAIN_BUFFERED_NUMERIC_FAILURE");\n end'
s=s.replace(anchor,replacement)
anchor=' tf=$fopen(trace_path,"w");if(!tf) $fatal(1,"MAIN_TRACE_OPEN");';assert anchor in s
s=s.replace(anchor,anchor+'\n if(!$value$plusargs("BTRACE=%s",btrace_path)) $fatal(1,"MAIN_BUFFERED_TRACE_PATH");\n btf=$fopen(btrace_path,"w");if(!btf) $fatal(1,"MAIN_BUFFERED_TRACE_OPEN");')
anchor=' $fclose(tf);$display("MAIN_COMPOSITION_DONE cycles=%0d retired=%0d",cycles,sr);$finish;';assert anchor in s
s=s.replace(anchor,' $fclose(btf);$display("MAIN_BUFFERED_DONE cycles=%0d ports=31",cycles);\n'+anchor)
p=P/'tests/rtl/stream/main_tb_buffered_block_stream.sv';assert not p.exists();p.write_text(s,encoding='utf-8',newline='\n')
out=E/'miter-design-01';out.mkdir(exist_ok=False);(out/p.name).write_bytes(p.read_bytes())
rec={'scope':'Preinspection historicalreference reused; wrapper public-port adapter authored after reading preserved Flash partial source. No buffered_dut hierarchy accessed. Direct reference composition plus separate input-derived integer codec scoreboard. Historicaldriver/stimulus reuse disclosed. No new corealgorithm/first-evercomposition claim.','main_tb_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'main_tb':str(p),'outputs':outs,'inputs':iw,'field_count':len(outs),'output_width':width,'reference_freeze_sha256':hashlib.sha256((F/'MAIN_FREEZE.json').read_bytes()).hexdigest()};(out/'DESIGN.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps({'ports':len(outs),'width':width,'tb_sha256':rec['main_tb_sha256']}))
