from pathlib import Path
import hashlib,importlib.util,json,re,sys,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/stream/buffered-block-stream-20261024-35';D=Path(__file__).parent;O=E/'main/final-audit-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def get(p):return json.loads(p.read_bytes())
terminal=get(D/'parser-repair1-terminal.json')[0];assert terminal['terminal'] and not terminal['stale'] and terminal['status']=='completed'
runner=P/'tools/stream/run_buffered_block_stream.py';assert sha(runner)=='8317ed54b456b0fab22279932c2980cb289126537fdd7e23218bc19f8929dcce'
spec=importlib.util.spec_from_file_location('main_final_bbs_parser',runner);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);v,_=m.make_vectors();raw=(E/'author/attempt-03/command-12.stdout.bin').read_bytes();positive=m.parse_suite(raw,v)
probes=[]
for p in sorted((E/'main/author-parser-qualification-01').glob('*.log')):
 try:m.parse_suite(p.read_bytes(),v)
 except m.FixtureFailure as ex:probes.append({'name':p.name,'rejected':True,'reason':str(ex)})
 else:raise AssertionError('main original red accepted '+p.name)
assert len(probes)==203
extra=[];text=raw.decode();lines=text.splitlines()
for i,line in enumerate(lines):
 if 'BBS_CHECK seq=' not in line:continue
 hit=re.search(r'observed=(-?\d+) expected=(-?\d+)',line);assert hit
 changed=line[:hit.start()]+f'observed={int(hit[1])+1} expected={int(hit[2])+1}'+line[hit.end():]
 copy=lines[:];copy[i]=changed;data=('\n'.join(copy)+'\n').encode()
 try:m.parse_suite(data,v)
 except m.FixtureFailure as ex:extra.append({'line':i,'equal_but_wrong_pair_rejected':True,'reason':str(ex)})
 else:raise AssertionError('equal alteredpair accepted')
assert len(extra)==100
verified=[]
def verify(p,h):
 assert sha(p)==h,str(p);verified.append({'path':str(p.relative_to(W)),'sha256':h})
for index in (E/'author/evidence-index.json',E/'author/parser-repair1/evidence-index.json'):
 for x in get(index):
  p=P/x['path'];assert p.stat().st_size==x['bytes'];verify(p,x['sha256'])
ar=get(E/'author/RESULT.json')
for n,h in ar['final_source_pins'].items():
 if n=='tools/stream/run_buffered_block_stream.py':verify(E/'author/parser-repair1/inputs/run_buffered_block_stream.py',h)
 else:verify(P/n,h)
repair=get(E/'author/parser-repair1/RESULT.json');assert repair['commands']['actual_exit_code']==0 and repair['qualification']['vendor_executions']==0
for s in ('stdout','stderr'):
 rec=repair['commands'][s];verify(E/'author/parser-repair1'/rec['path'],rec['sha256'])
commands=[]
for f in (E/'main').rglob('*.command.json'):
 if '/inputs/' in f.as_posix():continue
 x=get(f);assert x['exit_code']==0 and not x['timed_out'];stem=f.name.removesuffix('.command.json')
 for s in ('stdout','stderr'):verify(f.parent/(stem+'.'+s+'.bin'),x[s+'_sha256'])
 commands.append({'path':str(f.relative_to(E)),'pid':x['pid'],'exit_code':0,'diagnostic_failures':x['diagnostic_failures']})
for f in (E/'main').rglob('INPUTS.json'):
 for n,x in get(f).items():verify(f.parent/'inputs'/Path(n).name,x['sha256'])
for f in (E/'main').rglob('RESULT.json'):
 x=get(f)
 for n in ('trace.txt','buffered_trace.txt'):
  if n in x:verify(f.parent/n,x[n]['sha256'])
main=get(E/'main/positive-01/RESULT.json');mutants=get(E/'main/compiled-mutants-01/RESULT.json');assert main['status']=='PASS' and mutants['actual_compiled_mutants']==3
for x in mutants['records']:assert x['exit']==0 and x['counterexample']['expected']!=x['counterexample']['actual']
verify(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json','6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8')
r={'status':'ACCEPTED_BOUNDED_WRAPPER_SOFTWARE','accepted_bounded_wrapper':True,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804','rtl_pins':{n:h for n,h in ar['final_source_pins'].items() if n.endswith('.sv')},'runner_sha256':sha(runner),'main_events':main['external']['edges'],'main_port_checks':main['external']['miter_port_comparisons'],'main_external_reference':main['external'],'compiled_connection_mutants':3,'author_cases':len(positive['cases']),'author_checks':positive['checks'],'author_admissions':positive['admissions'],'author_commands':12,'author_actual_simulations_including_failed':3,'saved_positive':positive,'main_original_red_rejections':probes,'main_new_equal_wrong_rejections':extra,'author_repair_qualification':repair['qualification'],'main_command_receipts':commands,'verified_files':verified,'limitations':['New thin wrapper only; original codec/stream/queue remain unchanged.','Main reused pre-frozen historical independent mathematical/reference composition and cases, adapter authored after partial wrapper inspection.','Internal block payload up to256B is not production TRACE<=32B; no public ABI or freshness/BOOT/TTL/control authority.','OOC33 synthesis separately executed and diagnostic timing failed. This wrapper has no synthesis/implementation/CDC_RDC/board/system acceptance. All29 formal cards, B01/B03/B06/R03 remain not_run. Physical board A only.'],'history':['Original Flash402 partial threefiles preserved before ownership transfer; native author removed two erroneous ready-net assignments.','Three original author vendor attempts retained; final attempt3 qualified; author runner203 false accepts repaired using savedlogs only.','Main original203 and100newwrongexpected negatives now rejected; no vendor rerun from parser repair.']}
(O/'RESULT.json').write_text(json.dumps(r,indent=2)+'\n',encoding='utf-8');print(json.dumps({'status':r['status'],'verified_files':len(verified),'main_commands':len(commands),'main_parser_rejections':len(probes)+len(extra),'ports':r['main_port_checks']}))
