from pathlib import Path
import datetime,hashlib,json,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/stream/buffered-block-stream-20261024-35/main';S=P/'fpga/stream/deepeye_buffered_block_stream.sv'
b=S.read_bytes();assert hashlib.sha256(b).hexdigest()=='8f1596ba50d0979e97f68e5ba125eab9b125f2b073f143d71e9be425522080d1';s=b.decode();assert s.count('.cancel(cancel)')==2
variants={}
i=s.index('deepeye_encoded_frame_queue u_encoded_frame_queue');variants['queue_cancel_omitted']=s[:i]+s[i:].replace('.cancel(cancel)',".cancel(1'b0)",1)
assert s.count('.m_ready(stream_m_ready)')==1;variants['stream_ready_bypasses_queue']=s.replace('.m_ready(stream_m_ready)','.m_ready(out_ready)')
assert s.count('.stat_retired(queue_stat_retired)')==1;variants['retired_counter_aliases_admission']=s.replace('.stat_retired(queue_stat_retired)','.stat_retired()').replace('endmodule','assign queue_stat_retired = queue_stat_meta;\nendmodule')
out=E/'compiled-mutants-01';out.mkdir(exist_ok=False);records=[]
for name,text in variants.items():
 p=out/(name+'.sv');p.write_text(text,encoding='utf-8',newline='\n');run=out/name
 argv=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(P/'tools/stream/main_verify_buffered_block_stream.py'),'--out',str(run),'--wrapper',str(p),'--negative']
 (out/(name+'.intent.json')).write_text(json.dumps({'argv':argv,'source_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2))
 cp=subprocess.run(argv,cwd=W,capture_output=True,creationflags=0x08000000,timeout=280);(out/(name+'.stdout.bin')).write_bytes(cp.stdout);(out/(name+'.stderr.bin')).write_bytes(cp.stderr)
 rec={'name':name,'exit':cp.returncode,'stdout_sha256':hashlib.sha256(cp.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(cp.stderr).hexdigest()};(out/(name+'.process.json')).write_text(json.dumps(rec,indent=2));assert cp.returncode==0,(name,cp.stderr[-1500:].decode())
 r=json.loads((run/'RESULT.json').read_bytes());assert r['status']=='EXPECTED_NUMERIC_REJECTION';rec['counterexample']={k:r[k] for k in ['cycle','expected','actual']};records.append(rec)
 assert hashlib.sha256(S.read_bytes()).hexdigest()==hashlib.sha256(b).hexdigest()
(out/'RESULT.json').write_text(json.dumps({'actual_compiled_mutants':len(records),'records':records,'production_source_unchanged':True},indent=2)+'\n');print(json.dumps({'mutants':len(records),'cycles':[r['counterexample']['cycle'] for r in records]}))
