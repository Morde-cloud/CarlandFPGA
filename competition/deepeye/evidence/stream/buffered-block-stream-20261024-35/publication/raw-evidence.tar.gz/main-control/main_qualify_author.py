from pathlib import Path
import hashlib,importlib.util,json,re,sys
P=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye');E=P/'evidence/stream/buffered-block-stream-20261024-35';out=E/'main/author-parser-qualification-01';out.mkdir(exist_ok=False)
runner=P/'tools/stream/run_buffered_block_stream.py';b=runner.read_bytes();assert hashlib.sha256(b).hexdigest()=='54d30bd0ceb97898eb39e22833176439faca3ae089a7078734ca2d80cfae7c39';(out/'original_runner.py').write_bytes(b)
spec=importlib.util.spec_from_file_location('bbs_author_qualified',runner);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m);v,known=m.make_vectors();raw=(E/'author/attempt-03/command-12.stdout.bin').read_bytes();positive=m.parse_suite(raw,v);lines=raw.decode().splitlines();probes=[]
for i,line in enumerate(lines):
 if 'BBS_CHECK seq=' in line:
  hit=re.search(r'observed=(-?\d+) expected=(-?\d+)',line);assert hit and int(hit[1])==int(hit[2])
  probes.append(('observed-mismatch-'+str(i),i,line[:hit.start(1)]+str(int(hit[1])+1)+line[hit.end(1):]))
  probes.append(('wrong-label-'+str(i),i,re.sub(r'label=[a-z][a-z0-9_]*','label=unexpected_label',line)))
 elif 'BBS_SUITE_TALLY ' in line:
  for field in ['metadata','payload_bytes','invariant_cycles']:
   probes.append(('tally-'+field,i,re.sub(field+r'=\d+',field+'=999999',line)))
results=[]
for name,i,changed in probes:
 z=lines.copy();z[i]=changed;data=('\n'.join(z)+'\n').encode();reason=None
 try:m.parse_suite(data,v);accepted=True
 except Exception as ex:accepted=False;reason=repr(ex)
 (out/(name+'.log')).write_bytes(data);results.append({'name':name,'accepted':accepted,'reason':reason,'sha256':hashlib.sha256(data).hexdigest()})
record={'status':'REJECTED_AUTHOR_RUNNER_QUALIFICATION','original_positive':positive,'probes':results,'false_acceptances':sum(x['accepted'] for x in results),'runner_sha256':hashlib.sha256(b).hexdigest(),'raw_source_sha256':hashlib.sha256(raw).hexdigest(),'main_positive_rtl_miter':'PASS independently130783edges/4054242comparisons','three_compiled_mutants':'numeric rejections at115669,1513,1379','scope':'saved-log qualification only; original actualModelSim positivevalues agree, this does not alterRTL or rerun vendor'};(out/'RESULT.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'probes':len(results),'false_acceptances':record['false_acceptances']}))
