from pathlib import Path
import hashlib,importlib.util,json,sys
D=Path(__file__).parent;P=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye');script=P/'tools/stream/main_verify_buffered_block_stream.py';spec=importlib.util.spec_from_file_location('main35_verifier',script);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
out=P/'evidence/stream/buffered-block-stream-20261024-35/main/terminal-qualification-01';out.mkdir(exist_ok=False)
rows=['MAIN_BUFFERED_DONE cycles=7 ports=31','MAIN_COMPOSITION_DONE cycles=7 retired=11'];valid='\n'.join('# '+r for r in rows);m.terminal(valid,7);probes=[]
for i,row in enumerate(rows):
 variants={'prefix':'NOT_'+row,'suffix':row+' trailing','duplicate_field':row+' cycles=7','wrong_value':row.replace('cycles=7','cycles=8'),'signed_value':row.replace('cycles=7','cycles=+7'),'leading_zero':row.replace('cycles=7','cycles=07'),'tab':row.replace(' ','\t',1),'bare_extra':row+' |','double_comment':'# # '+row}
 for kind,changed in variants.items():
  q=rows.copy();q[i]=changed;probes.append((str(i)+'-'+kind,'\n'.join(q)))
 probes.append((str(i)+'-deleted','\n'.join(rows[:i]+rows[i+1:])))
 probes.append((str(i)+'-duplicate','\n'.join(rows[:i]+[row]+rows[i:])))
probes += [('reordered','\n'.join(reversed(rows))),('conflicting_extra',valid+'\nMAIN_BUFFERED_DONE cycles=999 ports=31'),('foreign_status',valid+'\nMAIN_BUFFERED_UNEXPECTED status=FAIL')]
for i,(name,text) in enumerate(probes):
 rejected=False
 try:m.terminal(text,7)
 except AssertionError:rejected=True
 assert rejected,name;(out/(str(i)+'-'+name+'.txt')).write_text(text+'\n')
result={'valid_patterns':1,'rejected_negative_logs':len(probes),'verifier_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'scope':'synthetic terminal grammar only; no vendor execution claim'};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
