from pathlib import Path
import datetime,hashlib,json
D=Path(__file__).parent;W=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=W/'competition/deepeye'
wait=json.loads((D/'wait.stdout.json').read_text(encoding='utf-8-sig'));j=wait[0];assert j['terminal'] and j['status']=='failed' and '402' in j['error']
out=D/'failed-flash-partial-snapshot';out.mkdir(exist_ok=False);files={}
for n in ['fpga/stream/deepeye_buffered_block_stream.sv','fpga/stream/buffered_block_stream_candidate.md','tests/rtl/stream/tb_buffered_block_stream.sv','tools/stream/run_buffered_block_stream.py']:
 p=P/n
 if p.is_file():
  b=p.read_bytes();(out/p.name).write_bytes(b);files[n]={'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
 else:files[n]={'absent':True}
record={'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-BUFFERED-BLOCK-STREAM-20261024-35-native-recovery1','old_job':j,'terminal_confirmed':True,'files':files,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'no_auto_retry':True,'scope':'preserve incomplete unaccepted edits, new explicit native continuation; main keeps independent acceptance','requirements_sha256':'c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804'}
(out/'TRANSFER.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps({'preserved':len([v for v in files.values() if not v.get('absent')]),'terminal':j['status'],'out':str(out)}))
