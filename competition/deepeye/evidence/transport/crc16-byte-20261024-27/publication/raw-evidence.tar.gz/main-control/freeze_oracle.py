from pathlib import Path
import binascii,hashlib,json,time,sys,datetime
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014')
O=R/'competition/deepeye/evidence/transport/crc16-byte-20261024-27/main/oracle-01'
O.mkdir(parents=True,exist_ok=False)
t=time.time();table=[binascii.crc_hqx(b'\x00',seed) for seed in range(65536)]
raw=''.join(f'{x:04x}\n' for x in table).encode('ascii');(O/'oracle.hex').write_bytes(raw)
values=[bytes([b]) for b in range(256)];count=0
for seed in range(65536):
 for b,blob in enumerate(values):
  direct=binascii.crc_hqx(blob,seed);assert direct==table[seed^(b<<8)],(seed,b,direct)
  count+=1
prefixes=[binascii.crc_hqx(b'123456789'[:i],0xffff) for i in range(10)];assert prefixes[-1]==0x29b1
tb=R/'competition/deepeye/tests/rtl/transport/main_tb_crc16_byte.sv'
receipt={'actual_direct_library_pairs':count,'prefixes':prefixes,'elapsed_seconds':time.time()-t,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'table_sha256':hashlib.sha256(raw).hexdigest(),'tb_sha256':hashlib.sha256(tb.read_bytes()).hexdigest(),'python':sys.version,'binascii_binary':str(binascii.__file__),'binascii_sha256':hashlib.sha256(Path(binascii.__file__).read_bytes()).hexdigest(),'author_source_inspected':False,'not_RTL_execution':True}
(O/'FREEZE.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
