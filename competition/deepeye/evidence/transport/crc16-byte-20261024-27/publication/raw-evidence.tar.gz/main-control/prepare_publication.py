from pathlib import Path
import gzip,hashlib,io,json,tarfile,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=Path(__file__).parent;O=P/'publication';O.mkdir(exist_ok=False)
E=W/'competition/deepeye/evidence/transport/crc16-byte-20261024-27';B=E/'publication';B.mkdir(exist_ok=False)
OLD=R/'.local/deployment/node-b/evidence/uart-link-publish-20261024-25-26'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):
 with p.open('x',encoding='utf-8',newline='\n') as f:json.dump(x,f,ensure_ascii=False,indent=2);f.write('\n')
assert (P/'wait.exit.txt').read_text().strip()=='0'
wait=json.loads((P/'wait.stdout.json').read_text(encoding='utf-8-sig'))[0];assert wait['terminal'] and not wait['stale'] and wait['status']=='completed'
main=json.loads((E/'main/exhaustive-01/RESULT.json').read_bytes());assert main['accepted']
mutants=json.loads((E/'main/mutants-01/RESULT.json').read_bytes())
qualification=json.loads((E/'main/qualification-01/RESULT.json').read_bytes());assert qualification['accepted']
accept=json.loads((P/'LOCAL_ACCEPTANCE.json').read_bytes());assert accept['rtl_sha256']==sha((W/'competition/deepeye/fpga/transport/deepeye_crc16_byte.sv').read_bytes())
paths=['competition/deepeye/fpga/transport/deepeye_crc16_byte.sv','competition/deepeye/fpga/transport/crc16_byte_candidate.md','competition/deepeye/tests/rtl/transport/tb_crc16_byte.sv','competition/deepeye/tests/rtl/transport/main_tb_crc16_byte.sv','competition/deepeye/tools/transport/run_crc16_byte.py','competition/deepeye/tools/transport/main_verify_crc16_byte.py']
sources={p:sha((W/p).read_bytes()) for p in paths};raws={};omitted=[]
for area in ('author','main'):
 for p in sorted((E/area).rglob('*')):
  if not p.is_file():continue
  rel=p.relative_to(E).as_posix()
  if any(x in ('work','temp','tmp','__pycache__','pycache','cache') for x in p.relative_to(E).parts) or p.suffix.lower() in ('.wlf','.vstf'):omitted.append(rel);continue
  raws[rel]=p.read_bytes()
for p in sorted(P.iterdir()):
 if p.is_file() and p.suffix.lower() in ('.md','.json','.py','.txt'):raws['main-control/'+p.name]=p.read_bytes()
index={k:{'bytes':len(v),'sha256':sha(v)} for k,v in raws.items()};put(B/'RAW_INDEX.json',{'files':index,'omitted_compiler_scratch':omitted})
with (B/'raw-evidence.tar.gz').open('xb') as out:
 with gzip.GzipFile(filename='',fileobj=out,mode='wb',mtime=0) as gz:
  with tarfile.open(fileobj=gz,mode='w') as tar:
   for name,data in sorted(raws.items()):
    info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(data))
put(B/'BUNDLE_MANIFEST.json',{'archive':'raw-evidence.tar.gz','sha256':sha((B/'raw-evidence.tar.gz').read_bytes()),'index':'RAW_INDEX.json','index_sha256':sha((B/'RAW_INDEX.json').read_bytes()),'members':len(raws),'raw_bytes':sum(map(len,raws.values()))})
put(B/'SOURCE_BINDING.json',{'base_commit':'dfdb2b8120793ba816fd09cd8fc255953bbf73ac','sources':sources,'requirements_sha256':accept['requirements_sha256'],'main_thread':accept['main_thread'],'main_turn':'01a16933-edc1-7022-8e5f-25b4561a4ea5','author_job':wait['job_id'],'author_thread':wait['result']['thread_id'],'author_turn':wait['result']['turn']['id'],'author_terminal_at':wait['updated_at']})
accept['status']='accepted_pure_binary_crc_simulation_only';accept.pop('publication');accept['history_notes']=['First table generator completed its loop but failed while looking for binascii.__file__; original failure remains. Fresh second full generation is the accepted freeze.','Author initial compilation failure and unsupported vlib -version exit1 are retained. Actual compilation/simulation exits are separately recorded.','Author runner originally accepted inconsistent per-case check totals. Main preserved red fixture and original runner, repaired aggregate qualification, tested six synthetic negatives and one saved positive, then executed one new real CLI suite.','No full packet coverage/CRC error detection guarantee or physical acceptance is implied by complete binary update coverage.']
put(B/'ACCEPTANCE.json',accept)
(B/'README.md').write_text('# B-DEEPEYE-CRC16-BYTE-20261024-27\n\nPure combinational CRC16/CCITT-FALSE update: arbitrary binary16bit state and8bit data, eight MSB-first polynomial1021 steps. Caller owns seed, framing, byte order and validation policy. Main independently froze a library-derived table before reading author RTL, checked all16777216 seed/byte pairs directly against binascii, then actually simulated all16777216 pairs and9 known-message prefixes. Three compiled behavioral mutants fail with numeric public-output contradictions. Author seven cases/198437 checks remain separately attributed; sampled author and exhaustive main checks share the binascii library, not an algorithmically distinct CRC implementation.\n\nSOURCE_BINDING pins final files, including the qualified author runner. RAW_INDEX hashes all archive members; failed attempts and original accepted-negative log remain. Final author parser qualification is six synthetic negatives, one saved real positive and one new actual CLI simulation. The original author RESULT predates that runner fix.\n\nReproduce main_verify_crc16_byte.py using --rtl, --tb, --table from archived main/oracle-02/oracle.hex, and a fresh --out plus --tools ModelSim directory. Table hash364ef72ec21a070f1f8c4641f171b53bb488c0ca3c1b06d4704cd532f562ce66 is required. All29/B04/R03/fullproduct/synthesis/implementation/timing/CDC_RDC/board/system remain not_run. A alone operates physical board. H01-H15 canonical c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 remains fixed.\n',encoding='utf-8',newline='\n')
paths += [p.relative_to(W).as_posix() for p in sorted(B.iterdir()) if p.is_file()]
op={'operation_id':'B-DEEPEYE-CRC16-BYTE-20261024-27','evidence_prefix':B.relative_to(W).as_posix()+'/','files':paths,'acceptance':accept,'archive_members':len(raws)}
put(O/'SELECTED.json',{'root':str(W),'baseline':'dfdb2b8120793ba816fd09cd8fc255953bbf73ac','files':[{'path':p,'sha256':sha((W/p).read_bytes()),'bytes':(W/p).stat().st_size} for p in paths],'operations':[op]})
for name in ('delivery26batch.py','publish26batch.py','verify_remote.py','git_blobs15.py'):
 raw=(OLD/name).read_text(encoding='utf-8')
 replacements=[('delivery26batch','delivery27'),('op26batch','op27'),('operations25/26','operation27'),('B-UART-LINK-PUBLISH-20261024-25-26-v1','B-CRC16-BYTE-PUBLISH-20261024-27-v1'),('B-DEEPEYE-UART-LINK-PUBLISH-20261024-25-26','B-DEEPEYE-CRC16-BYTE-PUBLISH-20261024-27'),('UART RX/frame TX and qualified bounded RTL archives','pure CRC primitive and exhaustive bounded RTL archives'),('both raw archives','the exact CRC archive'),('DeepEye B: UART receive and complete-frame transmission with independent verification','DeepEye B: UART transport primitives and exhaustive CRC verification')]
 for a,b in replacements:raw=raw.replace(a,b)
 dest={'delivery26batch.py':'delivery27.py','publish26batch.py':'publish27.py'}.get(name,name)
 (O/dest).write_text(raw,encoding='utf-8',newline='\n')
raw=(OLD/'commit_local.py').read_text(encoding='utf-8')
start=raw.index(" request={'operation_id':")
end=raw.index(" inp='handoffs/b/",start)
request=""" request={'operation_id':oid,'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'requester':'node-b','code_commit':source,'test_steps':[
  f"Verify final SOURCE_BINDING and all{op['archive_members']} indexed archive members, including original failures and main parser repair fixtures.",
  'Inspect full16777216 library pairs and actual ModelSim16777216 pairs+9prefixes, three compiled numeric mutants, and preinspection freeze. Both author sampled oracle and main exhaustive oracle use binascii; do not call them algorithmically independent CRC implementations.',
  'Verify original author7cases/198437checks and six process receipts; runner aggregate defect preserved and fixed; saved positive plus6synthetic negatives and one new actual CLI suite qualify final runner.',
  'H01-H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 requirements c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804; design1011259415a0916054eb580687612580bc1e5f09 unchanged.'
 ],'expected_result':'Pure binary CRC byte-update simulation only. All29/B04/R03/fullproduct/synth/impl/timing/CDC_RDC/board/system not_run. No protocol/ABI/authentication/source freshness/control or physical acceptance. Board A-only.'}
 stages={k:{'status':'passed','log':ep+'ACCEPTANCE.json'} for k in ('bounded_crc_rtl_simulation','main_exhaustive_binary_domain','saved_evidence_and_parser_qualification')}
 for k in ('simulation','synthesis','implementation','timing','CDC_RDC','board','system','formal_cards','B04','R03','full_product'):stages[k]={'status':'not_run'}
"""
raw=raw[:start]+request+raw[end:]
raw=raw.replace('Add bounded UART receive and frame transmit with independent verification','Add CRC byte primitive with exhaustive binary-domain verification').replace('Record operations25 and26 exact bounded UART evidence handoffs','Record operation27 exact CRC evidence handoff')
start=raw.index("body='Adds the missing")
raw=raw[:start]+"""body='Adds a pure CRC16 byte-update primitive used by the next bounded frame candidates. Independent main execution checks all16,777,216 binary seed/byte pairs and9 known-message prefixes; three actual compiled behavioral mutants fail numerically. Original author7cases/198437checks and a separately repaired strict runner are preserved with failed attempts. Both sampled author and exhaustive main oracles use binascii; the main fixture was frozen before source inspection.\\n\\nSource `'+source+'`; head `'+target+'`.\\n\\n'
for x in operations:body+='- Operation `'+x['operation_id']+'`; request `'+x['request_hash']+'`; manifest `'+x['manifest']+'` SHA256 `'+x['manifest_sha256']+'`. '+str(x['raw_members'])+' indexed raw members.\\n'
body+='\\nEarlier UART/codec/transport checkpoints retain exact-head scope. Accepted only mathematical binary CRC update in digital simulation. All29/B04/R03/fullproduct/synthesis/implementation/timing/CDC_RDC/board/system remain not_run. No ABI/freshness/authentication/motion or physical grant. Board A-only. H01-H15 canonical c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804 and design1011259415a0916054eb580687612580bc1e5f09 unchanged.\\n'
(O/'PR_BODY.md').write_text(body,encoding='utf-8',newline='\\n');print(json.dumps({'source':source,'head':target,'files':len(allowed),'operations':operations}))
"""
(O/'commit_local.py').write_text(raw,encoding='utf-8',newline='\n')
print(json.dumps({'files':len(paths),'raw_members':len(raws),'archive_bytes':(B/'raw-evidence.tar.gz').stat().st_size,'publication_directory':str(O)}))
