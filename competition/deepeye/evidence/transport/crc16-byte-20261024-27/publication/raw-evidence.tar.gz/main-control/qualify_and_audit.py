from pathlib import Path
import hashlib,json,importlib.util,re,subprocess,sys,time
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=R/'competition/deepeye';E=P/'evidence/transport/crc16-byte-20261024-27';O=E/'main/qualification-01';O.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p,n):
 s=importlib.util.spec_from_file_location(n,p);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
runner=P/'tools/transport/run_crc16_byte.py';old=runner.read_bytes();(O/'original_runner.py').write_bytes(old);m=load(runner,'crc_original')
base=E/'author/attempt-03-final';raw=(base/'vsim-log.txt').read_bytes();red=re.sub(rb'(CASE_END[^\r\n]+checks=)(\d+)',lambda z:z[1]+str(int(z[2])+1).encode(),raw,count=1)
assert m.parse_simulation({},raw) and m.parse_simulation({},red)
(O/'original_positive.bin').write_bytes(raw);(O/'original_accepted_negative.bin').write_bytes(red)
s=old.decode();anchor='    recognized = 0';assert s.count(anchor)==1
s=s.replace(anchor,'    case_check_total = sum(int(CASE_END.fullmatch(row).group(3)) for row in structured if CASE_END.fullmatch(row))\n    if case_check_total != EXPECTED_CHECKS:\n        problems.append(f"case check total={case_check_total} expected={EXPECTED_CHECKS}")\n\n'+anchor)
runner.write_text(s,encoding='utf-8',newline='\n');fixed=load(runner,'crc_fixed');assert fixed.parse_simulation({},raw) and not fixed.parse_simulation({},red)
variants={'inflated_case':red,'fake_end':raw.replace(b'TB_END pass',b'NOT_TB_END pass'),'duplicate_end':raw+b'# TB_END pass\n','bad_summary':raw.replace(b'checks=198437',b'checks=198438'),'bad_stat':raw+next(z for z in raw.splitlines(keepends=True) if b'TB_STAT' in z),'early_end':b'# TB_END pass\n'+raw.replace(b'# TB_END pass\r\n',b'').replace(b'# TB_END pass\n',b'')}
for n,b in variants.items():assert not fixed.parse_simulation({},b),n;(O/(n+'.bin')).write_bytes(b)
commands=[];hashes=0
for jf in base.glob('commands/*/command.json'):
 c=json.loads(jf.read_bytes());assert not c.get('timed_out') and not c.get('process_error')
 for stream in ('stdout','stderr'):assert sha(Path(c[stream]))==c[stream+'_sha256'];hashes+=1
 if c['exit_code']!=0:assert Path(c['argv'][0]).name.lower()=='vlib.exe' and '-version' in c['argv'] and c['exit_code']==1
 commands.append({'argv':c['argv'],'exit':c['exit_code']})
assert len(commands)==6
main_runs=[]
for d in [E/'main/exhaustive-01',*sorted((E/'main/mutants-01').iterdir())]:
 if not d.is_dir() or not (d/'RESULT.json').exists():continue
 x=json.loads((d/'RESULT.json').read_bytes());assert x['accepted']
 for c in x['commands']:
  assert c['returncode']==0 and not c['timeout']
  for stream in ('stdout','stderr'):assert sha(d/(c['name']+'.'+stream+'.bin'))==c[stream+'_sha256'];hashes+=1
 for name,info in x['inputs'].items():assert sha(d/name)==info['sha256'];hashes+=1
 main_runs.append({'name':d.name,'counterexamples':x['numeric_counterexamples']})
assert len(main_runs)==4
argv=[sys.executable,'-B','-X','utf8',str(runner),'--attempt','main-qualified-04'];t=time.time();r=subprocess.run(argv,cwd=R,capture_output=True,timeout=120);(O/'cli.stdout.bin').write_bytes(r.stdout);(O/'cli.stderr.bin').write_bytes(r.stderr)
receipt={'original_runner_sha256':hashlib.sha256(old).hexdigest(),'final_runner_sha256':sha(runner),'reproduced_defect':'individual case check total can conflict with fixed final total','saved_real_positive':1,'synthetic_negative_probes':len(variants),'author_raw_commands':commands,'main_runs':main_runs,'raw_hash_checks':hashes,'new_cli':{'actual_executor':'main','argv':argv,'exit':r.returncode,'elapsed':time.time()-t,'stdout_sha256':sha(O/'cli.stdout.bin'),'stderr_sha256':sha(O/'cli.stderr.bin')},'accepted':r.returncode==0,'no_RTL_change':True}
(O/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k not in ('author_raw_commands','main_runs')}));assert r.returncode==0
