# Operation26: complete-frame UART send buffer and direction timing

Task DEEPEYE-IMPLEMENTATION-20261014/v1. Work B-UART-FRAME-TX-20261023-26-v1;
operation B-DEEPEYE-UART-FRAME-TX-20261023-26. Main01a13b55-095b-7461-8dd5-5476a130bd82,
turn01a16933-edc1-7022-8e5f-25b4561a4ea5. Base B head
b90fcbc58cdd7f3bf53fb6931dbdd47cd55afc8a. These are new unowned files.

First fully read H01-H15, DEEPEYE-HUMAN-LOCK-20261014/revision1 pinned
f5989cd5defce561f9ba98e6b18fc2682945f0a2; verify canonical requirements hash
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Design1011259415a0916054eb580687612580bc1e5f09 stays fixed. Physical A-only.
This is internal buffering and digital direction sequencing, not the public
UART packet format, arbitration, RS485 electrical approval or full B04.

## Read-only accepted dependency

competition/deepeye/fpga/transport/deepeye_uart_tx.sv SHA256
5076286e4dd1598aeb2c78281bec83020c85d0711dcee9b985088ac707353c47.
Instantiate exactly one unchanged TX. It gates input on idle, emits complete
8N1 byte, busy clears only after final stop boundary. No same-edge next-byte
credit. Never replace it or use its own waveform as the expected oracle.

## Fixed candidate interface

Module deepeye_uart_frame_tx with CLOCK_HZ=100000000,BAUD=9600,
PRE_CYCLES=0,POST_CYCLES=0,STAT_W=32. CLOCK_HZ2..2147483647,
BAUD1..floor(CLOCK_HZ/2), PRE_CYCLES/POST_CYCLES0..65535, STAT_W2..32.
Ports: clk,rst,cancel; cfg_valid,cfg_ready,cfg_count[6:0]; s_valid,s_ready,
s_data[7:0],s_last; tx,de,busy,receiving,faulted,fault_event,fault_code[1:0],
stat_admitted,stat_sent,stat_aborted,stat_faults (STAT_W each).
Exactly one64-byte frame memory and finite metadata; no other frame queue.
Count1..64 is internal storage capacity, not a new public wire payload limit.
All cfg/sample handshakes are gated during rst/cancel/fault. No same-edge
config and payload handshake. Config accepted only idle, reserves wholeframe
and increments admitted. Invalid count0 or65..127 reserves poisoned frame,
sets faulted and code1/event/counter, never de or tx data; explicit abort needed.
Sample accepted only receiving. s_last must equal index==count-1; wrong early
or absent final last latches code2/event/counter, retains reservation, accepts
no more bytes, never transmits any byte of poisoned or partial frame. No
timeout or guessed resynchronization. Complete good frame seals on last
sample edge; memory addresses always0..63. Same-edge send bypass forbidden.

busy means reservation allocated (receiving, sealed, transmitting, guards,
or fault), not just TX-core busy. receiving=valid partial input and not faulted.
faulted/code sticky until reset/cancel; event one cycle per new fault only.

After good seal, at the NEXT rising edge assert registered de=1 and start
pre-guard. If that DE assertion is edge d, first TX-core admission may occur
no earlier than d+PRE_CYCLES+1. Require exact earliest edge in ordinary
unstalled core conditions. PRE_CYCLES=0 therefore still gives one full clock
between DE rise and start bit. Hold de throughout all bytes. Feed each stable
stored byte on core ready, then await its completion before advancing. The
TX-core busy falls after final stop; no byte may be skipped/repeated and
final frame retirement is not inferred from last byte admission.

Let c be the actual rising edge on which TX-core busy falls for the final byte.
Top may observe that old busy was high only at c; the falling observation is
available at c+1 under normal sequential semantics. Release registered de,
clear busy and increment stat_sent at EXACT edge c+POST_CYCLES+1. Hence zero
post guard still holds DE one additional complete clock after stop completion.
No new config may use completion credit at that edge; next admission later.
Interbyte gaps from core handshake/state latency must be documented with
public waveform evidence; this is not a configured bitrate/throughput claim.

Reset>cancel>ordinary, synchronous active-high. Reset clears all control and
counters; cancel aborts the one allocated frame if busy, increments aborted
once, preserves admitted/sent/faults, and clears fault/control/DE. Pass the
same rst/cancel to the unchanged core. tx and de are registered effects, no
combinational asynchronous forcing. Cancellation may truncate an on-wire byte
and disable DE; this is explicit abort, not graceful drain or physical safety.
Parent protocol must discard partial frame. Held cancel no recount. At final
release edge cancel wins and counts aborted rather than sent. Before counter
saturation, admitted=sent+aborted+busy. All counters saturate with widened math.

Illegal parameters use safe declarations then exact own timezero fatal in
priority CLOCK_HZ,BAUD,PRE_CYCLES,POST_CYCLES,STAT_W. Own diagnostic
"deepeye_uart_frame_tx: <PARAM> out of range". Clamp parameters passed to core
so own guard is not obscured by duplicate dependency fatals. Guards excluded
from synthesis; only legal configurations supported for hardware generation.

## Ownership and independent acceptance

Root D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014.
Flash author ONLY competition/deepeye/fpga/transport/deepeye_uart_frame_tx.sv,
fpga/transport/uart_frame_tx_candidate.md, tests/rtl/transport/tb_uart_frame_tx.sv,
tools/transport/run_uart_frame_tx.py, evidence/transport/uart-frame-tx-20261023-26/author/
(all latter paths also under competition/deepeye). No RX files or old TX
edits. Main owns new main tests/evidence, exact handoff and this private scope.

Main freezes a separate accepted-frame list and absolute-bit waveform model
before reading author source. Required all lengths1..64, all byte values,
guard0/1/65535 and unequal guards, raw cfg/s gaps, early/missing last faults,
sticky recovery, no partial transmission, rst/cancel during each stage and
pre/post/final edge, small counter saturation, long source silence, real
100MHz/300/1200/9600 examples, parameter guards, and2compiled public-port
behavioral mutants. No hierarchy peeks/force or reused output as oracle.

Actual ModelSim10.7, original raw stdout/stderr/commands/versions/exits/hashes,
new attempt dirs and retained failures. Portable strict runner, anchored unique
markers/complete consistent stats and no hard-coded historical Git-HEAD gate.
TEMP/TMP/TMPDIR/caches/simulator cwd inside exclusive author evidence.
No commit/push/peer/group/service/credentials/config/SQL/queue/board action.
No reading/importing main oracle. Report actual thread/turn, RESULTS and hashes
in author/RESULT.json; main handles decisions/acceptance/publication.
H01-H15/All29/B04/R03/CDC_RDC/synth/implementation/board/system remain not_run.
