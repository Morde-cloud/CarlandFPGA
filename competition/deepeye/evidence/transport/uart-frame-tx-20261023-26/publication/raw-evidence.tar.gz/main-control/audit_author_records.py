from pathlib import Path
import json,hashlib,datetime
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=R/'competition/deepeye'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def walk(v):
 if isinstance(v,dict):
  yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
for stem,op,attempt,summary in [('uart_rx','uart-rx-20261023-25','attempt-10-final-all','summary.json'),('uart_frame_tx','uart-frame-tx-20261023-26','attempt-final-03','result.json')]:
 base=P/'evidence/transport'/op/'author'/attempt
 source=P/'fpga/transport'/('deepeye_'+stem+'.sv');tb=P/'tests/rtl/transport'/('tb_'+stem+'.sv');runner=P/'tools/transport'/('run_'+stem+'.py')
 expected={x.name:sha(x) for x in [source,tb,runner,P/'fpga/transport/deepeye_uart_tx.sv']}
 doc=json.loads((base/summary).read_text(encoding='utf-8'));assert doc['status']=='pass'
 seen={};files={};source_copies=[];exceptions=[]
 for jf in base.rglob('*.json'):
  if any(x in ('work','temp','tmp','cache') for x in jf.relative_to(base).parts):continue
  d=json.loads(jf.read_text(encoding='utf-8'))
  for item in walk(d):
   if 'argv' in item and 'stdout_sha256' in item and isinstance(item.get('stdout'),str):
    key=item['stdout'];seen[key]=item
    assert not item.get('timed_out',False) and not item.get('timeout',False)
    assert not item.get('spawn_error') and not item.get('process_error')
    for tag in ('stdout','stderr'):
     f=Path(item[tag]).resolve(strict=True);assert f.is_relative_to(base.resolve())
     actual=sha(f);assert actual==item[tag+'_sha256'],str(f);files[str(f.relative_to(base))]=actual
    code=item.get('returncode',item.get('exit_code'))
    if code!=0:
     assert Path(item['argv'][0]).name.lower()=='vlib.exe' and '-version' in item['argv'],item
     exceptions.append({'argv':item['argv'],'exit':code,'scope':'unsupported version probe, not compile/run'})
   if all(k in item for k in ('source_path','snapshot_path','source_sha256','snapshot_sha256')):
    f=Path(item['snapshot_path']);assert f.resolve().is_relative_to(base.resolve())
    assert sha(f)==item['snapshot_sha256']==item['source_sha256']==sha(Path(item['source_path']))
 for f in base.rglob('*'):
  if f.is_file() and f.name in expected and not any(x in ('work','temp','tmp','cache') for x in f.relative_to(base).parts):
   assert sha(f)==expected[f.name],str(f);source_copies.append(str(f.relative_to(base)))
 assert len(seen)>=45 and len(source_copies)>=3
 result={'accepted_raw_integrity':True,'operation':op,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'final_summary_sha256':sha(base/summary),'unique_process_receipts':len(seen),'unique_raw_pipes':len(files),'source_copies_verified':len(source_copies),'current_source_sha256':expected,'nonzero_version_probes':exceptions,'author_own_audit_is_not_independent':True,'raw_files':files,'source_copies':source_copies}
 out=P/'evidence/transport'/op/'main/AUTHOR_RAW_AUDIT.json';assert not out.exists();out.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items() if k not in ('raw_files','source_copies','current_source_sha256')}))
