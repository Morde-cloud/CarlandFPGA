from pathlib import Path
import json,hashlib,importlib.util
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=R/'competition/deepeye'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
for stem,op,expect_positive,expect_guards in [('uart_rx','uart-rx-20261023-25',7,9),('uart_frame_tx','uart-frame-tx-20261023-26',9,11)]:
 main=P/'evidence/transport'/op/'main';runner=P/'tools/transport'/('main_verify_'+stem+'.py')
 spec=importlib.util.spec_from_file_location(stem,runner);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 positive=[];guards=[];mutants=[];failed=[];hash_checks=0;commands=0
 for d in [main/'suite-01',main/'remaining-mutants-01']:
  for f in sorted(d.glob('*/RESULT.json')):
   x=json.loads(f.read_text());run=f.parent
   for c in x['commands']:
    for pipe in ('stdout','stderr'):
     assert sha(run/(c['name']+'.'+pipe+'.bin'))==c[pipe+'_sha256'];hash_checks+=1
    assert not c['timeout'];commands+=1
   for name,info in x['inputs'].items():assert sha(run/name)==info['sha256'];hash_checks+=1
   if not x['accepted']:
    assert run.name=='stat1' and d.name=='suite-01';failed.append(str(f.relative_to(main)));continue
   raw=(run/'vsim.stdout.bin').read_bytes()+b'\n'+(run/'vsim.stderr.bin').read_bytes();code=x['commands'][-1]['returncode']
   if x['mode']=='positive':
    parsed=m.classify(raw,code,tuple(x['parameters']));assert parsed['accepted'] and parsed['stats']==x['stats'];positive.append({'name':str(run.relative_to(main)),'stats':x['stats']})
   elif x['mode']=='mutant':
    parsed=m.classify(raw,code,tuple(x['parameters']),True);assert parsed['accepted'];mutants.append({'name':run.name,'numeric_counterexamples':parsed['numeric_counterexamples']})
   else:
    lines=m.text_lines(raw);assert lines.count('** Fatal: '+x['diagnostic'])==1 and lines.count('Errors: 1, Warnings: 0')==1 and code==0;guards.append({'name':str(run.relative_to(main)),'diagnostic':x['diagnostic']})
 assert len(positive)==expect_positive+1 and len(guards)==expect_guards and len(mutants)==3
 originals=[x for x in positive if x['name'].startswith('suite-01/')]
 result={'accepted':True,'original_positive_configurations':len(originals),'original_cycles':sum(x['stats']['cycles'] for x in originals),'original_checks':sum(x['stats']['checks'] for x in originals),'guards':guards,'mutants':mutants,'additional_legal_confirmation':1,'retained_failed_main_fixtures':failed,'raw_hash_checks':hash_checks,'command_receipts':commands,'all_positive':positive,'note':'Main guard port clamp repaired only for illegal STAT_W. Legal widths unchanged and confirmed with actual fresh legal run. Product RTL unchanged.'}
 dest=main/'MAIN_REVIEW.json';assert not dest.exists();dest.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('all_positive','guards','mutants')}))
