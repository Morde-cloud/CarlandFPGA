from pathlib import Path
s=Path(__file__).with_name('audit_main_runs.py').read_text(encoding='utf-8')
s=s.replace('str(run.relative_to(main))','run.relative_to(main).as_posix()')
s=s.replace("dest=main/'MAIN_REVIEW.json'","dest=main/'MAIN_REVIEW_V2.json'")
s=s.replace("result={'accepted':True", "assert len(originals)==expect_positive\n result={'accepted':True,'prior_summary_issue':'First Windows path summary used slash test on backslash paths, reported zero original counts. Original saved; this fresh raw reclassification fixes path normalization; no vendor replay.'")
exec(compile(s,__file__,'exec'))
