from pathlib import Path
import hashlib,json,datetime
root=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014')
src=root/'competition/deepeye/tools/transport/main_verify_uart_tx.py'
dest=root/'competition/deepeye/tools/transport/main_verify_uart_frame_tx.py'
if dest.exists():raise SystemExit('existing output: no replay')
s=src.read_text(encoding='utf-8').replace('UART oracle','UART frame oracle').replace('uart_tx','uart_frame_tx')
s=s.replace('tuple[int, int, int, int]','tuple[int, int, int, int, int, int]')
s=s.replace('stat={expected[2]} brief={expected[3]}','stat={expected[2]} pre={expected[3]} post={expected[4]} brief={expected[5]}')
s=s.replace(r'MAIN_STATS cycles=(\d+) checks=(\d+) admitted=(\d+) completed=(\d+) aborted=(\d+)',r'MAIN_STATS cycles=(\d+) checks=(\d+) admitted=(\d+) sent=(\d+) aborted=(\d+) faults=(\d+) bytes=(\d+) gap_min=(\d+) gap_max=(\d+)')
s=s.replace('("cycles", "checks", "admitted", "completed", "aborted")','("cycles", "checks", "admitted", "sent", "aborted", "faults", "bytes", "gap_min", "gap_max")')
s=s.replace('minimum = 4 if expected[3] else 256','minimum = 1 if expected[5] else 320')
s=s.replace('stats["completed"] >= minimum and stats["checks"] == stats["cycles"] * 6 - 1','stats["sent"] >= minimum and stats["checks"] == stats["cycles"] * 18')
s=s.replace('stats["completed"] + stats["aborted"]','stats["sent"] + stats["aborted"]')
s=s.replace('p.add_argument("--rtl", type=Path, required=True)','p.add_argument("--rtl", type=Path, required=True)\n    p.add_argument("--core", type=Path, required=True)\n    p.add_argument("--pre", type=int, default=0)\n    p.add_argument("--post", type=int, default=0)')
s=s.replace('choices=("CLOCK_HZ", "BAUD", "STAT_W")','choices=("CLOCK_HZ", "BAUD", "PRE_CYCLES", "POST_CYCLES", "STAT_W")')
s=s.replace('for name, src in (("dut.sv", rtl), ("main_tb.sv", tb)):','for name, src in (("dut.sv", rtl), ("main_tb.sv", tb), ("core.sv", a.core.resolve(strict=True))):')
s=s.replace('"dut.sv", "main_tb.sv"]','"core.sv", "dut.sv", "main_tb.sv"]')
s=s.replace('f"-gBRIEF={a.brief}",','f"-gBRIEF={a.brief}", f"-gPRE_CYCLES={a.pre}", f"-gPOST_CYCLES={a.post}",')
s=s.replace('[a.clock, a.baud, a.stat, a.brief]','[a.clock, a.baud, a.stat, a.pre, a.post, a.brief]')
s=s.replace('(a.clock, a.baud, a.stat, a.brief)','(a.clock, a.baud, a.stat, a.pre, a.post, a.brief)')
dest.write_text(s,encoding='utf-8',newline='\n')
tb=root/'competition/deepeye/tests/rtl/transport/main_tb_uart_frame_tx.sv'
record={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','basis':'Scope and accepted TX dependency only; no author frame TX source/tests inspected','files':{str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [dest,tb]},'scope_limit':'Interbyte starts are observable anchors; first start and every subsequent bit plus final release independently timed.'}
(Path(__file__).parent/'ORACLE_FREEZE.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf-8')
print(json.dumps(record))
