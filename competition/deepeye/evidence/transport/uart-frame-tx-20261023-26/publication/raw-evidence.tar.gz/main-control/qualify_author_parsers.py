from pathlib import Path
import importlib.util,json,hashlib,re
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=R/'competition/deepeye'
def sha(b):return hashlib.sha256(b).hexdigest()
def load(path,label):
 s=importlib.util.spec_from_file_location(label,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
for stem,op,attempt,summary in [('uart_rx','uart-rx-20261023-25','attempt-10-final-all','summary.json'),('uart_frame_tx','uart-frame-tx-20261023-26','attempt-final-03','result.json')]:
 runner=P/'tools/transport'/('run_'+stem+'.py');old=runner.read_bytes();original=load(runner,'original_'+stem)
 O=P/'evidence/transport'/op/'main/runner-repair-01';O.mkdir(exist_ok=False);(O/'ORIGINAL_RUNNER.py').write_bytes(old)
 base=P/'evidence/transport'/op/'author'/attempt;doc=json.loads((base/summary).read_text());samples=[]
 if stem=='uart_rx':
  for x in doc['suites']:
   if x['expected_guard'] is None:samples.append((x['suite'],Path(x['commands'][-1]['stdout']).read_bytes()))
 else:
  for name,x in doc['suites'].items():
   if x['kind']=='ordinary':samples.append((name,Path(x['vsim']['stdout']).read_bytes()))
 def accept(m,name,raw):
  if stem=='uart_rx':return m.parse_normal(name,m.SUITES[name],{},raw)
  return m.parse_ordinary(raw.decode(),m.SUITES[name],[])['status']=='pass'
 def mutate(raw,kind):
  lines=raw.decode().splitlines()
  pos=lambda s:next(i for i,x in enumerate(lines) if (x[2:] if x.startswith('# ') else x).startswith(s))
  if kind=='end_first':line=lines.pop(pos('TB_END'));lines.insert(0,line)
  elif kind=='inflated_summary':i=pos('TB_SUMMARY');lines[i]=re.sub(r'checks=(\d+)',lambda m:'checks='+str(int(m[1])+1),lines[i])
  elif kind=='duplicate_end':lines.append(lines[pos('TB_END')])
  elif kind=='fake_end':i=pos('TB_END');lines[i]=lines[i].replace('TB_END','NOT_TB_END')
  elif kind=='duplicate_stat':lines.append(lines[pos('TB_STAT')])
  elif kind=='conflict_stat':line=lines[pos('TB_STAT')];lines.append(re.sub(r'=(\d+)',lambda m:'='+str(int(m[1])+1),line,count=1))
  elif kind=='missing_begin':lines.pop(pos('TB_BEGIN'))
  elif kind=='missing_summary':lines.pop(pos('TB_SUMMARY'))
  elif kind=='begin_trailing':i=pos('TB_BEGIN');lines[i]+=' trailing'
  elif kind=='case_end_first':i=pos('CASE_END');line=lines.pop(i);lines.insert(pos('CASE_BEGIN'),line)
  elif kind=='summary_first':i=pos('TB_SUMMARY');line=lines.pop(i);lines.insert(0,line)
  return ('\n'.join(lines)+'\n').encode()
 target='inflated_summary' if stem=='uart_rx' else 'end_first'
 name,raw=samples[0];red=mutate(raw,target);assert accept(original,name,raw);assert accept(original,name,red),'expected reproduced defect no longer present'
 (O/'original-positive.stdout.bin').write_bytes(raw);(O/'original-accepted-negative.stdout.bin').write_bytes(red)
 text=old.decode()
 if stem=='uart_rx':
  anchor='            if checks < spec["min_checks"]:'
  insert='            case_total = sum(int(CASE_END.fullmatch(row).group(3)) for row in case_end_rows if CASE_END.fullmatch(row))\n            if checks != case_total:\n                problems.append(f"summary check total={checks} case sum={case_total}")\n'
  assert text.count(anchor)==1;text=text.replace(anchor,insert+anchor)
 else:
  anchor='    add_check(checks, "run-marker-malformed", not malformed, repr(malformed[:8]))'
  insert='    marker_rows = [normalize_row(row) for row in text.splitlines() if normalize_row(row).startswith(("TB_", "CASE_"))]\n    marker_order = [row.split()[0] for row in marker_rows]\n    expected_order = ["TB_BEGIN"] + [tag for _ in spec["cases"] for tag in ("CASE_BEGIN", "CASE_END")] + ["TB_SUMMARY", "TB_STAT", "TB_END"]\n    add_check(checks, "run-marker-order", marker_order == expected_order, repr(marker_order))\n'
  assert text.count(anchor)==1;text=text.replace(anchor,insert+anchor)
 runner.write_text(text,encoding='utf-8',newline='\n');fixed=load(runner,'fixed_'+stem);rows=[]
 for name,raw in samples:
  assert accept(fixed,name,raw),(name,'saved original positive');rows.append({'suite':name,'probe':'saved_real_positive','passed':True,'sha256':sha(raw)})
  for kind in ('end_first','inflated_summary','duplicate_end','fake_end','duplicate_stat','conflict_stat','missing_begin','missing_summary','begin_trailing','case_end_first','summary_first'):
   probe=mutate(raw,kind);okay=not accept(fixed,name,probe);rows.append({'suite':name,'probe':kind,'passed':okay,'synthetic':True,'sha256':sha(probe)});assert okay,(stem,name,kind)
 receipt={'original_runner_sha256':sha(old),'fixed_runner_sha256':sha(runner.read_bytes()),'reproduced_original_accepts_invalid':target,'main_owns_runner_after_actual_author_terminal':True,'product_RTL_unchanged':True,'probes':rows,'accepted':True,'claims':'Reclassification of original real raw logs and synthetic mutations; no new vendor run counted.'}
 (O/'RESULT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps({k:v for k,v in receipt.items() if k!='probes'}))
