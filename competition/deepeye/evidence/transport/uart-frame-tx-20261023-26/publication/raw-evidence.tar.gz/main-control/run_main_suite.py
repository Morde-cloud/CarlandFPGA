"""Bounded exact-source frame-transmit suite; no model polling."""
from pathlib import Path
import sys,subprocess,json,hashlib,time
ROOT=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014')
P=ROOT/'competition/deepeye'
RUN=P/'tools/transport/main_verify_uart_frame_tx.py'
RTL=P/'fpga/transport/deepeye_uart_frame_tx.sv'
CORE=P/'fpga/transport/deepeye_uart_tx.sv'
TB=P/'tests/rtl/transport/main_tb_uart_frame_tx.sv'
cases=[('all97',97,11,32,0,0,0,None),('guards1',97,11,32,1,1,0,None),('asymmetric',31,3,2,3,2,0,None),('fast',2,1,32,0,0,0,None),('maxguards',97,11,32,65535,65535,1,None),('maxclock',2147483647,1073741823,32,0,0,1,None),('baud9600',100000000,9600,32,0,0,1,None),('baud1200',100000000,1200,32,0,0,1,None),('baud300',100000000,300,32,0,0,1,None)]
guards=[('clock1',1,1,32,0,0,'CLOCK_HZ'),('clockbig',2147483648,1,32,0,0,'CLOCK_HZ'),('baud0',97,0,32,0,0,'BAUD'),('baud49',97,49,32,0,0,'BAUD'),('preneg',97,11,32,-1,0,'PRE_CYCLES'),('prebig',97,11,32,65536,0,'PRE_CYCLES'),('postneg',97,11,32,0,-1,'POST_CYCLES'),('postbig',97,11,32,0,65536,'POST_CYCLES'),('stat1',97,11,1,0,0,'STAT_W'),('stat33',97,11,33,0,0,'STAT_W'),('priority',1,0,1,-1,-1,'CLOCK_HZ')]
cases += [(n,c,b,s,pre,post,1,g) for n,c,b,s,pre,post,g in guards]
base=P/'evidence/transport/uart-frame-tx-20261023-26/main'/sys.argv[1]
base.mkdir(parents=True,exist_ok=False)
sources={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [RUN,RTL,CORE,TB]}
results=[]
for name,c,b,s,pre,post,brief,guard in cases:
 argv=[sys.executable,'-B','-X','utf8',str(RUN),'--rtl',str(RTL),'--core',str(CORE),'--tb',str(TB),'--out',str(base/name),'--clock',str(c),'--baud',str(b),'--stat',str(s),'--pre',str(pre),'--post',str(post),'--brief',str(brief),'--timeout','240']
 if guard:argv+=['--mode','guard','--guard',guard]
 started=time.time();r=subprocess.run(argv,capture_output=True)
 (base/(name+'.stdout.bin')).write_bytes(r.stdout);(base/(name+'.stderr.bin')).write_bytes(r.stderr)
 receipt={'name':name,'argv':argv,'exit':r.returncode,'elapsed':time.time()-started,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
 (base/(name+'.process.json')).write_text(json.dumps(receipt,indent=2)+'\n')
 results.append(receipt);print(name,r.returncode,flush=True)
 if r.returncode:break
same=all(hashlib.sha256((ROOT/k).read_bytes()).hexdigest()==v for k,v in sources.items())
result={'actual_cases':len(results),'planned_cases':len(cases),'sources':sources,'sources_unchanged':same,'commands':results,'accepted':same and len(results)==len(cases) and all(r['exit']==0 for r in results)}
(base/'SUITE.json').write_text(json.dumps(result,indent=2)+'\n')
raise SystemExit(0 if result['accepted'] else 1)
