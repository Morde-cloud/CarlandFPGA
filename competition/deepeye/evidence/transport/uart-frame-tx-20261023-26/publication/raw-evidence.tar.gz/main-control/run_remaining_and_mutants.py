from pathlib import Path
import sys,json,hashlib,subprocess,time
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=R/'competition/deepeye'
E=P/'evidence/transport/uart-frame-tx-20261023-26/main';O=E/'remaining-mutants-01';O.mkdir(exist_ok=False)
rtl=P/'fpga/transport/deepeye_uart_frame_tx.sv';tb=P/'tests/rtl/transport/main_tb_uart_frame_tx.sv';core=P/'fpga/transport/deepeye_uart_tx.sv';runner=P/'tools/transport/main_verify_uart_frame_tx.py'
original=rtl.read_bytes();text=original.decode('utf-8');results=[]
cases=[('stat1',rtl,['--stat','1','--mode','guard','--guard','STAT_W']),('stat33',rtl,['--stat','33','--mode','guard','--guard','STAT_W']),('priority',rtl,['--clock','1','--baud','0','--stat','1','--pre','-1','--post','-1','--mode','guard','--guard','CLOCK_HZ']),('legal-after-guard-fix',rtl,[])]
changes=[('early_de_release','if (POST_CYCLES == 0) begin','if (POST_CYCLES >= 0) begin',['--post','2']),('repeated_byte',"send_index_q <= send_index_q + 6'd1;","send_index_q <= send_index_q;",[]),('wrong_pre_guard','pre_count_q >= PRE_CYCLES','pre_count_q > PRE_CYCLES',[])]
for name,old,new,args in changes:
 count=text.count(old);assert count==(2 if name=='wrong_pre_guard' else 1),(name,count)
 f=O/(name+'.sv');f.write_text(text.replace(old,new),encoding='utf-8',newline='\n');cases.append((name,f,['--mode','mutant']+args))
for name,dut,args in cases:
 argv=[sys.executable,'-B','-X','utf8',str(runner),'--rtl',str(dut),'--core',str(core),'--tb',str(tb),'--out',str(O/name)]+args
 t=time.time();r=subprocess.run(argv,capture_output=True);(O/(name+'.stdout.bin')).write_bytes(r.stdout);(O/(name+'.stderr.bin')).write_bytes(r.stderr)
 row={'name':name,'argv':argv,'exit':r.returncode,'elapsed':time.time()-t,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()};results.append(row);print(name,r.returncode,flush=True)
 if r.returncode:break
assert rtl.read_bytes()==original
(O/'RESULT.json').write_text(json.dumps({'commands':results,'accepted':len(results)==len(cases) and all(x['exit']==0 for x in results),'main_fixture_repair':'Invalid STAT_W output width now matches safe clamp. Legal widths identical; original failed guard logs preserved. Product RTL unchanged.'},indent=2)+'\n')
raise SystemExit(0 if len(results)==len(cases) and all(x['exit']==0 for x in results) else 1)
