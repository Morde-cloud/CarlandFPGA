from pathlib import Path
import ast,importlib.util,sys,json,hashlib,subprocess,os,time
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014')
P=Path(__file__).parent/'main-preflight-01';P.mkdir(exist_ok=False);(P/'temp').mkdir()
env=dict(os.environ,TEMP=str(P/'temp'),TMP=str(P/'temp'),TMPDIR=str(P/'temp'),PYTHONDONTWRITEBYTECODE='1')
out=[]
for stem,expected in [('uart_rx',(97,5,32,0)),('uart_frame_tx',(97,11,32,0,0,0))]:
 f=R/'competition/deepeye/tools/transport'/('main_verify_'+stem+'.py');raw=f.read_bytes();ast.parse(raw)
 spec=importlib.util.spec_from_file_location(stem,f);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 if stem=='uart_rx':
  begin='MAIN_BEGIN clock=97 baud=5 stat=32 brief=0';stats='MAIN_STATS cycles=100 checks=1400 frames=256 retired=254 overruns=2 framing=1 falses=1 aborted=2'
 else:
  begin='MAIN_BEGIN clock=97 baud=11 stat=32 pre=0 post=0 brief=0';stats='MAIN_STATS cycles=100 checks=1800 admitted=321 sent=320 aborted=1 faults=0 bytes=1000 gap_min=1 gap_max=3'
 lines=[begin,stats,'MAIN_PASS','Errors: 0, Warnings: 0'];ok='\n'.join(lines)+'\n'
 probes=[('valid',ok,0,True),('crlf',ok.replace('\n','\r\n'),0,True),('modelprefix',''.join('# '+x+'\n' for x in lines),0,True),('badexit',ok,1,False),('notpass',ok.replace('MAIN_PASS','NOT_MAIN_PASS_MARKER'),0,False),('duppass',ok+'MAIN_PASS\n',0,False),('dupstats',ok+stats+'\n',0,False),('conflictstats',ok+stats.replace('checks=','checks=0')+'\n',0,False),('dupbegin',ok+begin+'\n',0,False),('missingstats',ok.replace(stats,''),0,False),('badchecks',ok.replace('checks=1400','checks=1401').replace('checks=1800','checks=1801'),0,False),('error',ok+'** Error: test\n',0,False),('warning',ok+'** Warning: test\n',0,False),('fatal',ok+'** Fatal: test\n',0,False),('count',ok.replace('Errors: 0','Errors: 1'),0,False),('earlypass',begin+'\nMAIN_PASS\n'+stats+'\n',0,False)]
 for name,text,code,want in probes:
  got=m.classify(text.encode(),code,expected)['accepted'];out.append({'module':stem,'probe':name,'got':got,'want':want});assert got==want,(stem,name,got)
 (P/(stem+'.runner.py')).write_bytes(raw)
 tb=R/'competition/deepeye/tests/rtl/transport'/('main_tb_'+stem+'.sv');(P/tb.name).write_bytes(tb.read_bytes())
commands=[]
for name,args in [('vlib',['D:/modelsim1/win64/vlib.exe','work']),('vlog',['D:/modelsim1/win64/vlog.exe','-sv','-work','work','main_tb_uart_rx.sv','main_tb_uart_frame_tx.sv'])]:
 t=time.time();r=subprocess.run(args,cwd=P,env=env,capture_output=True,timeout=30)
 (P/(name+'.stdout.bin')).write_bytes(r.stdout);(P/(name+'.stderr.bin')).write_bytes(r.stderr)
 commands.append({'argv':args,'exit':r.returncode,'elapsed':time.time()-t,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()})
 assert r.returncode==0,r.stdout.decode(errors='replace')
(P/'RESULT.json').write_text(json.dumps({'synthetic_classifier_probes':out,'tb_compile_only_no_DUT_execution':commands,'accepted':True},indent=2)+'\n')
print(json.dumps({'synthetic_probes':len(out),'tb_syntax_compile':True,'not_RTL_product_test':True}))
