from pathlib import Path
import json,hashlib,datetime
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014')
specs=[('uart-rx-20261023-25','main_tb_uart_rx.sv','main_verify_uart_rx.py'),('uart-frame-tx-20261023-26','main_tb_uart_frame_tx.sv','main_verify_uart_frame_tx.py')]
for op,tbname,runname in specs:
 P=Path('D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence')/op
 save=P/'oracle-v1';save.mkdir(exist_ok=False)
 tb=R/'competition/deepeye/tests/rtl/transport'/tbname
 runner=R/'competition/deepeye/tools/transport'/runname
 for f in (tb,runner):(save/f.name).write_bytes(f.read_bytes())
 s=tb.read_text(encoding='utf-8')
 if 'uart-rx-' in op:
  s=s.replace('rd=(ready_mode==1)', 'if(ready_mode==4 && active && cycles+1-start_at==boundary(19))cc=1;\n+  if(ready_mode==5 && active && cycles+1-start_at==boundary(19))rr=1;\n+  rd=(ready_mode==1)'.replace('\n+','\n'))
  s=s.replace('// Pending output plus active reception: abort may remove two items.','serial(8\'h44,1,0,0,0);serial(8\'h92,1,4,0,0);idle(8,0);\n+  serial(8\'h44,1,0,0,0);serial(8\'h92,1,5,0,0);idle(8,1);\n+  // Pending output plus active reception: abort may remove two items.'.replace('\n+','\n'))
 else:
  s=s.replace('for(j=1;j<=2;j++)for(n=0;n<10;n++)begin','for(stage=0;stage<2;stage++)for(j=1;j<=2;j++)for(n=0;n<10;n++)begin')
  s=s.replace('load_frame(2,165,0);while(state!=4)idle(1);','load_frame(2,165,0);while(state!=4 || index!=stage)idle(1);')
  s=s.replace('// Abort exactly when final completion would release DE; abort wins.','// Abort sealed before DE, pre-guard/first admission, partial and fault.\n+  load_frame(2,41,0);tick(0,1,0,0,0,0,0);idle(2);\n+  load_frame(2,41,0);idle(1);tick(0,1,0,0,0,0,0);idle(2);\n+  tick(0,0,1,3,0,0,0);tick(0,0,0,0,1,99,0);tick(1,0,0,0,0,0,0);idle(2);\n+  tick(0,0,1,0,0,0,0);tick(1,0,0,0,0,0,0);idle(2);\n+  // Abort exactly when final completion would release DE; abort wins.'.replace('\n+','\n'))
 tb.write_text(s,encoding='utf-8',newline='\n')
 s=runner.read_text(encoding='utf-8')
 old='result.update(accepted=len(own) == 1 and not others and not any(x == "MAIN_PASS" for x in lines), diagnostic=expected, actual_returncode=code)'
 new='tallies = [x for x in lines if x.startswith("Errors:")]\n            zero_time = any(re.search(r"Time: 0 (?:ps|ns)\\s+Scope: .*\\.dut\\.", x) for x in lines)\n            result.update(accepted=code == 0 and len(own) == 1 and not others and tallies == ["Errors: 1, Warnings: 0"] and zero_time and not any(x.startswith("MAIN_PASS") for x in lines), diagnostic=expected, actual_returncode=code)'
 assert old in s;s=s.replace(old,new);runner.write_text(s,encoding='utf-8',newline='\n')
 receipt={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'basis':'Additional main race coverage and guard classifier; author RTL/tests still not inspected','files':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [tb,runner]}}
 (P/'ORACLE_FREEZE_V2.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))
