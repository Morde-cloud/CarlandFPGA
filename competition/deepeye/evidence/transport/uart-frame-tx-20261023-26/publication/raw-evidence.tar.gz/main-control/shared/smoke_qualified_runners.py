from pathlib import Path
import subprocess,sys,json,hashlib,time
R=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014');P=R/'competition/deepeye'
cases=[('uart-rx-20261023-25','run_uart_rx.py',['--attempt','main-parser-qualified-11','--suite','all_160_10']),('uart-frame-tx-20261023-26','run_uart_frame_tx.py',['--attempt-id','main-parser-qualified-04','--suite','faults','--tool-dir','D:/modelsim1/win64'])]
for op,name,args in cases:
 O=P/'evidence/transport'/op/'main/qualified-cli-01';O.mkdir(exist_ok=False)
 argv=[sys.executable,'-B','-X','utf8',str(P/'tools/transport'/name)]+args;t=time.time();r=subprocess.run(argv,cwd=R,capture_output=True,timeout=180)
 (O/'stdout.bin').write_bytes(r.stdout);(O/'stderr.bin').write_bytes(r.stderr)
 receipt={'actual_executor':'main01a13b55-095b-7461-8dd5-5476a130bd82','author_job_previously_terminal':True,'new_author_subdir_is_main_CLI_invocation_not_new_child_claim':True,'argv':argv,'cwd':str(R),'exit':r.returncode,'elapsed':time.time()-t,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()}
 (O/'RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(op,r.returncode);assert r.returncode==0,r.stderr.decode(errors='replace')
