# B-UART-LINK-FIXTURE-20261024-34-v1 RESULT

Status: `PASS` for the bounded author-owned ModelSim fixture. Independent main
review and acceptance remain pending. This is not an ABI, control grant,
physical-clock tolerance, board, system, or product result.

## Binding

- Task: `DEEPEYE-IMPLEMENTATION-20261014/v1`
- Operation: `B-DEEPEYE-UART-LINK-FIXTURE-20261024-34`
- Main thread: `01a13b55-095b-7461-8dd5-5476a130bd82`
- Main turn: `01a16933-edc1-7022-8e5f-25b4561a4ea5`
- Contract: `DEEPEYE-HUMAN-LOCK-20261014/revision1`, H01-H15, commit
  `f5989cd5defce561f9ba98e6b18fc2682945f0a2`
- Canonical requirements SHA256:
  `c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804`
- Scope SHA256:
  `4d4c14ce5d83b67e7b1ca0ad86091a11529bff01d483a851988c744135fc2a89`
- Exact source: `bbfb11439b35e0866a6d2486f3857b92ed6cf529`
- Published PR30 head / worktree HEAD:
  `04e3a46eb1169afca0c133815a9b9f3da15d89f5`
- Frozen design: `1011259415a0916054eb580687612580bc1e5f09`

## Actual execution

Command:

```text
python -X utf8 competition/deepeye/tools/transport/run_uart_link_fixture.py
```

Process exit was `0`. The final immutable attempt is
`author/attempt-20261023T183422.828165Z-p36424/`.

- Result: 52 cases, 63 records, 5 simulations, 9/9 accepted command exits,
  3/3 rejected negative controls, 0 failure reasons.
- ModelSim: `Model Technology ModelSim SE-64 vsim 10.7 Simulator 2017.12`.
- All five simulations used the fixed public-port fixture and produced zero
  errors and zero warnings.
- All prior failed attempts remain in the same `author/` directory.

## Suite receipts

| Suite | Cases | Checks | Event rows | Vector SHA256 | Event SHA256 |
| --- | ---: | ---: | ---: | --- | --- |
| 0 `default` | 2 | 34 | 388 | `2914b3656ec787fdf4ed04a5c44e16ddeffcf96d701bb341dc0db229107ae2ce` | `0339ddf9a393b338e4e520ea37e5a8da8a5b8b4a72284ac4a0088b5577b97c3e` |
| 1 `primary_lengths` | 34 | 199 | 17370 | `7d8e7f629c1d5a6532e7efafeb9f5cdb15f73685144a91e7363881e5ab0fbb57` | `2c15c979dabf192950124e7a0482ac771b0727a87186efced55f95b11c168bfe` |
| 2 `rx_early_9900` | 4 | 44 | 1476 | `95252e94f17a5aefa2bab7f39e72dd237e553a326c942e4206c339c77d03199e` | `caec82443abc1caefe894837fb9b084ffed567829e80ef13a9f7ce42ec839f3b` |
| 3 `rx_late_10100` | 4 | 44 | 1476 | `dea3347da6890b93ff846d5ba98021132f85892f81aef4451c2a7b16dc7bb54d` | `fbed880e84fb208fe04d68feb4a88923f64fe4a321ad30ffadac83a31feb7b4a` |
| 4 `directed_faults` | 8 | 120 | 7834 | `6a6a7de4f79b3f271094ed2d08c58f065d85d946133eb418b4ac9ab9a011fd22` | `0e777650d656a8b489da6c930776552fe7f7208934a52cae2547cfdc077a8d24` |

The primary suite covers lengths 0..32 and all 256 byte values. Every case has
an exact pinned check count; every suite has an exact pinned suite-level count.
The vector manifest, vector text, event logs, raw stdout/stderr, command records,
and source binding are under the final attempt directory.

## Command receipts

Base: `author/attempt-20261023T183422.828165Z-p36424/raw/`

| Index | Receipt directory | Label | Exit |
| ---: | --- | --- | ---: |
| 000 | `000_modelsim_vsim_version` | `modelsim_vsim_version` | 0 |
| 001 | `001_modelsim_vlog_version` | `modelsim_vlog_version` | 0 |
| 002 | `002_vlib_work` | `vlib_work` | 0 |
| 003 | `003_vlog_compile_fixture` | `vlog_compile_fixture` | 0 |
| 004 | `004_vsim_suite_0_default` | `vsim_suite_0_default` | 0 |
| 005 | `005_vsim_suite_1_primary_lengths` | `vsim_suite_1_primary_lengths` | 0 |
| 006 | `006_vsim_suite_2_rx_early_9900` | `vsim_suite_2_rx_early_9900` | 0 |
| 007 | `007_vsim_suite_3_rx_late_10100` | `vsim_suite_3_rx_late_10100` | 0 |
| 008 | `008_vsim_suite_4_directed_faults` | `vsim_suite_4_directed_faults` | 0 |

Each receipt contains `command.json`, `stdout.raw`, and `stderr.raw`; every
stderr file is empty and every recorded timeout is false.

## Negative controls

- `wrong_expected_wire`: rejected by the real TX wire validator.
- `wrong_output_descriptor`: rejected by the real descriptor validator.
- `missing_case_end`: rejected by the real standard-output parser.

## Frozen RTL pins

| Module | SHA256 |
| --- | --- |
| `deepeye_wire_uart_tx.sv` | `4998acb76fed7e53405816c91203bc93df622f05b621da342e1cc8178f51133d` |
| `deepeye_uart_wire_rx.sv` | `b6abab4e1be54ee61bd45e4d7adfcfea8db39f7574d3ce2ae7b7030ff74ade2c` |
| `deepeye_wire_serializer.sv` | `efc6082f6f5dff215b100f718b12d87d4c6467db7b968a24f846802dc6a19885` |
| `deepeye_wire_parser.sv` | `7806c5d08785b96eae3708d9fd6d6002ef82faa4416a1f7244da73bece552649` |
| `deepeye_uart_tx.sv` | `5076286e4dd1598aeb2c78281bec83020c85d0711dcee9b985088ac707353c47` |
| `deepeye_uart_rx.sv` | `935f5d02008535fd5da75b7dc80696d14b03bd54d85f8b52fbf12c1e0504f08f` |
| `deepeye_uart_frame_tx.sv` | `83261e4c5a317500e224f5cd0e9ce538f067be24d3957dd98c7116425e706be3` |
| `deepeye_crc16_byte.sv` | `8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f` |

The final runner re-read these from exact Git commit
`bbfb11439b35e0866a6d2486f3857b92ed6cf529`; the worktree copies are byte-equal
and were not edited.

## Limits

`All29`, `B04`, `R03`, full product, synthesis/implementation, system behavior,
physical board, physical timing, electrical UART, oscillator/baud tolerance, and
ABI/control grants are `not_run` or `not_claimed`. No commit, push, peer/group
message, Vivado run, installer, service, credential access, or board operation
was performed. Only the four paths authorized by the scope were created or
changed. Full B04 still requires C's independent endpoint/scheduling work and A's
real I/O.
