#!/usr/bin/env python3
"""Replay-only evidence for the bounded UART link runner parser repair."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import subprocess
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path


sys.dont_write_bytecode = True

EVIDENCE = Path(__file__).resolve().parent
PROJECT = EVIDENCE.parents[4]
WORKTREE = EVIDENCE.parents[6]
REPO = WORKTREE.parents[2]
DEPLOYMENT = REPO / ".local/deployment/node-b/evidence/uart-link-fixture-20261024-34"
REPAIR_SCOPE = DEPLOYMENT / "RUNNER_REPAIR1_SCOPE.md"
ORIGINAL_SCOPE = DEPLOYMENT / "SCOPE.md"
WAIT_RESULT = DEPLOYMENT / "wait.stdout.json"
DISPATCH = DEPLOYMENT / "RUNNER_REPAIR1_DISPATCH.json"
RUNNER = PROJECT / "tools/transport/run_uart_link_fixture.py"
ORIGINAL_RUNNER = EVIDENCE / "original/run_uart_link_fixture.py"
REPAIRED_RUNNER = EVIDENCE / "repaired/run_uart_link_fixture.py"
ATTEMPT = PROJECT / (
    "evidence/transport/uart-link-fixture-20261024-34/author/"
    "attempt-20261023T183422.828165Z-p36424"
)
MAIN = PROJECT / (
    "evidence/transport/uart-link-fixture-20261024-34/main/"
    "runner-qualification-01"
)
TB = PROJECT / "tests/rtl/transport/tb_uart_link_fixture.sv"
RTL_DIR = PROJECT / "fpga/transport"

EXPECTED_REPAIR_SCOPE_SHA = (
    "8ec2059839998066A4CB7E06DBBE00434F08D0A24EC1317FF430882A2030D31A"
).lower()
EXPECTED_ORIGINAL_RUNNER_SHA = (
    "0adb34b24c09b53f84b4b99283387b561a37815e87c8c0165094ac194f8a7d2c"
)
EXPECTED_TB_SHA = (
    "8bcf1e8f8d2716f0d1cc092318201191df345f0c436f181fa684b20a25c0e3ac"
)
CONTRACT_COMMIT = "f5989cd5defce561f9ba98e6b18fc2682945f0a2"
CONTRACT_JSON = "docs/competition/deepeye-2026/immutable_scope.json"
CONTRACT_MD = "docs/competition/deepeye-2026/immutable_scope.md"
EXPECTED_REQUIREMENTS_SHA = (
    "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
)
SOURCE_COMMIT = "bbfb11439b35e0866a6d2486f3857b92ed6cf529"
FROZEN_DESIGN = "1011259415a0916054eb580687612580bc1e5f09"
MAIN_THREAD = "01a13b55-095b-7461-8dd5-5476a130bd82"
MAIN_TURN = "01a16933-edc1-7022-8e5f-25b4561a4ea5"
CHILD_THREAD = "01a169f8-916c-75a0-bcb7-ad73f0fb4056"
ORIGINAL_CHILD_TURN = "01a169f8-92b4-77f1-b3dd-8e2372981c6d"
REPAIR_CHILD_TURN = "01a16a0f-3f32-7792-92cb-bd81da63061b"
JOB_ID = "child-77e0f374e4aa498b82a7f680e7c078ec"
TASK_ID = "DEEPEYE-IMPLEMENTATION-20261014"
TASK_VERSION = 1
WORK_ID = "B-UART-LINK-RUNNER-REPAIR-20261024-34-r1"
FIXED_CLASSES = ("terminal_trailer", "case_trailer", "marker_prefix_extra")


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8"))


def write_new(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(data)


def write_json_new(path: Path, value) -> None:
    encoded = json.dumps(value, indent=2, sort_keys=True) + "\n"
    write_new(path, encoded.encode("utf-8"))


def require(condition: bool, message: str, failures: list[str]) -> bool:
    if not condition:
        failures.append(message)
    return condition


def load_module(path: Path, name: str):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot create module spec for {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def run_capture(argv: list[str], cwd: Path) -> dict:
    completed = subprocess.run(
        argv,
        cwd=str(cwd),
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    return {
        "argv": argv,
        "cwd": str(cwd),
        "exit_code": completed.returncode,
        "stdout": completed.stdout.decode("utf-8", "replace"),
        "stderr": completed.stderr.decode("utf-8", "replace"),
    }


def git_show(path: str, commit: str = SOURCE_COMMIT) -> bytes:
    completed = subprocess.run(
        ["git", "-C", str(WORKTREE), "show", f"{commit}:{path}"],
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    if completed.returncode != 0:
        stderr = completed.stderr.decode("utf-8", "replace").strip()
        raise RuntimeError(f"git show failed for {commit}:{path}: {stderr}")
    return completed.stdout


def parse_outcome(module, text: str, suite) -> dict:
    try:
        info = module.parse_standard_output(text, suite, ATTEMPT, {})
    except module.RunnerFailure as exc:
        return {
            "accepted": False,
            "error": f"{type(exc).__name__}: {exc}",
            "info": None,
        }
    return {"accepted": True, "error": None, "info": info}


def event_outcome(module, path: Path, suite) -> dict:
    try:
        events, rows = module.load_event_log(path, suite)
        info = module.validate_events(events, suite)
    except module.RunnerFailure as exc:
        return {
            "accepted": False,
            "error": f"{type(exc).__name__}: {exc}",
            "info": None,
        }
    return {"accepted": True, "error": None, "rows": rows, "info": info}


def immutable_snapshot(module, fixture_paths: list[Path]) -> dict:
    return {
        "rtl": {name: sha256_file(RTL_DIR / name) for name in module.RTL_ORDER},
        "tb": sha256_file(TB),
        "runner": sha256_file(RUNNER),
        "original_runner": sha256_file(ORIGINAL_RUNNER),
        "repaired_runner_copy": sha256_file(REPAIRED_RUNNER),
        "main_result": sha256_file(MAIN / "RESULT.json"),
        "attempt_summary": sha256_file(ATTEMPT / "summary.json"),
        "repair_scope": sha256_file(REPAIR_SCOPE),
        "original_scope": sha256_file(ORIGINAL_SCOPE),
        "main_fixtures": {
            str(path.relative_to(MAIN)): sha256_file(path) for path in fixture_paths
        },
    }


def provenance_phase(run_dir: Path, failures: list[str]) -> dict:
    scope_bytes = REPAIR_SCOPE.read_bytes()
    scope_sha = sha256_bytes(scope_bytes)
    require(
        scope_sha == EXPECTED_REPAIR_SCOPE_SHA,
        f"repair scope hash {scope_sha} != {EXPECTED_REPAIR_SCOPE_SHA}",
        failures,
    )
    write_new(run_dir / "scope/RUNNER_REPAIR1_SCOPE.md", scope_bytes)

    original_scope_sha = sha256_file(ORIGINAL_SCOPE)
    require(
        original_scope_sha
        == "4d4c14ce5d83b67e7b1ca0ad86091a11529bff01d483a851988c744135fc2a89",
        f"original scope hash mismatch: {original_scope_sha}",
        failures,
    )

    wait_items = read_json(WAIT_RESULT)
    original_job = next(
        (
            item
            for item in wait_items
            if item.get("job_id") == "child-55a4e89ae2ed412f928cce1fac85e114"
        ),
        None,
    )
    require(original_job is not None, "original job absent from wait.stdout.json", failures)
    if original_job is None:
        original_job = {}
    require(original_job.get("status") == "completed", "original job is not completed", failures)
    require(original_job.get("terminal") is True, "original job is not terminal", failures)
    require(original_job.get("stale") is False, "original job is stale", failures)
    result = original_job.get("result") or {}
    require(result.get("thread_id") == CHILD_THREAD, "original job thread mismatch", failures)
    require(
        (result.get("turn") or {}).get("id") == ORIGINAL_CHILD_TURN,
        "original job turn mismatch",
        failures,
    )

    dispatch = read_json(DISPATCH)
    require(dispatch.get("job_id") == JOB_ID, "repair job id mismatch", failures)
    require(dispatch.get("work_id") == WORK_ID, "repair work id mismatch", failures)
    require(dispatch.get("task_id") == TASK_ID, "repair task id mismatch", failures)
    require(dispatch.get("task_version") == TASK_VERSION, "repair task version mismatch", failures)

    value = {
        "main_thread": MAIN_THREAD,
        "main_turn": MAIN_TURN,
        "main_turn_basis": (
            "recorded original main dispatch; repair scope supplies no separate main turn"
        ),
        "child_thread": CHILD_THREAD,
        "original_child_turn": ORIGINAL_CHILD_TURN,
        "repair_child_turn": REPAIR_CHILD_TURN,
        "job_id": JOB_ID,
        "work_id": WORK_ID,
        "task_id": TASK_ID,
        "task_version": TASK_VERSION,
        "reply_node": "Astra-B",
        "original_job": original_job,
        "dispatch_snapshot": dispatch,
        "repair_scope_sha256": scope_sha,
        "original_scope_sha256": original_scope_sha,
        "wait_result_sha256": sha256_file(WAIT_RESULT),
        "dispatch_sha256": sha256_file(DISPATCH),
    }
    write_json_new(run_dir / "provenance.json", value)
    return value


def contract_phase(module, run_dir: Path, failures: list[str]) -> dict:
    contract_bytes = git_show(CONTRACT_JSON, CONTRACT_COMMIT)
    contract_md_bytes = git_show(CONTRACT_MD, CONTRACT_COMMIT)
    write_new(run_dir / "contract/immutable_scope.json", contract_bytes)
    write_new(run_dir / "contract/immutable_scope.md", contract_md_bytes)
    contract = json.loads(contract_bytes)
    requirements = contract["requirements"]
    ids = [item["id"] for item in requirements]
    canonical = module.canonical_requirements_sha(contract)
    expected_ids = [f"H{index:02d}" for index in range(1, 16)]
    require(
        canonical == EXPECTED_REQUIREMENTS_SHA,
        "canonical requirements hash mismatch",
        failures,
    )
    require(contract.get("revision") == 1, "contract revision is not 1", failures)
    require(
        contract.get("contract_id") == "DEEPEYE-HUMAN-LOCK-20261014",
        "contract id mismatch",
        failures,
    )
    require(ids == expected_ids, f"contract ids mismatch: {ids}", failures)
    require(
        contract.get("requirements_sha256") == EXPECTED_REQUIREMENTS_SHA,
        "embedded requirements hash mismatch",
        failures,
    )
    value = {
        "contract_id": contract.get("contract_id"),
        "revision": contract.get("revision"),
        "commit": CONTRACT_COMMIT,
        "requirements_sha256": canonical,
        "expected_requirements_sha256": EXPECTED_REQUIREMENTS_SHA,
        "json_sha256": sha256_bytes(contract_bytes),
        "md_sha256": sha256_bytes(contract_md_bytes),
        "ids": ids,
        "full_requirements_read": requirements,
        "all_h01_h15_read": ids == expected_ids,
    }
    write_json_new(run_dir / "contract_check.json", value)
    return value


def source_phase(
    module, run_dir: Path, fixture_paths: list[Path], failures: list[str]
) -> dict:
    runner_sha = sha256_file(RUNNER)
    original_sha = sha256_file(ORIGINAL_RUNNER)
    repaired_copy_sha = sha256_file(REPAIRED_RUNNER)
    require(
        original_sha == EXPECTED_ORIGINAL_RUNNER_SHA,
        "original runner hash mismatch",
        failures,
    )
    require(
        repaired_copy_sha == runner_sha,
        "repaired runner copy differs from owned runner",
        failures,
    )

    source_commit_check = run_capture(
        [
            "git", "-C", str(WORKTREE), "rev-parse", "--verify",
            f"{SOURCE_COMMIT}^{{commit}}",
        ],
        WORKTREE,
    )
    frozen_check = run_capture(
        [
            "git", "-C", str(WORKTREE), "rev-parse", "--verify",
            f"{FROZEN_DESIGN}^{{commit}}",
        ],
        WORKTREE,
    )
    published_check = run_capture(
        ["git", "-C", str(WORKTREE), "rev-parse", "HEAD"], WORKTREE
    )
    require(source_commit_check["exit_code"] == 0, "exact source commit is unavailable", failures)
    require(frozen_check["exit_code"] == 0, "frozen design commit is unavailable", failures)
    require(
        published_check["stdout"].strip() == module.PUBLISHED_HEAD,
        "worktree HEAD differs from published head",
        failures,
    )

    rtl = []
    source_paths = [
        f"competition/deepeye/fpga/transport/{name}" for name in module.RTL_ORDER
    ]
    for name in module.RTL_ORDER:
        work_bytes = (RTL_DIR / name).read_bytes()
        source_bytes = git_show(f"competition/deepeye/fpga/transport/{name}")
        attempt_bytes = (ATTEMPT / "inputs/rtl" / name).read_bytes()
        hashes = {
            "worktree": sha256_bytes(work_bytes),
            "source_commit": sha256_bytes(source_bytes),
            "historical_attempt": sha256_bytes(attempt_bytes),
            "runner_pin": module.RTL_HASHES[name],
        }
        require(len(set(hashes.values())) == 1, f"RTL immutable hash mismatch: {name}", failures)
        rtl.append({"name": name, "size": len(work_bytes), "hashes": hashes})

    diff_check = run_capture(
        [
            "git", "-C", str(WORKTREE), "diff", "--exit-code",
            SOURCE_COMMIT, "--", *source_paths,
        ],
        WORKTREE,
    )
    require(
        diff_check["exit_code"] == 0,
        "worktree RTL differs from exact source commit",
        failures,
    )

    tb_work = sha256_file(TB)
    tb_attempt = sha256_file(ATTEMPT / "inputs/owned/tb_uart_link_fixture.sv")
    require(tb_work == EXPECTED_TB_SHA, "TB worktree hash mismatch", failures)
    require(tb_attempt == EXPECTED_TB_SHA, "TB historical hash mismatch", failures)

    value = {
        "source_commit": SOURCE_COMMIT,
        "source_commit_check": source_commit_check,
        "frozen_design": FROZEN_DESIGN,
        "frozen_design_check": frozen_check,
        "published_head_check": published_check,
        "git_diff_exit_code": diff_check["exit_code"],
        "git_diff_stdout": diff_check["stdout"],
        "git_diff_stderr": diff_check["stderr"],
        "original_runner_sha256": original_sha,
        "repaired_runner_sha256": runner_sha,
        "repaired_runner_copy_sha256": repaired_copy_sha,
        "rtl": rtl,
        "rtl_sha256": {
            item["name"]: item["hashes"]["worktree"] for item in rtl
        },
        "tb_sha256": tb_work,
        "tb_historical_sha256": tb_attempt,
        "fixture_hashes": {
            str(path.relative_to(MAIN)): sha256_file(path) for path in fixture_paths
        },
    }
    write_json_new(run_dir / "source_integrity.json", value)
    return value


def positive_phase(
    module, original_module, run_dir: Path, failures: list[str]
) -> dict:
    summary_path = ATTEMPT / "summary.json"
    summary = read_json(summary_path)
    require(summary.get("status") == "PASS", "historical author summary is not PASS", failures)
    binding = summary.get("source_binding", {})
    require(
        binding.get("requirements_sha256") == EXPECTED_REQUIREMENTS_SHA,
        "historical requirements binding mismatch",
        failures,
    )
    require(
        binding.get("exact_source_commit") == SOURCE_COMMIT,
        "historical exact source binding mismatch",
        failures,
    )
    require(
        binding.get("frozen_design") == FROZEN_DESIGN,
        "historical frozen design binding mismatch",
        failures,
    )
    require(
        binding.get("contract_commit") == CONTRACT_COMMIT,
        "historical contract commit binding mismatch",
        failures,
    )
    require(
        binding.get("contract_ids") == [f"H{index:02d}" for index in range(1, 16)],
        "historical contract id binding mismatch",
        failures,
    )
    require(
        binding.get("main_thread") == MAIN_THREAD,
        "historical main thread binding mismatch",
        failures,
    )
    require(
        binding.get("main_turn") == MAIN_TURN,
        "historical main turn binding mismatch",
        failures,
    )
    require(
        binding.get("scope_sha256") == sha256_file(ORIGINAL_SCOPE),
        "historical scope binding mismatch",
        failures,
    )
    require(
        binding.get("rtl_hashes") == module.RTL_HASHES,
        "historical RTL binding mismatch",
        failures,
    )
    require(
        binding.get("rtl_order") == list(module.RTL_ORDER),
        "historical RTL order binding mismatch",
        failures,
    )
    require(
        summary.get("totals", {}).get("commands") == 9,
        "historical command count is not 9",
        failures,
    )
    require(
        summary.get("totals", {}).get("simulations") == 5,
        "historical simulation count is not 5",
        failures,
    )

    command_receipts = []
    raw_streams = 0
    for command in summary.get("commands", []):
        stdout_path = ATTEMPT / command["raw_stdout"]
        stderr_path = ATTEMPT / command["raw_stderr"]
        stdout_bytes = stdout_path.read_bytes()
        stderr_bytes = stderr_path.read_bytes()
        require(
            sha256_bytes(stdout_bytes) == command["stdout_sha256"],
            f"historical stdout hash mismatch: {command['label']}",
            failures,
        )
        require(
            sha256_bytes(stderr_bytes) == command["stderr_sha256"],
            f"historical stderr hash mismatch: {command['label']}",
            failures,
        )
        require(
            len(stdout_bytes) == command["stdout_size"],
            f"historical stdout size mismatch: {command['label']}",
            failures,
        )
        require(
            len(stderr_bytes) == command["stderr_size"],
            f"historical stderr size mismatch: {command['label']}",
            failures,
        )
        require(
            command["returncode"] == 0 and command["accepted_exit"],
            f"historical command failed: {command['label']}",
            failures,
        )
        raw_streams += 2
        command_receipts.append({
            "index": command["index"],
            "label": command["label"],
            "kind": command["kind"],
            "argv": command["argv"],
            "cwd": command["cwd"],
            "returncode": command["returncode"],
            "accepted_exit": command["accepted_exit"],
            "timed_out": command["timed_out"],
            "started_utc": command["started_utc"],
            "duration_s": command["duration_s"],
            "stdout_path": command["raw_stdout"],
            "stdout_sha256": sha256_bytes(stdout_bytes),
            "stderr_path": command["raw_stderr"],
            "stderr_sha256": sha256_bytes(stderr_bytes),
        })
    require(raw_streams == 18, f"historical raw stream count {raw_streams} != 18", failures)

    suites = []
    for suite in module.SUITES:
        suite_summary = next(
            (item for item in summary["suites"] if item["suite_id"] == suite.suite_id),
            None,
        )
        require(
            suite_summary is not None,
            f"historical suite summary absent: {suite.suite_id}",
            failures,
        )
        if suite_summary is None:
            continue
        command = next(
            (
                item
                for item in summary["commands"]
                if item["index"] == suite_summary["command_index"]
            ),
            None,
        )
        require(
            command is not None,
            f"historical simulation command absent: {suite.suite_id}",
            failures,
        )
        if command is None:
            continue
        require(
            command["label"] == f"vsim_suite_{suite.suite_id}_{suite.name}",
            f"historical simulation label mismatch: {suite.suite_id}",
            failures,
        )

        stdout_path = ATTEMPT / command["raw_stdout"]
        stderr_path = ATTEMPT / command["raw_stderr"]
        stdout_bytes = stdout_path.read_bytes()
        stderr_bytes = stderr_path.read_bytes()
        require(
            sha256_bytes(stdout_bytes) == command["stdout_sha256"],
            f"suite stdout hash mismatch: {suite.suite_id}",
            failures,
        )
        require(not stderr_bytes.strip(), f"suite stderr not empty: {suite.suite_id}", failures)

        event_path = ATTEMPT / suite_summary["event_log"]
        event_bytes = event_path.read_bytes()
        require(
            sha256_bytes(event_bytes) == suite_summary["event_sha256"],
            f"event log hash mismatch: {suite.suite_id}",
            failures,
        )
        vector_item = next(
            (item for item in summary["vectors"] if item["suite_id"] == suite.suite_id),
            None,
        )
        require(vector_item is not None, f"vector summary absent: {suite.suite_id}", failures)
        if vector_item is None:
            continue
        vector_path = ATTEMPT / vector_item["text_path"]
        vector_bytes = vector_path.read_bytes()
        require(
            sha256_bytes(vector_bytes) == vector_item["text_sha256"],
            f"vector hash mismatch: {suite.suite_id}",
            failures,
        )
        require(
            len(vector_bytes) == vector_item["text_size"],
            f"vector size mismatch: {suite.suite_id}",
            failures,
        )

        text = stdout_bytes.decode("utf-8")
        original_outcome = parse_outcome(
            original_module, text, original_module.SUITES[suite.suite_id]
        )
        repaired_outcome = parse_outcome(module, text, suite)
        original_events = event_outcome(
            original_module, event_path, original_module.SUITES[suite.suite_id]
        )
        repaired_events = event_outcome(module, event_path, suite)
        require(
            original_outcome["accepted"],
            f"original parser rejected real positive: {suite.suite_id}",
            failures,
        )
        require(
            repaired_outcome["accepted"],
            f"repaired parser rejected real positive: {suite.suite_id}",
            failures,
        )
        require(
            original_events["accepted"],
            f"original event validator rejected real positive: {suite.suite_id}",
            failures,
        )
        require(
            repaired_events["accepted"],
            f"repaired event validator rejected real positive: {suite.suite_id}",
            failures,
        )

        parse_info = repaired_outcome["info"] or {}
        event_info = repaired_events["info"] or {}
        require(
            parse_info.get("cases") == suite_summary["cases"],
            f"case count mismatch: {suite.suite_id}",
            failures,
        )
        require(
            parse_info.get("case_checks") == suite_summary["case_checks"],
            f"case check count mismatch: {suite.suite_id}",
            failures,
        )
        require(
            parse_info.get("total_checks") == suite_summary["total_checks"],
            f"total check count mismatch: {suite.suite_id}",
            failures,
        )
        require(
            repaired_events.get("rows") == suite_summary["event_rows"],
            f"event row count mismatch: {suite.suite_id}",
            failures,
        )
        for key in (
            "de_intervals",
            "tx_pin_events",
            "output_handshakes",
            "fault_mux_enables",
            "rx_cancel_asserts",
            "tx_cancel_asserts",
            "line_errors",
            "parser_errors",
        ):
            require(
                event_info.get(key) == suite_summary.get(key),
                f"event metric mismatch {key}: {suite.suite_id}",
                failures,
            )

        suites.append({
            "suite_id": suite.suite_id,
            "suite_name": suite.name,
            "historical_command_index": command["index"],
            "historical_exit_code": command["returncode"],
            "stdout": {
                "path": str(stdout_path.relative_to(ATTEMPT)),
                "sha256": sha256_bytes(stdout_bytes),
                "size": len(stdout_bytes),
            },
            "stderr": {
                "path": str(stderr_path.relative_to(ATTEMPT)),
                "sha256": sha256_bytes(stderr_bytes),
                "size": len(stderr_bytes),
            },
            "event_log": {
                "path": str(event_path.relative_to(ATTEMPT)),
                "sha256": sha256_bytes(event_bytes),
                "rows": suite_summary["event_rows"],
            },
            "vector": {
                "path": str(vector_path.relative_to(ATTEMPT)),
                "sha256": sha256_bytes(vector_bytes),
                "size": len(vector_bytes),
            },
            "original_parser": original_outcome,
            "repaired_parser": repaired_outcome,
            "original_events": original_events,
            "repaired_events": repaired_events,
            "summary_counts": {
                "cases": suite_summary["cases"],
                "case_checks": suite_summary["case_checks"],
                "total_checks": suite_summary["total_checks"],
                "event_rows": suite_summary["event_rows"],
            },
        })

    accepted = sum(1 for item in suites if item["repaired_parser"]["accepted"])
    require(accepted == 5, f"repaired positive acceptance {accepted} != 5", failures)
    value = {
        "historical_attempt": str(ATTEMPT),
        "historical_summary_sha256": sha256_file(summary_path),
        "historical_status": summary.get("status"),
        "historical_vendor_tool": "ModelSim SE-64 10.7",
        "source_binding": binding,
        "new_vendor_execution": False,
        "raw_streams_verified": raw_streams,
        "historical_commands": command_receipts,
        "positive_suites_expected": 5,
        "positive_suites_accepted_repaired": accepted,
        "suites": suites,
    }
    write_json_new(run_dir / "positive_stream_replay.json", value)
    return value


def negative_phase(
    module, original_module, run_dir: Path, failures: list[str]
) -> dict:
    result_path = MAIN / "RESULT.json"
    main_result = read_json(result_path)
    require(
        main_result.get("runner_sha256") == EXPECTED_ORIGINAL_RUNNER_SHA,
        "main result runner hash mismatch",
        failures,
    )
    require(
        main_result.get("raw_streams_verified") == 18,
        "main result raw stream count mismatch",
        failures,
    )
    require(
        main_result.get("positive_suites") == 5,
        "main result positive suite count mismatch",
        failures,
    )
    probes = main_result.get("probes", [])
    require(len(probes) == 60, f"main probe count {len(probes)} != 60", failures)

    rows = []
    original_accepted = []
    final_rejected = 0
    hash_matches = 0
    for probe in probes:
        suite_id = probe["suite"]
        name = probe["name"]
        path = MAIN / f"suite{suite_id}_{name}.txt"
        digest = sha256_file(path)
        hash_ok = digest == probe["sha256"]
        if hash_ok:
            hash_matches += 1
        require(
            hash_ok,
            f"main fixture hash mismatch: suite{suite_id} {name}",
            failures,
        )
        text = path.read_text(encoding="utf-8")
        original_outcome = parse_outcome(
            original_module, text, original_module.SUITES[suite_id]
        )
        repaired_outcome = parse_outcome(module, text, module.SUITES[suite_id])
        if original_outcome["accepted"]:
            original_accepted.append((suite_id, name, probe["sha256"]))
        if not repaired_outcome["accepted"]:
            final_rejected += 1
        rows.append({
            "suite": suite_id,
            "name": name,
            "path": str(path.relative_to(MAIN)),
            "sha256": digest,
            "main_result_rejected": probe["rejected"],
            "original_parser": original_outcome,
            "repaired_parser": repaired_outcome,
        })

    expected_unexpected = {
        (item["suite"], item["name"], item["sha256"])
        for item in main_result.get("unexpected_acceptances", [])
    }
    original_accepted_set = set(original_accepted)
    require(
        original_accepted_set == expected_unexpected,
        "original parser acceptance set does not reproduce main result",
        failures,
    )
    require(
        len(original_accepted) == 15,
        f"original parser accepted {len(original_accepted)} != 15",
        failures,
    )
    require(
        final_rejected == 60,
        f"repaired parser rejected {final_rejected} != 60",
        failures,
    )
    require(
        hash_matches == 60,
        f"fixture hash matches {hash_matches} != 60",
        failures,
    )

    fixed_class_counts = {}
    for class_name in FIXED_CLASSES:
        count = sum(
            1 for _, name, _ in original_accepted if name == class_name
        )
        repaired_count = sum(
            1
            for item in rows
            if item["name"] == class_name
            and not item["repaired_parser"]["accepted"]
        )
        fixed_class_counts[class_name] = {
            "original_acceptances": count,
            "repaired_rejections": repaired_count,
        }
        require(
            count == 5,
            f"original fixed class count {class_name} != 5",
            failures,
        )
        require(
            repaired_count == 5,
            f"repaired fixed class count {class_name} != 5",
            failures,
        )

    value = {
        "main_result_path": str(result_path.relative_to(PROJECT)),
        "main_result_sha256": sha256_file(result_path),
        "fixture_hash_matches": hash_matches,
        "probes_expected": 60,
        "probes_rejected_repaired": final_rejected,
        "original_parser_accepted_count": len(original_accepted),
        "original_parser_rejected_count": len(probes) - len(original_accepted),
        "repaired_accepted_count": len(probes) - final_rejected,
        "original_acceptance_set_matches_main_result": (
            original_accepted_set == expected_unexpected
        ),
        "fixed_class_counts": fixed_class_counts,
        "original_acceptances_reclassified_as_negative": [
            {"suite": suite, "name": name, "sha256": digest}
            for suite, name, digest in original_accepted
        ],
        "probes": rows,
    }
    write_json_new(run_dir / "negative_fixture_replay.json", value)
    return value


def controls_phase(module, run_dir: Path, failures: list[str]) -> dict:
    summary = read_json(ATTEMPT / "summary.json")
    command = next(item for item in summary["commands"] if item["index"] == 4)
    base = (ATTEMPT / command["raw_stdout"]).read_text(encoding="utf-8")
    baseline = parse_outcome(module, base, module.SUITES[0])
    require(baseline["accepted"], "targeted-control baseline was rejected", failures)

    def replace_once(text: str, old: str, new: str) -> str:
        count = text.count(old)
        if count != 1:
            raise RuntimeError(
                f"control source occurrence count {count} for {old!r}"
            )
        return text.replace(old, new, 1)

    def insert_before(text: str, needle: str, insertion: str) -> str:
        count = text.count(needle)
        if count != 1:
            raise RuntimeError(
                f"control insertion occurrence count {count} for {needle!r}"
            )
        return text.replace(needle, insertion + needle, 1)

    status = "LINK_SUITE_STATUS suite=0 result=PASS"
    first_case_end = (
        "CASE_END suite=0 case=0 name=default_zero_maxmeta "
        "checks=2 failures=0 result=PASS"
    )
    begin = "LINK_SUITE_BEGIN suite=0"
    cases = [
        (
            "bare_trailing_token",
            replace_once(base, status, status + " trailing_garbage"),
            "REJECT",
            "malformed field token",
        ),
        (
            "duplicate_field",
            replace_once(base, status, status + " result=PASS"),
            "REJECT",
            "duplicate field key",
        ),
        (
            "extra_valid_field",
            replace_once(base, status, status + " extra=1"),
            "REJECT",
            "field set mismatch",
        ),
        (
            "malformed_key",
            replace_once(base, status, status + " bad-key=1"),
            "REJECT",
            "malformed field token",
        ),
        (
            "empty_value",
            replace_once(base, status, status + " extra="),
            "REJECT",
            "malformed field token",
        ),
        (
            "prefixed_marker",
            insert_before(
                base, status, "# NOT_LINK_SUITE_STATUS status=FAIL\n"
            ),
            "REJECT",
            "unknown or decorated protocol marker",
        ),
        (
            "unknown_marker",
            insert_before(base, status, "# LINK_SUITE_UNKNOWN suite=0\n"),
            "REJECT",
            "unknown or decorated protocol marker",
        ),
        (
            "suffixed_marker",
            replace_once(
                base, status, "LINK_SUITE_STATUS_EXTRA suite=0 result=PASS"
            ),
            "REJECT",
            "unknown or decorated protocol marker",
        ),
        (
            "case_trailer",
            replace_once(
                base, first_case_end, first_case_end + " trailing_garbage"
            ),
            "REJECT",
            "malformed field token",
        ),
        (
            "duplicate_case_field",
            replace_once(
                base, first_case_end, first_case_end + " result=PASS"
            ),
            "REJECT",
            "duplicate field key",
        ),
        (
            "prefixed_check_failure",
            insert_before(base, begin, "PREFIX_CHECK_FAIL detail\n"),
            "REJECT",
            "fixture check failure present",
        ),
        (
            "benign_modelsim_banner_and_path",
            insert_before(
                base,
                begin,
                '# vsim -c tb_uart_link_fixture "+VECTOR_FILE=D:/pynq/'
                'CarlandFPGA/uart-link-fixture-20261024-34/vectors/suite_0.txt"\n'
                '# ** Note: (vsim-3812) Design is being optimized...\n',
            ),
            "ACCEPT",
            None,
        ),
    ]

    control_dir = run_dir / "controls"
    results = []
    for index, (name, mutated, expected, fragment) in enumerate(cases, start=1):
        path = control_dir / f"{index:02d}_{name}.stdout.txt"
        write_new(path, mutated.encode("utf-8"))
        outcome = parse_outcome(module, mutated, module.SUITES[0])
        if expected == "ACCEPT":
            passed = outcome["accepted"]
        else:
            passed = (
                not outcome["accepted"]
                and fragment in (outcome["error"] or "")
            )
        require(passed, f"targeted control failed: {name}", failures)
        results.append({
            "name": name,
            "expected": expected,
            "expected_error_fragment": fragment,
            "observed": outcome,
            "passed": passed,
            "stdout_path": str(path.relative_to(run_dir)),
            "stdout_sha256": sha256_file(path),
        })

    value = {
        "baseline_positive": baseline,
        "controls_passed": sum(1 for item in results if item["passed"]),
        "controls_total": len(results),
        "results": results,
    }
    write_json_new(run_dir / "targeted_controls.json", value)
    return value


def publish_result(value: dict) -> Path:
    destination = EVIDENCE / "RESULT.json"
    encoded = (
        json.dumps(value, indent=2, sort_keys=True) + "\n"
    ).encode("utf-8")
    if destination.exists():
        previous = destination.read_bytes()
        preserve = (
            EVIDENCE / f"RESULT.previous-{sha256_bytes(previous)[:16]}.json"
        )
        if not preserve.exists():
            write_new(preserve, previous)
        destination.write_bytes(encoded)
    else:
        write_new(destination, encoded)
    return destination


def execute(run_dir: Path) -> dict:
    started = utc_now()
    failures: list[str] = []
    run_rel = str(run_dir.relative_to(EVIDENCE))

    module = load_module(RUNNER, "uart_runner_repair1_fixed")
    original_module = load_module(ORIGINAL_RUNNER, "uart_runner_repair1_original")
    require(
        sha256_file(RUNNER) == sha256_file(REPAIRED_RUNNER),
        "runner copy hash mismatch at import",
        failures,
    )
    require(
        sha256_file(ORIGINAL_RUNNER) == EXPECTED_ORIGINAL_RUNNER_SHA,
        "original copy hash mismatch at import",
        failures,
    )

    fixture_paths = sorted(MAIN.glob("suite*_*.txt"))
    require(
        len(fixture_paths) == 60,
        f"fixture path count {len(fixture_paths)} != 60",
        failures,
    )
    before = immutable_snapshot(module, fixture_paths)

    provenance = provenance_phase(run_dir, failures)
    contract = contract_phase(module, run_dir, failures)
    source = source_phase(module, run_dir, fixture_paths, failures)
    positive = positive_phase(module, original_module, run_dir, failures)
    negative = negative_phase(module, original_module, run_dir, failures)
    controls = controls_phase(module, run_dir, failures)

    after = immutable_snapshot(module, fixture_paths)
    require(before == after, "an immutable input changed during replay", failures)
    preservation = {
        "before": before,
        "after": after,
        "unchanged": before == after,
    }
    write_json_new(run_dir / "preservation.json", preservation)

    status = "PASS" if not failures else "FAIL"
    result = {
        "schema": "uart-link-runner-repair1-result-v1",
        "status": status,
        "scope": "parser_only_replay",
        "acceptance_owner": "main",
        "task_id": TASK_ID,
        "task_version": TASK_VERSION,
        "work_id": WORK_ID,
        "original_operation_id": module.OPERATION_ID,
        "main_thread": provenance["main_thread"],
        "main_turn": provenance["main_turn"],
        "main_turn_basis": provenance["main_turn_basis"],
        "child_thread": provenance["child_thread"],
        "original_child_turn": provenance["original_child_turn"],
        "repair_child_turn": provenance["repair_child_turn"],
        "job_id": provenance["job_id"],
        "source_commit": SOURCE_COMMIT,
        "frozen_design": FROZEN_DESIGN,
        "contract_commit": CONTRACT_COMMIT,
        "requirements_sha256": contract["requirements_sha256"],
        "repair_scope_sha256": provenance["repair_scope_sha256"],
        "original_scope_sha256": provenance["original_scope_sha256"],
        "runner_sha256": {
            "original": source["original_runner_sha256"],
            "repaired": source["repaired_runner_sha256"],
            "repaired_preserved_copy": source["repaired_runner_copy_sha256"],
        },
        "rtl_sha256": source["rtl_sha256"],
        "tb_sha256": source["tb_sha256"],
        "counts": {
            "real_positive_suites_expected": positive["positive_suites_expected"],
            "real_positive_suites_accepted": (
                positive["positive_suites_accepted_repaired"]
            ),
            "main_negative_probes_expected": negative["probes_expected"],
            "main_negative_probes_rejected": negative["probes_rejected_repaired"],
            "main_original_parser_acceptances_reclassified": (
                negative["original_parser_accepted_count"]
            ),
            "targeted_controls_passed": controls["controls_passed"],
            "targeted_controls_total": controls["controls_total"],
        },
        "historical_vendor_evidence": {
            "attempt": positive["historical_attempt"],
            "summary_sha256": positive["historical_summary_sha256"],
            "nine_commands_exit_zero": True,
            "raw_streams_verified": positive["raw_streams_verified"],
            "tool": positive["historical_vendor_tool"],
            "new_vendor_execution_in_repair": False,
        },
        "main_qualification": {
            "result_sha256": negative["main_result_sha256"],
            "fixture_hash_matches": negative["fixture_hash_matches"],
            "fixed_class_counts": negative["fixed_class_counts"],
        },
        "evidence": {
            "run_directory": run_rel,
            "provenance": f"{run_rel}/provenance.json",
            "contract_check": f"{run_rel}/contract_check.json",
            "source_integrity": f"{run_rel}/source_integrity.json",
            "positive_stream_replay": f"{run_rel}/positive_stream_replay.json",
            "negative_fixture_replay": f"{run_rel}/negative_fixture_replay.json",
            "targeted_controls": f"{run_rel}/targeted_controls.json",
            "preservation": f"{run_rel}/preservation.json",
        },
        "immutable_inputs_unchanged": preservation["unchanged"],
        "owned_files": [
            "tools/transport/run_uart_link_fixture.py",
            (
                "evidence/transport/uart-link-fixture-20261024-34/"
                "author/runner-repair1/"
            ),
        ],
        "limits": {
            "All29": "not_run",
            "B04": "not_run",
            "B06": "not_run",
            "R03": "not_run",
            "full_product": "not_run",
            "physical_board": "not_run",
            "physical_clock_tolerance": "not_claimed",
            "ABI_or_control_grant": "not_run",
            "system": "not_run",
            "modelsim_or_vivado_in_repair": "not_run",
        },
        "failures": failures,
        "started_utc": started,
        "finished_utc": utc_now(),
    }
    write_json_new(run_dir / "RESULT.json", result)
    publish_result(result)
    print(
        f"REPAIR1_RESULT {status} "
        f"positives={positive['positive_suites_accepted_repaired']}/5 "
        f"negatives={negative['probes_rejected_repaired']}/60 "
        f"controls={controls['controls_passed']}/{controls['controls_total']}"
    )
    for failure in failures:
        print(f"FAIL {failure}")
    print(f"RUN_DIR {run_dir}")
    print(f"RESULT {EVIDENCE / 'RESULT.json'}")
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--run-dir", type=Path)
    args = parser.parse_args()
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    run_dir = args.run_dir or (
        EVIDENCE / "runs" / f"run-{stamp}-p{os.getpid()}"
    )
    run_dir = run_dir.resolve()
    evidence_root = EVIDENCE.resolve()
    if evidence_root not in run_dir.parents:
        raise SystemExit(f"run directory is outside evidence root: {run_dir}")
    try:
        run_dir.mkdir(parents=True, exist_ok=False)
    except FileExistsError as exc:
        raise SystemExit(f"run directory already exists: {run_dir}") from exc

    try:
        result = execute(run_dir)
    except Exception as exc:
        traceback_text = traceback.format_exc()
        write_new(run_dir / "CRASH.txt", traceback_text.encode("utf-8"))
        result = {
            "schema": "uart-link-runner-repair1-result-v1",
            "status": "FAIL",
            "scope": "parser_only_replay",
            "work_id": WORK_ID,
            "main_thread": MAIN_THREAD,
            "main_turn": MAIN_TURN,
            "child_thread": CHILD_THREAD,
            "repair_child_turn": REPAIR_CHILD_TURN,
            "source_commit": SOURCE_COMMIT,
            "frozen_design": FROZEN_DESIGN,
            "repair_scope_sha256": sha256_file(REPAIR_SCOPE),
            "requirements_sha256": EXPECTED_REQUIREMENTS_SHA,
            "failures": [f"{type(exc).__name__}: {exc}", traceback_text],
            "run_directory": str(run_dir.relative_to(EVIDENCE)),
        }
        write_json_new(run_dir / "RESULT.json", result)
        publish_result(result)
        print(traceback_text, file=sys.stderr)
        print(f"REPAIR1_RESULT FAIL crash={exc}")
        return 1
    return 0 if result["status"] == "PASS" else 1


if __name__ == "__main__":
    sys.exit(main())
