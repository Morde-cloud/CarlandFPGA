#!/usr/bin/env python3
"""Run the parser-repair replay once and preserve the actual command result."""

from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


sys.dont_write_bytecode = True

EVIDENCE = Path(__file__).resolve().parent
PROJECT = EVIDENCE.parents[4]
REPLAY = EVIDENCE / "replay_repair1.py"
RUNNER = PROJECT / "tools/transport/run_uart_link_fixture.py"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        raise RuntimeError(f"refusing to overwrite {path}")
    path.write_bytes(
        (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")
    )


def main() -> int:
    timestamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    run_id = f"run-{timestamp}-p{os.getpid()}"
    run_dir = EVIDENCE / "runs" / run_id
    run_dir.parent.mkdir(parents=True, exist_ok=True)

    argv = [
        sys.executable,
        "-X",
        "utf8",
        str(REPLAY),
        "--run-dir",
        str(run_dir),
    ]
    environment = os.environ.copy()
    environment["PYTHONDONTWRITEBYTECODE"] = "1"
    started = utc_now()
    completed = subprocess.run(
        argv,
        cwd=str(PROJECT),
        env=environment,
        stdin=subprocess.DEVNULL,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
    )
    finished = utc_now()
    run_dir.mkdir(parents=True, exist_ok=True)
    launcher_path = Path(__file__).resolve()

    stdout_path = run_dir / "stdout.raw"
    stderr_path = run_dir / "stderr.raw"
    if stdout_path.exists() or stderr_path.exists():
        raise RuntimeError("refusing to overwrite replay output streams")
    stdout_path.write_bytes(completed.stdout)
    stderr_path.write_bytes(completed.stderr)

    command = {
        "schema": "uart-link-runner-repair1-command-v1",
        "launcher_argv": sys.argv,
        "launcher_command": [sys.executable, "-X", "utf8", str(launcher_path)],
        "launcher_cwd": str(Path.cwd()),
        "launcher_path": str(launcher_path),
        "launcher_sha256": sha256_file(launcher_path),
        "inner_argv": argv,
        "inner_cwd": str(PROJECT),
        "started_utc": started,
        "finished_utc": finished,
        "exit_code": completed.returncode,
        "stdout_path": "stdout.raw",
        "stdout_size": len(completed.stdout),
        "stdout_sha256": hashlib.sha256(completed.stdout).hexdigest(),
        "stderr_path": "stderr.raw",
        "stderr_size": len(completed.stderr),
        "stderr_sha256": hashlib.sha256(completed.stderr).hexdigest(),
        "python_executable": sys.executable,
        "python_version": sys.version,
        "python_dont_write_bytecode": environment.get("PYTHONDONTWRITEBYTECODE"),
        "replay_script_sha256": sha256_file(REPLAY),
        "runner_sha256": sha256_file(RUNNER),
        "new_modelsim_execution": False,
        "new_vivado_execution": False,
        "new_board_execution": False,
    }
    write_json(run_dir / "command.json", command)

    manifest_path = EVIDENCE / "MANIFEST.sha256"
    if manifest_path.exists():
        previous = manifest_path.read_bytes()
        previous_path = (
            EVIDENCE / f"MANIFEST.previous-{hashlib.sha256(previous).hexdigest()[:16]}.sha256"
        )
        if not previous_path.exists():
            previous_path.write_bytes(previous)
    manifest_lines = []
    for path in sorted(EVIDENCE.rglob("*")):
        if not path.is_file() or path == manifest_path:
            continue
        relative = path.relative_to(EVIDENCE).as_posix()
        manifest_lines.append(f"{sha256_file(path)}  {relative}")
    manifest_bytes = ("\n".join(manifest_lines) + "\n").encode("utf-8")
    manifest_path.write_bytes(manifest_bytes)

    sys.stdout.buffer.write(completed.stdout)
    sys.stdout.flush()
    sys.stderr.buffer.write(completed.stderr)
    sys.stderr.flush()
    print(f"COMMAND {run_dir / 'command.json'}")
    print(f"MANIFEST {manifest_path}")
    return completed.returncode


if __name__ == "__main__":
    sys.exit(main())
