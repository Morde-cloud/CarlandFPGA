from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=R/'.local/deployment/node-b/evidence/uart-link-fixture-20261024-34';E=P/'evidence/transport/uart-link-fixture-20261024-34/main';py=R/'.local/venv/Scripts/python.exe'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
tb=P/'tests/rtl/transport/main_tb_uart_link.sv';gen=P/'tools/transport/main_generate_uart_link.py';spec=importlib.util.spec_from_file_location('main_gen',gen);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
draft=D/'pre-simulation-draft';draft.mkdir(exist_ok=False);(draft/'main_tb_uart_link.sv').write_bytes(tb.read_bytes());(draft/'NOTE.txt').write_text('Original vector generation01 did not initialize TX before first earlier RX edge. No vendor run had occurred. Preserve draft TB/vector01; use explicit common reset edge at1ps and generation02. This is main harness preparation correction, not a DUT failure.\n');tb.write_text(m.bench(),encoding='utf-8',newline='\n')
for period in (10000,9900,10100):
 argv=[str(py),'-B','-X','utf8',str(gen),'--out',str(E/f'vectors-{period}-02'),'--rx-period',str(period),'--tb',str(tb)]
 r=subprocess.run(argv,capture_output=True);(D/f'generate-{period}.stdout').write_bytes(r.stdout);(D/f'generate-{period}.stderr').write_bytes(r.stderr);(D/f'generate-{period}.receipt.json').write_text(json.dumps({'argv':argv,'exit':r.returncode})+'\n');assert r.returncode==0,r.stderr.decode();print(r.stdout.decode().strip(),flush=True)
files=[gen,tb,P/'tools/transport/main_verify_uart_link.py',D/'MAIN_SCOPE.md']+[E/f'vectors-{p}-02'/n for p in (10000,9900,10100) for n in ('FREEZE.json','events.hex')]
record={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'work_id':'B-UART-LINK-MAIN-20261024-34-v1','main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','author34_source_read':False,'files':{str(p.relative_to(R)):{'sha256':sha(p),'bytes':p.stat().st_size} for p in files},'references':m.PINS,'scope':'fixed finite digital clock composition only'}
(D/'MAIN_PREINSPECTION_FREEZE.json').write_text(json.dumps(record,indent=2)+'\n');print('PREINSPECTION_FREEZE_SAVED',flush=True)
