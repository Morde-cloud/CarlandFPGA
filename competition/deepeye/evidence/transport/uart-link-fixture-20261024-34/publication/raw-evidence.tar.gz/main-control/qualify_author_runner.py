from pathlib import Path
import hashlib,importlib.util,json,re,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;out=P/'evidence/transport/uart-link-fixture-20261024-34/main/runner-qualification-01';out.mkdir(exist_ok=False)
runner=P/'tools/transport/run_uart_link_fixture.py';spec=importlib.util.spec_from_file_location('author_link_qualification',runner);m=importlib.util.module_from_spec(spec);sys.modules[spec.name]=m;spec.loader.exec_module(m)
attempt=P/'evidence/transport/uart-link-fixture-20261024-34/author/attempt-20261023T183422.828165Z-p36424';summary=json.loads((attempt/'summary.json').read_bytes());probes=[];verified=0
for cmd in summary['commands']:
 assert cmd['returncode']==0 and not cmd['timed_out']
 for stream in ('stdout','stderr'):
  b=(attempt/cmd['raw_'+stream]).read_bytes();assert hashlib.sha256(b).hexdigest()==cmd[stream+'_sha256'] and len(b)==cmd[stream+'_size'];verified+=1
for suite in m.SUITES:
 n=suite.suite_id;cmd=summary['commands'][4+n];text=(attempt/cmd['raw_stdout']).read_text(encoding='utf-8');v=json.loads((attempt/f'vectors/suite_{n}.json').read_bytes());m.parse_standard_output(text,suite,attempt,v)
 lines=text.splitlines();norm=lambda x:x[2:] if x.startswith('# ') else x
 begin=next(x for x in lines if norm(x).startswith('LINK_SUITE_BEGIN '));status=next(x for x in lines if norm(x).startswith('LINK_SUITE_STATUS '));caseend=next(x for x in lines if norm(x).startswith('CASE_END '));tally=next(x for x in lines if norm(x).startswith('Errors:'))
 bad={'substring_terminal':text.replace(status,'# NOT_'+norm(status)), 'duplicate_terminal':text.replace(status,status+'\n'+status),'conflicting_case':text.replace(caseend,caseend+'\n'+re.sub(r'checks=\d+','checks=0',caseend)),'absent_case':text.replace(caseend+'\n',''),'early_tally':text.replace(tally+'\n','').replace(begin,tally+'\n'+begin),'warning':text.replace(status,'# ** Warning: injected\n'+status),'fatal_suffix':text.replace(status,'# ** Fatal: injected suffix\n'+status),'wrong_count':text.replace(caseend,re.sub(r'checks=\d+','checks=0',caseend)),'unknown_marker':text.replace(status,'# LINK_UNEXPECTED\n'+status),'terminal_trailer':text.replace(status,status+' trailing_garbage'),'case_trailer':text.replace(caseend,caseend+' trailing_garbage'),'marker_prefix_extra':text.replace(status,'# NOT_LINK_SUITE_STATUS status=FAIL\n'+status)}
 for name,raw in bad.items():
  rejected=False;error=None
  try:m.parse_standard_output(raw,suite,attempt,v)
  except Exception as e:rejected=True;error=type(e).__name__+': '+str(e)
  p=out/f'suite{n}_{name}.txt';p.write_text(raw,encoding='utf-8');probes.append({'suite':n,'name':name,'rejected':rejected,'error':error,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
result={'runner_sha256':hashlib.sha256(runner.read_bytes()).hexdigest(),'raw_streams_verified':verified,'positive_suites':5,'probes':probes,'unexpected_acceptances':[x for x in probes if not x['rejected']]};(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k!='probes'}))
