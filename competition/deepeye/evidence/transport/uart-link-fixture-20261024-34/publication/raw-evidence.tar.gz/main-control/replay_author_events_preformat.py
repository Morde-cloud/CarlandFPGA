"""Postinspection format adapter; no imports from author runner/TB.

Derive wire bytes from input JSON using struct and binascii. Absolute TX times
come from config/final-payload acceptance, never an observed serial start.
Main's separate preinspection fixtures cover cycle-by-cycle RX state.
"""
from pathlib import Path
import argparse,binascii,hashlib,json,re,struct
def pairs(s):
 p={}
 for part in s.split():
  k,v=part.split('=',1);assert k not in p;p[k]=v
 return p
def blob(r):
 p=bytes.fromhex(r['payload_hex']);assert len(p)==r['length']<=32
 b=struct.pack('<BBBBHI',3,r['type'],len(p),r['epoch'],r['seq'],r['tick'])+p
 return b'\xa5\x5a'+b+struct.pack('<H',binascii.crc_hqx(b,65535))
def verify(log,vector):
 lines=log.decode('utf-8').splitlines();spec=json.loads(vector);records=[r for c in spec['cases'] for r in c['records']]
 end=re.fullmatch(r'LINK_EVENT_LOG_END suite=(\d+) rows=(\d+) status=OK',lines[-1]);assert end and int(end[1])==spec['suite_id'] and int(end[2])==len(lines)-1
 events=[];prev=-1
 for line in lines[:-1]:
  m=re.fullmatch(r't_ps=(\d+) (\w+)(?: (.*))?',line);assert m,line
  t=int(m[1]);assert t>=prev;prev=t;events.append((t,m[2],pairs(m[3] or '')))
 def rows(name):return [(t,p) for t,n,p in events if n==name]
 profiles=rows('LINK_CLOCK_PROFILE');assert len(profiles)==1;cp=profiles[0][1]
 tp=int(cp['tx_period_ps']);first=int(cp['tx_first_rise_ps']);c=int(cp['tx_clock_hz']);b=int(cp['tx_baud']);pre=int(cp['tx_pre']);post=int(cp['tx_post']);L=(10*c+b-1)//b
 cfg=rows('TX_CFG_ACCEPT');pay=rows('TX_PAYLOAD_ACCEPT');de=[(t,int(p['value'])) for t,p in rows('TX_DE')];assert de[0][1]==0;de=de[1:]
 assert len(cfg)==len(records) and len(de)==2*len(records)
 payloadpos=0;expected_changes=[];wirebytes=0;lastline=1;aborts=0
 cancels=[t for t,p in rows('TX_CANCEL') if p['value']=='1']
 for i,(r,(accept,p)) in enumerate(zip(records,cfg)):
  assert p=={'type':f'{r["type"]:02x}','epoch':f'{r["epoch"]:02x}','seq':f'{r["seq"]:04x}','tick':f'{r["tick"]:08x}','len':str(r['length'])}
  assert (accept-first)%tp==0
  seal=accept;payload=bytes.fromhex(r['payload_hex'])
  for j,value in enumerate(payload):
   t,q=pay[payloadpos];payloadpos+=1;assert t>seal and (t-first)%tp==0
   assert q=={'index':str(j),'data':f'{value:02x}','last':str(int(j==len(payload)-1))};seal=t
  w=blob(r);assert w.hex()==r['wire_hex'];wirebytes+=len(w)
  rise=seal+(len(w)+2)*tp;start=rise+(pre+1)*tp;fall=start+((len(w)-1)*(L+2)+L+post+1)*tp
  if not r['expect_sent']:
   ce=[z for z in cancels if rise<=z<fall];assert len(ce)==1
   fall=first+((ce[0]-first+tp-1)//tp)*tp;aborts+=1
  assert de[2*i:2*i+2]==[(rise,1),(fall,0)],(i,de[2*i:2*i+2],rise,fall)
  for j,value in enumerate(w):
   a=start+j*(L+2)*tp
   for k,valuebit in enumerate([0]+[(value>>k)&1 for k in range(8)]+[1]):
    when=a+((k*c+b-1)//b)*tp
    if when>=fall:break
    if valuebit!=lastline:expected_changes.append((when,valuebit));lastline=valuebit
  if lastline!=1:expected_changes.append((fall,1));lastline=1
 assert payloadpos==len(pay)
 actual_changes=[];last=1
 for t,q in rows('TX_PIN'):
  value=int(q['tx'],2)
  if value!=last:actual_changes.append((t,value));last=value
 assert actual_changes==expected_changes,('absolute TX transitions differ',len(actual_changes),len(expected_changes),next(((a,b) for a,b in zip(actual_changes,expected_changes) if a!=b),None))
 outputs=rows('RX_OUT_HANDSHAKE');expected=[r for r in records if r['expect_output']]
 assert len(outputs)==len(expected)
 for r,(stamp,q) in zip(expected,outputs):
  assert (stamp-int(cp['rx_first_rise_ps']))%int(cp['rx_period_ps'])==0
  want={'type':f'{r["type"]:02x}','epoch':f'{r["epoch"]:02x}','seq':f'{r["seq"]:04x}','tick':f'{r["tick"]:08x}','len':str(r['length']),'payload':bytes.fromhex(r['payload_hex']).ljust(32,b'\0').hex()}
  assert q==want,('descriptor differs',q,want)
 # Actual diagnostic evidence, not just task names or author's final PASS.
 if rows('FAULT_BIT_ERROR'):assert any(q.get('code')=='3' for _,q in rows('RX_PARSER_ERROR'))
 if rows('FAULT_BAD_STOP'):assert any(q.get('framing')=='1' for _,q in rows('RX_LINE_ERROR'))
 if rows('RX_OVERRUN_OBSERVED'):assert any(q.get('overrun')=='1' for _,q in rows('RX_LINE_ERROR')) and rows('RX_OUT_PENDING_INVALIDATED')
 return {'suite_id':spec['suite_id'],'rows':len(events),'input_records':len(records),'payload_bytes':payloadpos,'independent_wire_bytes':wirebytes,'absolute_tx_transitions':len(actual_changes),'descriptor_handshakes':len(outputs),'explicit_tx_aborts':aborts,'event_sha256':hashlib.sha256(log).hexdigest(),'vector_sha256':hashlib.sha256(vector).hexdigest()}
def main():
 p=argparse.ArgumentParser();p.add_argument('--attempt',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(exist_ok=False);results=[]
 for n in range(5):
  log=(a.attempt/f'events/suite_{n}.events.log').read_bytes();vector=(a.attempt/f'vectors/suite_{n}.json').read_bytes();results.append(verify(log,vector))
 (a.out/'RESULT.json').write_text(json.dumps({'accepted':True,'suites':results,'adapter_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'author_runner_imported':False,'scope':'postinspection saved-output/source-input verification; separate preinspection main simulation scope retained'},indent=2)+'\n');print(json.dumps(results))
if __name__=='__main__':main()
