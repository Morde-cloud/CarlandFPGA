from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=R/'.local/deployment/node-b/evidence/uart-link-fixture-20261024-34';E=P/'evidence/transport/uart-link-fixture-20261024-34/main';py=R/'.local/venv/Scripts/python.exe';runner=P/'tools/transport/main_verify_uart_link.py';tb=P/'tests/rtl/transport/main_tb_uart_link.sv'
assert (D/'MAIN_PREINSPECTION_FREEZE.json').is_file()
freeze=json.loads((D/'MAIN_PREINSPECTION_FREEZE.json').read_bytes())
for name,info in freeze['files'].items():assert hashlib.sha256((R/name).read_bytes()).hexdigest()==info['sha256'],name
out=D/'main-execution-01';out.mkdir(exist_ok=False);receipts=[]
spec=importlib.util.spec_from_file_location('main_review',runner);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
f={'events':17,'checks':663};good='MAIN_LINK_BEGIN\nMAIN_LINK_STATS events=17 checks=663\nMAIN_LINK_PASS\nErrors: 0, Warnings: 0\n'
bad={'substring':good.replace('MAIN_LINK_PASS','NOT_MAIN_LINK_PASS_MARKER'), 'duplicate_stats':good.replace('MAIN_LINK_PASS','MAIN_LINK_STATS events=17 checks=662\nMAIN_LINK_PASS'), 'early_tally':good.replace('Errors: 0, Warnings: 0\n','').replace('MAIN_LINK_STATS','Errors: 0, Warnings: 0\nMAIN_LINK_STATS'), 'warning':good.replace('MAIN_LINK_PASS','** Warning: bad\nMAIN_LINK_PASS'), 'fatal_suffix':good.replace('MAIN_LINK_PASS','** Fatal: bad suffix\nMAIN_LINK_PASS'), 'missing_begin':good.replace('MAIN_LINK_BEGIN\n',''),'missing_stats':good.replace('MAIN_LINK_STATS events=17 checks=663\n',''),'missing_end':good.replace('MAIN_LINK_PASS\n',''),'missing_tally':good.replace('Errors: 0, Warnings: 0\n',''),'extra_marker':good+'MAIN_EXTRA\n','wrong_count':good.replace('checks=663','checks=662'),'reordered':good.replace('MAIN_LINK_BEGIN\n','').replace('MAIN_LINK_PASS','MAIN_LINK_PASS\nMAIN_LINK_BEGIN'),'prefix_stats':good.replace('MAIN_LINK_STATS','not_MAIN_LINK_STATS'),'trailing_diag':good+'Warnings: hidden\n'}
assert m.classify(good.encode(),0,f)['accepted'];assert not m.classify(good.encode(),1,f)['accepted']
for name,s in bad.items():assert not m.classify(s.encode(),0,f)['accepted'],name
mutation='MAIN_LINK_BEGIN\nMAIN_MISMATCH event=3 time_ps=9000 field=line got=0 expected=1\n** Fatal: main link numeric mismatch\nErrors: 1, Warnings: 0\n'
assert m.classify(mutation.encode(),0,f,True)['accepted']
for name,s in {'samevalue':mutation.replace('got=0','got=1'),'unknownvalue':mutation.replace('got=0','got=x'),'wrongfatal':mutation.replace('numeric mismatch','numeric mismatch extra'),'outofrange':mutation.replace('event=3','event=99')}.items():assert not m.classify(s.encode(),0,f,True)['accepted'];bad[name]=s
(out/'log-probes.json').write_text(json.dumps({'positive':good,'mutant_positive':mutation,'negatives':bad,'all_rejected':True,'nonzero_exit_rejected':True},indent=2)+'\n')
for period,mutant in [(p,None) for p in (10000,9900,10100)]+[(10000,x) for x in ('no_fault_mux','no_receiver_cancel')]:
 name=f'run-{period}-'+(mutant or 'positive');target=E/name
 argv=[str(py),'-B','-X','utf8',str(runner),'--worktree',str(W),'--vectors',str(E/f'vectors-{period}-02'),'--tb',str(tb),'--out',str(target)]
 if mutant:argv+=['--mutant',mutant]
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();r=subprocess.run(argv,capture_output=True);(out/(name+'.stdout')).write_bytes(r.stdout);(out/(name+'.stderr')).write_bytes(r.stderr)
 rec={'argv':argv,'exit':r.returncode,'start_utc':start,'end_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()};receipts.append(rec);(out/'commands.json').write_text(json.dumps(receipts,indent=2)+'\n');print(name,r.returncode,r.stdout.decode()[:1000],flush=True)
 if r.returncode:raise RuntimeError('main actual failure retained; no automatic rerun')
(out/'RESULT.json').write_text(json.dumps({'accepted_all_five':True,'runs':receipts,'log_negative_count':len(bad)+1,'author_source_inspected':False,'scope':'bounded digital link only'},indent=2)+'\n')
