from pathlib import Path
import datetime,hashlib,importlib.util,json,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';D=Path(__file__).parent;E=P/'evidence/transport/uart-link-fixture-20261024-34';out=E/'main/final-audit-01'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
wait=json.loads((D/'repair1-wait.stdout.json').read_text(encoding='utf-8-sig'))
if isinstance(wait,list):assert len(wait)==1;wait=wait[0]
assert wait['terminal'] and wait['status']=='completed' and not wait['stale'];out.mkdir(exist_ok=False)
runner=P/'tools/transport/run_uart_link_fixture.py';assert sha(runner)=='891b961e984910d1cdc85e36f4912a8d031ce771c4327d6b0301d4aa84a96ff2'
repair=E/'author/runner-repair1/RESULT.json';fix=json.loads(repair.read_bytes());assert fix['status']=='PASS' and fix['immutable_inputs_unchanged'] and not fix['historical_vendor_evidence']['new_vendor_execution_in_repair']
assert fix['runner_sha256']==sha(runner);tb=P/'tests/rtl/transport/tb_uart_link_fixture.sv';assert sha(tb)==fix['tb_sha256']
spec=importlib.util.spec_from_file_location('main_link_audit',P/'tools/transport/main_verify_uart_link.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
rtl={}
for n,h in m.PINS.items():
 b=subprocess.check_output(['git','-C',str(W),'show',m.SOURCE+':competition/deepeye/fpga/transport/'+n]);assert hashlib.sha256(b).hexdigest()==h==sha(P/'fpga/transport'/n);rtl[n]=h
freeze=json.loads((D/'MAIN_PREINSPECTION_FREEZE.json').read_bytes());assert freeze['author34_source_read'] is False
for name,info in freeze['files'].items():assert sha(R/name)==info['sha256'],name
mainruns=[];verified=0
for name in ['run-10000-positive','run-9900-positive','run-10100-positive','run-10000-no_fault_mux','run-10000-no_receiver_cancel']:
 d=E/'main'/name;j=json.loads((d/'RESULT.json').read_bytes());assert j['accepted']
 for filename,v in j['inputs'].items():assert sha(d/filename)==v['sha256'];verified+=1
 for cmd in j['commands']:
  assert cmd['returncode']==0 and not cmd['timeout']
  for s in ('stdout','stderr'):assert sha(d/(cmd['name']+'.'+s+'.bin'))==cmd[s+'_sha256'];verified+=1
 params=json.loads((d/'FREEZE.json').read_bytes());raw=(d/'vsim.stdout.bin').read_bytes()+b'\n'+(d/'vsim.stderr.bin').read_bytes();ver=m.classify(raw,0,params,bool(j['mutant']));assert ver['accepted'] and ver['protocol']==j['protocol']
 mainruns.append({'name':name,'events':params['events'],'checks':params['checks'],'mutant':j['mutant'],'result_sha256':sha(d/'RESULT.json'),'numeric_counterexamples':ver['numeric_counterexamples']})
qual=json.loads((E/'main/runner-qualification-repair1-01/RESULT.json').read_bytes());assert qual['runner_sha256']==sha(runner) and qual['positive_suites']==5 and len(qual['probes'])==60 and not qual['unexpected_acceptances']
for x in qual['probes']:
 assert x['rejected'];p=E/'main/runner-qualification-repair1-01'/f'suite{x["suite"]}_{x["name"]}.txt';assert sha(p)==x['sha256'];verified+=1
replay=json.loads((E/'main/author-replay-03/RESULT.json').read_bytes());assert replay['accepted'] and not replay['author_runner_imported']
attempt=E/'author/attempt-20261023T183422.828165Z-p36424';author=json.loads((attempt/'summary.json').read_bytes());assert author['status']=='PASS' and len(author['commands'])==9 and len(author['suites'])==5
assert sha(attempt/'inputs/owned/tb_uart_link_fixture.sv')==sha(tb)
for c in author['commands']:
 assert c['returncode']==0 and not c['timed_out']
 for s in ('stdout','stderr'):assert sha(attempt/c['raw_'+s])==c[s+'_sha256'];verified+=1
for q in replay['suites']:
 n=q['suite_id'];assert sha(attempt/f'events/suite_{n}.events.log')==q['event_sha256'];assert sha(attempt/f'vectors/suite_{n}.json')==q['vector_sha256'];verified+=2
hist=[]
for d in sorted((E/'author').glob('attempt-*')):
 s=d/'summary.json';hist.append({'attempt':d.name,'status':json.loads(s.read_bytes())['status'] if s.is_file() else 'setup_incomplete_no_summary','summary_sha256':sha(s) if s.is_file() else None})
assert sha(W/'handoffs/b/B-DEEPEYE-CODEC-20261016-01/input.json')=='6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8'
result={'accepted_bounded_uart_link':True,'main_events':sum(x['events'] for x in mainruns if not x['mutant']),'main_port_checks':sum(x['checks'] for x in mainruns if not x['mutant']),'compiled_connection_mutants':2,'main_runs':mainruns,'author_cases':author['totals']['cases'],'author_records':author['totals']['records'],'author_commands':9,'author_rx_handshakes':sum(x['descriptor_handshakes'] for x in replay['suites']),'absolute_tx_transitions':sum(x['absolute_tx_transitions'] for x in replay['suites']),'author_event_rows':sum(x['rows'] for x in replay['suites']),'runner_negative_probes':60,'original_runner_accepted_negatives':15,'verified_artifact_hashes':verified,'rtl_pins':rtl,'source_commit':m.SOURCE,'author_original_attempts':hist,'final_author_runner_sha256':sha(runner),'tb_sha256':sha(tb),'author_repair_result_sha256':sha(repair),'actual_terminal':{'job_id':wait['job_id'],'updated_at':wait['updated_at'],'thread':wait['result']['thread_id'],'turn':wait['result']['turn']['id']},'main_thread':os_thread if (os_thread:='01a13b55-095b-7461-8dd5-5476a130bd82') else None,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'limits':['main references reuse prior independent TX/RX models, mergewritten beforeauthor34sourceinspection','mainbenchexplicitresetat1ps and narrowposedgepulses are simulationonly','savedauthorreplay postinspection; two formatadaptererrors retained; no vendorrerun','runnerrepair reclassifies historical logs; all8RTL/TB unchanged','all29/B04/B06/R03/fullproduct/implementation/timing/CDC_RDC/board/system not_run; A-onlyboard']}
(out/'RESULT.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k] for k in ('accepted_bounded_uart_link','main_events','main_port_checks','author_cases','author_records','author_rx_handshakes','absolute_tx_transitions','verified_artifact_hashes')}))
