Before reading author RTL or receiving its result, main strengthened its own
test to check registered tx/busy between edges after changing reset/cancel/data,
and clamped testbench wire widths for illegal-parameter guard compilation.
Original test bytes are retained as main_tb_uart_tx.pre-read-v1.sv. Current TB
SHA256 bc79df5b5cc1fbe4a48bf1e1ec0715c022dba98a4da4283132a1a980c38f365a.
These changes preserve the absolute elapsed-time oracle and original scope.

The actual ordinary Python CLI event wait was started once after ending the
tool cell; it is process session81258 using existing project_cli wait and
wait.args.json. It writes true stdout/stderr/exit under this private directory.
No model invocation occurs inside that wait. This does not prove automatic
Desktop model wakeup when the process finishes or permanent online status.
