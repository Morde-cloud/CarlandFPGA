# B UART TX implementation, operation24

Task DEEPEYE-IMPLEMENTATION-20261014/version1. Current human-designated main
01a13b55-095b-7461-8dd5-5476a130bd82, turn01a16933-edc1-7022-8e5f-25b4561a4ea5.
Work B-UART-TX-20261023-24-v1; operation B-DEEPEYE-UART-TX-20261023-24.
Base local/published B head f49e30d2cf9a82b1a8f7963768ad3520f68dbd47.

H01-H15 were read; canonical JSON requirements recomputed successfully as
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Contract DEEPEYE-HUMAN-LOCK-20261014/revision1 at
f5989cd5defce561f9ba98e6b18fc2682945f0a2; frozen design
1011259415a0916054eb580687612580bc1e5f09. All requirements remain binding.
Physical board A-only. All29 formal cards remain not_run.

## Authority and stopped-writer check

Human current-turn instruction retains this thread as current main and grants
worker management, task progress and necessary member synchronization. MCP
child_status returned no nonterminal jobs. App wait_threads returned the
coordinator01a154de-abd8-7590-b9a3-2819249458e3 idle/completed at
turn01a16403-c649-7731-a199-eb10ed93fd50. Op23 accepted publication is retained;
it is not rerun. No existing source ownership is transferred for this work.
New exclusive files only. Protected codec input.json SHA256 remains
6db8fca48b2240807ae7df68dc8aa21501eb1b6ab9e89392c5a9272de1a887f8.

## B04 gap and bounded implementation

Add an internal byte-to-serial transmitter. UART/RS485 endpoint is explicitly
missing in the prior B completion matrix. Public message framing, scheduler,
shared bidirectional budgets, RX/CDC, direction/guard, pins/clock calibration,
public ABI and board execution remain independent gates. No old file, clock
source or transport is enabled. This is useful internal RTL, not full B04.

## Fixed interface and semantics

Module deepeye_uart_tx, ports clk,rst,cancel,in_valid,in_ready,in_data[7:0],
tx,busy,stat_accepted,stat_completed,stat_aborted. Parameters integer CLOCK_HZ
default100000000, BAUD default9600, STAT_W default32. Supported CLOCK_HZ
2..2147483647, BAUD1..floor(CLOCK_HZ/2), STAT_W2..32. Effective parameter
localparams clamp illegal declarations to safe values. Invalid cases must
compile then reach their own exact time-zero fatal, priority CLOCK_HZ,BAUD,
STAT_W. Own messages: deepeye_uart_tx: CLOCK_HZ out of range; BAUD out of
range; STAT_W out of range. Guards excluded under SYNTHESIS.

Single clock, synchronous active-high rst/cancel, priority rst>cancel>ordinary.
in_ready is !rst && !cancel && !busy. No extra input queue, no same-edge
completion credit. busy is registered occupancy. tx is registered and is NOT
combinationally gated by abort. Reset/cancel force tx high at their clock edge.

One accepted byte at edge t=0 immediately drives start=0 and latches all8 bits.
Bits are start, data0..data7, stop=1. Boundary k occurs at exactly
ceil(k*CLOCK_HZ/BAUD) elapsed rising edges after admission, k1..10. At k1 data0
begins, k8 data7 begins, k9 stop begins, k10 busy clears and completed increments.
Use bounded integer arithmetic (phase accumulator or equivalent), no real,
unbounded queues, delays, DPI or files in RTL. Initial phase resets per byte;
idle gaps have no accumulated credit. The minimum bit length is2 clocks.
tx remains high when idle. Input changes/strobes while busy are not accepted.
Data is transmitted LSB first. A new byte can only enter on the next edge after
completion. Outward tx waveform grants no source freshness, clock proof or
direction-enable authority.

Reset clears all counters. Cancel discards the one pending byte (if any), adds
one to aborted with saturation, preserves accepted/completed, clears phase and
busy, forces idle tx. Held cancel does not recount. Cancel at the final
completion edge aborts rather than completes. Reset overrides cancel.
Counters unsigned saturate at2**STAT_W-1; arithmetic uses sufficient width.
Before saturation, accepted=completed+aborted+busy. Cancellation may truncate a
byte, so downstream must share reset/discard protocol; no graceful drain or
asynchronous stopped-clock kill is claimed.

## Exclusive ownership

Workspace D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014.
One Flash/max author owns ONLY:
- competition/deepeye/fpga/transport/deepeye_uart_tx.sv
- competition/deepeye/fpga/transport/uart_tx_candidate.md
- competition/deepeye/tests/rtl/transport/tb_uart_tx.sv
- competition/deepeye/tools/transport/run_uart_tx.py
- competition/deepeye/evidence/transport/uart-tx-20261023-24/author/

Main owns ONLY new main evidence under that same operation, new
tests/rtl/transport/main_tb_uart_tx.sv, tools/transport/main_verify_uart_tx.py,
handoffs/b/B-DEEPEYE-UART-TX-20261023-24/, and this private operation directory.
No old evidence is rewritten. No concurrent edits of author files; terminal
execution and explicit correction rationale required before main takes over.

## Acceptance fixed before author code

Main independent oracle derives every bit from absolute elapsed time and the
ceil boundary formula, not the author's state/accumulator or output. Required:
all256 byte values; exact/nonintegral ratios including97/11,31/3,2/1; long idle
and sustained offered input; input perturbations while busy; default100MHz
9600 plus300/1200 baud representative frames; parameter boundaries and exact
own guards; reset/cancel at each of the10 bit phases, held abort, bothabort,
terminal competition, immediate fresh-byte recovery; small STAT_W saturation
via actual transfers. Independent test observes public ports only.
At least2 compiled behavioral mutants must fail with numeric waveform or
counter contradictions (not X/parse/compile/timeouts). Main records actual
ModelSim version, immutable inputs, commands, cwd, exits, stdout/stderr and
hashes; separately qualifies runner failure detection. No old suite replay.
No synthesis, implementation, timing, CDC/RDC, board/system acceptance inferred.

## Waiting and continuation

Use one supported child_wait on the exact dispatched job, with underlying
asyncio.Event waiter verified in fpga_mesh/child_control.py. App wait_threads
successfully returned a real prior terminal event. This proves bounded event
retrieval, not permanent App wakeup or zero standby-token service. No timed
model automation, presence polling, second writer, SQL/lock/service changes.
On completion examine actual files/logs/exits, independently test, then publish
only the accepted scope and choose the next input-ready B gap. Human retains
this main even when a waiting turn ends.
