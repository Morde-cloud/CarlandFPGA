"""One bounded independent suite, exact new outputs, no external actions."""
from pathlib import Path
import hashlib,json,os,subprocess,sys,time
R=Path('D:/pynq/CarlandFPGA')
W=R/'.local/worktrees/deepeye-implementation-20261014'
E=W/'competition/deepeye/evidence/transport/uart-tx-20261023-24/main'
P=R/'.local/deployment/node-b/evidence/uart-tx-20261023-24'
RTL=W/'competition/deepeye/fpga/transport/deepeye_uart_tx.sv'
TB=W/'competition/deepeye/tests/rtl/transport/main_tb_uart_tx.sv'
RUN=W/'competition/deepeye/tools/transport/main_verify_uart_tx.py'
PY=R/'.local/venv/Scripts/python.exe'
raw=RTL.read_bytes()
assert hashlib.sha256(raw).hexdigest()=='5076286e4dd1598aeb2c78281bec83020c85d0711dcee9b985088ac707353c47'
cases=[('ratio97',97,11,32,0),('ratio31',31,3,2,0),('minratio',2,1,3,0),
       ('maxclock',2147483647,1073741823,32,1),('baud9600',100000000,9600,32,1),
       ('baud1200',100000000,1200,32,1),('baud300',100000000,300,32,1)]
commands=[]
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',TEMP=str(P),TMP=str(P),TMPDIR=str(P))
def run(name,rtl,tb,clock,baud,stat,brief=0,mode='positive',guard=None):
    out=E/('run-'+name+'-01')
    argv=[str(PY),'-B','-X','utf8',str(RUN),'--rtl',str(rtl),'--tb',str(tb),'--out',str(out),
          '--clock',str(clock),'--baud',str(baud),'--stat',str(stat),'--brief',str(brief),'--mode',mode,'--timeout','180']
    if guard:argv+=['--guard',guard]
    start=time.time()
    p=subprocess.run(argv,cwd=P,env=env,capture_output=True,timeout=210)
    (P/(name+'.stdout.bin')).write_bytes(p.stdout)
    (P/(name+'.stderr.bin')).write_bytes(p.stderr)
    row={'name':name,'argv':argv,'cwd':str(P),'exit_code':p.returncode,'elapsed_seconds':time.time()-start,
         'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
    commands.append(row)
    (P/(name+'.command.json')).write_text(json.dumps(row,indent=2),encoding='utf-8')
    result=json.loads((out/'RESULT.json').read_text(encoding='utf-8')) if (out/'RESULT.json').exists() else {}
    print(json.dumps({'case':name,'exit':p.returncode,'accepted':result.get('accepted'),'stats':result.get('stats'),'error':result.get('error')}),flush=True)
    return p.returncode==0 and result.get('accepted') is True

# Stop on a failed positive so incorrect tooling cannot silently fabricate coverage.
good=True
for name,clock,baud,stat,brief in cases:
    if not run(name,RTL,TB,clock,baud,stat,brief): good=False; break
if good:
    guards=[('clock0',0,0,1,'CLOCK_HZ'),('clock1',1,1,32,'CLOCK_HZ'),('clockneg',-1,11,32,'CLOCK_HZ'),
            ('baud0',97,0,1,'BAUD'),('baudneg',97,-1,32,'BAUD'),('baudhigh',97,49,32,'BAUD'),
            ('stat0',97,11,0,'STAT_W'),('stat1',97,11,1,'STAT_W'),('stat33',97,11,33,'STAT_W')]
    for name,clock,baud,stat,guard in guards:
        good=run(name,RTL,E/'guard_tb.sv',clock,baud,stat,mode='guard',guard=guard) and good
if good:
    mutants=[('late_boundary',b'phase_sum >= {1\'b0, clock_u}',b'phase_sum > {1\'b0, clock_u}',2,1),
             ('reversed_bit',b"4'd1: tx_q <= data_q[0];",b"4'd1: tx_q <= data_q[7];",97,11),
             ('async_cancel',b'assign tx       = tx_q;',b'assign tx       = cancel ? 1\'b1 : tx_q;',97,11)]
    for name,before,after,clock,baud in mutants:
        assert raw.count(before)==1
        path=E/(name+'.sv')
        with path.open('xb') as f:f.write(raw.replace(before,after))
        good=run(name,path,TB,clock,baud,32,mode='mutant') and good
assert RTL.read_bytes()==raw
result={'accepted':good,'commands':commands,'rtl_sha256':hashlib.sha256(raw).hexdigest(),'scope':'main independent UART TX RTL simulation; no full B04 or board acceptance'}
with (P/'MAIN_SUITE_RESULT.json').open('x',encoding='utf-8') as f:json.dump(result,f,indent=2)
sys.exit(0 if good else 1)
