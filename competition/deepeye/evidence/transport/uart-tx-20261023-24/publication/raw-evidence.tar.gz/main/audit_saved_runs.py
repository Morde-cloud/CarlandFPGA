"""Rehash original process evidence; reclassify without launching vendor tools."""
from pathlib import Path
import hashlib,importlib.util,json,re,sys
W=Path(sys.argv[1]); E=W/'competition/deepeye/evidence/transport/uart-tx-20261023-24'; M=E/'main'
def load(name,path):
 s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s); s.loader.exec_module(m);return m
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
author=load('author_runner',W/'competition/deepeye/tools/transport/run_uart_tx.py')
main=load('main_runner',W/'competition/deepeye/tools/transport/main_verify_uart_tx.py')
checks=[]
def check(name,value): checks.append({'name':name,'pass':bool(value)})
final=E/'author/attempt-07-final-all'
result=json.loads((final/'result.json').read_text(encoding='utf-8'))
check('original_result_sha',sha(final/'result.json')=='ba33e66663804e3f935ae6afa08f42d649dc67513bd5bf541027b695a393d7a8')
processes=list(final.rglob('process.json'))
for path in processes:
 row=json.loads(path.read_text(encoding='utf-8'))
 check(str(path.relative_to(E)),row['returncode']==0 and not row['timed_out'] and row['spawn_error'] is None
       and sha(Path(row['stdout']))==row['stdout_sha256'] and sha(Path(row['stderr']))==row['stderr_sha256'])
for name,suite in result['suites'].items():
 ck=[]; spec=author.SUITES[name]; folder=final/'suites'/name
 compile_text=author.combined_text(folder/'steps/02-vlog')
 author.classify_compile(compile_text,ck,'compile')
 text=author.combined_text(folder/'steps/03-vsim')
 if spec['kind']=='guard':author.parse_guard(text,spec,ck)
 else:
  author.parse_ordinary(text,spec,ck)
  check(name+'_tally',author.tally_values(text)==[(0,0)])
 check(name+'_classification',author.checks_pass(ck))
 for src in suite['sources']:
  check(name+'_'+src['key']+'_snapshot',sha(Path(src['snapshot']))==src['snapshot_sha256']==src['source_sha256']==sha(Path(src['source'])))

text=author.combined_text(final/'suites/ratio97_11/steps/03-vsim')
spec=author.SUITES['ratio97_11']
negatives={
 'substring_pass':text.replace('TB_END pass','NOT_TB_END pass'),
 'duplicate_end':text+'\nTB_END pass\n',
 'conflicting_stats':text+'\nTB_STAT accepted=1\n',
 'same_duplicate_stats':text+'\nTB_STAT accepted=257\n',
 'missing_stats':re.sub(r'^.*TB_STAT accepted=.*(?:\n|$)','',text,flags=re.M),
 'trailing_marker':text+'\nTB_SUMMARY rubbish\n',
 'case_failure':text.replace('status=pass','status=fail',1),
 'fail_row':text+'\nCHECK_FAIL reason=synthetic\n',
}
for name,variant in negatives.items():
 ck=[]; author.parse_ordinary(variant,spec,ck);check('author_negative_'+name,not author.checks_pass(ck))

main_rows=[]
for folder in sorted(M.glob('run-*-01')):
 r=json.loads((folder/'RESULT.json').read_text(encoding='utf-8'))
 for cmd in r['commands']:
  check(folder.name+'_'+cmd['name']+'_raw',sha(folder/(cmd['name']+'.stdout.bin'))==cmd['stdout_sha256'] and sha(folder/(cmd['name']+'.stderr.bin'))==cmd['stderr_sha256'] and not cmd['timeout'])
 if r['mode']=='guard': classified={'accepted':r['accepted'],'diagnostic':r['diagnostic']}
 else:
  raw=(folder/'vsim.stdout.bin').read_bytes()+b'\n'+(folder/'vsim.stderr.bin').read_bytes()
  code=r['commands'][-1]['returncode']
  classified=main.classify(raw,code,tuple(r['parameters']),r['mode']=='mutant')
 check(folder.name+'_reclassification',classified['accepted'])
 main_rows.append({'run':folder.name,'classification':classified,'original_result_sha256':sha(folder/'RESULT.json')})
positive=[r['classification']['stats'] for r in main_rows if r['classification'].get('stats')]
out={'scope':'saved raw-byte audit/reclassification; no new simulator executions','checks':len(checks),'passed':sum(x['pass'] for x in checks),
 'author_processes':len(processes),'author_suites':len(result['suites']),'main_runs':main_rows,
 'main_cycles':sum(r['cycles'] for r in positive),'main_checks':sum(r['checks'] for r in positive),'details':checks,
 'source_hashes':{str(p.relative_to(W)):sha(p) for p in [W/'competition/deepeye/fpga/transport/deepeye_uart_tx.sv',W/'competition/deepeye/tools/transport/run_uart_tx.py',W/'competition/deepeye/tools/transport/main_verify_uart_tx.py']}}
with (M/'AUDIT_SAVED_RUNS.json').open('x',encoding='utf-8') as f:json.dump(out,f,indent=2)
print(json.dumps({k:v for k,v in out.items() if k not in ('details','main_runs','source_hashes')}))
sys.exit(0 if all(x['pass'] for x in checks) else 1)
