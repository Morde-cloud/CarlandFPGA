`timescale 1ns/1ps
module main_tb_uart_tx;
parameter integer CLOCK_HZ=97, BAUD=11, STAT_W=32, BRIEF=0;
reg clk=0;
always #5 clk=~clk;
deepeye_uart_tx #(.CLOCK_HZ(CLOCK_HZ),.BAUD(BAUD),.STAT_W(STAT_W)) dut(
 .clk(clk),.rst(1'b1),.cancel(1'b0),.in_valid(1'b0),.in_data(8'd0),
 .in_ready(),.tx(),.busy(),.stat_accepted(),.stat_completed(),.stat_aborted());
initial begin #100; $fatal(1,"MAIN_GUARD_MISSING"); end
endmodule
