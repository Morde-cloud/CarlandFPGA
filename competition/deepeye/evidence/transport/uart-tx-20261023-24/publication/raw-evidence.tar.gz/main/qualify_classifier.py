"""Synthetic transcript probes; these are explicitly not simulator runs."""
import importlib.util
import json
from pathlib import Path
import sys

runner, output = map(Path, sys.argv[1:])
spec = importlib.util.spec_from_file_location("main_uart", runner)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
params = (97, 11, 32, 1)
good = b"# MAIN_BEGIN clock=97 baud=11 stat=32 brief=1\n# MAIN_STATS cycles=10 checks=59 admitted=4 completed=4 aborted=0\n# MAIN_PASS\n"
cases = [("healthy_synthetic", good, 0, True)]
for name, data in [
    ("missing_pass", good.replace(b"# MAIN_PASS\n", b"")),
    ("substring_pass", good.replace(b"MAIN_PASS", b"NOT_MAIN_PASS")),
    ("duplicate_pass", good + b"# MAIN_PASS\n"),
    ("extra_pass", good + b"# MAIN_PASS extra\n"),
    ("duplicate_begin", good + good.splitlines(keepends=True)[0]),
    ("wrong_parameters", good.replace(b"clock=97", b"clock=98")),
    ("duplicate_stats", good + good.splitlines(keepends=True)[1]),
    ("wrong_checks", good.replace(b"checks=59", b"checks=58")),
    ("too_few_bytes", good.replace(b"completed=4", b"completed=3")),
    ("missing_stats", good.replace(good.splitlines(keepends=True)[1], b"")),
    ("malformed_stats", good.replace(b"cycles=10", b"cycles=10x")),
    ("error", good + b"# ** Error: unrelated error\n"),
    ("warning", good + b"# ** Warning: unrelated warning\n"),
    ("fatal", good + b"# ** Fatal: unexpected\n"),
    ("tally_error", good + b"# Errors: 1, Warnings: 0\n"),
    ("tally_warning", good + b"# Errors: 0, Warnings: 1\n"),
    ("mismatch", good + b"# MAIN_MISMATCH cycle=1 field=tx got=0 expected=1 elapsed=1\n"),
    ("before_stats", good.splitlines(keepends=True)[0] + b"# MAIN_PASS\n" + good.splitlines(keepends=True)[1]),
]:
    cases.append((name, data, 0, False))
cases.extend([(f"exit_{code}", good, code, False) for code in (-1, 1, 2, 17)])
rows = []
for name, data, code, expect in cases:
    result = module.classify(data, code, params)
    rows.append({"name": name, "expected": expect, "actual": result["accepted"], "pass": result["accepted"] == expect})
mutant = b"# MAIN_BEGIN clock=97 baud=11 stat=32 brief=1\n# MAIN_MISMATCH cycle=1 field=tx got=0 expected=1 elapsed=1\n# ** Fatal: main numeric mismatch\n# Errors: 1, Warnings: 0\n"
for name, data, expected in [
    ("mutant_known_numeric", mutant, True),
    ("mutant_unknown", mutant.replace(b"got=0", b"got=x"), False),
    ("mutant_equal", mutant.replace(b"got=0", b"got=1"), False),
    ("mutant_error", mutant + b"# ** Error: unrelated\n", False),
    ("mutant_extra_fatal", mutant + b"# ** Fatal: unrelated\n", False),
    ("mutant_no_fatal", mutant.replace(b"# ** Fatal: main numeric mismatch\n", b""), False),
    ("mutant_extra_errors", mutant.replace(b"Errors: 1", b"Errors: 2"), False),
    ("mutant_no_tally", mutant.replace(b"# Errors: 1, Warnings: 0\n", b""), False),
]:
    value = module.classify(data, 1, params, True)["accepted"]
    rows.append({"name": name, "expected": expected, "actual": value, "pass": value == expected})
result = {"scope": "synthetic parser probes, no RTL or vendor execution", "checks": len(rows), "passed": sum(x["pass"] for x in rows), "rows": rows}
with output.open("x", encoding="utf-8") as f:
    json.dump(result, f, indent=2)
print(json.dumps({k: v for k, v in result.items() if k != "rows"}))
sys.exit(0 if all(x["pass"] for x in rows) else 1)
