#!/usr/bin/env python3
"""Reproduce the nine accepted negatives and verify strict repaired parsing."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import os
import pathlib
import sys
from datetime import datetime, timezone


ROOT = pathlib.Path(__file__).resolve().parents[7]
AUTHOR = (
    ROOT
    / "competition/deepeye/evidence/transport/uart-wire-rx-20261024-31/author"
)
REPAIR = AUTHOR / "repair1"
PARSER_ATTEMPTS = REPAIR / "parser-tests"
RUNNER = ROOT / "competition/deepeye/tools/transport/run_uart_wire_rx.py"
MAIN = (
    ROOT
    / "competition/deepeye/evidence/transport/uart-wire-rx-20261024-31/main/runner-negative-01"
)
ORIGINAL_RUNNER = MAIN / "original_runner.py"
ORIGINAL_RAW = (
    AUTHOR / "attempts/attempt-20261023T173408.542617Z-p37748/raw"
)
GUARD_SOURCE = (
    ORIGINAL_RAW / "013_vsim_guard_clock_low"
)


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_new(path: pathlib.Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(data)


def load_module(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def create_attempt() -> pathlib.Path:
    PARSER_ATTEMPTS.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    base = PARSER_ATTEMPTS / f"attempt-{stamp}-p{os.getpid()}"
    for suffix in range(100):
        candidate = base if suffix == 0 else pathlib.Path(f"{base}-{suffix:02d}")
        try:
            candidate.mkdir()
        except FileExistsError:
            continue
        for child in ("inputs", "variants"):
            (candidate / child).mkdir()
        return candidate
    raise RuntimeError("could not allocate parser-test attempt")


def replace_once(text: str, old: str, new: str, label: str) -> str:
    count = text.count(old)
    if count != 1:
        raise RuntimeError(f"{label}: expected one replacement anchor, found {count}")
    return text.replace(old, new, 1)


def combined_raw(path: pathlib.Path) -> bytes:
    stdout = (path / "stdout.raw").read_bytes()
    stderr = (path / "stderr.raw").read_bytes()
    return stdout + (b"" if stdout.endswith(b"\n") else b"\n") + stderr


def rejection(fn, *args) -> str:
    try:
        fn(*args)
    except Exception as exc:
        return f"{type(exc).__name__}: {exc}"
    raise RuntimeError("negative fixture was accepted")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--author-thread", required=True)
    parser.add_argument("--author-turn", required=True)
    args = parser.parse_args()
    repaired = load_module("repair1_runner_parser_checks", RUNNER)
    original = load_module("repair1_original_runner", ORIGINAL_RUNNER)
    attempt = create_attempt()
    failures: list[str] = []
    inputs = []

    def snapshot(name: str, source: pathlib.Path) -> pathlib.Path:
        data = source.read_bytes()
        target = attempt / "inputs" / name
        write_new(target, data)
        inputs.append(
            {
                "name": name,
                "source": str(source),
                "sha256": sha(data),
                "size": len(data),
            }
        )
        return target

    snapshot("original_runner.py", ORIGINAL_RUNNER)
    snapshot("run_uart_wire_rx.py", RUNNER)
    fixture_names = [
        "positive.log",
        "warning.log",
        "unknown_prefixed_marker.log",
        "missing_tally.log",
        "conflicting_tally.log",
        "early_tally.log",
        "forged_case_counts.log",
        "actual_stat33_13warnings.log",
        "guard_fatal_suffix.log",
        "guard_missing_tally.log",
    ]
    fixture_paths = {}
    for name in fixture_names:
        fixture_paths[name] = snapshot(name, MAIN / name)

    guard_stdout = (GUARD_SOURCE / "stdout.raw").read_bytes()
    guard_stderr = (GUARD_SOURCE / "stderr.raw").read_bytes()
    guard_data = guard_stdout + (
        b"" if guard_stdout.endswith(b"\n") else b"\n"
    ) + guard_stderr
    guard_path = attempt / "inputs/guard_positive_clock_low.log"
    write_new(guard_path, guard_data)
    inputs.append(
        {
            "name": "guard_positive_clock_low.log",
            "source": str(GUARD_SOURCE),
            "sha256": sha(guard_data),
            "size": len(guard_data),
        }
    )

    original_normal = {
        name: fixture_paths[name].read_bytes()
        for name in (
            "warning.log",
            "unknown_prefixed_marker.log",
            "missing_tally.log",
            "conflicting_tally.log",
            "early_tally.log",
            "forged_case_counts.log",
        )
    }
    original_guard = {
        name: fixture_paths[name].read_bytes()
        for name in (
            "actual_stat33_13warnings.log",
            "guard_fatal_suffix.log",
            "guard_missing_tally.log",
        )
    }
    original_records = []
    for name, data in original_normal.items():
        try:
            result = original.parse_normal_suite(data, original.SUITES[0], name)
        except Exception as exc:
            failures.append(f"original runner unexpectedly rejected {name}: {exc}")
            original_records.append({"name": name, "accepted": False})
        else:
            original_records.append(
                {
                    "name": name,
                    "accepted": True,
                    "cases": result["cases"],
                    "checks": result["checks"],
                }
            )
    for name, data in original_guard.items():
        try:
            result = original.parse_guard(data, name, "STAT_W")
        except Exception as exc:
            failures.append(f"original runner unexpectedly rejected {name}: {exc}")
            original_records.append({"name": name, "accepted": False})
        else:
            original_records.append(
                {
                    "name": name,
                    "accepted": True,
                    "fatal_marker_count": result["fatal_marker_count"],
                }
            )
    accepted_invalid = sum(record["accepted"] for record in original_records)
    if accepted_invalid != 9:
        failures.append(f"original invalid accepted count {accepted_invalid} != 9")

    repaired_records = []
    for name, data in {**original_normal, **original_guard}.items():
        if name in original_normal:
            reason = rejection(
                repaired.parse_normal_suite,
                data,
                repaired.SUITES[0],
                name,
            )
        else:
            reason = rejection(repaired.parse_guard, data, name, "STAT_W")
        repaired_records.append({"name": name, "rejected": True, "reason": reason})

    positive = repaired.parse_normal_suite(
        fixture_paths["positive.log"].read_bytes(),
        repaired.SUITES[0],
        "positive.log",
    )
    positive_guard = repaired.parse_guard(
        guard_data, "guard_positive_clock_low", "CLOCK_HZ"
    )

    saved_suites = []
    for index, suite in enumerate(repaired.SUITES, start=8):
        raw_dir = ORIGINAL_RAW / f"{index:03d}_vsim_suite_{suite.name}"
        data = combined_raw(raw_dir)
        result = repaired.parse_normal_suite(data, suite, f"saved_{suite.name}")
        saved_suites.append(
            {
                "name": suite.name,
                "cases": result["cases"],
                "checks": result["checks"],
                "diagnostics": result["diagnostics"],
                "stdout_sha256": sha((raw_dir / "stdout.raw").read_bytes()),
                "stderr_sha256": sha((raw_dir / "stderr.raw").read_bytes()),
            }
        )
    saved_cases = sum(item["cases"] for item in saved_suites)
    saved_checks = sum(item["checks"] for item in saved_suites)
    if saved_cases != repaired.EXPECTED_TOTAL_CASES:
        failures.append(f"saved suite cases {saved_cases} mismatch")
    if saved_checks != repaired.EXPECTED_TOTAL_CHECKS:
        failures.append(f"saved suite checks {saved_checks} mismatch")

    saved_guards = []
    for index, (label, _, _, _, parameter) in enumerate(
        repaired.GUARDS, start=13
    ):
        raw_dir = ORIGINAL_RAW / f"{index:03d}_vsim_{label}"
        data = combined_raw(raw_dir)
        record = {
            "name": label,
            "stdout_sha256": sha((raw_dir / "stdout.raw").read_bytes()),
            "stderr_sha256": sha((raw_dir / "stderr.raw").read_bytes()),
        }
        if label == "guard_stat_high":
            record["old_stat33_rejected"] = True
            record["reason"] = rejection(
                repaired.parse_guard, data, f"saved_{label}", parameter
            )
        else:
            result = repaired.parse_guard(data, f"saved_{label}", parameter)
            record["accepted"] = True
            record["fatal_marker_count"] = result["fatal_marker_count"]
            record["diagnostics"] = result["diagnostics"]
        saved_guards.append(record)

    normal_text = fixture_paths["positive.log"].read_text(encoding="utf-8")
    begin_line = "# WIRE_RX_BEGIN suite=default clock_hz=100000000 baud=9600 stat_w=32"
    case_line = (
        "# WIRE_RX_CASE suite=default case=default_bounded checks=52 status=PASS"
    )
    tally_line = "# WIRE_RX_TALLY suite=default cases=1 checks=52 failures=0"
    status_line = "# WIRE_RX_STATUS suite=default result=PASS"
    normal_variant_text = {
        "normal_marker_prefixed": replace_once(
            normal_text,
            begin_line,
            "PREFIX " + begin_line,
            "normal_marker_prefixed",
        ),
        "normal_marker_suffixed": replace_once(
            normal_text,
            status_line,
            status_line + " NOT_ACTUAL",
            "normal_marker_suffixed",
        ),
        "normal_marker_malformed": replace_once(
            normal_text,
            begin_line,
            begin_line.replace("WIRE_RX_BEGIN", "WIRE_RX_BEGINX"),
            "normal_marker_malformed",
        ),
        "normal_marker_duplicate": replace_once(
            normal_text,
            case_line + "\n",
            case_line + "\n" + case_line + "\n",
            "normal_marker_duplicate",
        ),
        "normal_marker_missing": replace_once(
            normal_text,
            case_line + "\n",
            "",
            "normal_marker_missing",
        ),
        "normal_marker_out_of_order": replace_once(
            normal_text,
            case_line + "\n" + tally_line,
            tally_line + "\n" + case_line,
            "normal_marker_out_of_order",
        ),
    }
    normal_variant_records = []
    for name, text in normal_variant_text.items():
        data = text.encode("utf-8")
        write_new(attempt / "variants" / f"{name}.log", data)
        try:
            repaired.parse_diagnostic_tally(data.decode("utf-8"), name)
        except Exception as exc:
            failures.append(f"{name}: diagnostic tally precheck failed: {exc}")
        reason = rejection(
            repaired.parse_normal_suite, data, repaired.SUITES[0], name
        )
        normal_variant_records.append(
            {"name": name, "rejected": True, "reason": reason, "sha256": sha(data)}
        )

    guard_text = guard_data.decode("utf-8")
    guard_newline = "\r\n" if "\r\n" in guard_text else "\n"
    guard_fatal = "# ** Fatal: deepeye_uart_wire_rx: CLOCK_HZ out of range"
    guard_tally = "# Errors: 1, Warnings: 0"
    guard_variant_text = {
        "guard_fatal_suffix_clean": replace_once(
            guard_text,
            guard_fatal,
            guard_fatal + " NOT_ACTUAL",
            "guard_fatal_suffix_clean",
        ),
        "guard_missing_tally_clean": replace_once(
            guard_text,
            guard_tally,
            "",
            "guard_missing_tally_clean",
        ),
        "guard_duplicate_fatal": replace_once(
            guard_text,
            guard_fatal,
            guard_fatal + guard_newline + guard_fatal,
            "guard_duplicate_fatal",
        ),
        "guard_dependency_preemption": replace_once(
            guard_text,
            "deepeye_uart_wire_rx: CLOCK_HZ out of range",
            "deepeye_uart_rx: CLOCK_HZ out of range",
            "guard_dependency_preemption",
        ),
        "guard_warning": replace_once(
            guard_text,
            guard_tally,
            "# ** Warning: injected\n" + guard_tally,
            "guard_warning",
        ),
        "guard_success_marker": replace_once(
            guard_text,
            guard_tally,
            "# WIRE_RX_STATUS suite=default result=PASS\n" + guard_tally,
            "guard_success_marker",
        ),
        "guard_fallback_token": replace_once(
            guard_text,
            guard_tally,
            "# FALLBACK\n" + guard_tally,
            "guard_fallback_token",
        ),
        "guard_conflicting_tally": replace_once(
            guard_text,
            guard_tally,
            "# Errors: 9, Warnings: 3\n" + guard_tally,
            "guard_conflicting_tally",
        ),
    }
    guard_variant_records = []
    for name, text in guard_variant_text.items():
        data = text.encode("utf-8")
        write_new(attempt / "variants" / f"{name}.log", data)
        reason = rejection(
            repaired.parse_guard, data, name, "CLOCK_HZ"
        )
        guard_variant_records.append(
            {"name": name, "rejected": True, "reason": reason, "sha256": sha(data)}
        )

    status = "PASS" if not failures else "FAIL"
    summary = {
        "status": status,
        "failures": failures,
        "started_utc": utc_now(),
        "attempt": str(attempt),
        "author_thread": args.author_thread,
        "author_turn": args.author_turn,
        "original_invalid_accepted": accepted_invalid,
        "original_records": original_records,
        "repaired_records": repaired_records,
        "positive_normal": positive,
        "positive_guard": positive_guard,
        "saved_suite_readback": saved_suites,
        "saved_guard_readback": saved_guards,
        "normal_variants": normal_variant_records,
        "guard_variants": guard_variant_records,
        "inputs": inputs,
    }
    write_new(
        attempt / "parser_check_results.json",
        (json.dumps(summary, indent=2, sort_keys=True) + "\n").encode("utf-8"),
    )
    print(f"PARSER_CHECKS {status}")
    print(f"PARSER_ATTEMPT {attempt}")
    print(f"ORIGINAL_INVALID_ACCEPTED {accepted_invalid}")
    print(f"REPAIRED_NEGATIVES_REJECTED {len(repaired_records)}")
    print(f"NORMAL_VARIANTS_REJECTED {len(normal_variant_records)}")
    print(f"GUARD_VARIANTS_REJECTED {len(guard_variant_records)}")
    print(f"POSITIVE_NORMAL_CHECKS {positive['checks']}")
    print(f"POSITIVE_GUARD_FATAL_COUNT {positive_guard['fatal_marker_count']}")
    print(f"SAVED_SUITE_READBACK {len(saved_suites)} cases={saved_cases} checks={saved_checks}")
    print(
        f"SAVED_GUARD_READBACK {sum(1 for x in saved_guards if x.get('accepted'))} "
        f"old_stat33_rejected={sum(1 for x in saved_guards if x.get('old_stat33_rejected'))}"
    )
    for failure in failures:
        print(f"FAIL {failure}")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
