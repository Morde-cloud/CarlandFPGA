#!/usr/bin/env python3
"""Reproduce operation-31 STAT_W=33 width mismatch from the original RTL."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import os
import pathlib
import shutil
import sys
from datetime import datetime, timezone


ROOT = pathlib.Path(__file__).resolve().parents[7]
EVIDENCE = (
    ROOT
    / "competition/deepeye/evidence/transport/uart-wire-rx-20261024-31/author"
)
REPAIR = EVIDENCE / "repair1"
PREPATCH = REPAIR / "prepatch"
RUNNER = ROOT / "competition/deepeye/tools/transport/run_uart_wire_rx.py"
ORIGINAL_INPUTS = (
    EVIDENCE / "attempts/attempt-20261023T173408.542617Z-p37748/inputs"
)
TRANSPORT = ROOT / "competition/deepeye/fpga/transport"
TB = ROOT / "competition/deepeye/tests/rtl/transport/tb_uart_wire_rx.sv"
SCOPE = (
    ROOT.parents[1]
    / "deployment/node-b/evidence/uart-wire-rx-20261024-31/SCOPE.md"
)
REPAIR_SCOPE = SCOPE.with_name("REPAIR1.md")
CONTRACT_JSON = ROOT / "docs/competition/deepeye-2026/immutable_scope.json"
CONTRACT_MD = ROOT / "docs/competition/deepeye-2026/immutable_scope.md"

EXPECTED = {
    "SCOPE.md": "575bba8abfcacddcd6a445a0d56f0dacdca7e1bf976390b479dbff70c0f55a8b",
    "REPAIR1.md": "aeec36032fcfd5bb6a36f4017d66d4fe3be5ae6cb213078977380af9fd2a03e1",
    "immutable_scope.json": "6a86000e97d1571c0b7b89b9d3cf7facb11d2b6a06455eb1d53e0637676b6bc4",
    "immutable_scope.md": "27c5bf0b194036cf4300dbec371b6abba42bc5fda604da0e6e06284e4c5a2ddd",
    "deepeye_uart_wire_rx.sv": "5ca258b491a4be4415a750a009ca808cf94e8f444e312f92922ab11f60afd661",
    "tb_uart_wire_rx.sv": "3aca3b1bb4493cb45662b586383f608149b1ec925412e862a0e8d13be380eed0",
    "deepeye_uart_rx.sv": "935f5d02008535fd5da75b7dc80696d14b03bd54d85f8b52fbf12c1e0504f08f",
    "deepeye_wire_parser.sv": "7806c5d08785b96eae3708d9fd6d6002ef82faa4416a1f7244da73bece552649",
    "deepeye_crc16_byte.sv": "8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat().replace("+00:00", "Z")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def write_new(path: pathlib.Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("xb") as handle:
        handle.write(data)


def load_module(name: str, path: pathlib.Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load module {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def create_attempt() -> pathlib.Path:
    PREPATCH.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S.%fZ")
    base = PREPATCH / f"attempt-{stamp}-p{os.getpid()}"
    for suffix in range(100):
        candidate = base if suffix == 0 else pathlib.Path(f"{base}-{suffix:02d}")
        try:
            candidate.mkdir()
        except FileExistsError:
            continue
        for child in ("inputs", "raw", "sim", "temp", "pycache"):
            (candidate / child).mkdir()
        return candidate
    raise RuntimeError("could not allocate prepatch attempt")


def main() -> int:
    rr = load_module("repair1_runner_prepatch", RUNNER)
    attempt = create_attempt()
    started = utc_now()
    failures: list[str] = []
    commands: list[dict] = []

    source_paths = {
        "SCOPE.md": SCOPE,
        "REPAIR1.md": REPAIR_SCOPE,
        "immutable_scope.json": CONTRACT_JSON,
        "immutable_scope.md": CONTRACT_MD,
        "deepeye_uart_wire_rx.sv": ORIGINAL_INPUTS / "deepeye_uart_wire_rx.sv",
        "tb_uart_wire_rx.sv": TB,
        "deepeye_uart_rx.sv": TRANSPORT / "deepeye_uart_rx.sv",
        "deepeye_wire_parser.sv": TRANSPORT / "deepeye_wire_parser.sv",
        "deepeye_crc16_byte.sv": TRANSPORT / "deepeye_crc16_byte.sv",
    }
    inputs = []
    snapshots: dict[str, pathlib.Path] = {}
    for name, source in source_paths.items():
        data = source.read_bytes()
        actual = sha(data)
        if actual != EXPECTED[name]:
            raise RuntimeError(f"input hash mismatch {name}: {actual}")
        target = attempt / "inputs" / name
        write_new(target, data)
        snapshots[name] = target
        inputs.append({"name": name, "source": str(source), "sha256": actual, "size": len(data)})
    runner_data = RUNNER.read_bytes()
    write_new(attempt / "inputs/run_uart_wire_rx.py", runner_data)
    inputs.append(
        {
            "name": "run_uart_wire_rx.py",
            "source": str(RUNNER),
            "sha256": sha(runner_data),
            "size": len(runner_data),
        }
    )

    def record(label: str, argv: list[str], expected: tuple[int, ...], timeout: float, kind: str):
        item = rr.run_command(
            attempt,
            len(commands),
            label,
            argv,
            expected,
            timeout,
            kind,
        )
        commands.append(item)
        return item

    observed: dict[str, object] = {}
    try:
        py = record(
            "python_version",
            [str(rr.PYTHON), "-c", "import sys; print(sys.version); print(sys.executable)"],
            (0,),
            30,
            "tool_probe",
        )
        if not py["accepted_exit"]:
            failures.append("python version probe failed")

        vlib = record("vlib_version", [str(rr.VLIB), "-version"], (0, 1), 30, "tool_probe")
        vlib_text = rr.decode_output(rr.combine_output(vlib, attempt), vlib["label"])
        if vlib["returncode"] != 1 or "Usage: vlib" not in vlib_text:
            failures.append("vlib usage/exit-1 probe mismatch")

        vlog = record("vlog_version", [str(rr.VLOG), "-version"], (0,), 30, "tool_probe")
        vsim = record("vsim_version", [str(rr.VSIM), "-version"], (0,), 30, "tool_probe")
        if "vlog 10.7" not in rr.decode_output(rr.combine_output(vlog, attempt), "vlog"):
            failures.append("vlog 10.7 probe mismatch")
        if "vsim 10.7" not in rr.decode_output(rr.combine_output(vsim, attempt), "vsim"):
            failures.append("vsim 10.7 probe mismatch")

        git = shutil.which("git")
        if git is None:
            failures.append("git unavailable")
        else:
            head = record(
                "git_head", [git, "-C", str(ROOT), "rev-parse", "HEAD"], (0,), 30, "git_probe"
            )
            ancestor = record(
                "git_design_ancestor",
                [git, "-C", str(ROOT), "merge-base", "--is-ancestor", "1011259415a0916054eb580687612580bc1e5f09", "HEAD"],
                (0,),
                30,
                "git_probe",
            )
            if not head["accepted_exit"] or not ancestor["accepted_exit"]:
                failures.append("git identity/ancestry probe failed")

        vlib_work = record("vlib_work", [str(rr.VLIB), "work"], (0,), 60, "compile")
        if not vlib_work["accepted_exit"]:
            failures.append("vlib work failed")
        else:
            compile_sources = [
                snapshots["deepeye_crc16_byte.sv"],
                snapshots["deepeye_uart_rx.sv"],
                snapshots["deepeye_wire_parser.sv"],
                snapshots["deepeye_uart_wire_rx.sv"],
                snapshots["tb_uart_wire_rx.sv"],
            ]
            compile_record = record(
                "vlog_compile_original",
                [str(rr.VLOG), "-sv", "-work", "work", *(str(path) for path in compile_sources)],
                (0,),
                180,
                "compile",
            )
            if not compile_record["accepted_exit"]:
                failures.append("original RTL compilation failed")
            else:
                guard = record(
                    "vsim_original_stat33",
                    [
                        str(rr.VSIM),
                        "-c",
                        "tb_uart_wire_rx",
                        "-gSUITE=5",
                        "-gCLOCK_HZ=64",
                        "-gBAUD=4",
                        "-gSTAT_W=33",
                        "-do",
                        "run -all; quit -f",
                    ],
                    (0,),
                    120,
                    "guard_probe",
                )
                text = rr.decode_output(rr.combine_output(guard, attempt), guard["label"])
                lines = rr.normalized_log_lines(text)
                warnings = [line for line in lines if "** Warning:" in line]
                vopt_warnings = [line for line in warnings if "(vopt-2241)" in line]
                tally = rr.parse_diagnostic_tally(text, "original_stat33")
                expected_fatal = "** Fatal: deepeye_uart_wire_rx: STAT_W out of range"
                fatal_count = sum(line == expected_fatal for line in lines)
                wrong_guard = [
                    line
                    for line in lines
                    if "out of range" in line and line != expected_fatal
                ]
                observed = {
                    "diagnostic_tally": {"errors": tally[0], "warnings": tally[1]},
                    "warning_rows": len(warnings),
                    "vopt_2241_rows": len(vopt_warnings),
                    "exact_own_fatal_rows": fatal_count,
                    "wrong_guard_rows": len(wrong_guard),
                }
                if tally != (1, 13):
                    failures.append(f"original red tally {tally!r} != (1, 13)")
                if len(warnings) != 13 or len(vopt_warnings) != 13:
                    failures.append(
                        f"original red warnings {len(warnings)}/{len(vopt_warnings)} != 13/13"
                    )
                if fatal_count != 1 or wrong_guard:
                    failures.append("original red own fatal was not unique/exact")
    except Exception as exc:
        failures.append(f"{type(exc).__name__}: {exc}")

    status = "PASS_OLD_RED_REPRODUCED" if not failures else "FAIL"
    summary = {
        "status": status,
        "failures": failures,
        "started_utc": started,
        "finished_utc": utc_now(),
        "attempt": str(attempt),
        "operation_id": "B-DEEPEYE-UART-WIRE-RX-20261024-31",
        "repair": "B-UART-WIRE-RX-QUALIFY-20261024-31-r1",
        "inputs": inputs,
        "source_under_test": "original RTL snapshot 5ca258b491a4be4415a750a009ca808cf94e8f444e312f92922ab11f60afd661",
        "observed": observed,
        "commands": commands,
    }
    write_new(
        attempt / "summary.json",
        (json.dumps(summary, indent=2, sort_keys=True) + "\n").encode("utf-8"),
    )
    print(f"PREPATCH_STATUS {status}")
    print(f"PREPATCH_ATTEMPT {attempt}")
    print(f"PREPATCH_OBSERVED {json.dumps(observed, sort_keys=True)}")
    for failure in failures:
        print(f"FAIL {failure}")
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
