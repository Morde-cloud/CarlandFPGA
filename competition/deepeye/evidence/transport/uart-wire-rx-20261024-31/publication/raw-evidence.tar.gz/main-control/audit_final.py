from pathlib import Path
import hashlib,importlib.util,json,sys,re,difflib
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/uart-wire-rx-20261024-31';D=E/'main/final-audit-01';D.mkdir(exist_ok=False);private=R/'.local/deployment/node-b/evidence/uart-wire-rx-20261024-31'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def walk(x):
 if isinstance(x,dict):
  yield x
  for y in x.values():yield from walk(y)
 elif isinstance(x,list):
  for y in x:yield from walk(y)
wait=json.loads((private/'repair1-wait.stdout.json').read_text(encoding='utf-8-sig'))[0];assert wait['terminal'] and wait['status']=='completed' and not wait['stale']
rp=E/'author/repair1/REPAIR1_RESULT.json';assert sha(rp)=='6d31d09be53aa68e635026e6ad96735b2a6c290f0f4904f9fd31ffd86aa747ab';report=json.loads(rp.read_bytes());assert report['author']['thread_id']==wait['result']['thread_id'] and report['author']['turn_id']==wait['result']['turn']['id']
final=report['validation']['final_simulation'];A=W/final['inner'];assert sha(A/'summary.json')==final['summary_sha256'];d=json.loads((A/'summary.json').read_bytes());assert d['status']=='PASS';refs={}
for v in walk(report):
 if isinstance(v.get('path'),str) and isinstance(v.get('sha256'),str):
  p=W/v['path'];assert p.resolve().is_relative_to(R.resolve()) and sha(p)==v['sha256'],str(p);refs[str(p)]=sha(p)
commands=[]
for c in d['commands']:
 assert not c['timed_out'];expected=1 if c['label']=='vlib_version' else 0
 assert c['returncode']==expected,(c['label'],c['returncode']);pipes={}
 for tag in ('stdout','stderr'):
  p=A/c['raw_'+tag];assert p.resolve().is_relative_to(A.resolve()) and sha(p)==c[tag+'_sha256'];pipes[tag]=sha(p)
 commands.append({'label':c['label'],'actual_exit':c['returncode'],'pipes':pipes})
inputs=d['inputs']['inputs'] if isinstance(d['inputs'],dict) else d['inputs'];source_copies=[]
for v in inputs:
 p=Path(v['source_path']);q=A/v['snapshot'];assert sha(p)==sha(q)==v['sha256'];source_copies.append({'path':str(p),'sha256':sha(p)})
rtl=P/'fpga/transport/deepeye_uart_wire_rx.sv';runner=P/'tools/transport/run_uart_wire_rx.py';tb=P/'tests/rtl/transport/tb_uart_wire_rx.sv'
assert sha(rtl)==sha(E/'main/source-snapshot-repair1-01/dut.sv')=='b6abab4e1be54ee61bd45e4d7adfcfea8db39f7574d3ce2ae7b7030ff74ade2c'
assert sha(runner)==sha(E/'main/runner-qualification-repair1-01/runner.py')=='11223f4f42086a5056a9abf65972063735f06ec2e44fb8ae7f7c4262fc809d55';assert sha(tb)=='3aca3b1bb4493cb45662b586383f608149b1ec925412e862a0e8d13be380eed0'
original=(E/'main/source-snapshot-01/dut.sv').read_text(encoding='utf-8');current=rtl.read_text(encoding='utf-8');assert current==original.replace('localparam integer STAT_SAFE = STAT_VALID ? STAT_W : 2;','localparam integer STAT_SAFE = (STAT_W < 2) ? 2 : ((STAT_W > 32) ? 32 : STAT_W);');(D/'rtl.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),current.splitlines(True),fromfile='original',tofile='final')),encoding='utf-8')
s=importlib.util.spec_from_file_location('main_rx_final',runner);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);suites=[];guards=[]
for suite in m.SUITES:
 c=next(c for c in d['commands'] if c['label']=='vsim_suite_'+suite.name);b=(A/c['raw_stdout']).read_bytes()+b'\n'+(A/c['raw_stderr']).read_bytes();out=m.parse_normal_suite(b,suite,c['label']);suites.append({'suite':suite.name,'cases':out['cases'],'checks':out['checks']})
for name,clock,baud,stat,param in m.GUARDS:
 c=next(c for c in d['commands'] if c['label']=='vsim_'+name);b=(A/c['raw_stdout']).read_bytes()+b'\n'+(A/c['raw_stderr']).read_bytes();m.parse_guard(b,name,param);guards.append(name)
qualification=json.loads((E/'main/runner-qualification-repair1-01/RESULT.json').read_bytes());assert qualification['qualified_snapshot'] and qualification['runner_sha256']==sha(runner)
for x in qualification['probes']:assert x['accepted']==x['expected'] and sha(E/'main/runner-qualification-repair1-01'/(x['name']+'.log'))==x['sha256']
mainruns=[];checks=0
for p in [E/'main'/n/'RESULT.json' for n in ('vector-full-repair1-01','vector-fractional-repair1-01','vector-default-repair1-01')]+sorted((E/'main/guards-mutants-repair1-01').glob('*/RESULT.json')):
 v=json.loads(p.read_bytes());assert v['accepted']
 for c in v['commands']:
  assert c['returncode']==0 and not c['timeout']
  for tag in ('stdout','stderr'):assert sha(p.parent/(c['name']+'.'+tag+'.bin'))==c[tag+'_sha256'];checks+=1
 for n,x in v['inputs'].items():assert sha(p.parent/n)==x['sha256'];checks+=1
 mainruns.append({'path':str(p.relative_to(E)),'sha256':sha(p),'mode':v['mode']})
assert len(mainruns)==15
sources=[rtl,runner,tb,P/'fpga/transport/uart_wire_rx_candidate.md',P/'fpga/transport/deepeye_uart_rx.sv',P/'fpga/transport/deepeye_wire_parser.sv',P/'fpga/transport/deepeye_crc16_byte.sv']
result={'accepted_bounded_uart_wire_rx':True,'final_author_cases':sum(x['cases'] for x in suites),'final_author_checks':sum(x['checks'] for x in suites),'author_unique_processes':len(commands),'author_commands':commands,'author_references':refs,'source_copies_verified':source_copies,'author_suites_reclassified':suites,'author_guards_reclassified':guards,'main_cycles':3725739,'main_port_checks':193738428,'main_guards':8,'compiled_behavioral_mutants':4,'main_runs':mainruns,'main_raw_hash_checks':checks,'main_log_probes':len(qualification['probes']),'final_sources':{str(p.relative_to(W)):sha(p) for p in sources},'terminal':{'job':wait['job_id'],'thread':wait['result']['thread_id'],'turn':wait['result']['turn']['id'],'updated_at':wait['updated_at']},'limits':['Exact final bytes equal prior immutable independently tested working snapshot; no vendor rerun needed after terminal.','Original author result path was initially assumed at author root but actual repair report resides author/repair1; path lookup failure ran no tests.','Original author transient out-of-ownership result file was disclosed as removed before original completion; no claim it is rehashable now.','Main acceptance same-clock opaque digital only; all29/B04/R03/fullproduct/synth/impl/timing/CDC_RDC/board/system not_run.']};put(D/'RESULT.json',result);print(json.dumps({k:result[k] for k in ('accepted_bounded_uart_wire_rx','final_author_cases','final_author_checks','author_unique_processes','main_raw_hash_checks','main_log_probes')}))
