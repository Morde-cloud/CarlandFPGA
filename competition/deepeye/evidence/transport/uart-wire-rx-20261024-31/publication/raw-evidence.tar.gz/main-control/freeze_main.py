from pathlib import Path
import hashlib,json,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/uart-wire-rx-20261024-31/main'
files=[P/'tools/transport/main_generate_uart_wire_rx.py',P/'tools/transport/main_generate_wire_vectors.py',P/'tools/transport/main_verify_uart_wire_rx.py',P/'tests/rtl/transport/main_tb_uart_wire_rx.sv']
for d in sorted(E.glob('vectors-*')):files.extend([d/'FREEZE.json',d/'vectors.rle'])
assert len(files)==10
o={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','main_turn':'01a16933-edc1-7022-8e5f-25b4561a4ea5','author_source_read':False,'files':{p.relative_to(W).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in files},'scope':'opaque syntax and same-clock digital receive timing; all29/fullproduct not_run'}
out=Path(__file__).parent/'MAIN_PREINSPECTION_FREEZE.json'
with out.open('x',encoding='utf-8') as f:json.dump(o,f,indent=2);f.write('\n')
print(json.dumps({'path':str(out),'at_utc':o['at_utc'],'files':len(files),'sha256':hashlib.sha256(out.read_bytes()).hexdigest()}))
