from pathlib import Path
import hashlib,json,datetime,importlib.util
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=P/'evidence/transport/wire-uart-tx-20261024-30/main/classifier-order-01';old=D/'main_verify_wire_uart_tx.py'
s=importlib.util.spec_from_file_location('old_main',old);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);f=json.loads((D.parent/'vectors-64-4-0-0-32/FREEZE.json').read_bytes());reds=[]
for n in ('single_early_tally','malformed_tally','malformed_fatal'):
 b=(D/(n+'.log')).read_bytes();c=m.classify(b,0,f,f['parameters']);reds.append({'name':n,'original_accepted':c['accepted'],'log_sha256':hashlib.sha256(b).hexdigest()})
assert reds[0]['original_accepted']
with (D/'ORIGINAL_REDS.json').open('x',encoding='utf-8') as out:json.dump(reds,out,indent=2)
p=P/'tools/transport/main_verify_uart_wire_rx.py';o={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'author_source_read':False,'change':'main classifier complete ordered marker/diagnostic validation only; oracle/TB/vectors unchanged','runner_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'qualification_path':str(D/'RESULT.json'),'qualification_sha256':hashlib.sha256((D/'RESULT.json').read_bytes()).hexdigest()}
with (Path(__file__).parent/'MAIN_PREINSPECTION_RUNNER_UPDATE.json').open('x',encoding='utf-8') as out:json.dump(o,out,indent=2)
print(json.dumps({'update':o,'original_reds':reds}))
