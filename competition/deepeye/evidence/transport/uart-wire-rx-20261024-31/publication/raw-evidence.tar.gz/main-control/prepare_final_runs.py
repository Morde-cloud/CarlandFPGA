from pathlib import Path
import hashlib,json
O=Path(__file__).parent;P=Path('D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014/competition/deepeye');E=P/'evidence/transport/uart-wire-rx-20261024-31/main'
# Preparation only. These programs are executed only after terminal repair and source diff review.
s=(O/'snapshot_and_run_main.py').read_text(encoding='utf-8');s=s.replace("source-snapshot-01","source-snapshot-final-01").replace("'author_terminal_received':False","'author_terminal_received':True").replace("'status':'read-only provisional snapshot; final source equality and terminal receipt required for acceptance'","'status':'final terminal-repair snapshot after main diff review; independent acceptance still pending'")
for a,b in [('vector-full-01','vector-full-final-01'),('vector-fractional-01','vector-fractional-final-01'),('vector-default-01','vector-default-final-01')]:s=s.replace(a,b)
with (O/'run_final_vectors.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_guards_mutants.py').read_text(encoding='utf-8').replace('guards-mutants-01','guards-mutants-final-01').replace('source-snapshot-01','source-snapshot-final-01')
with (O/'run_final_guards_mutants.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
q=E/'guards-mutants-01/stat33';o={'status':'REJECTED_ORIGINAL_STAT33_GUARD','source_sha256':hashlib.sha256((E/'source-snapshot-01/dut.sv').read_bytes()).hexdigest(),'raw_log_sha256':hashlib.sha256((q/'vsim.stdout.bin').read_bytes()).hexdigest(),'cause':'STAT_W33 topports clamp32 but internal STAT_SAFE2 creates13widthwarnings before correct ownfatal; main correctly rejects. Original child runner incorrectly accepted this guard.','prior_completed_positive_cycles':3725739,'prior_completed_positive_checks':193738428,'subsequent_main_guards_and_mutants':'not_run_after_first_guard_failure','decision':'new explicit repair1; final full source will receive own three positive configurations and8guards/4mutants'}
with (E/'guards-mutants-01/FAILURE.json').open('x',encoding='utf-8') as f:json.dump(o,f,indent=2)
print(json.dumps({'prepared':['run_final_vectors.py','run_final_guards_mutants.py'],'executed':False}))
