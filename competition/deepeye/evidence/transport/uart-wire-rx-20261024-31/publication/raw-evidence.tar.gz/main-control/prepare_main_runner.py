from pathlib import Path
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye/tools/transport';s=(P/'main_verify_wire_uart_tx.py').read_text(encoding='utf-8')
a=s.index('PINS=');b=s.index('def sha(',a)
s=s[:a]+"PINS={'deepeye_crc16_byte.sv':'8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f','deepeye_uart_rx.sv':'935f5d02008535fd5da75b7dc80696d14b03bd54d85f8b52fbf12c1e0504f08f','deepeye_wire_parser.sv':'7806c5d08785b96eae3708d9fd6d6002ef82faa4416a1f7244da73bece552649'}\nPARAMS={'clock':'CLOCK_HZ','baud':'BAUD','stat':'STAT_W'}\n"+s[b:]
s=s.replace('wire_uart_tx','uart_wire_rx').replace('absolute-clock composition vectors','absolute-sample-time RX composition vectors')
with (P/'main_verify_uart_wire_rx.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
