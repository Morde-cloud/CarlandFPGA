from pathlib import Path
import json,datetime
O=Path(__file__).parent
s=(O/'snapshot_and_run_main.py').read_text(encoding='utf-8').replace('source-snapshot-01','source-snapshot-repair1-01')
for a,b in [('vector-full-01','vector-full-repair1-01'),('vector-fractional-01','vector-fractional-repair1-01'),('vector-default-01','vector-default-repair1-01')]:s=s.replace(a,b)
s=s.replace("b=rtl.read_bytes();(D/'dut.sv').write_bytes(b)","b=rtl.read_bytes();assert hashlib.sha256(b).hexdigest()=='b6abab4e1be54ee61bd45e4d7adfcfea8db39f7574d3ce2ae7b7030ff74ade2c';(D/'dut.sv').write_bytes(b)")
with (O/'run_provisional_repair_vectors.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
s=(O/'run_guards_mutants.py').read_text(encoding='utf-8').replace('guards-mutants-01','guards-mutants-repair1-01').replace('source-snapshot-01','source-snapshot-repair1-01')
with (O/'run_provisional_repair_guards.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
o={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'decision':'Start independent tests on immutable working-repair snapshot while author finalizes reports. This is readonly input copy, not ownership transfer. Formal acceptance waits actual terminal and equality of final RTL/TB/dependencies. Planned final-run scripts remain unused; if final bytes equal this tested snapshot, reuse actual results without redundant vendor runs.','sha256':'b6abab4e1be54ee61bd45e4d7adfcfea8db39f7574d3ce2ae7b7030ff74ade2c'}
with (O/'PROVISIONAL_REPAIR_TEST_DECISION.json').open('x',encoding='utf-8') as f:json.dump(o,f,indent=2)
