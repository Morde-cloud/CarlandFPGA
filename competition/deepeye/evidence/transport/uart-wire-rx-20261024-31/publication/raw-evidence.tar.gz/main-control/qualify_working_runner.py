from pathlib import Path
import hashlib,importlib.util,json,sys,re
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/uart-wire-rx-20261024-31';D=E/'main/runner-qualification-repair1-01';D.mkdir(exist_ok=False);runner=P/'tools/transport/run_uart_wire_rx.py';b=runner.read_bytes();assert hashlib.sha256(b).hexdigest()=='11223f4f42086a5056a9abf65972063735f06ec2e44fb8ae7f7c4262fc809d55';(D/'runner.py').write_bytes(b)
s=importlib.util.spec_from_file_location('main_rx_working_runner',D/'runner.py');m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m);report=json.loads((E/'author/RESULT.json').read_bytes());A=W/report['passing_attempt']['path'];a=json.loads((A/'summary.json').read_bytes());probes=[]
def probe(name,b,suite=None,guard=None,expected=False):
 path=D/(name+'.log');path.write_bytes(b)
 try:
  if suite:m.parse_normal_suite(b,suite,name)
  else:m.parse_guard(b,name,guard)
  accepted=True;error=None
 except Exception as ex:accepted=False;error=str(ex)
 probes.append({'name':name,'accepted':accepted,'expected':expected,'sha256':hashlib.sha256(b).hexdigest(),'error':error});assert accepted==expected,name
for suite in m.SUITES:
 c=next(c for c in a['commands'] if c['label']=='vsim_suite_'+suite.name);positive=(A/c['raw_stdout']).read_bytes();probe(suite.name+'_positive',positive,suite=suite,expected=True);text=positive.decode();lines=text.splitlines();protocol=[x for x in lines if 'WIRE_RX' in x]
 for i,row in enumerate(protocol):
  probe(suite.name+'_missing_'+str(i),('\n'.join(x for j,x in enumerate(lines) if j!=lines.index(row))+'\n').encode(),suite=suite)
  probe(suite.name+'_duplicate_'+str(i),text.replace(row,row+'\n'+row,1).encode(),suite=suite)
  if i:probe(suite.name+'_early_'+str(i),(row+'\n'+'\n'.join(x for j,x in enumerate(lines) if j!=lines.index(row))+'\n').encode(),suite=suite)
  if 'WIRE_RX_CASE' in row:probe(suite.name+'_wrong_checks_'+str(i),text.replace(row,re.sub(r'checks=(\d+)',lambda x:'checks='+str(int(x[1])+1),row),1).encode(),suite=suite)
for f in sorted((E/'main/runner-negative-01').glob('*.log')):
 guard='STAT_W' if f.stem.startswith('guard_') or f.stem=='actual_stat33_13warnings' else None;probe('original_'+f.stem,f.read_bytes(),suite=None if guard else m.SUITES[0],guard=guard,expected=f.stem=='positive')
g=(E/'main/guards-mutants-repair1-01/stat33/vsim.stdout.bin').read_bytes();probe('actual_repaired_stat33',g,guard='STAT_W',expected=True)
for name,extra in [('error',b'# ** Error: injected\n'),('warning',b'# ** Warning: injected\n'),('fatal',b'# ** Fatal: injected\n'),('success',b'# WIRE_RX_STATUS suite=default result=PASS\n'),('tally',b'# Errors: 1, Warnings: 0\n')]:probe('guard_'+name,extra+g,guard='STAT_W')
probe('guard_suffix',g.replace(b'STAT_W out of range',b'STAT_W out of range suffix'),guard='STAT_W');probe('guard_missing_tally',b'\n'.join(x for x in g.splitlines() if b'Errors:' not in x),guard='STAT_W')
out={'qualified_snapshot':True,'author_terminal_received':False,'runner_sha256':hashlib.sha256(b).hexdigest(),'probes':probes,'requires':'actual terminal and final runner equality, fresh CLI raw/source audit before main acceptance','scope':'Saved raw log qualification, not new RTL simulation'};(D/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps({'qualified_snapshot':True,'runner_sha256':out['runner_sha256'],'main_log_probes':len(probes)}))
