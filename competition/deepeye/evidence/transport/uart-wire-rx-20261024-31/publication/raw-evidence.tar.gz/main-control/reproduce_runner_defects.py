from pathlib import Path
import hashlib,importlib.util,json,sys,re
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/uart-wire-rx-20261024-31';D=E/'main/runner-negative-01';D.mkdir(exist_ok=False);p=P/'tools/transport/run_uart_wire_rx.py';(D/'original_runner.py').write_bytes(p.read_bytes())
s=importlib.util.spec_from_file_location('rx_original_runner',p);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
report=json.loads((E/'author/RESULT.json').read_bytes());A=W/report['passing_attempt']['path'];d=json.loads((A/'summary.json').read_bytes());c=next(c for c in d['commands'] if c['label']=='vsim_suite_default');positive=(A/c['raw_stdout']).read_bytes();lines=positive.decode().splitlines();tally=next(x for x in lines if 'Errors: 0, Warnings: 0' in x)
variants={'positive':positive,'warning':positive+b'\n# ** Warning: injected\n','unknown_prefixed_marker':positive+b'\n# NOT_WIRE_RX_STATUS suite=default result=FAIL\n','missing_tally':('\n'.join(x for x in lines if x!=tally)+'\n').encode(),'conflicting_tally':positive+b'\n# Errors: 9, Warnings: 3\n','early_tally':('\n'.join([tally]+[x for x in lines if x!=tally])+'\n').encode(),'forged_case_counts':positive.replace(b'checks=52',b'checks=1')}
results=[]
for name,b in variants.items():
 (D/(name+'.log')).write_bytes(b)
 try:m.parse_normal_suite(b,m.SUITES[0],name);accepted=True;error=None
 except Exception as e:accepted=False;error=str(e)
 results.append({'name':name,'accepted':accepted,'expected':name=='positive','sha256':hashlib.sha256(b).hexdigest(),'error':error})
guard=E/'main/guards-mutants-01/stat33/vsim.stdout.bin';g=guard.read_bytes()
for name,b in [('actual_stat33_13warnings',g),('guard_fatal_suffix',g.replace(b'STAT_W out of range',b'STAT_W out of range NOT_ACTUAL')),('guard_missing_tally',b'\n'.join(x for x in g.splitlines() if b'Errors:' not in x))]:
 (D/(name+'.log')).write_bytes(b)
 try:m.parse_guard(b,name,'STAT_W');accepted=True;error=None
 except Exception as e:accepted=False;error=str(e)
 results.append({'name':name,'accepted':accepted,'expected':False,'sha256':hashlib.sha256(b).hexdigest(),'error':error})
out={'original_runner_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'tests':results,'actual_invalid_accepted':sum(x['accepted'] and not x['expected'] for x in results),'main_decision':'Rejected: illegal STAT_W33 width mismatch emitted13warnings; author runner accepted warnings, absent/conflicting/early diagnostics and forged counts. Keep original evidence.'};(D/'RESULT.json').write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(out))
