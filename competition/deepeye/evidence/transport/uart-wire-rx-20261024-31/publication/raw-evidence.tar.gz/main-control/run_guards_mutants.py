from pathlib import Path
import hashlib,json,subprocess
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/transport/uart-wire-rx-20261024-31/main';D=E/'guards-mutants-01';D.mkdir(exist_ok=False);rtl=E/'source-snapshot-01/dut.sv';raw=rtl.read_text(encoding='utf-8');results=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def run(label,source,mode,ov=(),expected=None):
 args=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(P/'tools/transport/main_verify_uart_wire_rx.py'),'--rtl',str(source),'--dependencies',str(P/'fpga/transport'),'--tb',str(P/'tests/rtl/transport/main_tb_uart_wire_rx.sv'),'--vectors',str(E/'vectors-64-4-32'),'--out',str(D/label),'--mode',mode]
 for k,v in ov:args+=['--override',f'{k}={v}']
 if expected:args+=['--guard-expect',expected]
 r=subprocess.run(args,capture_output=True);(D/(label+'.stdout.bin')).write_bytes(r.stdout);(D/(label+'.stderr.bin')).write_bytes(r.stderr);d=json.loads((D/label/'RESULT.json').read_bytes());rec={'label':label,'argv':args,'exit':r.returncode,'accepted':d['accepted'],'counterexamples':d.get('numeric_counterexamples',[]),'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)};results.append(rec);put(D/'PROGRESS.json',results);print(json.dumps({k:v for k,v in rec.items() if k!='argv'}),flush=True);assert r.returncode==0 and d['accepted'],label
for label,ov,expected in [('clock_negative',[('clock',-1)],'CLOCK_HZ'),('clock0',[('clock',0)],'CLOCK_HZ'),('clock15',[('clock',15)],'CLOCK_HZ'),('baud0',[('baud',0)],'BAUD'),('baud_above',[('clock',16),('baud',2)],'BAUD'),('stat1',[('stat',1)],'STAT_W'),('stat33',[('stat',33)],'STAT_W'),('priority',[('clock',1),('baud',0),('stat',1)],'CLOCK_HZ')]:run(label,rtl,'guard',ov,expected)
for label,a,b in [('ignore_loss','assign internal_cancel = cancel || line_error_event;','assign internal_cancel = cancel;'),('drop_backpressure','.out_ready(parser_in_ready)',".out_ready(1'b1)"),('line_bit_order','assign line_error_bits = {uart_overrun, uart_framing_error, uart_false_start};','assign line_error_bits = {uart_false_start, uart_framing_error, uart_overrun};'),('ignore_output_stall','.out_ready(out_ready)',".out_ready(1'b1)")]:
 assert raw.count(a)==1;p=D/(label+'.sv');p.write_text(raw.replace(a,b),encoding='utf-8',newline='\n');run(label,p,'mutant')
put(D/'RESULT.json',{'accepted':True,'rtl_sha256':sha(rtl.read_bytes()),'runner_sha256':sha((P/'tools/transport/main_verify_uart_wire_rx.py').read_bytes()),'runs':results,'limits':'same-clock digital guarded composition only; all29/fullproduct/physical not_run'})
