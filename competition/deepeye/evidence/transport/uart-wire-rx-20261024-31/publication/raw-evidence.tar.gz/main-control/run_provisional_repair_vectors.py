from pathlib import Path
import hashlib,json,datetime,subprocess
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';E=P/'evidence/transport/uart-wire-rx-20261024-31/main';D=E/'source-snapshot-repair1-01';D.mkdir(exist_ok=False);rtl=P/'fpga/transport/deepeye_uart_wire_rx.sv';b=rtl.read_bytes();assert hashlib.sha256(b).hexdigest()=='b6abab4e1be54ee61bd45e4d7adfcfea8db39f7574d3ce2ae7b7030ff74ade2c';(D/'dut.sv').write_bytes(b)
receipt={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source':str(rtl),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b),'author_terminal_received':False,'status':'read-only provisional snapshot; final source equality and terminal receipt required for acceptance'}
(D/'SNAPSHOT.json').write_text(json.dumps(receipt,indent=2)+'\n',encoding='utf-8');print(json.dumps(receipt),flush=True)
for vectors,label in [('vectors-64-4-32','vector-full-repair1-01'),('vectors-97-5-2','vector-fractional-repair1-01'),('vectors-default-brief','vector-default-repair1-01')]:
 args=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(P/'tools/transport/main_verify_uart_wire_rx.py'),'--rtl',str(D/'dut.sv'),'--dependencies',str(P/'fpga/transport'),'--tb',str(P/'tests/rtl/transport/main_tb_uart_wire_rx.sv'),'--vectors',str(E/vectors),'--out',str(E/label)]
 r=subprocess.run(args,capture_output=True);(D/(label+'.stdout.bin')).write_bytes(r.stdout);(D/(label+'.stderr.bin')).write_bytes(r.stderr)
 rec={'argv':args,'exit':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(r.stderr).hexdigest()};(D/(label+'.process.json')).write_text(json.dumps(rec,indent=2)+'\n',encoding='utf-8');print(r.stdout.decode('utf-8'),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
