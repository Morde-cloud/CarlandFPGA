onerror {
    puts "WIRE_PARSER_ONERROR|FAIL"
    quit -f -code 71
}
run -all
puts "WIRE_PARSER_ONERROR|NONE"
quit -f -code 0
