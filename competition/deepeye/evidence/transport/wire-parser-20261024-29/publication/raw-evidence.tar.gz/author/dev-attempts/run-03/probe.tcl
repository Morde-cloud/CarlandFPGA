run -all
set rs [runStatus -full]
puts "WIRE_PARSER_RUNSTATUS|$rs"
if {[string match -nocase *fatal* $rs] || [string match -nocase *error* $rs]} {
    puts "WIRE_PARSER_SIM_EXIT|FAIL"
    quit -f -code 71
} else {
    puts "WIRE_PARSER_SIM_EXIT|OK"
    quit -f -code 0
}
