#!/usr/bin/env python3
"""Build RUNNER_REPAIR2_RESULT.json from preserved actual evidence."""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import sqlite3
import subprocess
from pathlib import Path
from typing import Any, Dict, List


BASE = Path(__file__).resolve().parent
WORKTREE = BASE.parents[6]
AUTHOR = BASE.parents[0]
ATTEMPTS = AUTHOR / "attempts"
CONTRACT_COMMIT = "f5989cd5defce561f9ba98e6b18fc2682945f0a2"
CONTRACT_PATH = "docs/competition/deepeye-2026/immutable_scope.json"
CONTRACT_SHA256 = "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
SCOPE_PATH = Path("D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/wire-parser-20261024-29/RUNNER_REPAIR2.md")
SCOPE_SHA256 = "7470587189d6e423c27f7679d29196a424b704c7989ee73336699aaae9db425d"
THREAD_ID = "01a1696b-3c8f-7e63-8fe6-3f74a9564ab7"
PARENT_THREAD_ID = "01a13b55-095b-7461-8dd5-5476a130bd82"
PARENT_TURN_ID = "01a16933-edc1-7022-8e5f-25b4561a4ea5"


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="microseconds").replace("+00:00", "Z")


def sha256_bytes(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def file_record(path: Path) -> Dict[str, Any]:
    raw = path.read_bytes()
    return {
        "path": path.resolve().relative_to(WORKTREE).as_posix() if path.resolve().is_relative_to(WORKTREE) else str(path.resolve()),
        "sha256": sha256_bytes(raw),
        "size_bytes": len(raw),
    }


def load_json(path: Path) -> Dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def current_turn_row() -> Dict[str, Any]:
    path = Path(os.environ["CODEX_HOME"]) / "thread_history_1.sqlite"
    con = sqlite3.connect("file:" + path.as_posix() + "?mode=ro", uri=True)
    try:
        row = con.execute(
            "select turn_id,status,started_at,rollout_ordinal from thread_turns "
            "where thread_id=? order by rollout_ordinal desc limit 1",
            (THREAD_ID,),
        ).fetchone()
    finally:
        con.close()
    if row is None:
        return {"turn_id": "not_provided", "status": "not_provided", "source": "CODEX_HOME/thread_history_1.sqlite:thread_turns"}
    return {
        "turn_id": row[0],
        "status": row[1],
        "started_at_epoch_seconds": row[2],
        "rollout_ordinal": row[3],
        "source": "CODEX_HOME/thread_history_1.sqlite:thread_turns",
    }


def verify_contract() -> Dict[str, Any]:
    raw = subprocess.check_output(
        ["git", "show", CONTRACT_COMMIT + ":" + CONTRACT_PATH],
        cwd=WORKTREE,
    )
    document = json.loads(raw.decode("utf-8"))
    canonical = json.dumps(
        document["requirements"],
        ensure_ascii=False,
        sort_keys=True,
        separators=(",", ":"),
    ).encode("utf-8")
    actual = sha256_bytes(canonical)
    if actual != CONTRACT_SHA256:
        raise RuntimeError("canonical requirements hash changed: " + actual)
    identifiers = [entry["id"] for entry in document["requirements"]]
    if identifiers != ["H%02d" % n for n in range(1, 16)]:
        raise RuntimeError("H01-H15 IDs/order changed")
    return {
        "contract_id": document.get("contract_id"),
        "revision": document.get("revision"),
        "pinned_commit": CONTRACT_COMMIT,
        "path": CONTRACT_PATH,
        "raw_sha256": sha256_bytes(raw),
        "requirements_sha256": actual,
        "expected_requirements_sha256": CONTRACT_SHA256,
        "requirement_ids": identifiers,
        "all_h01_h15_inspected": True,
        "verified": True,
    }


def command_summary(attempt: Dict[str, Any]) -> List[Dict[str, Any]]:
    return [
        {
            "name": command["name"],
            "command_line": command["command_line"],
            "expected_exit": command["expected_exit"],
            "actual_exit": command["actual_exit"],
            "timed_out": command["timed_out"],
            "timeout_seconds": command["timeout_seconds"],
            "stdout_path": command["stdout_path"],
            "stdout_sha256": command["stdout_sha256"],
            "stdout_bytes": command["stdout_bytes"],
            "stderr_path": command["stderr_path"],
            "stderr_sha256": command["stderr_sha256"],
            "stderr_bytes": command["stderr_bytes"],
        }
        for command in attempt.get("commands", [])
    ]


def attempt_record(path: Path) -> Dict[str, Any]:
    manifest_path = path / "attempt.json"
    manifest = load_json(manifest_path)
    record: Dict[str, Any] = {
        "attempt_path": path.relative_to(WORKTREE).as_posix(),
        "attempt_manifest": file_record(manifest_path),
        "status": manifest.get("status"),
        "failure": manifest.get("failure"),
        "session_context": manifest.get("session_context"),
        "environment": manifest.get("environment"),
        "commands": command_summary(manifest),
        "sources": manifest.get("records", {}).get("sources", {}),
    }
    main_suite = manifest.get("records", {}).get("main_suite")
    if main_suite:
        record["main_suite"] = {
            "status": main_suite.get("status"),
            "case_count": main_suite.get("case_count"),
            "check_count": main_suite.get("check_count"),
            "error_count": main_suite.get("error_count"),
            "case_names": [case["name"] for case in main_suite.get("cases", [])],
            "modelsim_diagnostics": main_suite.get("modelsim_diagnostics"),
        }
    guards = manifest.get("records", {}).get("guards")
    if guards:
        record["guards"] = {
            width: {
                "status": value.get("status"),
                "modelsim_diagnostics": value.get("modelsim_diagnostics"),
            }
            for width, value in guards.items()
        }
    return record


def cli_record(
    name: str,
    log_dir: Path,
    actual_exit: int,
    note: str | None = None,
    stdout_name: str = "stdout.bin",
    stderr_name: str = "stderr.bin",
) -> Dict[str, Any]:
    record = {
        "name": name,
        "actual_exit": actual_exit,
        "stdout": file_record(log_dir / stdout_name),
        "stderr": file_record(log_dir / stderr_name),
    }
    if note:
        record["note"] = note
    return record


def inventory(root: Path) -> List[Dict[str, Any]]:
    return [file_record(path) for path in sorted(root.rglob("*")) if path.is_file()]


def main() -> int:
    scope_raw = SCOPE_PATH.read_bytes()
    scope_hash = sha256_bytes(scope_raw)
    if scope_hash != SCOPE_SHA256:
        raise RuntimeError("RUNNER_REPAIR2 scope hash mismatch: " + scope_hash)
    if PARENT_TURN_ID not in scope_raw.decode("utf-8"):
        raise RuntimeError("authorizing parent turn is not present in scope")
    contract = verify_contract()

    final_attempt_path = ATTEMPTS / "runner-repair2-final-01-20261023T170941.018380Z-pid47116"
    final_attempt = attempt_record(final_attempt_path)
    if final_attempt["status"] != "PASS":
        raise RuntimeError("final actual CLI attempt is not PASS")
    main_raw = (final_attempt_path / "commands/08_vsim_main_directed.stdout.bin").read_bytes()
    main_text = main_raw.decode("utf-8", errors="replace")
    guard1_raw = (final_attempt_path / "commands/09_guard_stat_w_1.stdout.bin").read_bytes()
    guard33_raw = (final_attempt_path / "commands/10_guard_stat_w_33.stdout.bin").read_bytes()
    guard1_text = guard1_raw.decode("utf-8", errors="replace")
    guard33_text = guard33_raw.decode("utf-8", errors="replace")

    pre = load_json(BASE / "pre_fix_qualification.json")
    post = load_json(BASE / "post_fix_qualification.json")
    pre_main_accepted = sum(1 for item in pre["main_feedback_negatives"] if item["accepted"])
    pre_current_accepted = sum(1 for item in pre["current21_adapted_negatives"] if item["accepted"])
    pre_guard_accepted = sum(1 for item in pre["guard_negative_probes"] if item["accepted"])
    post_negatives = (
        post["historical_feedback_negatives"]
        + post["current21_targeted_negatives"]
        + post["guard_targeted_negatives"]
    )
    if not all(item["accepted"] for item in post["positive_controls"]):
        raise RuntimeError("post-fix positive control failed")
    if any(item["accepted"] for item in post_negatives):
        raise RuntimeError("post-fix negative control was accepted")
    if not all(post["verdict"].values()):
        raise RuntimeError("post-fix verdict is not complete")

    current_turn = current_turn_row()
    if current_turn["turn_id"] != "01a169b4-7e79-72b3-b5da-13ec240ce486":
        raise RuntimeError("unexpected actual current turn: " + current_turn["turn_id"])

    source_parser = WORKTREE / "competition/deepeye/fpga/transport/deepeye_wire_parser.sv"
    source_tb = WORKTREE / "competition/deepeye/tests/rtl/transport/tb_wire_parser.sv"
    source_crc = WORKTREE / "competition/deepeye/fpga/transport/deepeye_crc16_byte.sv"
    source_runner = WORKTREE / "competition/deepeye/tools/transport/run_wire_parser.py"
    candidate_doc = WORKTREE / "competition/deepeye/fpga/transport/wire_parser_candidate.md"
    expected_pins = {
        "parser": "7806c5d08785b96eae3708d9fd6d6002ef82faa4416a1f7244da73bece552649",
        "tb": "c849fb953ae0b7b7101d897a2351e6623b8c3cafecd074fd75d05d0650e09d61",
        "crc": "8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f",
    }
    actual_pins = {
        "parser": file_record(source_parser)["sha256"],
        "tb": file_record(source_tb)["sha256"],
        "crc": file_record(source_crc)["sha256"],
    }
    if actual_pins != expected_pins:
        raise RuntimeError("read-only RTL/TB/CRC pin changed: %r" % actual_pins)

    wrong_scope_attempt = attempt_record(ATTEMPTS / "runner-repair2-process-failure-20261023T170919.479295Z-pid18324")
    nonzero_attempt = attempt_record(ATTEMPTS / "runner-repair2-process-failure-02-20261023T170925.370575Z-pid51104")
    timeout_attempt = attempt_record(ATTEMPTS / "runner-repair2-timeout-01-20261023T171016.478526Z-pid33592")
    nonzero_command = next(command for command in nonzero_attempt["commands"] if command["name"] == "vlog_version")
    timeout_command = next(command for command in timeout_attempt["commands"] if command["name"] == "vlib_work")
    if nonzero_command["actual_exit"] != 1 or nonzero_command["expected_exit"] != 0:
        raise RuntimeError("nonzero process test did not observe the expected exit mismatch")
    if not timeout_command["timed_out"] or timeout_command["actual_exit"] is not None:
        raise RuntimeError("timeout process test did not record a timeout")

    runner_invocation = {
        "argv": [
            str(Path(os.sys.executable)),
            "-X", "utf8",
            str(source_runner),
            "--label", "runner-repair2-final-01",
            "--modelsim-bin", "D:\\modelsim1\\win64",
            "--scope-file", str(SCOPE_PATH),
            "--timeout", "180",
            "--thread-id", THREAD_ID,
            "--turn-id", "01a169b4-7e79-72b3-b5da-13ec240ce486",
            "--parent-thread-id", PARENT_THREAD_ID,
            "--parent-turn-id", PARENT_TURN_ID,
        ],
        "cwd": str(WORKTREE),
        "actual_exit": 0,
        "stdout": file_record(BASE / "runner_final_cli-01/stdout.bin"),
        "stderr": file_record(BASE / "runner_final_cli-01/stderr.bin"),
    }

    result = {
        "schema": 1,
        "result_type": "author_runner_repair2_qualification",
        "created_utc": utc_now(),
        "task": {
            "task_id": "DEEPEYE-IMPLEMENTATION-20261014/v1",
            "work_id": "B-WIRE-PARSER-RUNNER-QUALIFY-20261024-29-r2",
            "operation_id": "B-DEEPEYE-WIRE-PARSER-20261024-29",
            "child_thread_id": THREAD_ID,
            "child_turn_id": current_turn["turn_id"],
            "child_turn_status_at_result_creation": current_turn["status"],
            "child_turn_metadata_source": current_turn["source"],
            "parent_thread_id": PARENT_THREAD_ID,
            "parent_turn_id": PARENT_TURN_ID,
            "main_acceptance_owner": PARENT_THREAD_ID,
        },
        "scope": {
            "path": str(SCOPE_PATH),
            "sha256": scope_hash,
            "expected_sha256": SCOPE_SHA256,
            "verified": True,
            "prior_scope": file_record(Path("D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/wire-parser-20261024-29/SCOPE.md")),
            "repair1_scope": file_record(Path("D:/pynq/CarlandFPGA/.local/deployment/node-b/evidence/wire-parser-20261024-29/REPAIR1.md")),
        },
        "human_lock": contract,
        "workspace": {
            "root": str(WORKTREE),
            "head": "11e24d80ebf2acf822a7b45d3c3c346eb2a4d7cc",
            "head_is_context_only": True,
            "frozen_design_commit": "1011259415a0916054eb580687612580bc1e5f09",
            "tracked_status_was_preexisting": True,
            "main_tests_or_oracles_read": False,
            "only_main_feedback_path_read": "competition/deepeye/evidence/transport/wire-parser-20261024-29/main/runner-negative-01",
            "serializer_rx_tx_files_read": False,
        },
        "source_pins": {
            "read_only": {
                "parser_sha256": actual_pins["parser"],
                "tb_sha256": actual_pins["tb"],
                "crc_sha256": actual_pins["crc"],
                "expected": expected_pins,
                "unchanged": True,
            },
            "owned": {
                "runner": file_record(source_runner),
                "candidate_note": file_record(candidate_doc),
            },
        },
        "prior_results_preserved": {
            "original_result": file_record(AUTHOR / "RESULT.json"),
            "repair1_result": file_record(AUTHOR / "REPAIR1_RESULT.json"),
            "unchanged": True,
        },
        "pre_fix_reproduction": {
            "result_json": file_record(BASE / "pre_fix_qualification.json"),
            "verdict": pre["verdict"],
            "historical_original_runner": file_record(BASE / "inputs/original_runner_a3ba.py"),
            "current_prefix_runner": file_record(BASE / "inputs/pre_fix_runner_5d09.py"),
            "main_feedback_negatives_accepted": "%d/%d" % (pre_main_accepted, len(pre["main_feedback_negatives"])),
            "current21_adapted_negatives_accepted": "%d/%d" % (pre_current_accepted, len(pre["current21_adapted_negatives"])),
            "guard_negative_probes_accepted": "%d/%d" % (pre_guard_accepted, len(pre["guard_negative_probes"])),
            "required_six_historical_red_reproduced": pre["verdict"]["historical_original_accepts_all_six_negatives"],
            "required_six_current21_red_reproduced": pre["verdict"]["prefix_current_accepts_all_six_adapted_negatives"],
            "harness_failure_attempt": cli_record(
                "pre_fix_harness_first_attempt", BASE / "pre_fix_cli", 1,
                "Preserved harness bug: the case-name replacement matched three rows and stopped before classification.",
            ),
            "successful_attempt": cli_record("pre_fix_harness_success", BASE / "pre_fix_cli-02", 0),
        },
        "post_fix_qualification": {
            "result_json": file_record(BASE / "post_fix_qualification.json"),
            "verdict": post["verdict"],
            "positive_controls": len(post["positive_controls"]),
            "historical_negatives_rejected": "%d/%d" % (
                sum(1 for item in post["historical_feedback_negatives"] if not item["accepted"]),
                len(post["historical_feedback_negatives"]),
            ),
            "current21_targeted_negatives_rejected": "%d/%d" % (
                sum(1 for item in post["current21_targeted_negatives"] if not item["accepted"]),
                len(post["current21_targeted_negatives"]),
            ),
            "guard_targeted_negatives_rejected": "%d/%d" % (
                sum(1 for item in post["guard_targeted_negatives"] if not item["accepted"]),
                len(post["guard_targeted_negatives"]),
            ),
            "cli_attempt": cli_record("post_fix_harness", BASE / "post_fix_cli-01", 0),
        },
        "actual_modelsim_cli": {
            "fresh_attempt": final_attempt,
            "outer_invocation": runner_invocation,
            "simulator": "ModelSim SE-64 10.7",
            "main_protocol_counts": {
                "case_begin": main_text.count("WIRE_PARSER_CASE_BEGIN|"),
                "case_checks": main_text.count("WIRE_PARSER_CASE_CHECKS|"),
                "case_end": main_text.count("WIRE_PARSER_CASE_END|"),
                "summary": main_text.count("WIRE_PARSER_SUMMARY|"),
                "all_pass": main_text.count("WIRE_PARSER_ALL_PASS"),
                "final_zero_tally": main_text.count("Errors: 0, Warnings: 0"),
            },
            "guard1_protocol_counts": {
                "required_fatal": guard1_text.count("** Fatal: deepeye_wire_parser: STAT_W out of range"),
                "final_tally": guard1_text.count("Errors: 1, Warnings: 0"),
                "wire_parser_marker_lines": guard1_text.count("WIRE_PARSER_"),
            },
            "guard33_protocol_counts": {
                "required_fatal": guard33_text.count("** Fatal: deepeye_wire_parser: STAT_W out of range"),
                "final_tally": guard33_text.count("Errors: 1, Warnings: 0"),
                "wire_parser_marker_lines": guard33_text.count("WIRE_PARSER_"),
            },
            "inherited_home_verified": final_attempt["environment"]["HOME"] == os.environ.get("HOME"),
            "home_directory_created_in_attempt": (final_attempt_path / "home").exists(),
            "temp_and_cache_inside_attempt": all(
                final_attempt["environment"][name].startswith(str(final_attempt_path))
                for name in ("TEMP", "TMP", "TMPDIR", "MODELSIM_TMPDIR", "XDG_CACHE_HOME", "PYTHONPYCACHEPREFIX")
            ),
        },
        "process_failure_qualification": {
            "wrong_scope_preserved_failure": {
                "outer_cli": cli_record("process_failure_wrong_scope", BASE / "process_failure_cli", 1),
                "attempt": wrong_scope_attempt,
                "expected": "FAIL before tools because the deliberately wrong scope path does not exist",
            },
            "nonzero_child_exit": {
                "outer_cli": cli_record("process_failure_nonzero", BASE / "process_failure_cli-02", 1),
                "attempt": nonzero_attempt,
                "observed_exit": nonzero_command["actual_exit"],
                "expected_exit": nonzero_command["expected_exit"],
                "result": "FAIL closed",
            },
            "timeout": {
                "outer_cli": cli_record("timeout_child", BASE / "timeout_cli-01", 1),
                "attempt": timeout_attempt,
                "observed_timed_out": timeout_command["timed_out"],
                "timeout_seconds": timeout_command["timeout_seconds"],
                "result": "FAIL closed",
                "probe_source": file_record(BASE / "timeout-tool/Program.cs"),
                "compiled_probe": file_record(BASE / "timeout-tool/ModelSimHangProbe.exe"),
                "compile_failure_preserved": cli_record(
                    "csc_first_attempt", BASE / "timeout-tool", 1,
                    "Malformed /out argument; no runner attempt started.",
                    stdout_name="csc.stdout.bin", stderr_name="csc.stderr.bin",
                ),
                "compile_success": cli_record(
                    "csc_second_attempt", BASE / "timeout-tool", 0,
                    stdout_name="csc-02.stdout.bin", stderr_name="csc-02.stderr.bin",
                ),
            },
        },
        "raw_evidence": {
            "inputs": inventory(BASE / "inputs"),
            "mutations": inventory(BASE / "mutations"),
            "qualification_script": file_record(BASE / "qualify_runner.py"),
            "result_builder": file_record(BASE / "build_result.py"),
            "result_assembly_attempts": {
                "failed_missing_author_path": cli_record(
                    "result_builder_first_attempt", BASE / "result_build_cli-01", 1,
                    "AUTHOR path was one directory too high; stopped before writing the final result.",
                ),
                "failed_missing_timeout_field": cli_record(
                    "result_builder_second_attempt", BASE / "result_build_cli-02", 1,
                    "Command summary omitted timeout_seconds; stopped before writing the final result.",
                ),
                "successful_draft": cli_record("result_builder_third_attempt", BASE / "result_build_cli-03", 0),
            },
        },
        "claims": {
            "runner_only_qualification": "PASS",
            "historical_18case_positive": "PASS",
            "current_21case_positive": "PASS",
            "current_guard1_and_guard33": "PASS",
            "nonzero_child_fail_closed": "PASS",
            "timeout_child_fail_closed": "PASS",
            "all29": "not_run",
            "b04": "not_run",
            "r03": "not_run",
            "full_product": "not_run",
            "synthesis": "not_run",
            "implementation": "not_run",
            "timing": "not_run",
            "cdc_rdc": "not_run",
            "board": "not_run",
            "system": "not_run",
        },
        "authority_boundary": {
            "main_sole_acceptance_owner": PARENT_THREAD_ID,
            "a_alone_operates_board": True,
            "out_valid_is_syntactic_candidate_only": True,
            "semantic_profile_source_boot_ttl_motion_authority": False,
            "no_commit_push_peer_group_sql_queue_service_config_credentials_or_board_action": True,
            "no_rtl_tb_crc_serializer_main_fixture_or_oracle_edits": True,
        },
        "blockers": [],
    }
    output = AUTHOR / "RUNNER_REPAIR2_RESULT.json"
    temporary = output.with_name(output.name + ".tmp")
    temporary.write_bytes((json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) + "\n").encode("utf-8"))
    temporary.replace(output)
    print(str(output))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
