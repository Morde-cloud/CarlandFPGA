# Operation29: bounded byte-level version3 frame parser candidate

Task DEEPEYE-IMPLEMENTATION-20261014/v1; work B-WIRE-PARSER-20261024-29-v1;
operation B-DEEPEYE-WIRE-PARSER-20261024-29. Sole main
01a13b55-095b-7461-8dd5-5476a130bd82/turn01a16933-edc1-7022-8e5f-25b4561a4ea5.
Base local dfdb2b8120793ba816fd09cd8fc255953bbf73ac, new unowned paths; prior
25/26/27 author jobs actually terminal. Serializer is independently owned.

First read full H01-H15 DEEPEYE-HUMAN-LOCK-20261014/revision1 at
f5989cd5defce561f9ba98e6b18fc2682945f0a2 and verify requirements SHA256
c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804.
Frozen design1011259415a0916054eb580687612580bc1e5f09. Board A-only.

Read-only local main-accepted CRC primitive
competition/deepeye/fpga/transport/deepeye_crc16_byte.sv
SHA2568594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f,
verified16777216binary pairs+3compiled mutants, publication pending.
Do not change CRC/UART/serializer/shared-schema. This parser checks only byte
layout/version/length/CRC, treats type/epoch/seq/tick as opaque. It cannot
authenticate, approve profile/source/BOOT/TTL, authorize motion or freeze ABI.
Actual packet semantic acceptance remains A/public runtime responsibility.

Module deepeye_wire_parser, STAT_W32 legal2..32, safe width clamp then own
timezero fatal "deepeye_wire_parser: STAT_W out of range". Ports clk,rst,cancel;
in_valid,in_ready,in_data[7:0]; out_valid,out_ready,out_type[7:0],out_epoch[7:0],
out_seq[15:0],out_tick[31:0],out_len[5:0],out_payload[255:0]; receiving,
error_event,error_code[1:0]; stat_bytes,stat_frames,stat_retired,stat_version,
stat_length,stat_crc,stat_aborted (STAT_W saturating counters).

One bounded32byte payload register array, reused as completed output storage;
finite header/CRC state only. in_ready=!rst&&!cancel&&!completed_slot, no input
accepted on same edge an old completed slot retires. out_valid gated abort,
stalled full descriptor/payload stays byte-for-byte stable; unused payload lanes
zero. Payload bytei at bits8*i+:8. No new packet can overwrite a pending one.

Search A5 then5A. In SEARCH, unrelated bytes ignored; A5 starts a partial prefix.
In WAIT_5A, A5 retains prefix,5A enters VERSION, otherbyte returns SEARCH.
VERSION must3 else errorcode1/stat_version; resync by treating only the current
rejected byte as A5 prefix if equalA5, else SEARCH. Following bytes TYPE(any),
LEN(0..32), EPOCH, SEQlo,SEQhi,TICKlo,TICK8,TICK16,TICKhi, payloadLEN, CRClo,
CRChi. InvalidLEN>32 errorcode2/stat_length, same one-byte resync rule. CRC16
CCITT-FALSE startsFFFF and covers VERSION through payload inclusive; excludes
magic and two CRC bytes. One unchanged CRC primitive instance, update only
accepted covered bytes. Compare received little-endian CRC on accepted CRChi.
Mismatch code3/stat_crc, apply same one-current-byte resync; do not search
inside buffered rejected contents. Match creates completed output on following
cycle, stat_frames++, receivingfalse; never same-edge output retirement.
No earlier or partial output. After completion parse state SEARCH but input
paused while completed output retained; after retirement parsing may resume.

receiving means any partial prefix/candidate (state!=SEARCH), excluding pending
completed output. error_event pulses one ordinary cycle, error_code contains
1/2/3 only on event and is0 otherwise; no sticky poison. Accepted byte increments
stat_bytes including noise/error bytes. Correct CRC increments frames; output
handshake increments retired. Cancellation removes any partial prefix or
completed slot, stat_aborted increments1 iff either occupied; these are mutually
exclusive. Synchronous reset>cancel>ordinary, reset clears counters; cancel
preserves others, flushes controls/payload/errors, heldcancel no recount. No
sampling/retirement on abort. Any new candidate payload storage cleared before
fill so unused lanes are zero, not prior-packet bytes.

Storage and consumed-candidate length are bounded (maximum46wirebytes). No
wall-time timeout: stalled physical bytes require external abort/liveness.
Overrun/loss indication from UART must trigger a higher-layer discard; no claim
that this standalone parser can infer lost bytes, reject replay, or control a
device. Its out_valid is only a syntactically well-formed candidate.

Root D:/pynq/CarlandFPGA/.local/worktrees/deepeye-implementation-20261014.
Flash author owns ONLY competition/deepeye-relative fpga/transport/deepeye_wire_parser.sv,
fpga/transport/wire_parser_candidate.md, tests/rtl/transport/tb_wire_parser.sv,
tools/transport/run_wire_parser.py,evidence/transport/wire-parser-20261024-29/author/.
Main owns main tests/evidence/handoff/private scope. No main oracle reads; no
serializer author files read/import. No commit/push/peer/group/service/config/
credential/SQL/queue/board. No schema or old module edits.

Author real ModelSim10.7 tests: lengths0..32/allbytes, metadataendian/maxima,
independent stdlib CRC packets, noise/prefix overlap/truncation/corruptversion/
length/CRC and recovery, no inner-buffer rescan, input/output stalls, zero-tail
after32->0/short, reset/cancel everyheader/payload/CRC/slot phase, same-edge
retire-no-credit, smallstats/guards. Main separately freezes byte fixtures and
handshake oracle before source inspection, executes compiled mutants.
Strict portable runner: anchored unique orderedmarkers, per-case checks sum
equals total, complete stats, actual exits/timeouts/diagnostics. GitHEAD and
private scope absence contextonly; exact source snapshots/contract binding.
Keep allfailedattempts/rawcommands/toolversions/hashes, actual thread/turn and
author/RESULT.json. TEMP/TMP/TMPDIR/caches/simulatorcwd in owned directory.
All29/B04/R03/fullproduct/synth/impl/CDC_RDC/board/system not_run. Concrete
[需桌面回合]/[需本人操作] only to parent; no modelpolling/READY/presence reports.
