from pathlib import Path
import hashlib,importlib.util,json,re
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/wire-serializer-20261024-28';D=E/'main/final-audit-01';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def walk(v):
 if isinstance(v,dict):
  yield v
  for x in v.values():yield from walk(x)
 elif isinstance(v,list):
  for x in v:yield from walk(x)
live=P/'fpga/transport/deepeye_wire_serializer.sv';proposal=E/'main/proposal-01/proposed.sv';assert live.read_bytes()==proposal.read_bytes()
result=json.loads((E/'author/REPAIR1_RESULT.json').read_bytes());assert result['status']['author_verification']=='pass'
base=E/('author/attempt-'+result['status']['authoritative_attempt']);summary=json.loads((base/'summary.json').read_bytes());assert summary['passed']
seen={};source_copies=[];pipes={};exceptions=[]
for jf in base.rglob('*.json'):
 if any(n in ('work','temp','tmp','cache','__pycache__') for n in jf.relative_to(base).parts):continue
 data=json.loads(jf.read_bytes())
 for v in walk(data):
  if 'argv' in v and 'stdout_sha256' in v and isinstance(v.get('stdout'),str):
   f=Path(v['stdout']);assert f.resolve().is_relative_to(base.resolve());seen[str(f)]=v
   assert not v.get('timed_out') and not v.get('process_error')
   for tag in ('stdout','stderr'):
    p=Path(v[tag]);assert sha(p)==v[tag+'_sha256'];pipes[str(p.relative_to(base))]=sha(p)
   code=v.get('exit_code',v.get('returncode'))
   if code!=0:
    assert Path(v['argv'][0]).name.lower()=='vlib.exe' and '-version' in v['argv'];exceptions.append({'argv':v['argv'],'exit':code})
paths=[P/f'fpga/transport/{n}' for n in ('deepeye_wire_serializer.sv','wire_serializer_candidate.md','deepeye_crc16_byte.sv')]+[P/'tests/rtl/transport/tb_wire_serializer.sv',P/'tools/transport/run_wire_serializer.py']
expected={p.name:sha(p) for p in paths}
for p in (base/'inputs').rglob('*'):
 if p.is_file() and p.name in expected:assert sha(p)==expected[p.name];source_copies.append(str(p.relative_to(base)))
assert len(source_copies)>=4 and len(seen)>=6
runner=P/'tools/transport/run_wire_serializer.py';spec=importlib.util.spec_from_file_location('final_ser_runner',runner);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
good=next(Path(v['stdout']) for v in seen.values() if b'TB_END pass' in Path(v['stdout']).read_bytes());text=good.read_text(encoding='utf-8');raw=text.encode();(D/'saved-positive.log').write_bytes(raw)
lines=text.splitlines();end=next(x for x in lines if x=='# TB_END pass');summaryline=next(x for x in lines if x.startswith('# TB_SUMMARY'));caseline=next(x for x in lines if x.startswith('# CASE_END'));statline=next(x for x in lines if x.startswith('# TB_STAT'))
cases={'positive':text,'early_end':'\n'.join([end]+[x for x in lines if x!=end]),'early_summary':'\n'.join([summaryline]+[x for x in lines if x!=summaryline]),'duplicate_end':text+'\n'+end,'substring_only_end':text.replace(end,'# NOT_TB_END pass'),'duplicate_stats':text+'\n'+statline,'changed_stats':text.replace(statline,statline+'9'),'changed_casecount':text.replace(caseline,re.sub(r'checks=\d+', 'checks=1',caseline)),'conflicting_summary':text+'\n'+summaryline+' trailing','nonzero_tally':'# Errors: 1, Warnings: 0\n'+text,'warning':'# ** Warning: test warning\n'+text,'fatal':text+'\n# ** Fatal: injected','missing_case':text.replace(caseline,''),'unknown_marker':text+'\n# TB_EXTRA pass'}
probes=[]
for name,t in cases.items():
 f=D/(name+'.log');f.write_bytes(t.encode());error=None
 try:accepted=mod.parse_simulation({},t.encode())
 except Exception as e:accepted=False;error=repr(e)
 probes.append({'name':name,'accepted':accepted,'expected':name=='positive','sha256':sha(f),'error':error});assert accepted==(name=='positive'),name
mainruns=[]
for p in [E/'main/proposal-01'/x/'RESULT.json' for x in ('vector32','vector2','guard0','guard1','guard33','wrong_seed','ignore_last','advance_stall')]+[E/'main/final-vector32-01/RESULT.json']:
 d=json.loads(p.read_bytes());assert d['accepted']
 for c in d['commands']:
  assert c['returncode']==0 and not c['timeout']
  for tag in ('stdout','stderr'):assert sha(p.parent/(c['name']+'.'+tag+'.bin'))==c[tag+'_sha256']
 for name,inp in d['inputs'].items():assert sha(p.parent/name)==inp['sha256']
 mainruns.append({'path':str(p.relative_to(E)),'sha256':sha(p),'mode':d['mode'],'commands':len(d['commands'])})
decision={'accepted_bounded_serializer':True,'rtl_identical_to_independently_tested_private_proposal':True,'final_sources':{str(p.relative_to(W)):sha(p) for p in paths},'final_author_cases':11,'final_author_checks':20013,'author_unique_processes':len(seen),'author_raw_pipes':pipes,'version_probe_exceptions':exceptions,'source_copies_verified':source_copies,'main_cycles':21948+21667,'main_port_checks':658440+650010,'main_guards':3,'compiled_behavioral_mutants':3,'final_positive_confirmation_extra':1,'main_runs':mainruns,'runner_probes':probes,'author_self_recheck_is_not_independent':True,'formal':'All29/B04/R03/fullproduct/synth/impl/timing/CDC_RDC/board/system not_run'}
(D/'RESULT.json').write_text(json.dumps(decision,indent=2)+'\n');print(json.dumps({k:v for k,v in decision.items() if k not in ('final_sources','author_raw_pipes','source_copies_verified','main_runs','runner_probes')}))
