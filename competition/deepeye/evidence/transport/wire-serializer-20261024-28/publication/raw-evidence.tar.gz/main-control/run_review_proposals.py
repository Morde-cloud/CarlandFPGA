"""Main-owned immutable proposal copies; never write author-owned live files."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';E=W/'competition/deepeye';py=R/'.local/venv/Scripts/python.exe'
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
for kind,op,snapshot in [('wire_serializer','wire-serializer-20261024-28','event-repair-01-original'),('wire_parser','wire-parser-20261024-29','status-repair-01-original')]:
 root=E/f'evidence/transport/{op}/main/proposal-01';root.mkdir(exist_ok=False)
 original=(root.parent/snapshot/f'deepeye_{kind}.sv').read_text(encoding='utf-8');proposal=original
 if kind=='wire_serializer':changes=[('assign fault_event = fault_event_q && !rst && !cancel;','assign fault_event = fault_event_q;')]
 else:changes=[('assign receiving = !rst && !cancel && !completed_slot_q && (state_q != S_SEARCH);','assign receiving = !completed_slot_q && (state_q != S_SEARCH);'),('assign error_event = error_event_q && !rst && !cancel;','assign error_event = error_event_q;')]
 for a,b in changes:assert proposal.count(a)==1;proposal=proposal.replace(a,b)
 rtl=root/'proposed.sv';rtl.write_text(proposal,encoding='utf-8',newline='\n');put(root/'PROPOSAL.json',{'original_sha256':sha((root.parent/snapshot/f'deepeye_{kind}.sv').read_bytes()),'proposal_sha256':sha(rtl.read_bytes()),'changes':changes,'scope':'private proposed synchronous status correction, author final not yet accepted'})
 results=[]
 def run(label,src,stat=32,mode='positive'):
  out=root/label;argv=[str(py),'-B','-X','utf8',str(E/'tools/transport/main_verify_wire.py'),'--rtl',str(src),'--core',str(E/'fpga/transport/deepeye_crc16_byte.sv'),'--tb',str(E/f'tests/rtl/transport/main_tb_{kind}.sv'),'--vectors',str(E/f'evidence/transport/{op}/main/vectors-stat{stat if mode!="guard" else 32}-01'),'--out',str(out),'--mode',mode,'--stat',str(stat)]
  p=subprocess.run(argv,capture_output=True);(root/(label+'.stdout.bin')).write_bytes(p.stdout);(root/(label+'.stderr.bin')).write_bytes(p.stderr)
  result=json.loads((out/'RESULT.json').read_bytes());rec={'label':label,'exit':p.returncode,'accepted':result['accepted'],'stdout_sha256':sha(p.stdout),'stderr_sha256':sha(p.stderr),'counterexamples':result.get('numeric_counterexamples',[])};results.append(rec);put(root/'PROGRESS.json',results);print(json.dumps({'kind':kind,**rec}),flush=True);assert p.returncode==0 and result['accepted']
 for s in (32,2):run('vector'+str(s),rtl,s)
 for s in (0,1,33):run('guard'+str(s),rtl,s,'guard')
 if kind=='wire_serializer':mutations=[('wrong_seed',"16'hFFFF","16'h0000",3),('ignore_last',"if (p_last != (payload_index_q == (len_q - 6'd1)))","if (1'b0)",1),('advance_stall','if (out_ready)',"if (1'b1)",1)]
 else:mutations=[('crc_bypass','if (crc_q == {in_data, crc_lo_q})',"if (1'b1)",1),('prefix_reset','else if (in_data != MAGIC_A5)',"else if (1'b1)",1),('overwrite_pending','assign in_ready = !rst && !cancel && !completed_slot_q;','assign in_ready = !rst && !cancel;',1)]
 for label,a,b,count in mutations:
  assert proposal.count(a)==count,(label,proposal.count(a));data=proposal.replace(a,b);f=root/(label+'.sv');f.write_text(data,encoding='utf-8',newline='\n');run(label,f,32,'mutant')
 put(root/'RESULT.json',{'accepted_private_proposal':True,'results':results,'proposal_sha256':sha(rtl.read_bytes()),'no_author_live_files_written':True,'formal':'all29 and fullproduct not_run'})
