#!/usr/bin/env python3
"""Build the evidence result for the bounded TX runner repair."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path


EXPECTED_REQUIREMENTS_SHA256 = (
    "c229834bfc2292f5fe4411fc9f12c68487008f9d1adaf31f0144ee7a98173804"
)
PINNED_COMMIT = "f5989cd5defce561f9ba98e6b18fc2682945f0a2"
DESIGN_COMMIT = "1011259415a0916054eb580687612580bc1e5f09"
ORIGINAL_RUNNER_SHA256 = "eb4b947dbcbbd292fb707d6ffd5dddbfa17957e72191c4674b849bb291567127"
EXPECTED_PINS = {
    "rtl": "4998acb76fed7e53405816c91203bc93df622f05b621da342e1cc8178f51133d",
    "tb": "9f90c6adf45135e23c391b6fe32a4243225763f9b0d89150177e7edd142c5a48",
    "candidate": "f454de825ed68814562309114b2b114fcac13131af05400f9c0dc27646222618",
    "serializer": "efc6082f6f5dff215b100f718b12d87d4c6467db7b968a24f846802dc6a19885",
    "crc": "8594bad79593a5ff5a63761c3b4f5f83adc70ebcfdd5aec178de3aba1f313d6f",
    "frame_tx": "83261e4c5a317500e224f5cd0e9ce538f067be24d3957dd98c7116425e706be3",
    "uart_tx": "5076286e4dd1598aeb2c78281bec83020c85d0711dcee9b985088ac707353c47",
}


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def load_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def tree_digest(root: Path) -> dict:
    files = sorted(path for path in root.rglob("*") if path.is_file())
    lines = []
    for path in files:
        relative = path.relative_to(root).as_posix()
        lines.append(f"{relative}\0{sha256_file(path)}\0{path.stat().st_size}\n")
    return {
        "path": str(root.resolve()),
        "file_count": len(files),
        "tree_sha256": sha256_bytes("".join(lines).encode("utf-8")),
    }


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def pin_record(path: Path, expected: str | None = None) -> dict:
    actual = sha256_file(path)
    record = {
        "path": str(path.resolve()),
        "bytes": path.stat().st_size,
        "sha256": actual,
    }
    if expected is not None:
        record["expected_sha256"] = expected
        record["matches_expected"] = actual == expected
        require(actual == expected, f"pin mismatch: {path}")
    return record


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--author-root", required=True, type=Path)
    parser.add_argument("--product-root", required=True, type=Path)
    parser.add_argument("--worktree", required=True, type=Path)
    parser.add_argument("--repair-doc", required=True, type=Path)
    parser.add_argument("--thread-id", required=True)
    parser.add_argument("--turn-id", required=True)
    parser.add_argument("--session-transcript", required=True, type=Path)
    parser.add_argument("--fresh-attempt", required=True, type=Path)
    parser.add_argument("--red-result", required=True, type=Path)
    parser.add_argument("--red-process", required=True, type=Path)
    parser.add_argument("--red-failed-process", required=True, type=Path)
    parser.add_argument("--cli-process", required=True, type=Path)
    parser.add_argument("--qualification-result", required=True, type=Path)
    parser.add_argument("--qualification-process", required=True, type=Path)
    parser.add_argument("--main-negative-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    require(not args.output.exists(), f"output already exists: {args.output}")
    require(os.environ.get("CODEX_THREAD_ID") == args.thread_id, "thread ID mismatch")

    transcript_lines = args.session_transcript.read_text(encoding="utf-8").splitlines()
    turn_record = None
    turn_line_number = None
    turn_line_sha256 = None
    for line_number, line in enumerate(transcript_lines, start=1):
        if not line.strip():
            continue
        record = json.loads(line)
        if record.get("type") == "turn_context":
            turn_record = record
            turn_line_number = line_number
            turn_line_sha256 = sha256_bytes(line.encode("utf-8"))
            break
    require(turn_record is not None, "turn_context record not found")
    require(turn_record["payload"]["turn_id"] == args.turn_id, "turn ID mismatch")
    require(turn_record["payload"]["root_turn_id"] == args.turn_id, "root turn ID mismatch")

    contract_raw = subprocess.run(
        [
            "git",
            "-C",
            str(args.worktree),
            "show",
            f"{PINNED_COMMIT}:docs/competition/deepeye-2026/immutable_scope.json",
        ],
        check=True,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).stdout
    contract = json.loads(contract_raw.decode("utf-8-sig"))
    requirements = contract["requirements"]
    canonical = json.dumps(
        requirements, ensure_ascii=False, sort_keys=True, separators=(",", ":")
    ).encode("utf-8")
    requirements_sha256 = sha256_bytes(canonical)
    require(requirements_sha256 == EXPECTED_REQUIREMENTS_SHA256, "contract hash mismatch")
    require([item["id"] for item in requirements] == [f"H{i:02d}" for i in range(1, 16)], "H01-H15 mismatch")

    design_exists = subprocess.run(
        ["git", "-C", str(args.worktree), "cat-file", "-e", f"{DESIGN_COMMIT}^{{commit}}"],
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).returncode == 0
    design_ancestor = subprocess.run(
        ["git", "-C", str(args.worktree), "merge-base", "--is-ancestor", DESIGN_COMMIT, "HEAD"],
        check=False,
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
    ).returncode == 0
    require(design_exists and design_ancestor, "design anchor check failed")

    fresh_summary_path = args.fresh_attempt / "summary.json"
    fresh = load_json(fresh_summary_path)
    require(fresh["status"] == "pass", "fresh CLI did not pass")
    require(fresh["positive"]["summary"] == {"cases": 16, "pass": 16, "fail": 0, "checks": 6280}, "fresh summary mismatch")
    require(fresh["source_unchanged_after_run"] is True, "source changed during fresh run")

    source_paths = {
        "runner": args.product_root / "tools/transport/run_wire_uart_tx.py",
        "candidate": args.product_root / "fpga/transport/wire_uart_tx_candidate.md",
        "rtl": args.product_root / "fpga/transport/deepeye_wire_uart_tx.sv",
        "tb": args.product_root / "tests/rtl/transport/tb_wire_uart_tx.sv",
        "serializer": args.product_root / "fpga/transport/deepeye_wire_serializer.sv",
        "crc": args.product_root / "fpga/transport/deepeye_crc16_byte.sv",
        "frame_tx": args.product_root / "fpga/transport/deepeye_uart_frame_tx.sv",
        "uart_tx": args.product_root / "fpga/transport/deepeye_uart_tx.sv",
    }
    source_hashes = {
        name: pin_record(path, EXPECTED_PINS.get(name))
        for name, path in source_paths.items()
    }
    require(
        source_hashes["runner"]["sha256"] == fresh["sources"]["runner"]["sha256"],
        "live runner differs from fresh-run snapshot",
    )
    for name in ("candidate", "rtl", "tb"):
        require(
            source_hashes[name]["sha256"] == fresh["sources"][name]["sha256"],
            f"live {name} differs from fresh-run snapshot",
        )

    original_runner = args.author_root / "runner-repair1-qualification/original-runner-snapshot.py"
    original_runner_record = pin_record(original_runner, ORIGINAL_RUNNER_SHA256)

    red = load_json(args.red_result)
    require(red["defect_count"] == 7, "red defect count is not seven")
    require(red["all_seven_red_classes_reproduced"] is True, "red reproduction incomplete")
    red_process = load_json(args.red_process)
    require(red_process["exit_code"] == 0, "red reproduction process failed")

    cli_process = load_json(args.cli_process)
    require(cli_process["exit_code"] == 0, "fresh CLI process failed")
    require(cli_process["stderr_bytes"] == 0, "fresh CLI stderr not empty")

    qualification = load_json(args.qualification_result)
    require(qualification["summary"]["all_passed"] is True, "qualification failed")
    require(qualification["summary"]["total"] == 62, "qualification total mismatch")
    qualification_process = load_json(args.qualification_process)
    require(qualification_process["exit_code"] == 0, "qualification process failed")

    command_records = []
    for command in fresh["commands"]:
        stdout_path = Path(command["stdout_path"])
        stderr_path = Path(command["stderr_path"])
        require(sha256_file(stdout_path) == command["stdout_sha256"], f"stdout hash drift: {command['name']}")
        require(sha256_file(stderr_path) == command["stderr_sha256"], f"stderr hash drift: {command['name']}")
        command_records.append(command)

    original_result = args.author_root / "RESULT.json"
    original_attempts = {
        path.name: tree_digest(path)
        for path in sorted(args.author_root.glob("attempt-*"))
        if path.name in {"attempt-01-smoke", "attempt-02-smoke", "attempt-03-smoke", "attempt-04-smoke", "attempt-05-final"}
    }
    main_feedback = {
        relative: tree_digest(args.main_negative_root / relative)
        for relative in ("runner-negative-02", "runner-order-negative-03")
    }

    result = {
        "schema": "deepeye-wire-uart-tx-runner-repair1-result/v1",
        "generated_utc": utc_now(),
        "task": {
            "task_id": "DEEPEYE-IMPLEMENTATION-20261014",
            "task_version": 1,
            "work_id": "B-WIRE-UART-TX-RUNNER-QUALIFY-20261024-30-r1",
            "original_work_id": "B-WIRE-UART-TX-20261024-30-v1",
            "operation_id": "B-DEEPEYE-WIRE-UART-TX-20261024-30",
            "status": "pass_runner_only_parent_acceptance_pending",
            "main_acceptance_withheld": True,
            "ready_signal_emitted": False,
        },
        "acceptance_owner": {
            "thread_id": "01a13b55-095b-7461-8dd5-5476a130bd82",
            "turn_id": "01a16933-edc1-7022-8e5f-25b4561a4ea5",
            "decision_made_by_author": False,
        },
        "actual_execution": {
            "thread_id": args.thread_id,
            "turn_id": args.turn_id,
            "root_turn_id": turn_record["payload"]["root_turn_id"],
            "model": turn_record["payload"]["model"],
            "effort": turn_record["payload"]["effort"],
            "approval_policy": turn_record["payload"]["approval_policy"],
            "session_transcript": str(args.session_transcript.resolve()),
            "turn_context_line_number": turn_line_number,
            "turn_context_line_sha256": turn_line_sha256,
            "identity_note": "Read-only Codex session turn_context record; no SQL, queue, service or controller state read.",
        },
        "repair_scope": pin_record(args.repair_doc),
        "contract": {
            "pinned_commit": PINNED_COMMIT,
            "requirements_count": len(requirements),
            "requirements_ids": [item["id"] for item in requirements],
            "requirements_sha256": requirements_sha256,
            "expected_requirements_sha256": EXPECTED_REQUIREMENTS_SHA256,
            "matches": True,
            "raw_contract_sha256": sha256_bytes(contract_raw),
        },
        "design_anchor": {
            "commit": DESIGN_COMMIT,
            "exists": design_exists,
            "ancestor_of_head": design_ancestor,
            "workspace_head_context": fresh["workspace"]["head_context"],
            "head_changed": False,
        },
        "source_hashes": source_hashes,
        "original_runner": original_runner_record,
        "red_baseline": {
            "result_path": str(args.red_result.resolve()),
            "result_sha256": sha256_file(args.red_result),
            "defect_count": red["defect_count"],
            "all_seven_classes_accepted_by_original": red["all_seven_red_classes_reproduced"],
            "probes": red["probes"],
            "process": red_process,
        },
        "fresh_cli": {
            "attempt": fresh["attempt"],
            "attempt_path": str(args.fresh_attempt.resolve()),
            "started_utc": fresh["started_utc"],
            "ended_utc": fresh["ended_utc"],
            "summary_path": str(fresh_summary_path.resolve()),
            "summary_sha256": sha256_file(fresh_summary_path),
            "positive_log_path": str((args.fresh_attempt / "vsim-log.txt").resolve()),
            "positive_log_sha256": sha256_file(args.fresh_attempt / "vsim-log.txt"),
            "positive_summary": fresh["positive"]["summary"],
            "case_checks": fresh["positive"]["cases"],
            "expected_stats": fresh["expected_stats"],
            "guards": fresh["guards"],
            "source_unchanged_after_run": fresh["source_unchanged_after_run"],
            "command_count": len(command_records),
            "commands": command_records,
            "process": cli_process,
        },
        "qualification": {
            "result_path": str(args.qualification_result.resolve()),
            "result_sha256": sha256_file(args.qualification_result),
            "summary": qualification["summary"],
            "checks": qualification["checks"],
            "process": qualification_process,
        },
        "preserved_originals": {
            "author_RESULT": pin_record(original_result),
            "author_attempts": original_attempts,
            "main_feedback": main_feedback,
            "path_harness_failure": {
                "name": "red-baseline-01",
                "path": str(args.red_failed_process.parent.resolve()),
                "process": load_json(args.red_failed_process),
                "classification": "harness path failure before parser probes; not an RTL or log-acceptance result",
            },
            "crlf_note": "runner-negative-02 retained its historical duplicate-probe CRLF limitation; runner-order-negative-03 retains the corrected one-row move and all original logs remain unchanged.",
        },
        "isolation": {
            "rtl_edited": False,
            "tb_edited": False,
            "dependency_edited": False,
            "candidate_edited": False,
            "main_oracle_or_other_evidence_content_read": False,
            "other_main_evidence_path_metadata_enumerated": True,
            "allowed_negative_feedback_read": True,
            "qualified_parser_pattern_read": True,
            "rx_read": False,
            "sql_read": False,
            "queue_read": False,
            "commit": False,
            "push": False,
            "peer_or_group_message": False,
            "service_config_credentials_change": False,
            "board_operation": False,
            "home_override": False,
        },
        "limits": {
            "All29": "not_run",
            "B04": "not_run",
            "R03": "not_run",
            "full_product": "not_run",
            "synthesis": "not_run",
            "implementation": "not_run",
            "timing": "not_run",
            "CDC_RDC": "not_run",
            "board": "not_run; machine A alone owns physical board work",
            "system": "not_run",
            "public_ABI_packet_policy_control_policy": "not established",
        },
        "blockers": [],
        "blocker_markers": [],
        "model_polling": False,
        "result_builder": pin_record(Path(__file__).resolve()),
    }
    args.output.write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(
        "status={} reds={} qualification={}/{} fresh_cases={} fresh_checks={}".format(
            result["task"]["status"],
            result["red_baseline"]["defect_count"],
            result["qualification"]["summary"]["passed"],
            result["qualification"]["summary"]["total"],
            result["fresh_cli"]["positive_summary"]["cases"],
            result["fresh_cli"]["positive_summary"]["checks"],
        )
    )
    return 0


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
