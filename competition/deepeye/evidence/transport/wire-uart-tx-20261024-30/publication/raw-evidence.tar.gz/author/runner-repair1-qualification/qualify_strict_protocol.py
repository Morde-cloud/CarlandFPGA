#!/usr/bin/env python3
"""Independently qualify the repaired strict TX log protocol."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import re
import sys
from datetime import datetime, timezone
from pathlib import Path


GUARD_INPUTS = (
    ("guard_clock_hz", "deepeye_wire_uart_tx: CLOCK_HZ out of range"),
    ("guard_baud", "deepeye_wire_uart_tx: BAUD out of range"),
    ("guard_pre_cycles", "deepeye_wire_uart_tx: PRE_CYCLES out of range"),
    ("guard_post_cycles", "deepeye_wire_uart_tx: POST_CYCLES out of range"),
    ("guard_stat_w", "deepeye_wire_uart_tx: STAT_W out of range"),
)


SEVEN_RED_INPUTS = (
    ("warning", "runner-negative-02/warning.log"),
    ("malformed_summary", "runner-negative-02/malformed_summary.log"),
    ("unknown_marker", "runner-negative-02/unknown_marker.log"),
    ("malformed_case", "runner-negative-02/malformed_case.log"),
    ("early_end", "runner-order-negative-03/early_end.log"),
    ("early_summary", "runner-order-negative-03/early_summary.log"),
    ("early_tally", "runner-order-negative-03/early_tally.log"),
)


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def load_runner(path: Path):
    spec = importlib.util.spec_from_file_location("repaired_wire_uart_tx_runner", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load runner: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def observe_positive(module, path: Path, expected_stats: dict[str, int]) -> dict:
    try:
        parsed = module.parse_positive_log(path, expected_stats)
    except Exception as exc:
        return {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}
    return {
        "accepted": True,
        "error": None,
        "summary": parsed["summary"],
        "protocol_rows": len(parsed["protocol_rows"]),
    }


def observe_guard(module, path: Path, expected_message: str) -> dict:
    try:
        parsed = module.parse_guard_log(path, expected_message)
    except Exception as exc:
        return {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}
    return {
        "accepted": True,
        "error": None,
        "fatal_count": parsed["fatal_count"],
        "tally": parsed["tally"],
    }


def replace_once(lines: list[str], old: str, new: str) -> list[str]:
    result = list(lines)
    matches = [index for index, line in enumerate(result) if line == old]
    if len(matches) != 1:
        raise RuntimeError(f"expected exactly one {old!r}, found {len(matches)}")
    result[matches[0]] = new
    return result


def unique_index(lines: list[str], exact: str) -> int:
    matches = [index for index, line in enumerate(lines) if line == exact]
    if len(matches) != 1:
        raise RuntimeError(f"expected exactly one {exact!r}, found {len(matches)}")
    return matches[0]


def swap_case_pairs(lines: list[str], first: str, second: str) -> list[str]:
    first_index = unique_index(lines, f"# CASE_BEGIN name={first}")
    second_index = unique_index(lines, f"# CASE_BEGIN name={second}")
    if second_index != first_index + 2:
        raise RuntimeError("test assumes adjacent case pairs")
    first_pair = lines[first_index : first_index + 2]
    second_pair = lines[second_index : second_index + 2]
    return lines[:first_index] + second_pair + first_pair + lines[second_index + 2 :]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--runner", required=True, type=Path)
    parser.add_argument("--fresh-attempt", required=True, type=Path)
    parser.add_argument("--main-root", required=True, type=Path)
    parser.add_argument("--author-positive", required=True, type=Path)
    parser.add_argument("--original-red-result", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()

    if args.output_dir.exists():
        raise RuntimeError(f"output directory already exists: {args.output_dir}")
    positive_variant_dir = args.output_dir / "variants" / "positive"
    guard_variant_dir = args.output_dir / "variants" / "guard"
    positive_variant_dir.mkdir(parents=True)
    guard_variant_dir.mkdir(parents=True)

    module = load_runner(args.runner.resolve())
    fresh_positive = args.fresh_attempt / "vsim-log.txt"
    manifest = json.loads(
        (args.fresh_attempt / "inputs/vectors/vector-manifest.json").read_text(
            encoding="utf-8"
        )
    )
    expected_stats = module.expected_stat_values(manifest)
    fresh_text = fresh_positive.read_text(encoding="utf-8")
    positive_lines = fresh_text.splitlines()
    tally_line = "# Errors: 0, Warnings: 0"
    tally_index = unique_index(positive_lines, tally_line)
    if tally_index != max(index for index, line in enumerate(positive_lines) if line.strip()):
        raise RuntimeError("fresh positive tally is not the final nonblank line")

    checks: list[dict] = []

    def record(
        family: str,
        name: str,
        path: Path,
        expected_accept: bool,
        observed: dict,
        category: str,
    ) -> None:
        passed = observed["accepted"] is expected_accept
        checks.append(
            {
                "family": family,
                "name": name,
                "path": str(path.resolve()),
                "sha256": sha256_file(path),
                "category": category,
                "expected_acceptance": expected_accept,
                "observed": observed,
                "passed": passed,
            }
        )

    def check_positive_real(name: str, path: Path, expected_accept: bool, category: str) -> None:
        record(
            "positive",
            name,
            path,
            expected_accept,
            observe_positive(module, path, expected_stats),
            category,
        )

    def check_positive_bytes(name: str, data: bytes, expected_accept: bool, category: str) -> None:
        path = positive_variant_dir / f"{name}.log"
        path.write_bytes(data)
        record(
            "positive",
            name,
            path,
            expected_accept,
            observe_positive(module, path, expected_stats),
            category,
        )

    def check_positive_lines(name: str, lines: list[str], expected_accept: bool, category: str) -> None:
        check_positive_bytes(
            name,
            ("\n".join(lines) + "\n").encode("utf-8"),
            expected_accept,
            category,
        )

    check_positive_real("author_real_positive", args.author_positive.resolve(), True, "real_positive")
    check_positive_real("fresh_real_positive", fresh_positive.resolve(), True, "real_positive")
    for name, relative_path in SEVEN_RED_INPUTS:
        check_positive_real(
            f"main_red_{name}",
            (args.main_root / relative_path).resolve(),
            False,
            "main_red_class",
        )

    original_red = json.loads(args.original_red_result.read_text(encoding="utf-8"))
    if original_red.get("defect_count") != 7 or not original_red.get(
        "all_seven_red_classes_reproduced"
    ):
        raise RuntimeError("original red baseline did not record all seven defects")

    summary_line = next(line for line in positive_lines if line.startswith("# TB_SUMMARY "))
    first_case = "# CASE_BEGIN name=initial_reset"
    initial_end = "# CASE_END name=initial_reset status=pass checks=41"
    first_stat = next(line for line in positive_lines if line.startswith("# TB_STAT "))
    second_stat = next(
        line for line in positive_lines if line.startswith("# TB_STAT ") and line != first_stat
    )
    tb_end = "# TB_END pass"

    check_positive_lines(
        "wrong_case_order",
        swap_case_pairs(positive_lines, "initial_reset", "packet_vectors"),
        False,
        "case_order",
    )
    check_positive_lines(
        "missing_case_end",
        [line for line in positive_lines if line != initial_end],
        False,
        "case_completeness",
    )
    check_positive_lines(
        "wrong_case_checks",
        replace_once(
            positive_lines,
            initial_end,
            "# CASE_END name=initial_reset status=pass checks=42",
        ),
        False,
        "case_count",
    )
    check_positive_lines(
        "case_fail_status",
        replace_once(
            positive_lines,
            initial_end,
            "# CASE_END name=initial_reset status=fail checks=41",
        ),
        False,
        "case_status",
    )

    duplicate_end = list(positive_lines)
    duplicate_end.insert(unique_index(duplicate_end, tb_end), tb_end)
    check_positive_lines("duplicate_tb_end", duplicate_end, False, "duplicate_marker")

    unknown_marker = list(positive_lines)
    unknown_marker.insert(tally_index, "# TB_EXTRA pass")
    check_positive_lines("unknown_marker", unknown_marker, False, "unknown_marker")

    suffixed_end = list(positive_lines)
    suffixed_end[unique_index(suffixed_end, initial_end)] += " trailing"
    check_positive_lines("suffixed_case_end", suffixed_end, False, "suffixed_marker")

    malformed_begin = list(positive_lines)
    malformed_begin[unique_index(malformed_begin, first_case)] += " trailing"
    check_positive_lines("malformed_case_begin", malformed_begin, False, "malformed_marker")

    duplicate_summary = list(positive_lines)
    duplicate_summary.insert(unique_index(duplicate_summary, tb_end), summary_line)
    check_positive_lines("duplicate_summary", duplicate_summary, False, "duplicate_summary")

    check_positive_lines(
        "wrong_summary_checks",
        replace_once(positive_lines, summary_line, summary_line[:-1] + "1"),
        False,
        "summary_total",
    )

    swapped_stats = list(positive_lines)
    first_stat_index = unique_index(swapped_stats, first_stat)
    second_stat_index = unique_index(swapped_stats, second_stat)
    swapped_stats[first_stat_index], swapped_stats[second_stat_index] = (
        swapped_stats[second_stat_index],
        swapped_stats[first_stat_index],
    )
    check_positive_lines("stat_reorder", swapped_stats, False, "stat_order")

    stat_match = re.fullmatch(r"# TB_STAT ([a-z0-9_]+)=([0-9]+)", first_stat)
    if stat_match is None:
        raise RuntimeError("cannot mutate first TB_STAT row")
    wrong_stat = f"# TB_STAT {stat_match.group(1)}={int(stat_match.group(2)) + 1}"
    check_positive_lines(
        "stat_wrong_value",
        replace_once(positive_lines, first_stat, wrong_stat),
        False,
        "stat_value",
    )

    duplicate_stat = list(positive_lines)
    duplicate_stat.insert(unique_index(duplicate_stat, first_stat) + 1, first_stat)
    check_positive_lines("duplicate_stat", duplicate_stat, False, "duplicate_stat")

    for name, target_line in (
        ("early_tb_end", tb_end),
        ("early_summary", summary_line),
        ("early_tally", tally_line),
    ):
        moved = list(positive_lines)
        moved.remove(target_line)
        moved.insert(0, target_line)
        check_positive_lines(name, moved, False, "early_marker")

    duplicate_tally = list(positive_lines)
    duplicate_tally.append(tally_line)
    check_positive_lines("duplicate_tally", duplicate_tally, False, "duplicate_tally")

    malformed_tally = list(positive_lines)
    malformed_tally[unique_index(malformed_tally, tally_line)] += " trailing"
    check_positive_lines("malformed_tally", malformed_tally, False, "malformed_tally")

    for name, injected, category in (
        ("injected_warning", "# ** Warning: injected protocol warning", "diagnostic"),
        ("injected_error", "# ** Error: injected protocol error", "diagnostic"),
        ("injected_fatal", "# ** Fatal: injected protocol fatal", "diagnostic"),
    ):
        variant = list(positive_lines)
        variant.insert(0, injected)
        check_positive_lines(name, variant, False, category)

    check_positive_lines(
        "nonzero_tally",
        replace_once(positive_lines, tally_line, "# Errors: 1, Warnings: 0"),
        False,
        "nonzero_tally",
    )
    check_positive_lines(
        "warning_tally",
        replace_once(positive_lines, tally_line, "# Errors: 0, Warnings: 1"),
        False,
        "warning_tally",
    )

    ordinary_note = list(positive_lines)
    ordinary_note.insert(0, "# ** Note: ordinary vendor banner is allowed")
    check_positive_lines("ordinary_vendor_note", ordinary_note, True, "vendor_banner")

    crlf_text = "".join(f"{line}\r\n" for line in positive_lines).encode("utf-8")
    check_positive_bytes("positive_crlf", crlf_text, True, "crlf")

    spaced_dir = positive_variant_dir / "path with spaces"
    spaced_dir.mkdir()
    spaced_path = spaced_dir / "positive with spaces.log"
    spaced_path.write_text(fresh_text, encoding="utf-8")
    check_positive_real("positive_spaced_path", spaced_path, True, "path_with_spaces")

    real_guards: dict[str, tuple[Path, str]] = {}
    for name, expected_message in GUARD_INPUTS:
        path = args.fresh_attempt / f"{name}-log.txt"
        real_guards[name] = (path, expected_message)
        record(
            "guard",
            f"real_{name}",
            path,
            True,
            observe_guard(module, path, expected_message),
            "real_guard",
        )
        record(
            "guard",
            f"positive_parser_rejects_{name}",
            path,
            False,
            observe_positive(module, path, expected_stats),
            "guard_as_positive",
        )

    record(
        "guard",
        "guard_parser_rejects_positive",
        fresh_positive,
        False,
        observe_guard(module, fresh_positive, GUARD_INPUTS[0][1]),
        "positive_as_guard",
    )

    guard_path, guard_message = real_guards["guard_clock_hz"]
    guard_text = guard_path.read_text(encoding="utf-8")
    guard_lines = guard_text.splitlines()
    guard_tally = "# Errors: 1, Warnings: 0"
    guard_fatal = f"# ** Fatal: {guard_message}"
    if unique_index(guard_lines, guard_tally) != max(
        index for index, line in enumerate(guard_lines) if line.strip()
    ):
        raise RuntimeError("guard tally is not the final nonblank line")
    if unique_index(guard_lines, guard_fatal) < 0:
        raise RuntimeError("guard fatal missing")

    def check_guard_lines(name: str, lines: list[str], expected_accept: bool, category: str) -> None:
        path = guard_variant_dir / f"{name}.log"
        path.write_bytes(("\n".join(lines) + "\n").encode("utf-8"))
        record(
            "guard",
            name,
            path,
            expected_accept,
            observe_guard(module, path, guard_message),
            category,
        )

    extra_warning = list(guard_lines)
    extra_warning.insert(unique_index(extra_warning, guard_tally), "# ** Warning: injected warning")
    check_guard_lines("extra_warning", extra_warning, False, "extra_warning")

    extra_error = list(guard_lines)
    extra_error.insert(unique_index(extra_error, guard_tally), "# ** Error: injected error")
    check_guard_lines("extra_error", extra_error, False, "extra_error")

    duplicate_fatal = list(guard_lines)
    duplicate_fatal.insert(unique_index(duplicate_fatal, guard_fatal), guard_fatal)
    check_guard_lines("duplicate_expected_fatal", duplicate_fatal, False, "duplicate_fatal")

    check_guard_lines(
        "wrong_fatal_message",
        replace_once(
            guard_lines,
            guard_fatal,
            "# ** Fatal: deepeye_wire_uart_tx: CLOCK_HZ wrong guard",
        ),
        False,
        "fatal_message",
    )

    dependency_fatal = list(guard_lines)
    dependency_fatal.insert(
        unique_index(dependency_fatal, guard_tally),
        "# ** Fatal: deepeye_wire_serializer: BAUD out of range",
    )
    check_guard_lines("dependency_fatal", dependency_fatal, False, "dependency_guard")

    success_marker = list(guard_lines)
    success_marker.insert(unique_index(success_marker, guard_tally), "# TB_END pass")
    check_guard_lines("success_marker", success_marker, False, "success_marker")

    fallback_marker = list(guard_lines)
    fallback_marker.insert(unique_index(fallback_marker, guard_tally), "# FALLBACK accepted")
    check_guard_lines("fallback_marker", fallback_marker, False, "fallback_marker")

    malformed_guard_tally = list(guard_lines)
    malformed_guard_tally[unique_index(malformed_guard_tally, guard_tally)] += " trailing"
    check_guard_lines("malformed_tally", malformed_guard_tally, False, "malformed_tally")

    early_guard_tally = list(guard_lines)
    early_guard_tally.remove(guard_tally)
    early_guard_tally.insert(0, guard_tally)
    check_guard_lines("early_tally", early_guard_tally, False, "early_tally")

    duplicate_guard_tally = list(guard_lines)
    duplicate_guard_tally.append(guard_tally)
    check_guard_lines("duplicate_tally", duplicate_guard_tally, False, "duplicate_tally")

    check_guard_lines(
        "wrong_error_count",
        replace_once(guard_lines, guard_tally, "# Errors: 2, Warnings: 0"),
        False,
        "error_count",
    )
    check_guard_lines(
        "wrong_warning_count",
        replace_once(guard_lines, guard_tally, "# Errors: 1, Warnings: 1"),
        False,
        "warning_count",
    )

    missing_fatal = [line for line in guard_lines if line != guard_fatal]
    missing_fatal = replace_once(missing_fatal, guard_tally, "# Errors: 0, Warnings: 0")
    check_guard_lines("missing_fatal", missing_fatal, False, "missing_fatal")

    ordinary_guard = list(guard_lines)
    ordinary_guard.insert(0, "# ** Note: ordinary vendor banner is allowed")
    check_guard_lines("ordinary_vendor_note", ordinary_guard, True, "vendor_banner")

    guard_crlf_path = guard_variant_dir / "guard_crlf.log"
    guard_crlf_path.write_bytes(
        "".join(f"{line}\r\n" for line in guard_lines).encode("utf-8")
    )
    record(
        "guard",
        "guard_crlf",
        guard_crlf_path,
        True,
        observe_guard(module, guard_crlf_path, guard_message),
        "crlf",
    )

    guard_spaced_dir = guard_variant_dir / "path with spaces"
    guard_spaced_dir.mkdir()
    guard_spaced_path = guard_spaced_dir / "guard with spaces.log"
    guard_spaced_path.write_text(guard_text, encoding="utf-8")
    record(
        "guard",
        "guard_spaced_path",
        guard_spaced_path,
        True,
        observe_guard(module, guard_spaced_path, guard_message),
        "path_with_spaces",
    )

    failures = [check for check in checks if not check["passed"]]
    result = {
        "schema": "deepeye-wire-uart-tx-runner-repair1-qualification/v1",
        "generated_utc": utc_now(),
        "runner": {"path": str(args.runner.resolve()), "sha256": sha256_file(args.runner)},
        "fresh_attempt": {
            "path": str(args.fresh_attempt.resolve()),
            "summary_sha256": sha256_file(args.fresh_attempt / "summary.json"),
            "positive_sha256": sha256_file(fresh_positive),
        },
        "original_red_baseline": {
            "path": str(args.original_red_result.resolve()),
            "sha256": sha256_file(args.original_red_result),
            "defect_count": original_red["defect_count"],
        },
        "checks": checks,
        "summary": {
            "total": len(checks),
            "passed": len(checks) - len(failures),
            "failed": len(failures),
            "all_passed": not failures,
            "positive_checks": sum(check["family"] == "positive" for check in checks),
            "guard_checks": sum(check["family"] == "guard" for check in checks),
        },
    }
    result_path = args.output_dir / "QUALIFICATION_RESULT.json"
    result_path.write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result["summary"], sort_keys=True))
    return 0 if not failures else 1


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
