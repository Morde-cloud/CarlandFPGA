#!/usr/bin/env python3
"""Reproduce the seven accepted-invalid TX runner log classes."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from datetime import datetime, timezone
from pathlib import Path


NEGATIVES = (
    ("warning", "runner-negative-02/warning.log"),
    ("malformed_summary", "runner-negative-02/malformed_summary.log"),
    ("unknown_marker", "runner-negative-02/unknown_marker.log"),
    ("malformed_case", "runner-negative-02/malformed_case.log"),
    ("early_end", "runner-order-negative-03/early_end.log"),
    ("early_summary", "runner-order-negative-03/early_summary.log"),
    ("early_tally", "runner-order-negative-03/early_tally.log"),
)


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_runner(path: Path):
    spec = importlib.util.spec_from_file_location("original_wire_uart_tx_runner", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot load runner snapshot: {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parse_probe(module, path: Path) -> dict:
    try:
        parsed = module.parse_positive_log(path)
    except Exception as exc:
        return {"accepted": False, "error": f"{type(exc).__name__}: {exc}"}
    return {
        "accepted": True,
        "error": None,
        "summary": parsed["summary"],
        "case_count": len(parsed["cases"]),
        "stat_count": len(parsed["stats"]),
    }


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--original-runner", required=True, type=Path)
    parser.add_argument("--positive", required=True, type=Path)
    parser.add_argument("--negative-root", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()

    module = load_runner(args.original_runner.resolve())
    positive_observation = parse_probe(module, args.positive.resolve())
    probes = []
    for name, relative_path in NEGATIVES:
        path = (args.negative_root / relative_path).resolve()
        observation = parse_probe(module, path)
        probes.append(
            {
                "name": name,
                "path": str(path),
                "sha256": sha256_file(path),
                "expected_acceptance": False,
                "observed": observation,
                "defect_reproduced": observation["accepted"] is True,
            }
        )

    defect_count = sum(1 for probe in probes if probe["defect_reproduced"])
    passed = (
        positive_observation["accepted"] is True
        and len(probes) == 7
        and defect_count == 7
        and all(probe["defect_reproduced"] for probe in probes)
    )
    result = {
        "schema": "deepeye-wire-uart-tx-runner-repair1-red/v1",
        "generated_utc": utc_now(),
        "original_runner": {
            "path": str(args.original_runner.resolve()),
            "sha256": sha256_file(args.original_runner.resolve()),
        },
        "real_positive_baseline": {
            "path": str(args.positive.resolve()),
            "sha256": sha256_file(args.positive.resolve()),
            "observed": positive_observation,
        },
        "negative_feedback_scope": [
            "main/runner-negative-02",
            "main/runner-order-negative-03",
        ],
        "probes": probes,
        "defect_count": defect_count,
        "all_seven_red_classes_reproduced": passed,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8"
    )
    print(json.dumps(result, sort_keys=True, ensure_ascii=False))
    return 0 if passed else 1


if __name__ == "__main__":
    sys.dont_write_bytecode = True
    raise SystemExit(main())
