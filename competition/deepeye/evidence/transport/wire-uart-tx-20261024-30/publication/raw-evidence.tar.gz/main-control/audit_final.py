from pathlib import Path
import hashlib,importlib.util,json,re,sys
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/wire-uart-tx-20261024-30';D=E/'main/final-audit-01';D.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def walk(x):
 if isinstance(x,dict):
  yield x
  for y in x.values():yield from walk(y)
 elif isinstance(x,list):
  for y in x:yield from walk(y)
report=json.loads((E/'author/RUNNER_REPAIR1_RESULT.json').read_bytes());A=Path(report['fresh_cli']['attempt_path']);d=json.loads(Path(report['fresh_cli']['summary_path']).read_bytes());assert d['status']=='pass' or d['status']=='PASS'
refs={};mismatches=[]
for v in walk(report):
 pairs=[(v.get('path'),v.get('sha256'))]+[(v.get(k),v.get(k[:-5]+'_sha256')) for k in v if k.endswith('_path')]+[(v.get('log'),v.get('log_sha256'))]
 for path,h in pairs:
  if not isinstance(path,str) or not isinstance(h,str) or not re.fullmatch('[0-9a-f]{64}',h):continue
  p=Path(path)
  if not p.is_absolute():continue
  assert p.resolve().is_relative_to(R.resolve()),str(p)
  actual=sha(p);refs[str(p)]=actual
  if actual!=h:mismatches.append({'path':str(p),'reported':h,'actual':actual})
put(D/'REFERENCE_HASHES.json',{'files':refs,'mismatches':mismatches})
assert not mismatches,mismatches
commands=[]
for c in d['commands']:
 allowed=1 if c['name']=='tool-versions/vlib.exe' else 0;assert c['exit_code']==allowed and not c['timed_out'] and not c['process_error'];pipes={}
 for tag in ('stdout','stderr','exit','timeout'):
  p=Path(c[tag+'_path']);assert p.resolve().is_relative_to(A.resolve()) and sha(p)==c[tag+'_sha256'];pipes[tag]=sha(p)
 commands.append({'name':c['name'],'actual_exit':c['exit_code'],'pipes':pipes})
for src in d['sources'].values():assert sha(P/src['path'])==src['sha256']==sha(Path(src['snapshot']))
for src in report['source_hashes'].values():assert sha(Path(src['path']))==src['sha256']
assert report['source_hashes']['rtl']['sha256']=='4998acb76fed7e53405816c91203bc93df622f05b621da342e1cc8178f51133d'
runner=P/'tools/transport/run_wire_uart_tx.py';s=importlib.util.spec_from_file_location('main_tx_final_runner',runner);m=importlib.util.module_from_spec(s);sys.modules[s.name]=m;s.loader.exec_module(m)
stats=m.expected_stat_values(json.loads(Path(d['vectors']['manifest']).read_bytes()));assert stats==d['expected_stats'];pos=Path(report['fresh_cli']['positive_log_path']).read_text(encoding='utf-8');protocol=[x for x in pos.splitlines() if m.MARKER_FAMILY_PATTERN.search(x)];assert len(protocol)==56
tests={'positive':pos}
for i,row in enumerate(protocol):
 tests['remove_'+str(i)]=pos.replace(row+'\n','',1);tests['duplicate_'+str(i)]=pos.replace(row,row+'\n'+row,1)
 if i:tests['move_first_'+str(i)]=row+'\n'+pos.replace(row+'\n','',1)
 if 'checks=' in row:
  tests['wrong_checks_'+str(i)]=pos.replace(row,re.sub(r'checks=(\d+)',lambda x:'checks='+str(int(x[1])+1),row),1)
for stem in ('runner-negative-02','runner-order-negative-03'):
 for p in sorted((E/'main'/stem).glob('*.log')):
  if p.name!='positive.log':tests['historical_'+stem+'_'+p.stem]=p.read_text(encoding='utf-8')
tests['extra_warning']='# ** Warning: injected\n'+pos;tests['extra_fatal']=pos+'\n# ** Fatal: unexpected\n';tests['malformed_tally']=pos+'\n# Errors: malformed\n';tests['missing_tally']=pos.replace('# Errors: 0, Warnings: 0','')
probes=[]
for name,text in tests.items():
 p=D/(name+'.log');p.write_text(text,encoding='utf-8',newline='\n')
 try:m.parse_positive_log(p,stats);accepted=True;error=None
 except Exception as e:accepted=False;error=str(e)
 probes.append({'name':name,'accepted':accepted,'expected':name=='positive','sha256':sha(p),'error':error});assert accepted==(name=='positive'),name
for g in d['guards']:
 raw=Path(g['log']).read_text(encoding='utf-8');m.parse_guard_log(Path(g['log']),g['expected_message'])
 for name,extra in [('error','# ** Error: injected\n'),('warning','# ** Warning: injected\n'),('fatal','# ** Fatal: unrelated\n'),('tally','# Errors: 1, Warnings: 0\n'),('success','# TB_END pass\n')]:
  p=D/(g['name']+'_'+name+'.log');p.write_text(extra+raw,encoding='utf-8')
  try:m.parse_guard_log(p,g['expected_message']);accepted=True
  except Exception:accepted=False
  assert not accepted;probes.append({'name':p.stem,'accepted':False,'expected':False,'sha256':sha(p)})
mainruns=[];hashchecks=0
for p in [E/'main'/n/'RESULT.json' for n in ('vector-full-01','vector-fractional-01','vector-default-01','vector-maxguard-01')]+sorted((E/'main/guards-mutants-01').glob('*/RESULT.json')):
 v=json.loads(p.read_bytes());assert v['accepted']
 for c in v['commands']:
  assert c['returncode']==0 and not c['timeout']
  for tag in ('stdout','stderr'):assert sha(p.parent/(c['name']+'.'+tag+'.bin'))==c[tag+'_sha256'];hashchecks+=1
 for n,x in v['inputs'].items():assert sha(p.parent/n)==x['sha256'];hashchecks+=1
 mainruns.append({'path':str(p.relative_to(E)),'sha256':sha(p),'mode':v['mode']})
result={'accepted_bounded_wire_uart_tx':True,'final_author_cases':len(m.EXPECTED_CASE_CHECKS),'final_author_checks':sum(n for _,n in m.EXPECTED_CASE_CHECKS),'author_unique_processes':len(commands),'author_commands':commands,'author_reference_hashes':refs,'main_cycles':5627750,'main_port_checks':135066000,'main_guards':11,'compiled_behavioral_mutants':4,'main_runs':mainruns,'main_raw_hash_checks':hashchecks,'runner_main_probes':probes,'final_sources':report['source_hashes'],'limits':'opaque same-clock digital TX only; vlib-version exit1 retained; all29/B04/R03/fullproduct/synth/impl/timing/CDC_RDC/board/system not_run'}
put(D/'RESULT.json',result);print(json.dumps({'accepted':True,'author_cases':result['final_author_cases'],'author_checks':result['final_author_checks'],'author_processes':len(commands),'references':len(refs),'main_raw_hash_checks':hashchecks,'main_log_probes':len(probes)}))
