from pathlib import Path
import json,hashlib,datetime
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/wire-uart-tx-20261024-30/main'
paths=[P/'tools/transport/main_generate_wire_uart_tx.py',P/'tools/transport/main_verify_wire_uart_tx.py',P/'tests/rtl/transport/main_tb_wire_uart_tx.sv']
for d in sorted(E.glob('vectors-*')):paths += [d/'FREEZE.json',d/'vectors.rle']
assert len(paths)==11
r={'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'task_id':'DEEPEYE-IMPLEMENTATION-20261014','task_version':1,'main_thread':'01a13b55-095b-7461-8dd5-5476a130bd82','main_turn':'01a16933-edc1-7022-8e5f-25b4561a4ea5','author_source_read':False,'files':{p.relative_to(W).as_posix():{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths},'scope':'opaque bytes and absolute same-clock digital timing only; all29/fullproduct not_run'}
with (Path(__file__).parent/'MAIN_PREINSPECTION_FREEZE.json').open('x',encoding='utf-8') as f:json.dump(r,f,indent=2)
print(json.dumps({'at_utc':r['at_utc'],'frozen_files':len(paths),'author_source_read':False}))
