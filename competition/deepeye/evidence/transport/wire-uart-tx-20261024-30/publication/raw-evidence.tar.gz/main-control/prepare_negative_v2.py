from pathlib import Path
P=Path(__file__).parent;s=(P/'reproduce_runner_negatives.py').read_text(encoding='utf-8')
s=s.replace("D=E/'main/runner-negative-01'","D=E/'main/runner-negative-02'")
s=s.replace("good=W/(v['path'] if isinstance(v,dict) else v);raw=good.read_bytes();","good=E/'author'/(v['path'] if isinstance(v,dict) else v);raw=good.read_bytes();assert hashlib.sha256(raw).hexdigest()==r['final_attempt']['positive_log_sha256'];")
with (P/'reproduce_runner_negatives_v2.py').open('x',encoding='utf-8',newline='\n') as f:f.write(s)
