from pathlib import Path
import hashlib,importlib.util,json,datetime
R=Path('D:/pynq/CarlandFPGA');P=R/'.local/worktrees/deepeye-implementation-20261014/competition/deepeye';D=P/'evidence/transport/wire-uart-tx-20261024-30/main/classifier-order-01';D.mkdir(exist_ok=False)
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
recs=[]
for kind in ('wire_uart_tx','uart_wire_rx'):
 p=P/'tools/transport'/('main_verify_'+kind+'.py');b=p.read_bytes();(D/p.name).write_bytes(b);s=b.decode()
 needle=" return {'accepted':bool(code==0 and okay),'numeric_counterexamples':numeric,'markers':markers,'fatals':fatals,'tallies':tallies}"
 assert s.count(needle)==1
 replacement=""" # Bind diagnostics and markers in actual stream order; a single early tally
 # must not be accepted merely because its value is zero.
 protocol=[x for x in lines if 'MAIN_' in x or re.search(r'\\*\\*\\s*(?:Error|Warning|Fatal)|(?:Errors|Warnings)\\s*:',x)]
 if mode=='positive':expected=[begin,stats,'MAIN_PASS','Errors: 0, Warnings: 0']
 elif mode=='mutant':expected=[begin,*numeric,'** Fatal: main numeric mismatch','Errors: 1, Warnings: 0']
 else:expected=[*markers,*fatals,'Errors: 1, Warnings: 0']
 okay=okay and protocol==expected
 return {'accepted':bool(code==0 and okay),'numeric_counterexamples':numeric,'markers':markers,'fatals':fatals,'tallies':tallies,'protocol':protocol}"""
 s=s.replace(needle,replacement);p.write_text(s,encoding='utf-8',newline='\n');recs.append({'kind':kind,'before':sha(b),'after':sha(p.read_bytes())})
runner=P/'tools/transport/main_verify_wire_uart_tx.py';sp=importlib.util.spec_from_file_location('main_strict',runner);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
E=P/'evidence/transport/wire-uart-tx-20261024-30/main';results=[]
for result in sorted(E.rglob('RESULT.json')):
 if result.parent==D:continue
 d=json.loads(result.read_bytes())
 if 'parameters' not in d or not (result.parent/'vsim.stdout.bin').exists() or not d.get('accepted'):continue
 raw=(result.parent/'vsim.stdout.bin').read_bytes()+b'\n'+(result.parent/'vsim.stderr.bin').read_bytes();f=json.loads((result.parent/'FREEZE.json').read_bytes());mode=d['mode'];guard=None
 if mode=='guard':guard=d['fatals'][0].split(': ')[-1].split(' ')[0]
 c=m.classify(raw,0,f,d['parameters'],mode,guard);assert c['accepted'],str(result);results.append({'path':str(result),'mode':mode,'accepted':True,'stdout_sha256':sha(raw)})
f=json.loads((E/'vectors-64-4-0-0-32/FREEZE.json').read_bytes());raw=(E/'vector-full-01/vsim.stdout.bin').read_bytes();lines=raw.decode().splitlines();tally=next(x for x in lines if x.endswith('Errors: 0, Warnings: 0'));probes=[]
variants={'positive':raw,'single_early_tally':('\n'.join([tally]+[x for x in lines if x!=tally])+'\n').encode(),'malformed_tally':raw+b'\n# Errors: invalid\n','malformed_fatal':raw+b'\n# ** Fatal malformed\n','later_warning':raw+b'\n# ** Warning: unexpected\n','unknown_marker':raw+b'\n# MAIN_EXTRA\n','duplicate_stats':raw+b'\n# MAIN_STATS cycles=1951014 checks=46824336\n'}
for n,b in variants.items():
 (D/(n+'.log')).write_bytes(b);accepted=m.classify(b,0,f,f['parameters'])['accepted'];assert accepted==(n=='positive');probes.append({'name':n,'accepted':accepted,'sha256':sha(b)})
put(D/'RESULT.json',{'accepted':True,'at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_changes':recs,'saved_runs_reclassified':results,'probes':probes,'scope':'Main log-classifier strengthening only. Frozen numeric oracle/TB/vectors unchanged; saved vendor runs are reclassified, not rerun.'})
print(json.dumps({'accepted':True,'saved_runs':len(results),'probes':len(probes),'changes':recs}))
