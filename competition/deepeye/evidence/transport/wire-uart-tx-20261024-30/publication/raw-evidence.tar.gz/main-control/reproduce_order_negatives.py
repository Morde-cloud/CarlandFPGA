from pathlib import Path
import importlib.util,hashlib,json
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';E=W/'competition/deepeye/evidence/transport/wire-uart-tx-20261024-30';D=E/'main/runner-order-negative-03';D.mkdir(exist_ok=False)
src=W/'competition/deepeye/tools/transport/run_wire_uart_tx.py';sp=importlib.util.spec_from_file_location('original_tx_order_qual',src);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m)
r=json.loads((E/'author/RESULT.json').read_bytes());p=E/'author'/r['final_attempt']['positive_log'];raw=p.read_bytes();assert hashlib.sha256(raw).hexdigest()==r['final_attempt']['positive_log_sha256'];(D/'original-positive.bin').write_bytes(raw)
rows=raw.decode().splitlines();text='\n'.join(rows)+'\n';out=[]
for name,prefix in [('early_end','# TB_END'),('early_summary','# TB_SUMMARY'),('early_tally','# Errors:')]:
 row=next(x for x in rows if x.startswith(prefix));changed='\n'.join([row]+[x for x in rows if x!=row])+'\n';f=D/(name+'.log');f.write_bytes(changed.encode());assert sum(x.startswith(prefix) for x in changed.splitlines())==1
 try:m.parse_positive_log(f);accepted=True
 except Exception:accepted=False
 out.append({'name':name,'accepted':accepted,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()})
(D/'RESULT.json').write_text(json.dumps({'probes':out,'history':'runner-negative-02 moved-marker probes did not remove original CRLF row, so those two were duplicate tests. Here splitlines builds exactly one moved row; original bytes retained.'},indent=2)+'\n');print(json.dumps(out))
