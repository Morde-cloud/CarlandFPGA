from pathlib import Path
import importlib.util,json,hashlib
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/wire-uart-tx-20261024-30';D=E/'main/runner-negative-01';D.mkdir(exist_ok=False)
src=P/'tools/transport/run_wire_uart_tx.py';s=importlib.util.spec_from_file_location('tx_original_qualify',src);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
r=json.loads((E/'author/RESULT.json').read_bytes());v=r['final_attempt']['positive_log'];good=W/(v['path'] if isinstance(v,dict) else v);raw=good.read_bytes();t=raw.decode();rows=t.splitlines();end=next(x for x in rows if x=='# TB_END pass');summary=next(x for x in rows if x.startswith('# TB_SUMMARY'))
probes={'positive':t,'early_end':end+'\n'+t.replace(end+'\n','',1),'early_summary':summary+'\n'+t.replace(summary+'\n','',1),'warning':'# ** Warning: injected contradictory warning\n'+t,'malformed_summary':t+'\n'+summary+' trailing\n','unknown_marker':t+'\n# TB_EXTRA pass\n','malformed_case':t+'\n# CASE_END name=initial_reset status=fail checks=1 trailing\n'}
results=[]
for name,data in probes.items():
 p=D/(name+'.log');p.write_bytes(data.encode());error=None
 try:m.parse_positive_log(p);accepted=True
 except Exception as e:accepted=False;error=repr(e)
 results.append({'name':name,'accepted':accepted,'synthetic':name!='positive','sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'error':error})
assert results[0]['accepted']
(D/'original_runner.py').write_bytes(src.read_bytes());(D/'RESULT.json').write_text(json.dumps({'runner_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'positive_source':str(good),'probes':results},indent=2)+'\n');print(json.dumps(results))
