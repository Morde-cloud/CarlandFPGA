from pathlib import Path
import hashlib,importlib.util,json,subprocess
R=Path('D:/pynq/CarlandFPGA');W=R/'.local/worktrees/deepeye-implementation-20261014';P=W/'competition/deepeye';E=P/'evidence/transport/wire-uart-tx-20261024-30';D=E/'main/guards-mutants-01';D.mkdir(exist_ok=False)
runner=P/'tools/transport/main_verify_wire_uart_tx.py';rtl=P/'fpga/transport/deepeye_wire_uart_tx.sv';raw=rtl.read_text(encoding='utf-8');results=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def put(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8')
def run(label,source,mode,overrides=(),expect=None):
 args=[str(R/'.local/venv/Scripts/python.exe'),'-B','-X','utf8',str(runner),'--rtl',str(source),'--dependencies',str(P/'fpga/transport'),'--tb',str(P/'tests/rtl/transport/main_tb_wire_uart_tx.sv'),'--vectors',str(E/'main/vectors-64-4-0-0-32'),'--out',str(D/label),'--mode',mode]
 for k,v in overrides:args+=['--override',f'{k}={v}']
 if expect:args+=['--guard-expect',expect]
 r=subprocess.run(args,capture_output=True);(D/(label+'.stdout.bin')).write_bytes(r.stdout);(D/(label+'.stderr.bin')).write_bytes(r.stderr);d=json.loads((D/label/'RESULT.json').read_bytes());rec={'label':label,'exit':r.returncode,'accepted':d['accepted'],'counterexamples':d.get('numeric_counterexamples',[]),'stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)};results.append(rec);put(D/'PROGRESS.json',results);print(json.dumps(rec),flush=True);assert r.returncode==0 and d['accepted']
for label,ov,expect in [('clock0',[('clock',0)],'CLOCK_HZ'),('clock1',[('clock',1)],'CLOCK_HZ'),('baud0',[('baud',0)],'BAUD'),('baud_above',[('clock',16),('baud',9)],'BAUD'),('pre_negative',[('pre',-1)],'PRE_CYCLES'),('pre_large',[('pre',65536)],'PRE_CYCLES'),('post_negative',[('post',-1)],'POST_CYCLES'),('post_large',[('post',65536)],'POST_CYCLES'),('stat1',[('stat',1)],'STAT_W'),('stat33',[('stat',33)],'STAT_W'),('priority',[('clock',1),('baud',0),('pre',-1),('post',-1),('stat',1)],'CLOCK_HZ')]:run(label,rtl,'guard',ov,expect)
mutants=[('wrong_count',".cfg_count({1'b0, ser_out_count})",".cfg_count({1'b0, ser_out_count}+7'd1)",1),('early_retire','if (!frame_busy)',"if (1'b1)",1),('rotate_byte','.s_data(ser_out_data)',".s_data({ser_out_data[0],ser_out_data[7:1]})",1)]
for label,a,b,n in mutants:
 assert raw.count(a)==n;p=D/(label+'.sv');p.write_text(raw.replace(a,b),encoding='utf-8',newline='\n');run(label,p,'mutant')
# Exactly the second dependency loses cancel; wrapper and serializer still abort.
assert raw.count('.cancel(cancel),')==2
a,b=raw.rsplit('.cancel(cancel),',1);p=D/'frame_ignores_cancel.sv';p.write_text(a+".cancel(1'b0),"+b,encoding='utf-8',newline='\n');run('frame_ignores_cancel',p,'mutant')
s=importlib.util.spec_from_file_location('main_tx_classifier',runner);m=importlib.util.module_from_spec(s);s.loader.exec_module(m)
f=json.loads((E/'main/vectors-64-4-0-0-32/FREEZE.json').read_bytes());positive=(E/'main/vector-full-01/vsim.stdout.bin').read_bytes();probes=[]
cases={'positive':positive,'duplicate_pass':positive+b'\n# MAIN_PASS\n','substring_pass':positive.replace(b'# MAIN_PASS',b'# NOT_MAIN_PASS'),'early_pass':b'# MAIN_PASS\n'+positive.replace(b'# MAIN_PASS',b''),'wrong_checks':positive.replace(b'checks=46824336',b'checks=46824337'),'wrong_cycles':positive.replace(b'cycles=1951014',b'cycles=1951015'),'extra_tally':b'# Errors: 4, Warnings: 0\n'+positive,'extra_warning':b'# ** Warning: injected\n'+positive,'extra_fatal':positive+b'\n# ** Fatal: injected\n','unknown_marker':positive+b'\n# MAIN_EXTRA\n'}
for name,data in cases.items():
 (D/(name+'.log')).write_bytes(data);accepted=m.classify(data,0,f,f['parameters'])['accepted'];assert accepted==(name=='positive');probes.append({'name':name,'accepted':accepted,'sha256':sha(data)})
put(D/'RESULT.json',{'accepted':True,'rtl_sha256':sha(rtl.read_bytes()),'runner_sha256':sha(runner.read_bytes()),'runs':results,'classifier_probes':probes,'limits':'Digital same-clock tests only; all29/fullproduct/CDC_RDC/timing/board/system not_run'})
